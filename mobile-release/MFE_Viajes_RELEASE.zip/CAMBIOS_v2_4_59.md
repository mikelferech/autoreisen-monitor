# Cambios v2.4.59

- Resaltado de la opción preferida de AutoReisen en ambos destinos y de la habitación preferida en Cordial en Portada, con misma estética verde que Dunas.
- Nuevos grupos persistentes de Presupuesto para Binter y Parking epark. No se duplican gastos al migrar el parking desde Autobús; conceptos ya guardados se respetan.
- Nuevo bloque Binter con reserva total; su precio web en Seguimiento no cuenta como compra.
- Los gastos automáticos de Binter/epark muestran PAGADO/NO PAGADO según el estado real, con edición a través de sus propios editores.
- Cambio de botón «Crear grupo» a «Añadir bloque», conservando la gestión de bloques personalizados.
- BAT: actualiza **solo Hosting**, compatible con Spark; no necesita ni intenta desplegar Functions. No toca Cloudflare Workers, reglas de Firestore ni configuraciones GitHub.

## Revision del instalador (FIX BAT)
- Formato CRLF Windows corregido para los cuatro .bat (antes eran LF de Unix).
- Lanzador muestra mensaje de inicio y sigue pausando en exito o fallo.
- Validacion automatica de CRLF para futuras revisiones.
- Misma app v2.4.59, sin cambios en preferencias, presupuesto o monitores.

### Corrección adicional del instalador Windows

- Solucionada la prueba que generaba rutas duplicadas como `D:\D:\Descargas\...\app.js` en Windows al pasar una URL a `node --check`. Ahora las pruebas convierten las URL de archivo a rutas nativas con `fileURLToPath`.
- Mismo ajuste preventivo en los verificadores de Cordial, AutoReisen y Vueling.
- Los BAT mantienen formato CRLF, ventana abierta ante errores y despliegue exclusivo de Firebase Hosting, sin Functions ni Workers.
