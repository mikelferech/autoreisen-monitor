// MFE_POOLS_AUTOMATION_VERSION: 1.0.8
import fs from 'node:fs/promises';
import path from 'node:path';
import { chromium } from 'playwright';
import { postResult, snapshot, isoNow } from './lib.mjs';

const SOURCE_URL='https://cordial.galileus.es/gweb/siloe/diario/?token=NUEraFBKcnlEYzdUVVRobnRPMHc5Zz09';
const ARTIFACTS=path.resolve('artifacts/pools');
const clean=v=>String(v??'').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim();
const norm=v=>clean(v).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
const metricPattern=/(temperatura|temperature|temp\.?\b|ph\b|cloro|chlorine|bromo|bromine|turbidez|turbidity|recirculaci[oó]n|recirculation|conductividad|conductivity|alcalinidad|alkalinity|redox|orp|salinidad|salinity)/i;
const measurementPattern=/(last measurement|ultima medici[oó]n|última medición|1st measurement|2nd measurement|1ª medici[oó]n|2ª medici[oó]n|primera medici[oó]n|segunda medici[oó]n)/i;
const placeholderPattern=/^(select|selecciona|seleccionar|choose|--+|piscina|pool|nombre|name)$/i;

function safeMetricValue(v){
  const value=clean(v);
  if(!value||/^[-–—]+$/.test(value))return '';
  return value;
}
function looksLikeMetricLabel(v){return metricPattern.test(clean(v));}
function metricClass(label=''){
  const n=norm(label);
  if(/temperatura|temperature|temp\b/.test(n))return 'temperature';
  if(/\bph\b/.test(n))return 'ph';
  if(/cloro|chlorine/.test(n))return 'chlorine';
  if(/bromo|bromine/.test(n))return 'bromine';
  return 'other';
}
function temperatureFromMetrics(metrics=[]){
  for(const m of metrics){
    if(metricClass(m.label)!=='temperature')continue;
    const hit=String(m.value||'').replace(',','.').match(/-?\d+(?:\.\d+)?/);
    const n=hit?Number(hit[0]):NaN;
    if(Number.isFinite(n)&&n>-5&&n<60)return n;
  }
  return null;
}
function metricNumber(value=''){
  const hit=String(value??'').replace(',','.').match(/-?\d+(?:\.\d+)?/);
  return hit?Number(hit[0]):NaN;
}
function repairRecirculationMeasurements(measurements=[]){
  const cloned=(measurements||[]).map(m=>({...m,metrics:(m.metrics||[]).map(metric=>({...metric}))}));
  const latest=cloned.find(m=>/ultima|última|last/i.test(clean(m.measurement)))||cloned[0]||null;
  const latestTurbidity=(latest?.metrics||[]).find(metric=>/turbidez|turbidity/i.test(clean(metric.label)));
  const latestTurbidityValue=metricNumber(latestTurbidity?.value);
  for(const measurement of cloned){
    if(/ultima|última|last/i.test(clean(measurement.measurement)))continue;
    const metrics=measurement.metrics||[];
    if(metrics.some(metric=>/recirculaci[oó]n|recirculation/i.test(clean(metric.label))))continue;
    // Galileus/SILOE ordena visualmente el índice de recirculación junto a la
    // primera medición. En la vista móvil el DOM puede dejar el valor (p.ej. 4)
    // bajo la etiqueta anterior "Turbidez (UNF)". Lo reparamos solo cuando el
    // bloque no contiene otros parámetros, el valor es una hora entera plausible
    // y la última turbidez real es un valor bajo/decimal.
    if(metrics.length!==1)continue;
    const metric=metrics[0];
    if(!/turbidez|turbidity/i.test(clean(metric.label)))continue;
    const value=metricNumber(metric.value);
    if(!Number.isFinite(value)||!Number.isInteger(value)||value<1||value>24)continue;
    if(!Number.isFinite(latestTurbidityValue)||latestTurbidityValue>=1)continue;
    metric.label='Índice de recirculación (h)';
  }
  return cloned;
}
function makeMeasurementsFromMatrix(rows=[]){
  const cleanRows=rows.map(r=>r.map(clean).filter((v,i,a)=>i===0||v!==''||a.length>1)).filter(r=>r.some(Boolean));
  const metricRows=cleanRows.filter(r=>looksLikeMetricLabel(r[0]||''));
  if(!metricRows.length)return [];
  let headers=[];
  for(const row of cleanRows){
    if(row.some(cell=>measurementPattern.test(cell))){headers=row;break;}
  }
  const maxCols=Math.max(...metricRows.map(r=>Math.max(0,r.length-1)),1);
  const out=[];
  for(let col=0;col<maxCols;col++){
    const metrics=[];
    for(const row of metricRows){
      const value=safeMetricValue(row[col+1]);
      if(value)metrics.push({label:clean(row[0]),value});
    }
    if(!metrics.length)continue;
    const label=clean(headers[col+1])||['Última medición','1.ª medición','2.ª medición'][col]||`Medición ${col+1}`;
    out.push({measurement:label,date:'',time:'',metrics,temperature:temperatureFromMetrics(metrics)});
  }
  return out;
}
function makeMeasurementsFromLines(lines=[]){
  const rows=lines.map(clean).filter(Boolean);
  const metricIndices=[];
  for(let i=0;i<rows.length;i++)if(looksLikeMetricLabel(rows[i]))metricIndices.push(i);
  if(!metricIndices.length)return [];
  const found=[];
  let maxValues=0;
  for(const idx of metricIndices){
    const label=rows[idx];const values=[];
    for(let j=idx+1;j<Math.min(rows.length,idx+8);j++){
      if(looksLikeMetricLabel(rows[j]))break;
      if(measurementPattern.test(rows[j]))continue;
      const value=safeMetricValue(rows[j]);
      if(!value)continue;
      if(/^(pool measurements|mediciones|go back|volver)$/i.test(value))continue;
      if(/^-?\d+(?:[.,]\d+)?(?:\s*°?c|\s*ppm|\s*mg\/l|\s*(?:ntu|unf|fnu|unt)|\s*µs\/cm)?$/i.test(value)||/\b\d{1,2}:\d{2}\b/.test(value)||/\b\d{1,2}[\/-]\d{1,2}[\/-]\d{2,4}\b/.test(value))values.push(value);
      if(values.length>=3)break;
    }
    if(values.length){found.push({label,values});maxValues=Math.max(maxValues,values.length);}
  }
  const measurements=[];
  for(let col=0;col<maxValues;col++){
    const metrics=[];
    for(const row of found){const value=safeMetricValue(row.values[col]);if(value)metrics.push({label:row.label,value});}
    if(metrics.length)measurements.push({measurement:['Última medición','1.ª medición','2.ª medición'][col]||`Medición ${col+1}`,date:'',time:'',metrics,temperature:temperatureFromMetrics(metrics)});
  }
  return measurements;
}
async function extractPool(page,poolName='Piscina'){
  const tables=await page.locator('table').evaluateAll(nodes=>nodes.map(table=>[...table.querySelectorAll('tr')].map(tr=>[...tr.querySelectorAll('th,td')].map(td=>String(td.innerText||td.textContent||'').trim())).filter(row=>row.length))).catch(()=>[]);
  for(const rows of tables){const measurements=makeMeasurementsFromMatrix(rows);if(measurements.length)return {name:clean(poolName)||'Piscina',measurements};}
  const text=await page.locator('body').innerText().catch(()=> '');
  const measurements=makeMeasurementsFromLines(String(text).split(/\r?\n/));
  return measurements.length?{name:clean(poolName)||'Piscina',measurements}:null;
}
async function selectDescriptors(page){
  return page.locator('select').evaluateAll(nodes=>nodes.map((s,index)=>{
    const label=(s.labels&&s.labels[0]?.innerText)||s.getAttribute('aria-label')||s.getAttribute('name')||s.id||'';
    const parent=String(s.parentElement?.innerText||'').slice(0,350);
    return {index,name:s.getAttribute('name')||'',id:s.id||'',label:String(label).trim(),parent,options:[...s.options].map(o=>({value:String(o.value||''),text:String(o.textContent||'').trim(),disabled:Boolean(o.disabled)}))};
  })).catch(()=>[]);
}
function choosePoolSelect(selects=[]){
  const scored=selects.map(s=>{
    const options=(s.options||[]).filter(o=>!o.disabled&&clean(o.text)&&!placeholderPattern.test(clean(o.text)));
    const context=norm(`${s.name} ${s.id} ${s.label} ${s.parent}`);
    let score=options.length*5;if(/pisc|pool|vaso/.test(context))score+=100;if(/select|selecc/.test(context))score+=10;
    return {...s,options,score};
  }).filter(s=>s.options.length);
  scored.sort((a,b)=>b.score-a.score);return scored[0]||null;
}
async function customOptions(page){
  const selectTrigger=page.getByText(/^Select$/i).first();
  if(await selectTrigger.isVisible().catch(()=>false)){await selectTrigger.click({force:true}).catch(()=>{});await page.waitForTimeout(400);}
  const selectors=['[role="option"]','.dropdown-menu a','.dropdown-menu button','.dropdown-menu li','.select2-results__option','.choices__item--choice','.bootstrap-select .dropdown-menu li a'];
  const seen=new Map();
  for(const selector of selectors){
    const loc=page.locator(selector);const count=Math.min(await loc.count().catch(()=>0),50);
    for(let i=0;i<count;i++){
      const el=loc.nth(i);if(!await el.isVisible().catch(()=>false))continue;
      const text=clean(await el.innerText().catch(()=>''));if(!text||placeholderPattern.test(text)||measurementPattern.test(text)||text.length>100)continue;
      if(!seen.has(text))seen.set(text,{text,selector,index:i});
    }
  }
  return [...seen.values()];
}
async function collectNetworkResponses(page){
  const items=[];
  page.on('response',async response=>{
    try{
      const req=response.request();if(!['xhr','fetch'].includes(req.resourceType()))return;
      const url=response.url();if(!/galileus|siloe|diario|pisc|pool|medic|measure/i.test(url))return;
      const ct=response.headers()['content-type']||'';if(!/json|text|html|javascript/i.test(ct))return;
      const text=await response.text();if(text.length>160000)return;
      items.push({url,status:response.status(),contentType:ct,body:text.slice(0,160000)});
    }catch{}
  });
  return items;
}
// API Galileus 2026: ubicación + registros, no una fila plana con «temperatura».
function poolsFromGalileusDaily(payload){
  const out=[];
  const walk=value=>{
    if(Array.isArray(value)){value.forEach(walk);return;}
    if(!value||typeof value!=='object')return;
    const name=clean(value.location_name||value.location?.name||value.pool_name||value.poolName||'');
    const records=Array.isArray(value.records)?value.records:[];
    if(name&&records.length){
      const groups=new Map();
      for(const record of records){
        const desc=clean(record.DESCRIPCION||record.descripcion||record.description||'');
        const val=record.REGISTRO??record.registro??record.value;
        if(val===undefined||val===null||val==='')continue;
        const time=desc.match(/(?:a\s+las\s+)(\d{1,2}:\d{2})/i)?.[1]||'—';
        const date=String(record.FECHA||record.fecha||'').slice(0,10);
        const label=clean(desc.replace(/^medir\s+/i,'').replace(/\s+a\s+las\s+\d{1,2}:\d{2}.*$/i,'').replace(/\s*-\s*SILO[ÉE]\s*$/i,''));
        const key=date+'|'+time;
        if(!groups.has(key))groups.set(key,{measurement:time==='—'?'Medición':'Medición '+time,date,time:time==='—'?'':time,metrics:[],temperature:null});
        groups.get(key).metrics.push({label:label||clean(record.REFERENCIA||'Parámetro'),value:String(val)});
      }
      const measurements=[...groups.values()].filter(group=>group.metrics.length).sort((a,b)=>(b.date+' '+b.time).localeCompare(a.date+' '+a.time));
      for(const m of measurements){
        const water=m.metrics.find(x=>/temperatura\s+(?:del?\s+)?agua|temperatura\s+vaso|water\s+temp/i.test(x.label));
        const candidates=[water,...m.metrics.filter(x=>/temperatura/i.test(x.label))].filter(Boolean);
        for(const c of candidates){const n=metricNumber(c.value);if(Number.isFinite(n)&&n>-5&&n<60){m.temperature=n;break;}}
      }
      out.push({name,locationId:value.location_id??null,measurements});
      return;
    }
    for(const child of Object.values(value))if(child&&typeof child==='object')walk(child);
  };
  walk(payload);
  return out;
}
function poolsFromNetwork(items=[]){
  const out=[];
  const walk=(value,path='')=>{
    if(Array.isArray(value)){for(const [i,v] of value.entries())walk(v,`${path}[${i}]`);return;}
    if(!value||typeof value!=='object')return;
    const entries=Object.entries(value);const flat=Object.fromEntries(entries.map(([k,v])=>[norm(k),v]));
    const name=clean(flat.piscina||flat.pool||flat.nombre||flat.name||flat.vaso||flat.descripcion||'');
    const metrics=[];
    for(const [k,v] of entries){if(looksLikeMetricLabel(k)&&['string','number'].includes(typeof v))metrics.push({label:clean(k),value:clean(v)});}
    if(name&&!placeholderPattern.test(name)&&/(piscina|pool|perchel|infinity|infantil|spa)/i.test(name)&&metrics.length)out.push({name,measurements:[{measurement:'Última medición',date:'',time:'',metrics,temperature:temperatureFromMetrics(metrics)}]});
    for(const [k,v] of entries)if(v&&typeof v==='object')walk(v,`${path}.${k}`);
  };
  for(const item of items){
    try{const payload=JSON.parse(item.body);const parsed=poolsFromGalileusDaily(payload);if(parsed.length)out.push(...parsed);else walk(payload);}catch{}
  }
  return out;
}
function mergePools(list=[]){
  const map=new Map();
  for(const pool of list){
    const name=clean(pool?.name);if(!name||placeholderPattern.test(name)||!/(piscina|pool|perchel|infinity|infantil|spa)/i.test(name))continue;const key=norm(name);if(!map.has(key))map.set(key,{name,measurements:[]});
    const target=map.get(key);
    for(const m of pool.measurements||[]){
      const sig=JSON.stringify([m.date||'',m.time||'',m.measurement||'',(m.metrics||[]).map(x=>[norm(x.label),clean(x.value)])]);if(!target.measurements.some(x=>JSON.stringify([x.date||'',x.time||'',x.measurement||'',(x.metrics||[]).map(y=>[norm(y.label),clean(y.value)])])===sig))target.measurements.push(m);
    }
  }
  return [...map.values()].map(p=>{const measurements=repairRecirculationMeasurements(p.measurements);const latest=measurements.find(m=>/ultima|última|last/i.test(clean(m.measurement)))||measurements[0]||{};const temperature=latest.temperature??temperatureFromMetrics(latest.metrics||[]);return {...p,measurements,latest,temperature};});
}

// La vista pública puede mostrar varias piscinas simultáneamente sin el select antiguo.
// Leemos cada panel por separado; un HTML con varias tablas nunca debe interpretarse
// como una única piscina ni convertir datos no publicados en temperaturas inventadas.
async function extractPublicPoolCards(page){
  const nodes=await page.evaluate(()=>{
    const metric=/(temperatura|temperature|\bph\b|cloro|chlorine|bromo|turbidez|turbidity|recirculaci[oó]n|conductividad)/i;
    const poolName=/(piscina|pool|vaso|santa.{0,8}a.{0,8}gueda|perchel)/i;
    const containers=[...document.querySelectorAll('[data-pool],[data-piscina],[class*="pool-card"],[class*="piscina-card"],article,section,.card')];
    return containers.flatMap(node=>{
      const text=String(node.innerText||'').trim();
      if(!text||text.length>5500||!metric.test(text))return [];
      const title=String(node.querySelector('h2,h3,h4,h5,[class*="pool-title"],[class*="piscina-title"],header strong')?.innerText||node.getAttribute('data-pool')||node.getAttribute('data-piscina')||'').trim();
      if(!poolName.test(title))return [];
      const tables=[...node.querySelectorAll('table')].map(t=>[...t.querySelectorAll('tr')].map(tr=>[...tr.querySelectorAll('th,td')].map(td=>String(td.innerText||'').trim())));
      return [{name:title,rows:tables,lines:text.split(/\r?\n/).map(x=>x.trim())}];
    });
  }).catch(()=>[]);
  const map=new Map();
  for(const row of nodes){
    const name=clean(row.name),key=norm(name);if(!name||map.has(key))continue;
    let measurements=[];
    for(const matrix of row.rows||[]){measurements=makeMeasurementsFromMatrix(matrix);if(measurements.length)break;}
    if(!measurements.length)measurements=makeMeasurementsFromLines(row.lines||[]);
    map.set(key,{name,measurements});
  }
  return [...map.values()];
}

async function readPublicPools(page){
  const publicUrl='https://cordial.galileus.es/pools/public?token=NUEraFBKcnlEYzdUVVRobnRPMHc5Zz09';
  const extraPage=await page.context().newPage();
  const diagnostics={source:publicUrl,pools:0,options:0,network:0,warning:''};
  try{
    const network=await collectNetworkResponses(extraPage);
    const api='https://cordial.galileus.es/api/pool-status/public/daily?token='+new URL(publicUrl).searchParams.get('token');
    let direct=[],apiPayload=null;
    try{
      const responseApi=await extraPage.request.get(api,{timeout:16000});
      if(responseApi.ok()){
        apiPayload=await responseApi.json();
        direct=poolsFromGalileusDaily(apiPayload);
      }
    }catch(e){diagnostics.apiError=String(e?.message||e).slice(0,160);}
    const response=await extraPage.goto(publicUrl,{waitUntil:'domcontentloaded',timeout:45000});
    if(!response?.ok())throw new Error('La vista pública devolvió HTTP '+response?.status());
    await extraPage.waitForTimeout(2200);
    const text=await extraPage.locator('body').innerText().catch(()=>'');
    const pools=[...direct];
    diagnostics.apiLocations=direct.map(x=>x.name);
    const discoveredNames=new Map();
    const discover=name=>{const n=clean(name);if(n&&!placeholderPattern.test(n)&&/(piscina|pool|perchel|agueda|águeda|vaso)/i.test(n)&&n.length<130)discoveredNames.set(norm(n),n);};
    // El API puede enumerar instalaciones sin medición de hoy. Conservar sus nombres,
    // mostrando "sin datos" y sin asignar temperaturas de otra piscina.
    const discoverLocations=value=>{
      if(Array.isArray(value)){value.forEach(discoverLocations);return;}
      if(!value||typeof value!=='object')return;
      const name=String(value.location_name||value.pool_name||value.poolName||value.location?.name||'').trim();
      if(name)discover(name);
      for(const [key,child] of Object.entries(value))if(child&&typeof child==='object'&&key!=='records')discoverLocations(child);
    };
    if(apiPayload)discoverLocations(apiPayload);
    const triggerName=clean(await extraPage.locator('[data-slot="popover-trigger"]').first().innerText().catch(()=>''));
    if(triggerName)discover(triggerName);
    // La fuente pública puede publicar distintas piscinas como tarjetas sin selector.
    pools.push(...await extractPublicPoolCards(extraPage));
    pools.forEach(x=>discover(x.name));
    // Primera fuente: datos estructurados publicados en la propia página.
    try{
      const json=JSON.parse(String(await response.text()));
      pools.push(...poolsFromNetwork([{body:JSON.stringify(json)}]));
    }catch{}
    // Selector moderno Base UI: muestra piscinas en un popover en vez del <select> clásico.
    const trigger=extraPage.locator('[data-slot="popover-trigger"]').first();
    if(await trigger.count()&&await trigger.isVisible().catch(()=>false)){
      await trigger.click().catch(()=>{});
      await extraPage.waitForTimeout(250);
      const optionLabels=await extraPage.locator('[role="option"], [role="menuitem"], [data-slot="popover-content"] button').allInnerTexts().catch(()=>[]);
      const options=[...new Set(optionLabels.map(clean))].filter(label=>/(piscina|pool|perchel|vaso)/i.test(label)&&label.length<130);
      diagnostics.popoverOptions=options;
      options.forEach(discover);
      for(const name of options.slice(0,40)){
        try{
          await extraPage.goto(publicUrl,{waitUntil:'domcontentloaded',timeout:45000});await extraPage.waitForTimeout(350);
          const select=extraPage.locator('[data-slot="popover-trigger"]').first();await select.click();
          const item=extraPage.getByRole('option',{name,exact:true});
          const candidate=await item.count()?item.first():extraPage.getByText(name,{exact:true}).last();
          if(!await candidate.isVisible().catch(()=>false))continue;
          await candidate.click({force:true});await extraPage.waitForTimeout(900);
          await extraPage.waitForLoadState('networkidle',{timeout:4000}).catch(()=>{});
          const selected=await extractPool(extraPage,name);if(selected)pools.push(selected);
        }catch(e){diagnostics.popoverError=String(e?.message||e).slice(0,160);}
      }
    }
    const chosen=choosePoolSelect(await selectDescriptors(extraPage));
    if(chosen){
      diagnostics.options=chosen.options.length;
      chosen.options.forEach(opt=>discover(opt.text));
      for(const opt of chosen.options.slice(0,45)){
        const select=choosePoolSelect(await selectDescriptors(extraPage));if(!select)break;
        try{
          await extraPage.locator('select').nth(select.index).selectOption(opt.value?{value:opt.value}:{label:opt.text});
          await extraPage.waitForTimeout(500);
          const entry=await extractPool(extraPage,opt.text);
          if(entry)pools.push(entry);
        }catch{}
      }
    }else{
      const options=await customOptions(extraPage);
      diagnostics.options=options.length;
      options.forEach(opt=>discover(opt.text));
      for(const opt of options.slice(0,35)){
        try{
          await extraPage.goto(publicUrl,{waitUntil:'domcontentloaded',timeout:45000});
          await extraPage.waitForTimeout(400);
          const trigger=extraPage.getByText(/^Select$/i).first();
          if(await trigger.isVisible().catch(()=>false))await trigger.click({force:true});
          const option=extraPage.getByText(opt.text,{exact:true}).last();
          if(!await option.isVisible().catch(()=>false))continue;
          await option.click({force:true});await extraPage.waitForTimeout(550);
          const entry=await extractPool(extraPage,opt.text);
          if(entry)pools.push(entry);
        }catch{}
      }
      if(!pools.length){
        const locationName=clean(await extraPage.locator('[data-slot="popover-trigger"]').first().innerText().catch(()=>''));
        const single=await extractPool(extraPage,locationName||'Piscina');
        if(single)pools.push(single);
      }
    }
    pools.push(...poolsFromNetwork(network));
    diagnostics.network=network.length;
    let result=mergePools(pools);
    // Si la fuente enumera una segunda piscina sin lecturas publicadas, la mostramos
    // con estado «Sin mediciones», no la ocultamos ni copiamos valores de otra.
    for(const [key,name] of discoveredNames){
      if(!result.some(pool=>norm(pool.name)===key))result.push({name,measurements:[],latest:{},temperature:null,available:false});
    }
    diagnostics.pools=result.length;
    diagnostics.namedPools=[...discoveredNames.values()];
    if(!result.length)diagnostics.warning='La vista pública está accesible pero no expuso piscinas interpretables.';
    return {pools:result,diagnostics};
  }catch(error){
    diagnostics.warning=String(error?.message||error).slice(0,200);
    return {pools:[],diagnostics};
  }finally{await extraPage.close().catch(()=>{});}
}

async function scrapePools(page){
  const network=await collectNetworkResponses(page);
  await page.goto(SOURCE_URL,{waitUntil:'domcontentloaded',timeout:45000});
  await page.waitForTimeout(2500);
  await page.waitForLoadState('networkidle',{timeout:8000}).catch(()=>{});
  await snapshot(page,'pools/01-inicial').catch(()=>{});
  const diagnostics={selects:0,options:0,customOptions:0,networkResponses:0,attempted:0,mode:'',url:page.url()};
  let pools=[];
  let selects=await selectDescriptors(page);diagnostics.selects=selects.length;
  const chosen=choosePoolSelect(selects);
  if(chosen){
    diagnostics.mode='select';diagnostics.options=chosen.options.length;
    for(const option of chosen.options.slice(0,30)){
      diagnostics.attempted++;
      try{
        const current=choosePoolSelect(await selectDescriptors(page));if(!current)break;
        const loc=page.locator('select').nth(current.index);
        await loc.selectOption(option.value?{value:option.value}:{label:option.text});
        await page.waitForTimeout(900);await page.waitForLoadState('networkidle',{timeout:5000}).catch(()=>{});
        const pool=await extractPool(page,option.text);if(pool)pools.push(pool);
      }catch(error){diagnostics[`option${diagnostics.attempted}Error`]=String(error?.message||error).slice(0,180);}
    }
  }else{
    const options=await customOptions(page);diagnostics.customOptions=options.length;diagnostics.mode=options.length?'custom':'single';
    if(options.length){
      for(const option of options.slice(0,24)){
        diagnostics.attempted++;
        try{
          await page.goto(SOURCE_URL,{waitUntil:'domcontentloaded',timeout:45000});await page.waitForTimeout(1200);
          const trigger=page.getByText(/^Select$/i).first();if(await trigger.isVisible().catch(()=>false)){await trigger.click({force:true});await page.waitForTimeout(250);}
          const candidate=page.getByText(option.text,{exact:true}).last();if(!await candidate.isVisible().catch(()=>false))continue;
          await candidate.click({force:true});await page.waitForTimeout(900);await page.waitForLoadState('networkidle',{timeout:5000}).catch(()=>{});
          const pool=await extractPool(page,option.text);if(pool)pools.push(pool);
        }catch(error){diagnostics[`custom${diagnostics.attempted}Error`]=String(error?.message||error).slice(0,180);}
      }
    }else{
      const displayName=clean(await page.locator('[data-slot="popover-trigger"]').first().innerText().catch(()=>''));
      const pool=await extractPool(page,displayName||'Piscina');if(pool)pools.push(pool);
    }
  }
  await page.waitForTimeout(250);diagnostics.networkResponses=network.length;
  pools.push(...poolsFromNetwork(network));
  pools=mergePools(pools);
  const supplemental=await readPublicPools(page);
  diagnostics.publicSource=supplemental.diagnostics;
  if(supplemental.pools.length){
    const withReadings=mergePools([...pools,...supplemental.pools]);
    const withoutReadings=supplemental.pools.filter(p=>!(p.measurements||[]).length&&!withReadings.some(x=>norm(x.name)===norm(p.name)));
    pools=[...withReadings,...withoutReadings];
  }
  diagnostics.detectedPools=pools.length;
  await fs.mkdir(ARTIFACTS,{recursive:true});
  await fs.writeFile(path.join(ARTIFACTS,'diagnostic.json'),JSON.stringify({diagnostics,network:network.map(x=>({url:x.url,status:x.status,contentType:x.contentType,preview:x.body.slice(0,1000)}))},null,2),'utf8').catch(()=>{});
  await snapshot(page,'pools/99-final').catch(()=>{});
  return {source:'Galileus · SILOE · navegador real',sourceUrl:SOURCE_URL,fetchedAt:isoNow(),pools,diagnostics,warning:pools.length?'':`Galileus abrió correctamente, pero no se pudieron interpretar piscinas. Modo ${diagnostics.mode} · selectores ${diagnostics.selects} · opciones ${diagnostics.options||diagnostics.customOptions} · intentos ${diagnostics.attempted} · respuestas de red ${diagnostics.networkResponses}.`};
}

let browser;
try{
  try{browser=await chromium.launch({headless:true,channel:'chrome'});}catch{browser=await chromium.launch({headless:true});}
  const context=await browser.newContext({locale:'es-ES',timezoneId:'Atlantic/Canary',viewport:{width:430,height:932},isMobile:true,hasTouch:true,userAgent:'Mozilla/5.0 (Linux; Android 16; GC26 Pool Monitor) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140 Mobile Safari/537.36'});
  const page=await context.newPage();
  try{
    const result=await scrapePools(page);
    result.ok=true;result.status='ok';result.checkedAt=result.fetchedAt;
    await postResult('pools',result);
    console.log('[pools] OK',JSON.stringify({count:result.pools.length,diagnostics:result.diagnostics}));
  }catch(error){
    const result={ok:false,status:'error',source:'Galileus · SILOE · navegador real',sourceUrl:SOURCE_URL,checkedAt:isoNow(),fetchedAt:isoNow(),pools:[],error:String(error?.message||error),diagnostics:{fatal:true}};
    await snapshot(page,'pools/99-error').catch(()=>{});await postResult('pools',result).catch(()=>{});console.error('[pools] ERROR',error);process.exitCode=1;
  }finally{await context.close().catch(()=>{});}
}finally{await browser?.close().catch(()=>{});}
