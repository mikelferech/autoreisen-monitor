v2.4.46: Dunas 5 adultos/1 suite, precios por tarifa; piscinas múltiples con 2 lecturas; fechas Cordial 6–13 sept 2027; misma paleta AutoReisen; Worker GitHub con monitor nuevo.
