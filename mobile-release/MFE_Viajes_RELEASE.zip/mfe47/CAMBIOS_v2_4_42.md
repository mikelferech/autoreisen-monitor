# GC27 v2.4.42 · Dos islas y distribución

Basado en v2.4.41. Mantiene los datos de Firebase, las dos etapas y los monitores independientes.

- Portada: activar arrastre nativo únicamente en edición de distribución, incluir parking epark en ordenación y preservar la posición de las galerías; presentar detalles de reserva de Dunas y AutoReisen FUE.
- Alojamiento: selector de piscina para los vasos devueltos por Galileus y presentación de una ficha cada vez. Las mediciones proceden del monitor, nunca son ficticias.
- Dunas Club: campos de URL, texto, color y logo de Google, Tripadvisor y Booking, con valores por defecto idénticos a Cordial.
- AutoReisen Fuerteventura: paleta inicial sincronizada con GC; selector de vehículo dentro de la flota verificada, guardando grupo, modelo, ID, fotografía y precio del vehículo seleccionado.
- Seguimiento: no asignar tarifas de vehículos no elegidos. Espera más resistente del monitor Dunas ante carga lenta del motor Keytel e indicaciones de error adicionales.
- Configuración → Datos del viaje: incorporar hotel Dunas a «Vuelos, autobuses y alojamiento» y un segundo AutoReisen a «Alquiler de coche y movilidad».
- Adaptación más amplia de todas las pestañas en pantallas de escritorio, conservando ajustes móviles.

## Límites de verificación
La validación estática del proyecto y las pruebas locales de multietapa pasan. No se ha podido ejecutar una consulta real autenticada de Keytel, AutoReisen o Galileus desde este entorno, ni comprobar la disponibilidad de fotos que el proveedor no haya devuelto. El ZIP incluye la versión nueva del monitor Dunas dentro del Worker para su actualización.

## Instalación
Utiliza los scripts de actualización incluidos en el ZIP siguiendo las instrucciones del README. Actualiza los Workers para activar el monitor Dunas v1.2.0; la web v2.4.42 por sí sola no actualiza el monitor remoto.
