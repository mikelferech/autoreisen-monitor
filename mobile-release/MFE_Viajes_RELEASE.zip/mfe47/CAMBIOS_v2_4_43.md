# MFE Viajes GC27 · v2.4.43

## Correcciones que sí incorpora este paquete

- Se elimina de Portada la banda adicional «AutoReisen · Fuerteventura» creada en v2.4.42. En su lugar se amplía la **tarjeta de seguimiento que ya existía**, con modelo, oficinas, fechas, fotografía si la devuelve la fuente o está seleccionada, y un resumen de flota cuando exista.
- AutoReisen Fuerteventura: paleta y cabecera verdes como AutoReisen Gran Canaria, en lugar del fondo azul anterior.
- El configurador de la etapa 2 incluye un selector de coches con los modelos y precios que hayan sido efectivamente devueltos para las fechas de Fuerteventura. El listado del seguimiento muestra tarjetas con fotos cuando AutoReisen las envía. No mezcla las tarifas de Gran Canaria con Fuerteventura.
- Dunas: se usan los mismos iconos efectivos de Google, Tripadvisor y Booking que Cordial; las URL, etiquetas y colores específicos de Dunas siguen editables.
- Los datos antiguos con el nombre «Dunas blub» pasan a «Dunas Club».
- Alojamiento: selector de piscina siempre visible cuando Galileus devuelve una o más; etiqueta que indica la cantidad recibida, para no dar la falsa impresión de que se han recuperado piscinas no consultadas.
- Seguimiento Dunas: espacio para comparar todas las tarifas completas verificadas cuando el monitor las entregue; no se presentan cifras por habitación como precio del viaje completo.
- Espera de respuesta del monitor de GitHub ampliada para evitar que el cliente cancele prematuramente la lectura.

## Límites verificables

No se han podido ejecutar consultas reales contra los motores de reservas de AutoReisen y Keytel, ni extraer nuevas piscinas de Galileus desde la app publicada. En consecuencia, **este paquete no garantiza todavía** que haya lista completa de coches de Fuerteventura, varias piscinas, todas las tarifas de Dunas ni fotografía exacta del Dacia de GC. Si el servicio solo publica un precio, no se inventa una flota. Para completar estos puntos hay que comprobar los datos de ejecución real y la respuesta del monitor.

## Publicación

Usa `ACTUALIZAR_MFE.bat` en Windows desde la carpeta del ZIP. Publica los Workers y el Hosting tras superar las validaciones; exige las credenciales y los permisos de la cuenta de destino.
