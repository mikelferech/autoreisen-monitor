# MFE Viajes GC27 v2.4.40 · Estado comprobable de las correcciones

**Fecha:** 5 de noviembre de 2026. Esta revisión corrige un fallo de interfaz crítico de la v2.4.39 y añade controles de error. La comprobación local no sustituye las pruebas con tus sesiones, Firebase y servicios externos.

## Causa raíz del bloqueo de edición

Se habían escrito **seis** instrucciones con `$(selector).forEach(...)` en lugar de `$$(selector).forEach(...)`. `$` devuelve un único elemento DOM o `null`; no se puede iterar. Una de estas instrucciones lanzaba una excepción en el enlace de eventos de Portada, Alojamiento y Etapas, impidiendo registrar botones. Se han corregido las seis y las pruebas de regresión comprueban el error de forma expresa. Además se protegen las funciones auxiliares de inicialización para aislar errores.

## Comprobación por apartado

| Apartado y problema | Intervención realizada | Qué se ha probado / qué falta |
|---|---|---|
| Portada: lápices y editores | Se ha corregido el enlace de eventos que impedía ejecutar los formularios. | Apertura real en Chromium de editores de alojamiento, parking y segunda isla. **Probado localmente**. |
| Portada: parking sin edición de icono/colores | Se han añadido icono, URL/archivo PNG, color de acento, degradados y color del texto. | Guardar proveedor y degradado en navegador de prueba: **probado localmente**. |
| Portada: Dunas «Web oficial» | El botón compacto indica «Web». | **Verificado en código y pruebas.** |
| Portada: AutoReisen Fuerteventura al actualizar | Se conserva el despacho GitHub y se comprueba periódicamente su resultado, mostrando estado y error si no devuelve un precio. | **Flujo programado; no se confirma una tarifa nueva sin ejecutar GitHub real.** |
| Portada: Dunas sin precio | Se evita que la excepción del DOM bloquee los controles y se obtiene/actualiza un resultado solo si GitHub devuelve una búsqueda válida. | **No se confirma disponibilidad ni precio real de Dunas.** Su motor de reservas puede no ofrecer la combinación buscada. |
| Portada: tiempo no carga | La inicialización de los botones ya no se interrumpe por `.forEach`. | Se simuló respuesta meteorológica para Corralejo y se reflejó en pantalla. **No se ha confirmado acceso en producción al proveedor meteorológico.** |
| Presupuesto: aprovechar ancho | Se mantienen estilos de ancho de la revisión anterior. | **Se requiere verificar la vista publicada con tus datos y configuración de distribución.** |
| Alojamiento: piscinas sin datos | Se restaura el enlace de eventos; permanece el lector adaptado de la versión anterior. | **No hay garantía de datos:** el último diagnóstico disponible devolvió una sola piscina desde Galileus. No se añaden piscinas o temperaturas ficticias. |
| Alojamiento: archivos Drive | Se evita la excepción que interrumpía el registro de controles de Alojamiento. | **No verificado con tu OAuth de Google Drive**; puede requerir comprobar autorización y permisos. |
| Seguimientos: lápices, colores | Se inicializan los botones; se han probado los modales de AutoReisen y Cordial y las opciones de imagen/color de la segunda isla. | **Probado localmente**; comprobar persistencia con Firebase tras instalar. |
| Seguimientos: AutoReisen Fuerteventura | El monitor ahora realiza seguimiento del resultado y la ficha puede usar el precio verificado del modelo seleccionado si está presente en los datos de flota. | GitHub había registrado un Dacia Automático por **210,97 €** el 5/11; aún debe verse reflejado en tu perfil tras actualizar. |
| Seguimientos: Cordial precio oficial distinto | No se inventa ni sustituye el precio monitorizado por el importe escrito a mano. | **Pendiente de una nueva consulta oficial verificable**; el precio antiguo puede seguir visible hasta entonces. |
| Seguimientos: Dunas y Binter vacíos | Flujo de consulta y tratamiento de errores sin bloquear la pantalla. | **Precio real pendiente**; el monitor puede fallar o la web puede pedir interacción adicional. |
| Seguimientos: mapa gasolineras desaparecido | Se reanuda la inicialización al no interrumpirse la ejecución; permanece un iframe de respaldo. | Contenedor + mapa de respaldo **comprobados en Chromium local**. |
| Etapas: fotografía AutoReisen GC | Continúa la protección para no atribuir foto de Seat Arona al Dacia. | **No se garantiza foto real:** si AutoReisen no publica una imagen verificable, se mostrará sin foto o con una imagen manual que guardes. |

## Despliegue y seguridad de la actualización

- El BAT valida la versión, la interfaz, el enlace de los botones, el worker, el ZIP y después publica Cloudflare y Firebase.
- Las pruebas están basadas en datos simulados; **no se ha utilizado tu token de Drive ni se han realizado compras o reservas**.
- Recomendado descomprimir el ZIP nuevo en una carpeta nueva y ejecutar `ACTUALIZAR_MFE.bat` desde ella.
- Si se produce un fallo de publicación, conserva el texto íntegro del error. No declares resuelto un monitor externo solo por superar una prueba de sintaxis.
