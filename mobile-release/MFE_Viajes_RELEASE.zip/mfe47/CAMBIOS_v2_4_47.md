# MFE Viajes GC27 · v2.4.47

## Cordial
- Las consultas con distinta fecha, adultos o habitación no reemplazan el último resultado.
- Se muestra como actual solo un precio asociado a la combinación de búsqueda guardada.
- Si la habitación elegida no está disponible, no se sustituye silenciosamente por otra.
- Se elimina el importe fijo antiguo de la descripción de Seguimiento.
- Se mantienen las fechas propias de seguimiento del 6 al 13 de septiembre de 2027.

## Dunas Club
- Los cinco precios de muestra del 5/11/2026 se reconocen, agrupados por solo alojamiento, desayuno, media pensión y pensión completa.
- El monitor obtiene cada tarifa visible para 5 adultos y una habitación sin reservar.
- Portada y Seguimiento muestran tarifas en formato de tarjetas; se retienen solo importes publicados por el monitor.

## Piscinas
- Elimina opciones falsas denominadas «Nombre», «Piscina» y variantes repetidas del histórico.
- Conserva lecturas del mismo día y distinta hora para las gráficas.

## Alojamiento
- Ajuste de parrilla y botones entre Cordial y Dunas (Web, Cómo llegar, opiniones, check-in, fotos, reserva).
- Controles para subir o bajar los bloques principales; guardado en configuración.

## Instalación
- Descomprimir ZIP y ejecutar ACTUALIZAR_MFE.bat desde Windows.
- Worker Cloudflare con monitores incrustados sincronizados.
- Validación de código y pruebas locales OK; falta verificación real del sitio de reservas y mediciones de piscinas.

## Revisión de precio Cordial (capturas 20:46)
- La captura web con 2.787,36 € es «Oferta Prepago Online», cancelación con gastos; 2.976,84 € corresponde a la modalidad con desayuno. No se comparan directamente con un precio de «Reserva Online» flexible.
- La cifra del resumen de la aplicación solo se acepta desde una fila que coincida simultáneamente con la habitación configurada, Solo alojamiento y Reserva Online flexible. Se ignora cualquier `targetPrice` suelto o precio de otra habitación.
- La app conserva el listado de todas las tarifas leídas para poder contrastar cada opción en el detalle. Si no aparece la tarifa objetivo, el resumen debe indicar ausencia de precio confirmado.
