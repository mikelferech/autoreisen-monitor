# GC 27 v2.4.44 — Portada, Seguimiento, piscinas y Dunas

## Cambios de interfaz
- AutoReisen Gran Canaria y Fuerteventura: misma cabecera «Última búsqueda» y «Periodo», misma ficha de vehículo seleccionado y tabla de flota disponible; sangría uniforme y adaptación móvil.
- Los colores de Fuerteventura usan los definidos en su configuración, con herencia visual del seguimiento de Gran Canaria cuando no hay colores propios.
- La imagen del coche seleccionado se intenta cargar de las fuentes configuradas/flota; como respaldo para el Dacia Sandero se usa una imagen extraída de la captura aportada por el usuario. Es de resolución limitada, no una fotografía oficial verificada.
- Dunas Club: eliminado de Portada el bloque redundante de localizador / reservado / precio consultado; sus accesos de check-in, fotografías, reserva y opiniones aparecen tanto en Portada como en Alojamiento.

## Monitores
- Galileus: se conservan lecturas independientes de 1.ª y 2.ª medición cuando se publican. Los gráficos incluyen las mediciones de las capturas históricas, sin sustituirlas por una única lectura. Si no hay hora en el origen, se separan visualmente los puntos, sin atribuirles una hora real.
- Dunas: se amplía la detección de botones de elección, se deja de descartar tarifas por falta de título reconocible y se guardan capturas y diagnóstico JSON en un fallo. No se registra un total parcial. Solo aparece la tarifa verificada para la ocupación completa, y se resaltará la buscada.
- Los monitores fuente del proyecto están sincronizados con las copias que distribuye el Worker de Cloudflare; de otro modo la actualización podría reinstalar lectores obsoletos.

## Limitaciones comprobables
- No se ha confirmado en vivo un total de Dunas en la web Keytel. Tampoco se han podido verificar los nombres y temperaturas de todas las piscinas desde la fuente pública en este entorno.
- No se inventan importes, mediciones o tarifas que el proveedor no entregue.
- Se han ejecutado los scripts de validación de la aplicación y pruebas de regresión; no se ha desplegado en Firebase, Cloudflare ni GitHub desde esta sesión.
