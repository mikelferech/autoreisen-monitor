# MFE Viajes GC27 v2.4.62 · Foto y mapa a media anchura en ambos alojamientos

Actualización sobre la versión v2.4.61. Publica únicamente Firebase Hosting (compatible con Spark); no publica Functions, Firestore, Cloudflare ni monitores.

## Alojamiento

- En ordenadores (ancho >= 900 px), Cordial Santa Águeda y Dunas Club muestran fotografía a la izquierda y mapa a la derecha, cada uno ocupando el 50 % del espacio disponible, salvo el pequeño espacio de separación.
- Ambas parejas usan el mismo alto total (390 px), con el mapa ajustado bajo su encabezado, sin deformar fotografías.
- En tablet y móvil (ancho < 900 px) los dos bloques se apilan a una columna; alto de 310 px o 280 px en pantallas muy estrechas.
- Se conservan los planos/PDF en la estancia Cordial y las reservas, controles y fichas ordenables de v2.4.61.
- La disposición de Portada permanece igual.

## Instalación desde Windows

1. Extraer ZIP en una carpeta nueva.
2. Ejecutar `ACTUALIZAR_MFE.bat`; se mantiene abierta la ventana de resultados.
3. Se comprueba la versión publicada 2.4.62 después de publicar solo Firebase Hosting.

No requiere el plan Blaze.
