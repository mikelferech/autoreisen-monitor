/** Configuración Firebase de MFE Viajes */
export const firebaseConfig = {
  apiKey: "AIzaSyBC8CmDyQxtagvdBOmjMxzoybhLPYbqxQw",
  authDomain: "presupuesto-hogar-9dead.firebaseapp.com",
  projectId: "presupuesto-hogar-9dead",
  storageBucket: "presupuesto-hogar-9dead.firebasestorage.app",
  messagingSenderId: "259825574924",
  appId: "1:259825574924:web:9da31f5063fd709d5d7a29"
};

export const DEMO_MODE = false;
export const TRIP_ID = "viaje-verano-2026";
export const FUNCTIONS_REGION = "europe-west1";
