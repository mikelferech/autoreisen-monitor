export const SEED_DATA = {
  "settings": {
    "appName": "GC 26",
    "appIcon": "26",
    "appIconUrl": "./icons/gc26-logo.png",
    "tabIconUrls": {},
    "destination": "Arguineguín · Gran Canaria",
    "year": 2026,
    "people": 2,
    "departureDateTime": "2026-09-14T06:50:00+02:00",
    "returnDateTime": "2026-09-21T20:45:00+02:00",
    "editPinHash": "158a323a7ba44870f23d96f1516dd70aa48e9a72db4ebb026b0a89e212a208ab",
    "mapQuery": "Resort Cordial Santa Águeda, Arguineguín, Gran Canaria",
    "mapEmbedUrl": "",
    "weatherPlace": "Arguineguín",
    "weatherLatitude": "",
    "weatherLongitude": "",
    "priceWorkerUrl": "https://mfe-viajes-precios.mikelferech.workers.dev",
    "firebaseConsoleUrl": "https://console.firebase.google.com/project/presupuesto-hogar-9dead/overview",
    "firebaseMessagingUrl": "https://console.firebase.google.com/project/presupuesto-hogar-9dead/messaging",
    "googleDriveUrl": "https://drive.google.com/drive/my-drive",
    "googleCalendarUrl": "https://calendar.google.com/calendar/u/0/r",
    "githubRepoUrl": "",
    "githubActionsUrl": "",
    "cloudflareDashboardUrl": "https://dash.cloudflare.com/",
    "autoreisenSyncWithTripDates": true,
    "githubRunWorkflowAfterSync": true,
    "preferNativeApps": true,
    "coverImageUrl": "",
    "coverHiddenBlocks": [],
    "tripDataSectionOrder": ["travel", "rental", "stores"],
    "tripTransportOrder": ["bus:bus-out", "flight:flight-out", "flight:flight-back", "bus:bus-back", "lodging"],
    "budgetGroupOrderCustomized": false,
    "countdownShowSeconds": false,
    "countdownEndDateTime": "",
    "currency": "EUR",
    "locale": "es-ES",
    "theme": {
      "accent": "#4da3ff",
      "accent2": "#8a5cff",
      "surface": "#171a20",
      "surface2": "#20242d",
      "text": "#f6f7fb",
      "muted": "#aeb5c2",
      "success": "#39d98a",
      "danger": "#ff5c6c",
      "warning": "#ffc857",
      "gradientStart": "#244c78",
      "gradientEnd": "#402b73"
    },
    "officialDocumentHeaders": {
      "mikel": {
        "gradient1": "#184f68",
        "gradient2": "#257b91",
        "textColor": "#ffffff"
      },
      "nerea": {
        "gradient1": "#4e2768",
        "gradient2": "#754198",
        "textColor": "#ffffff"
      }
    },
    "sectionColors": {
      "flights": {
        "color": "#f6c946",
        "gradient1": "#7d6114",
        "gradient2": "#c49419",
        "textColor": "#ffffff"
      },
      "bus": {
        "color": "#49b6d6",
        "gradient1": "#173f53",
        "gradient2": "#2d7895",
        "textColor": "#ffffff"
      },
      "car": {
        "color": "#74b64c",
        "gradient1": "#294c1d",
        "gradient2": "#477c2f",
        "textColor": "#ffffff"
      },
      "lodging": {
        "color": "#9b9b9b",
        "gradient1": "#3b3b3b",
        "gradient2": "#676767",
        "textColor": "#ffffff"
      },
      "shopping": {
        "color": "#4f8b31",
        "gradient1": "#1f3e17",
        "gradient2": "#355e25",
        "textColor": "#ffffff"
      },
      "extras": {
        "color": "#f7c84b",
        "gradient1": "#70530e",
        "gradient2": "#a77a13",
        "textColor": "#ffffff"
      },
      "parking": {
        "color": "#4da3ff",
        "gradient1": "#173b61",
        "gradient2": "#285f91",
        "textColor": "#ffffff"
      }
    },
    "enabledTabs": [
      "cover",
      "lodging",
      "budget",
      "suitcase-common",
      "suitcase-mikel",
      "suitcase-nerea",
      "shopping",
      "purchases",
      "menu",
      "itinerary",
      "notes",
      "tasks",
      "emergency",
      "trackers",
      "settings"
    ],
    "tabOrder": [
      "cover",
      "lodging",
      "budget",
      "suitcase-common",
      "suitcase-mikel",
      "suitcase-nerea",
      "shopping",
      "purchases",
      "tasks",
      "emergency",
      "trackers",
      "menu",
      "itinerary",
      "notes",
      "settings"
    ],
    "navigationPosition": "top",
    "mapType": "satellite",
    "budgetFlightsCollapsed": false,
    "countdownTitle": "Nos vamooooos",
    "countdownSubtitle": "Hasta el inicio del vuelo de ida",
    "countdownImageUrl": "",
    "countdownImageCrop": {
      "x": 50,
      "y": 50,
      "zoom": 1
    },
    "googleDriveApiKey": "",
    "googleDriveClientId": "",
    "googleDriveAppId": "",
    "pushEnabled": false,
    "pushVapidKey": "",
    "fuelTankLitres": 50,
    "fuelExpectedLitres": 40,
    "carConsumption": 6.5,
    "fuelRadiusKm": 25,
    "fuelType": "Gasolina 95 E5",
    "countdownGradient1": "#244c78",
    "countdownGradient2": "#402b73",
    "countdownTextColor": "#ffffff",
    "countdownOverlayOpacity": 0.58,
    "countdownUnitBackground": "rgba(7,9,13,.56)",
    "coverOrder": [
      "countdown",
      "weather",
      "flights",
      "lodging",
      "budget",
      "documents",
      "mediaCarousels",
      "externalImages"
    ],
    "desktopCoverOrder": [
      "countdown",
      "weather",
      "flights",
      "lodging",
      "budget",
      "documents",
      "mediaCarousels",
      "externalImages"
    ],
    "desktopCoverWidths": {
      "countdown": "full",
      "weather": "full",
      "flights": "full",
      "lodging": "full",
      "budget": "full",
      "documents": "full",
      "mediaCarousels": "full",
      "externalImages": "full"
    },
    "vuelingWorkerUrl": "https://mfe-viajes-vueling.mikelferech.workers.dev",
    "poolPanel": {
      "enabled": true,
      "title": "Piscinas y servicios",
      "kicker": "DATOS EN DIRECTO",
      "sectionOrder": ["webcams", "pools", "temperatureChart", "source"],
      "hiddenSections": [],
      "poolOrder": [],
      "poolStyles": {},
      "cardBackground": "#171a20",
      "cardBorder": "#343b49",
      "temperatureBackground": "#10263a",
      "temperatureText": "#ffffff",
      "metricBackground": "#20242d",
      "webcamButtonColor": "#244c78",
      "webcamButtonText": "#ffffff",
      "chartAccent": "#4da3ff",
      "webcams": {
        "santa-agueda": {"enabled": true, "label": "Webcam Santa Águeda"},
        "el-perchel": {"enabled": true, "label": "Webcam El Perchel"}
      }
    }
  },
  "cover": {
    "lodging": {
      "name": "Resort Cordial Santa Águeda & Perchel Beach Club",
      "checkIn": "2026-09-14",
      "checkOut": "2026-09-21",
      "website": "",
      "mapsUrl": "https://www.google.com/maps/search/?api=1&query=Resort+Cordial+Santa+Águeda+Arguineguín",
      "imageUrl": "",
      "address": "",
      "imageCrop": {
        "x": 50,
        "y": 50,
        "zoom": 1
      },
      "gradient1": "#29313c",
      "gradient2": "#626d7b",
      "textColor": "#ffffff",
      "googleReviewsUrl": "https://www.google.com/maps/search/?api=1&query=Resort+Cordial+Santa+Agueda+Perchel+Beach+Club",
      "googleReviewsLabel": "Google",
      "googleReviewsColor": "#4285F4",
      "googleReviewsIcon": "",
      "googleReviewsIconUrl": "",
      "tripadvisorReviewsUrl": "https://www.tripadvisor.es/Hotel_Review-g23631509-d23025150-Reviews-Resort_Cordial_Santa_Agueda_Perchel_Beach_Club-El_Pajar_San_Bartolome_de_Tirajana_G.html",
      "tripadvisorReviewsLabel": "Tripadvisor",
      "tripadvisorReviewsColor": "#34E0A1",
      "tripadvisorReviewsIcon": "",
      "tripadvisorReviewsIconUrl": "",
      "bookingReviewsUrl": "https://www.booking.com/hotel/es/cordial-santa-agueda.html",
      "bookingReviewsLabel": "Booking",
      "bookingReviewsColor": "#003B95",
      "bookingReviewsIcon": "",
      "bookingReviewsIconUrl": "",
      "guestGuideUrl": "https://cordial.galileus.es/gweb/siloe/diario/?token=NUEraFBKcnlEYzdUVVRobnRPMHc5Zz09",
      "guestGuideLabel": "Temp Piscinas"
    },
    "flights": [
      {
        "id": "flight-out",
        "type": "IDA",
        "from": "Bilbao (BIO)",
        "to": "Gran Canaria (LPA)",
        "date": "2026-09-14",
        "departure": "2026-09-14T06:50:00+02:00",
        "arrival": "2026-09-14T09:05:00+01:00",
        "durationOverride": "3 h 15 min",
        "number": "VY3272",
        "airline": "Vueling",
        "vuelingButtonLabel": "Vueling",
        "vuelingButtonUrl": "https://www.vueling.com/es/servicios-vueling/informacion-de-vuelos/estado-de-vuelos",
        "vuelingButtonColor": "#FFD000",
        "vuelingButtonIcon": "✈️",
        "vuelingButtonIconUrl": "",
        "aenaButtonLabel": "AENA Bilbao",
        "aenaButtonUrl": "https://www.aena.es/es/infovuelos.html?Buscar=Buscar&accion=Inicio&origin=BIO",
        "aenaButtonColor": "#008C7A",
        "aenaButtonIcon": "🛫",
        "aenaButtonIconUrl": "",
        "flightAwareButtonLabel": "FlightAware",
        "flightAwareButtonUrl": "https://es.flightaware.com/live/flight/VLG3272",
        "flightAwareButtonColor": "#1675D1",
        "flightAwareButtonIcon": "◉",
        "flightAwareButtonIconUrl": "",
        "departureMapsUrl": "https://www.google.com/maps/search/?api=1&query=Aeropuerto+de+Bilbao",
        "arrivalMapsUrl": "https://www.google.com/maps/search/?api=1&query=Aeropuerto+de+Gran+Canaria",
        "color": "#f6c946",
        "logoUrl": "",
        "status": "Aún no publicado",
        "terminal": "",
        "gate": "",
        "checkInCounters": "",
        "lastUpdated": "",
        "source": "Manual",
        "checkInReminderHours": 25,
        "checkInNotifyAt": 1789271400000,
        "checkInNotifiedAt": "",
        "leaveAirportReminder": "",
        "leaveNotifyAt": 0,
        "leaveNotifiedAt": "",
        "gradient1": "#5d4a0d",
        "gradient2": "#c79a17",
        "textColor": "#ffffff"
      },
      {
        "id": "flight-back",
        "type": "VUELTA",
        "from": "Gran Canaria (LPA)",
        "to": "Bilbao (BIO)",
        "date": "2026-09-21",
        "departure": "2026-09-21T16:40:00+01:00",
        "arrival": "2026-09-21T20:45:00+02:00",
        "durationOverride": "3 h 10 min",
        "number": "VY3271",
        "airline": "Vueling",
        "vuelingButtonLabel": "Vueling",
        "vuelingButtonUrl": "https://www.vueling.com/es/servicios-vueling/informacion-de-vuelos/estado-de-vuelos",
        "vuelingButtonColor": "#FFD000",
        "vuelingButtonIcon": "✈️",
        "vuelingButtonIconUrl": "",
        "aenaButtonLabel": "AENA Gran Canaria",
        "aenaButtonUrl": "https://www.aena.es/es/infovuelos.html?Buscar=Buscar&accion=Inicio&origin=LPA",
        "aenaButtonColor": "#008C7A",
        "aenaButtonIcon": "🛫",
        "aenaButtonIconUrl": "",
        "flightAwareButtonLabel": "FlightAware",
        "flightAwareButtonUrl": "https://es.flightaware.com/live/flight/VLG3271",
        "flightAwareButtonColor": "#1675D1",
        "flightAwareButtonIcon": "◉",
        "flightAwareButtonIconUrl": "",
        "departureMapsUrl": "https://www.google.com/maps/search/?api=1&query=Aeropuerto+de+Gran+Canaria",
        "arrivalMapsUrl": "https://www.google.com/maps/search/?api=1&query=Aeropuerto+de+Bilbao",
        "color": "#f6c946",
        "logoUrl": "",
        "status": "Aún no publicado",
        "terminal": "",
        "gate": "",
        "checkInCounters": "",
        "lastUpdated": "",
        "source": "Manual",
        "checkInReminderHours": 25,
        "checkInNotifyAt": 1789915200000,
        "checkInNotifiedAt": "",
        "leaveAirportReminder": "",
        "leaveNotifyAt": 0,
        "leaveNotifiedAt": "",
        "gradient1": "#5d4a0d",
        "gradient2": "#c79a17",
        "textColor": "#ffffff"
      }
    ],
    "buses": [
      {
        "id": "bus-out",
        "type": "IDA",
        "visible": true,
        "company": "Avanza Gipuzkoa",
        "serviceNumber": "",
        "from": "Donostia / San Sebastián",
        "to": "Aeropuerto de Bilbao",
        "date": "2026-09-14",
        "departure": "2026-09-14T04:00:00+02:00",
        "arrival": "2026-09-14T05:15:00+02:00",
        "durationOverride": "1 h 15 min",
        "passengers": 2,
        "pricePerPerson": 4.16,
        "status": "unpaid",
        "reference": "",
        "notes": "",
        "purchaseButtonLabel": "Comprar billetes",
        "purchaseUrl": "https://online.pesa.net/",
        "purchaseButtonColor": "#f2d600",
        "purchaseButtonIcon": "🎫",
        "purchaseButtonIconUrl": "",
        "departureMapsUrl": "https://www.google.com/maps/search/?api=1&query=Donostia+San+Sebastian",
        "arrivalMapsUrl": "https://www.google.com/maps/search/?api=1&query=Aeropuerto+de+Bilbao",
        "icon": "🚌",
        "iconUrl": "",
        "logoUrl": "",
        "color": "#49b6d6",
        "gradient1": "#173f53",
        "gradient2": "#2d7895",
        "textColor": "#ffffff",
        "files": [],
        "documentFiles": []
      },
      {
        "id": "bus-back",
        "type": "VUELTA",
        "visible": false,
        "company": "Avanza Gipuzkoa",
        "serviceNumber": "",
        "from": "Aeropuerto de Bilbao",
        "to": "Donostia / San Sebastián",
        "date": "2026-09-21",
        "departure": "",
        "arrival": "",
        "durationOverride": "",
        "passengers": 2,
        "pricePerPerson": 0,
        "status": "unpaid",
        "reference": "",
        "notes": "",
        "purchaseButtonLabel": "Comprar billetes",
        "purchaseUrl": "https://online.pesa.net/",
        "purchaseButtonColor": "#f2d600",
        "purchaseButtonIcon": "🎫",
        "purchaseButtonIconUrl": "",
        "departureMapsUrl": "https://www.google.com/maps/search/?api=1&query=Aeropuerto+de+Bilbao",
        "arrivalMapsUrl": "https://www.google.com/maps/search/?api=1&query=Donostia+San+Sebastian",
        "icon": "🚌",
        "iconUrl": "",
        "logoUrl": "",
        "color": "#49b6d6",
        "gradient1": "#173f53",
        "gradient2": "#2d7895",
        "textColor": "#ffffff",
        "files": [],
        "documentFiles": []
      }
    ],
    "documents": [
      {
        "id": "doc-flight",
        "title": "Reserva de vuelo y billetes",
        "subtitle": "Vueling · GDQJJL",
        "url": "",
        "driveUrl": "",
        "imageUrl": "",
        "icon": "🎫",
        "color": "#f6c946",
        "linkType": "auto",
        "buttonLabel": "",
        "files": [],
        "gradient1": "#5d4a0d",
        "gradient2": "#c79a17",
        "textColor": "#ffffff"
      },
      {
        "id": "doc-car",
        "title": "Reserva del coche",
        "subtitle": "Autoreisen · RVA 5609115",
        "url": "",
        "driveUrl": "",
        "imageUrl": "",
        "icon": "🚗",
        "color": "#74b64c",
        "linkType": "auto",
        "buttonLabel": "",
        "files": [],
        "gradient1": "#173d20",
        "gradient2": "#478034",
        "textColor": "#ffffff"
      },
      {
        "id": "doc-lodging",
        "title": "Reserva del alojamiento",
        "subtitle": "ROL80645K · Cordial Santa Águeda",
        "url": "",
        "driveUrl": "",
        "imageUrl": "",
        "icon": "🏨",
        "color": "#9b9b9b",
        "linkType": "auto",
        "buttonLabel": "",
        "files": [],
        "gradient1": "#29313c",
        "gradient2": "#626d7b",
        "textColor": "#ffffff"
      },
      {
        "id": "doc-parking",
        "title": "Parking",
        "subtitle": "Añadir si hace falta",
        "url": "",
        "driveUrl": "",
        "imageUrl": "",
        "icon": "🅿️",
        "color": "#4da3ff",
        "linkType": "auto",
        "buttonLabel": "",
        "files": [],
        "gradient1": "#202936",
        "gradient2": "#343f50",
        "textColor": "#ffffff"
      }
    ],
    "mediaCarousels": [],
    "externalImages": []
  },
  "budget": {
    "groups": [
      {
        "id": "g-bus",
        "name": "Autobús aeropuerto",
        "icon": "🚌",
        "color": "#49b6d6",
        "gradient1": "#173f53",
        "gradient2": "#2d7895",
        "textColor": "#ffffff",
        "items": []
      },
      {
        "id": "g-flights",
        "name": "Vuelo Vueling",
        "icon": "✈️",
        "color": "#f6c946",
        "gradient1": "#7d6114",
        "gradient2": "#c49419",
        "textColor": "#ffffff",
        "items": [
          {
            "id": "b1",
            "name": "BIO-LPA",
            "detail": "Vueling GDQJJL.pdf",
            "amount": 161.98,
            "status": "paid",
            "url": "",
            "files": []
          },
          {
            "id": "b2",
            "name": "LPA-BIO",
            "detail": "",
            "amount": 83.98,
            "status": "paid",
            "url": "",
            "files": []
          },
          {
            "id": "b3",
            "name": "Maleta 25 kg",
            "detail": "",
            "amount": 92.0,
            "status": "paid",
            "url": "",
            "files": []
          }
        ]
      },
      {
        "id": "g-car",
        "name": "Alquiler coche",
        "icon": "🚗",
        "color": "#74b64c",
        "gradient1": "#294c1d",
        "gradient2": "#477c2f",
        "textColor": "#ffffff",
        "items": [
          {
            "id": "b4",
            "name": "Autoreisen",
            "detail": "Reserva RVA 5609115",
            "amount": 137.03,
            "status": "unpaid",
            "url": "",
            "files": []
          }
        ]
      },
      {
        "id": "g-lodging",
        "name": "Cordial Santa Águeda",
        "icon": "🏨",
        "color": "#9b9b9b",
        "gradient1": "#3b3b3b",
        "gradient2": "#676767",
        "textColor": "#ffffff",
        "items": [
          {
            "id": "b5",
            "name": "ROL80645K",
            "detail": "Resort Cordial Santa Águeda & Perchel Beach Club",
            "amount": 1094.4,
            "status": "unpaid",
            "url": "",
            "files": []
          }
        ]
      },
      {
        "id": "g-shopping",
        "name": "Compras",
        "icon": "🛒",
        "color": "#4f8b31",
        "gradient1": "#1f3e17",
        "gradient2": "#355e25",
        "textColor": "#ffffff",
        "items": [
          {
            "id": "b7",
            "name": "Gasolina",
            "detail": "",
            "amount": 15.0,
            "status": "unpaid",
            "url": "",
            "files": []
          }
        ]
      },
      {
        "id": "g-extras",
        "name": "Extras",
        "icon": "✨",
        "color": "#f7c84b",
        "gradient1": "#70530e",
        "gradient2": "#a77a13",
        "textColor": "#ffffff",
        "items": [
          {
            "id": "b8",
            "name": "Lotería",
            "detail": "",
            "amount": 20.0,
            "status": "unpaid",
            "url": "",
            "files": []
          },
          {
            "id": "b9",
            "name": "Cena A Casa Mia",
            "detail": "",
            "amount": 20.97,
            "status": "unpaid",
            "url": "",
            "files": []
          },
          {
            "id": "b10",
            "name": "Comida Ñoño",
            "detail": "",
            "amount": 24.0,
            "status": "unpaid",
            "url": "",
            "files": []
          },
          {
            "id": "b11",
            "name": "Guirlache",
            "detail": "",
            "amount": 5.2,
            "status": "unpaid",
            "url": "",
            "files": []
          }
        ]
      }
    ],
    "carKm": {
      "initial": "",
      "final": ""
    }
  },
  "suitcases": {
    "common": [
      {
        "id": "scg1",
        "name": "Documentación común",
        "icon": "📁",
        "color": "#4da3ff",
        "textColor": "#ffffff",
        "items": [
          {
            "id": "sci1",
            "name": "Reservas y billetes",
            "checked": false,
            "order": 0
          },
          {
            "id": "sci2",
            "name": "Tarjetas sanitarias / seguros",
            "checked": false,
            "order": 0
          },
          {
            "id": "sci3",
            "name": "Llaves y documentación del coche",
            "checked": false,
            "order": 0
          }
        ]
      },
      {
        "id": "scg2",
        "name": "Playa y apartamento",
        "icon": "🏖️",
        "color": "#ffc857",
        "textColor": "#ffffff",
        "items": [
          {
            "id": "sci4",
            "name": "Protector de volante y parasol",
            "checked": false,
            "order": 0
          },
          {
            "id": "sci5",
            "name": "Bolsas de compra",
            "checked": false,
            "order": 0
          },
          {
            "id": "sci6",
            "name": "Pinzas, embudo y papel de horno",
            "checked": false,
            "order": 0
          }
        ]
      }
    ],
    "mikel": [
      {
        "id": "sm1",
        "name": "Maleta",
        "icon": "🧳",
        "color": "#4da3ff",
        "textColor": "#ffffff",
        "items": [
          {
            "id": "sm1i1",
            "name": "Polos",
            "checked": false,
            "order": 0
          },
          {
            "id": "sm1i2",
            "name": "Camisetas · 2",
            "checked": false,
            "order": 0
          },
          {
            "id": "sm1i3",
            "name": "Pantalones · 1",
            "checked": false,
            "order": 0
          },
          {
            "id": "sm1i4",
            "name": "Calzoncillos · 2",
            "checked": false,
            "order": 0
          },
          {
            "id": "sm1i5",
            "name": "Calcetines · 2",
            "checked": false,
            "order": 0
          },
          {
            "id": "sm1i6",
            "name": "Pijama",
            "checked": false,
            "order": 0
          },
          {
            "id": "sm1i7",
            "name": "Camisetas Baskonia",
            "checked": false,
            "order": 0
          },
          {
            "id": "sm1i8",
            "name": "Bañadores · 2",
            "checked": false,
            "order": 0
          },
          {
            "id": "sm1i9",
            "name": "Chanclas",
            "checked": false,
            "order": 0
          },
          {
            "id": "sm1i10",
            "name": "Chanclas de ducha",
            "checked": false,
            "order": 0
          },
          {
            "id": "sm1i11",
            "name": "Neceser: lentillas, gafas, tijeras y desodorante",
            "checked": false,
            "order": 0
          },
          {
            "id": "sm1i12",
            "name": "Máquina de afeitar",
            "checked": false,
            "order": 0
          },
          {
            "id": "sm1i13",
            "name": "Cepillo de dientes y colutorio",
            "checked": false,
            "order": 0
          },
          {
            "id": "sm1i14",
            "name": "Pasta de dientes",
            "checked": false,
            "order": 0
          },
          {
            "id": "sm1i15",
            "name": "Crema solar",
            "checked": false,
            "order": 0
          },
          {
            "id": "sm1i16",
            "name": "Gafas de bucear",
            "checked": false,
            "order": 0
          },
          {
            "id": "sm1i17",
            "name": "Bolsas ZIP",
            "checked": false,
            "order": 0
          },
          {
            "id": "sm1i18",
            "name": "Mi Box S / Mi Stick",
            "checked": false,
            "order": 0
          },
          {
            "id": "sm1i19",
            "name": "Pinzas de hamaca",
            "checked": false,
            "order": 0
          },
          {
            "id": "sm1i20",
            "name": "Parasol y protege volante",
            "checked": false,
            "order": 0
          },
          {
            "id": "sm1i21",
            "name": "Nevera portátil",
            "checked": false,
            "order": 0
          }
        ]
      },
      {
        "id": "sm2",
        "name": "Mochila",
        "icon": "🎒",
        "color": "#8a5cff",
        "textColor": "#ffffff",
        "items": [
          {
            "id": "sm2i1",
            "name": "Tablet y auriculares",
            "checked": false,
            "order": 0
          },
          {
            "id": "sm2i2",
            "name": "Botella",
            "checked": false,
            "order": 0
          },
          {
            "id": "sm2i3",
            "name": "Cargadores",
            "checked": false,
            "order": 0
          },
          {
            "id": "sm2i4",
            "name": "Billetes / carpeta",
            "checked": false,
            "order": 0
          },
          {
            "id": "sm2i5",
            "name": "Comida",
            "checked": false,
            "order": 0
          },
          {
            "id": "sm2i6",
            "name": "Muda",
            "checked": false,
            "order": 0
          },
          {
            "id": "sm2i7",
            "name": "Boli",
            "checked": false,
            "order": 0
          },
          {
            "id": "sm2i8",
            "name": "Powerbank",
            "checked": false,
            "order": 0
          },
          {
            "id": "sm2i9",
            "name": "Palo selfie",
            "checked": false,
            "order": 0
          },
          {
            "id": "sm2i10",
            "name": "Cargador de reloj",
            "checked": false,
            "order": 0
          },
          {
            "id": "sm2i11",
            "name": "Localizador de maleta",
            "checked": false,
            "order": 0
          }
        ]
      },
      {
        "id": "sm3",
        "name": "Ropa puesta",
        "icon": "👕",
        "color": "#39d98a",
        "textColor": "#ffffff",
        "items": [
          {
            "id": "sm3i1",
            "name": "Pantalón deporte negro",
            "checked": false,
            "order": 0
          },
          {
            "id": "sm3i2",
            "name": "Polo",
            "checked": false,
            "order": 0
          },
          {
            "id": "sm3i3",
            "name": "Zapatillas",
            "checked": false,
            "order": 0
          },
          {
            "id": "sm3i4",
            "name": "Polo de manga larga",
            "checked": false,
            "order": 0
          },
          {
            "id": "sm3i5",
            "name": "Gafas de sol",
            "checked": false,
            "order": 0
          },
          {
            "id": "sm3i6",
            "name": "Cartera y documentación",
            "checked": false,
            "order": 0
          },
          {
            "id": "sm3i7",
            "name": "Auriculares Bluetooth",
            "checked": false,
            "order": 0
          }
        ]
      }
    ],
    "nerea": [
      {
        "id": "sn1",
        "name": "Maleta",
        "icon": "🧳",
        "color": "#ff7ab6",
        "textColor": "#ffffff",
        "items": [
          {
            "id": "sn1i1",
            "name": "Bragas x10",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn1i2",
            "name": "Sujetadores x2",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn1i3",
            "name": "Pantalones",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn1i4",
            "name": "Camisetas",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn1i5",
            "name": "Vestidos",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn1i6",
            "name": "Bikinis x2",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn1i7",
            "name": "Chanclas x2",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn1i8",
            "name": "Calzado",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn1i9",
            "name": "Joyas",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn1i10",
            "name": "Bolso",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn1i11",
            "name": "Pijama x2",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn1i12",
            "name": "Camisola piscina",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn1i13",
            "name": "Leggins",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn1i14",
            "name": "Mochilita piscina",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn1i15",
            "name": "Antifaz",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn1i16",
            "name": "Filtros café",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn1i17",
            "name": "Escarpines",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn1i18",
            "name": "Gafas piscina",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn1i19",
            "name": "Bolsa ropa sucia",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn1i20",
            "name": "Bolsas compra",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn1i21",
            "name": "Sombrero",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn1i22",
            "name": "Pinzas y embudo",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn1i23",
            "name": "Pinzas de hamaca",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn1i24",
            "name": "Protector volante y parasol",
            "checked": false,
            "order": 0
          }
        ]
      },
      {
        "id": "sn2",
        "name": "Mochila",
        "icon": "🎒",
        "color": "#8a5cff",
        "textColor": "#ffffff",
        "items": [
          {
            "id": "sn2i1",
            "name": "Portátil",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn2i2",
            "name": "Tablet",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn2i3",
            "name": "Cables y cargadores",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn2i4",
            "name": "Cartera y documentación",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn2i5",
            "name": "Llaves",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn2i6",
            "name": "Chicles",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn2i7",
            "name": "Gafas de sol",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn2i8",
            "name": "Botella de agua",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn2i9",
            "name": "E-book",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn2i10",
            "name": "Auriculares",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn2i11",
            "name": "Libreta",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn2i12",
            "name": "Palo selfie",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn2i13",
            "name": "Almohada hamaca",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn2i14",
            "name": "Klinex",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn2i15",
            "name": "Mi Stick",
            "checked": false,
            "order": 0
          }
        ]
      },
      {
        "id": "sn3",
        "name": "Neceser",
        "icon": "🧴",
        "color": "#ffc857",
        "textColor": "#ffffff",
        "items": [
          {
            "id": "sn3i1",
            "name": "Toallitas desmaquillantes",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn3i2",
            "name": "Lentillero",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn3i3",
            "name": "Líquido de lentillas",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn3i4",
            "name": "Lentillas de repuesto",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn3i5",
            "name": "Ganchos y gomas",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn3i6",
            "name": "Cepillo y pasta de dientes",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn3i7",
            "name": "Gel y champú",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn3i8",
            "name": "Cuchilla y repuestos",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn3i9",
            "name": "Crema corporal y facial",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn3i10",
            "name": "Desodorante",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn3i11",
            "name": "Agua micelar",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn3i12",
            "name": "Perfume",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn3i13",
            "name": "Maquillaje",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn3i14",
            "name": "Peine",
            "checked": false,
            "order": 0
          },
          {
            "id": "sn3i15",
            "name": "Medicación",
            "checked": false,
            "order": 0
          }
        ]
      }
    ]
  },
  "shopping": {
    "stores": [
      {
        "id": "store-mercadona",
        "name": "Mercadona",
        "icon": "🛒",
        "color": "#c26d2f",
        "gradient1": "#6f3518",
        "gradient2": "#ad5925",
        "textColor": "#ffffff",
        "postalCode": "35214",
        "products": [
          {
            "id": "pm1",
            "name": "Mozzarella rallada",
            "quantity": 2,
            "unitPrice": 1.65,
            "url": "",
            "imageUrl": "",
            "checked": false,
            "unit": "ud.",
            "imageCrop": {
              "x": 50,
              "y": 50,
              "zoom": 1
            }
          },
          {
            "id": "pm2",
            "name": "Contramuslo deshuesado",
            "quantity": 1,
            "unitPrice": 4.9,
            "url": "",
            "imageUrl": "",
            "checked": false,
            "unit": "ud.",
            "imageCrop": {
              "x": 50,
              "y": 50,
              "zoom": 1
            }
          },
          {
            "id": "pm3",
            "name": "Carne picada pollo",
            "quantity": 1,
            "unitPrice": 3.55,
            "url": "",
            "imageUrl": "",
            "checked": false,
            "unit": "ud.",
            "imageCrop": {
              "x": 50,
              "y": 50,
              "zoom": 1
            }
          },
          {
            "id": "pm4",
            "name": "Burger vacuno",
            "quantity": 1,
            "unitPrice": 4.85,
            "url": "",
            "imageUrl": "",
            "checked": false,
            "unit": "ud.",
            "imageCrop": {
              "x": 50,
              "y": 50,
              "zoom": 1
            }
          },
          {
            "id": "pm5",
            "name": "Contramuslo pavo",
            "quantity": 1,
            "unitPrice": 5.02,
            "url": "",
            "imageUrl": "",
            "checked": false,
            "unit": "ud.",
            "imageCrop": {
              "x": 50,
              "y": 50,
              "zoom": 1
            }
          },
          {
            "id": "pm6",
            "name": "Tortitas de avena",
            "quantity": 1,
            "unitPrice": 1.95,
            "url": "",
            "imageUrl": "",
            "checked": false,
            "unit": "ud.",
            "imageCrop": {
              "x": 50,
              "y": 50,
              "zoom": 1
            }
          },
          {
            "id": "pm7",
            "name": "Cereales muesli",
            "quantity": 1,
            "unitPrice": 2.45,
            "url": "",
            "imageUrl": "",
            "checked": false,
            "unit": "ud.",
            "imageCrop": {
              "x": 50,
              "y": 50,
              "zoom": 1
            }
          },
          {
            "id": "pm8",
            "name": "Jamón York doble",
            "quantity": 1,
            "unitPrice": 3.45,
            "url": "",
            "imageUrl": "",
            "checked": false,
            "unit": "ud.",
            "imageCrop": {
              "x": 50,
              "y": 50,
              "zoom": 1
            }
          },
          {
            "id": "pm9",
            "name": "Sándwich",
            "quantity": 1,
            "unitPrice": 2.8,
            "url": "",
            "imageUrl": "",
            "checked": false,
            "unit": "ud.",
            "imageCrop": {
              "x": 50,
              "y": 50,
              "zoom": 1
            }
          },
          {
            "id": "pm10",
            "name": "Burger pollo gruesa",
            "quantity": 1,
            "unitPrice": 3.4,
            "url": "",
            "imageUrl": "",
            "checked": false,
            "unit": "ud.",
            "imageCrop": {
              "x": 50,
              "y": 50,
              "zoom": 1
            }
          },
          {
            "id": "pm11",
            "name": "Pan brioche",
            "quantity": 1,
            "unitPrice": 1.1,
            "url": "",
            "imageUrl": "",
            "checked": false,
            "unit": "ud.",
            "imageCrop": {
              "x": 50,
              "y": 50,
              "zoom": 1
            }
          },
          {
            "id": "pm12",
            "name": "Plátano",
            "quantity": 0.89,
            "unitPrice": 3.4,
            "url": "",
            "imageUrl": "",
            "checked": false,
            "unit": "ud.",
            "imageCrop": {
              "x": 50,
              "y": 50,
              "zoom": 1
            }
          }
        ],
        "website": "",
        "active": true
      },
      {
        "id": "store-hiperdino",
        "name": "HiperDino",
        "icon": "🏪",
        "color": "#319a64",
        "gradient1": "#155637",
        "gradient2": "#23794d",
        "textColor": "#ffffff",
        "postalCode": "35200",
        "products": [
          {
            "id": "ph1",
            "name": "Munchitos",
            "quantity": 6,
            "unitPrice": 1.82,
            "url": "",
            "imageUrl": "",
            "checked": false,
            "unit": "ud.",
            "imageCrop": {
              "x": 50,
              "y": 50,
              "zoom": 1
            }
          },
          {
            "id": "ph2",
            "name": "Leche",
            "quantity": 5,
            "unitPrice": 0.87,
            "url": "",
            "imageUrl": "",
            "checked": false,
            "unit": "ud.",
            "imageCrop": {
              "x": 50,
              "y": 50,
              "zoom": 1
            }
          },
          {
            "id": "ph3",
            "name": "Croissant brioche",
            "quantity": 4,
            "unitPrice": 0.69,
            "url": "",
            "imageUrl": "",
            "checked": false,
            "unit": "ud.",
            "imageCrop": {
              "x": 50,
              "y": 50,
              "zoom": 1
            }
          },
          {
            "id": "ph4",
            "name": "Ambrosías 28u",
            "quantity": 4,
            "unitPrice": 3.69,
            "url": "",
            "imageUrl": "",
            "checked": false,
            "unit": "ud.",
            "imageCrop": {
              "x": 50,
              "y": 50,
              "zoom": 1
            }
          },
          {
            "id": "ph5",
            "name": "Néctar melocotón 2L",
            "quantity": 2,
            "unitPrice": 1.78,
            "url": "",
            "imageUrl": "",
            "checked": false,
            "unit": "ud.",
            "imageCrop": {
              "x": 50,
              "y": 50,
              "zoom": 1
            }
          },
          {
            "id": "ph6",
            "name": "Agua 1,5 L",
            "quantity": 2,
            "unitPrice": 0.39,
            "url": "",
            "imageUrl": "",
            "checked": false,
            "unit": "ud.",
            "imageCrop": {
              "x": 50,
              "y": 50,
              "zoom": 1
            }
          },
          {
            "id": "ph7",
            "name": "Agua 8 L",
            "quantity": 2,
            "unitPrice": 1.24,
            "url": "",
            "imageUrl": "",
            "checked": false,
            "unit": "ud.",
            "imageCrop": {
              "x": 50,
              "y": 50,
              "zoom": 1
            }
          },
          {
            "id": "ph8",
            "name": "Cola Zero",
            "quantity": 2,
            "unitPrice": 0.74,
            "url": "",
            "imageUrl": "",
            "checked": false,
            "unit": "ud.",
            "imageCrop": {
              "x": 50,
              "y": 50,
              "zoom": 1
            }
          },
          {
            "id": "ph9",
            "name": "Hojaldre jamón queso",
            "quantity": 2,
            "unitPrice": 1.1,
            "url": "",
            "imageUrl": "",
            "checked": false,
            "unit": "ud.",
            "imageCrop": {
              "x": 50,
              "y": 50,
              "zoom": 1
            }
          },
          {
            "id": "ph10",
            "name": "Galleta chocolate pack",
            "quantity": 1,
            "unitPrice": 2.05,
            "url": "",
            "imageUrl": "",
            "checked": false,
            "unit": "ud.",
            "imageCrop": {
              "x": 50,
              "y": 50,
              "zoom": 1
            }
          },
          {
            "id": "ph11",
            "name": "Pan hamburguesa brioche",
            "quantity": 1,
            "unitPrice": 1.6,
            "url": "",
            "imageUrl": "",
            "checked": false,
            "unit": "ud.",
            "imageCrop": {
              "x": 50,
              "y": 50,
              "zoom": 1
            }
          },
          {
            "id": "ph12",
            "name": "Tomate",
            "quantity": 1,
            "unitPrice": 0.84,
            "url": "",
            "imageUrl": "",
            "checked": false,
            "unit": "ud.",
            "imageCrop": {
              "x": 50,
              "y": 50,
              "zoom": 1
            }
          },
          {
            "id": "ph13",
            "name": "Tallarín",
            "quantity": 1,
            "unitPrice": 0.74,
            "url": "",
            "imageUrl": "",
            "checked": false,
            "unit": "ud.",
            "imageCrop": {
              "x": 50,
              "y": 50,
              "zoom": 1
            }
          },
          {
            "id": "ph14",
            "name": "Pan de molde grande",
            "quantity": 1,
            "unitPrice": 1.23,
            "url": "",
            "imageUrl": "",
            "checked": false,
            "unit": "ud.",
            "imageCrop": {
              "x": 50,
              "y": 50,
              "zoom": 1
            }
          },
          {
            "id": "ph15",
            "name": "Cubanitos",
            "quantity": 1,
            "unitPrice": 0.88,
            "url": "",
            "imageUrl": "",
            "checked": false,
            "unit": "ud.",
            "imageCrop": {
              "x": 50,
              "y": 50,
              "zoom": 1
            }
          },
          {
            "id": "ph16",
            "name": "Melón Galia",
            "quantity": 1,
            "unitPrice": 2.95,
            "url": "",
            "imageUrl": "",
            "checked": false,
            "unit": "ud.",
            "imageCrop": {
              "x": 50,
              "y": 50,
              "zoom": 1
            }
          },
          {
            "id": "ph17",
            "name": "Helado chocolate",
            "quantity": 1,
            "unitPrice": 2.82,
            "url": "",
            "imageUrl": "",
            "checked": false,
            "unit": "ud.",
            "imageCrop": {
              "x": 50,
              "y": 50,
              "zoom": 1
            }
          },
          {
            "id": "ph18",
            "name": "Helado stracciatella",
            "quantity": 1,
            "unitPrice": 2.96,
            "url": "",
            "imageUrl": "",
            "checked": false,
            "unit": "ud.",
            "imageCrop": {
              "x": 50,
              "y": 50,
              "zoom": 1
            }
          }
        ],
        "website": "",
        "active": true
      }
    ],
    "priceTracking": {
      "schedule": "daily",
      "lastRunAt": "",
      "lastAutoRunAt": "",
      "snapshots": [],
      "changes": [],
      "lastChanges": [],
      "lastSource": ""
    }
  },
  "purchases": {
    "records": [
      {
        "id": "pr1",
        "date": "2026-06-21",
        "store": "HiperDino",
        "amount": 50.22,
        "notes": "",
        "ticketUrl": "",
        "ticketStoragePath": ""
      },
      {
        "id": "pr2",
        "date": "2026-06-22",
        "store": "Mercadona",
        "amount": 35.07,
        "notes": "",
        "ticketUrl": "",
        "ticketStoragePath": ""
      },
      {
        "id": "pr3",
        "date": "2026-06-23",
        "store": "HiperDino",
        "amount": 9.65,
        "notes": "",
        "ticketUrl": "",
        "ticketStoragePath": ""
      },
      {
        "id": "pr4",
        "date": "2026-06-28",
        "store": "HiperDino",
        "amount": 16.42,
        "notes": "",
        "ticketUrl": "",
        "ticketStoragePath": ""
      }
    ],
    "ticketItems": [],
    "otherExpenses": [],
    "extras": []
  },
  "menu": {
    "days": [
      {
        "date": "2026-09-14",
        "breakfast": "",
        "lunch": "Ñoño",
        "dinner": "",
        "notes": "",
        "showBreakfast": true,
        "showLunch": true,
        "showDinner": true
      },
      {
        "date": "2026-09-15",
        "breakfast": "",
        "lunch": "",
        "dinner": "",
        "notes": "",
        "showBreakfast": true,
        "showLunch": true,
        "showDinner": true
      },
      {
        "date": "2026-09-16",
        "breakfast": "",
        "lunch": "",
        "dinner": "",
        "notes": "",
        "showBreakfast": true,
        "showLunch": true,
        "showDinner": true
      },
      {
        "date": "2026-09-17",
        "breakfast": "",
        "lunch": "",
        "dinner": "",
        "notes": "",
        "showBreakfast": true,
        "showLunch": true,
        "showDinner": true
      },
      {
        "date": "2026-09-18",
        "breakfast": "",
        "lunch": "",
        "dinner": "",
        "notes": "",
        "showBreakfast": true,
        "showLunch": true,
        "showDinner": true
      },
      {
        "date": "2026-09-19",
        "breakfast": "",
        "lunch": "",
        "dinner": "A Casa Mia",
        "notes": "",
        "showBreakfast": true,
        "showLunch": true,
        "showDinner": true
      },
      {
        "date": "2026-09-20",
        "breakfast": "",
        "lunch": "",
        "dinner": "",
        "notes": "",
        "showBreakfast": true,
        "showLunch": true,
        "showDinner": true
      },
      {
        "date": "2026-09-21",
        "breakfast": "",
        "lunch": "",
        "dinner": "",
        "notes": "",
        "showBreakfast": true,
        "showLunch": true,
        "showDinner": true
      }
    ]
  },
  "itinerary": {
    "view": "calendar",
    "activities": [
      {
        "id": "it1",
        "date": "2026-09-14",
        "start": "06:50",
        "end": "09:05",
        "title": "Vuelo Bilbao → Gran Canaria",
        "location": "Aeropuerto de Bilbao / LPA",
        "mapsUrl": "",
        "notes": "VY3272",
        "color": "#f6c946"
      },
      {
        "id": "it2",
        "date": "2026-09-14",
        "start": "10:00",
        "end": "11:00",
        "title": "Recogida del coche",
        "location": "Autoreisen · Aeropuerto de Gran Canaria",
        "mapsUrl": "",
        "notes": "Reserva RVA 5609115",
        "color": "#74b64c"
      },
      {
        "id": "it3",
        "date": "2026-09-14",
        "start": "15:00",
        "end": "",
        "title": "Entrada al alojamiento",
        "location": "Cordial Santa Águeda",
        "mapsUrl": "https://www.google.com/maps/search/?api=1&query=Resort+Cordial+Santa+Águeda+Arguineguín",
        "notes": "",
        "color": "#9b9b9b"
      },
      {
        "id": "it4",
        "date": "2026-09-21",
        "start": "16:40",
        "end": "20:45",
        "title": "Vuelo Gran Canaria → Bilbao",
        "location": "Aeropuerto de Gran Canaria / BIO",
        "mapsUrl": "",
        "notes": "VY3271",
        "color": "#f6c946"
      }
    ]
  },
  "notes": {
    "blocks": [
      {
        "id": "n1",
        "title": "Preguntas para Cordial Santa Águeda",
        "color": "#9b9b9b",
        "content": "Hola, buenas tardes,\n\nA partir del 14 de septiembre tenemos una reserva en su complejo y tengo algunas dudas:\n\n- ¿Para cuántos dispositivos es la conexión WiFi gratuita?\n- ¿Hay toallas de piscina o debemos llevarlas?\n- ¿En la habitación dejan gel de ducha y champú?\n- ¿Dejan pastillas para el lavavajillas y las reponen?\n- ¿Hay lavadora en los apartamentos Classic Duplex? ¿Dejan detergente?\n- ¿Hay secadora, plancha o tendedero?\n- ¿Dejan papel de cocina, jabón, bayeta y estropajo?\n- ¿Se deja algún amenity como agua, sal o azúcar a la llegada?\n- ¿La piscina tiene horario?\n- Preferencia: cama de matrimonio y piso alto para evitar ruido."
      },
      {
        "id": "n2",
        "title": "Notas generales",
        "color": "#4da3ff",
        "content": "Añade aquí teléfonos, dudas, direcciones, códigos de reserva o cualquier información útil del viaje."
      }
    ]
  },
  "tasks": {
    "items": [
      {
        "id": "task-checkin",
        "title": "Hacer check-in de los vuelos",
        "description": "Descargar las tarjetas de embarque y guardarlas en Documentos.",
        "responsible": "Ambos",
        "dueAt": "2026-09-13T05:50",
        "completed": false,
        "reminderMinutes": 60,
        "notifyAt": 1789267800000,
        "url": "",
        "notifiedAt": ""
      },
      {
        "id": "task-docs",
        "title": "Revisar documentación oficial",
        "description": "DNI, tarjetas sanitarias y carnets de conducir.",
        "responsible": "Ambos",
        "dueAt": "2026-09-12T18:00",
        "completed": false,
        "reminderMinutes": 120,
        "notifyAt": 1789221600000,
        "url": "",
        "notifiedAt": ""
      }
    ]
  },
  "emergency": {
    "contacts": [
      {
        "id": "em-112",
        "title": "Emergencias",
        "subtitle": "Policía, ambulancia y bomberos",
        "phone": "112",
        "address": "",
        "mapsUrl": "",
        "url": "",
        "icon": "🆘",
        "color": "#e05666"
      },
      {
        "id": "em-hotel",
        "title": "Alojamiento",
        "subtitle": "Resort Cordial Santa Águeda & Perchel Beach Club",
        "phone": "",
        "address": "",
        "mapsUrl": "https://www.google.com/maps/search/?api=1&query=Resort+Cordial+Santa+Águeda+Arguineguín",
        "url": "",
        "icon": "🏨",
        "color": "#4da3ff"
      }
    ],
    "documents": {
      "mikel": [
        {
          "id": "official-mikel-dni",
          "title": "DNI",
          "icon": "🪪",
          "color": "#4da3ff",
          "files": []
        },
        {
          "id": "official-mikel-health",
          "title": "Tarjeta sanitaria",
          "icon": "🏥",
          "color": "#39d98a",
          "files": []
        },
        {
          "id": "official-mikel-driving",
          "title": "Carnet de conducir",
          "icon": "🚗",
          "color": "#8a5cff",
          "files": []
        }
      ],
      "nerea": [
        {
          "id": "official-nerea-dni",
          "title": "DNI",
          "icon": "🪪",
          "color": "#8a5cff",
          "files": []
        },
        {
          "id": "official-nerea-health",
          "title": "Tarjeta sanitaria",
          "icon": "🏥",
          "color": "#39d98a",
          "files": []
        },
        {
          "id": "official-nerea-driving",
          "title": "Carnet de conducir",
          "icon": "🚗",
          "color": "#4da3ff",
          "files": []
        }
      ]
    }
  },
  "trackers": {
    "order": [
      "autoreisen",
      "cordial",
      "vueling",
      "fuel"
    ],
    "visible": {
      "autoreisen": true,
      "fuel": true,
      "cordial": true,
      "vueling": true
    },
    "autoreisen": {
      "pickup": "Gran Canaria - Aeropuerto",
      "dropoff": "Gran Canaria - Aeropuerto",
      "pickupOfficeId": "18",
      "dropoffOfficeId": "18",
      "pickupAt": "2026-09-14T09:00",
      "dropoffAt": "2026-09-21T15:00",
      "group": "E",
      "model": "Seat Arona o similar",
      "carId": "119",
      "imageUrl": "",
      "manualImageUrl": "",
      "reservedPrice": 137.03,
      "currentPrice": "",
      "lastUpdated": "",
      "searchUrl": "https://www.autoreisen.com/alquiler-coches/alquiler-de-coches.php",
      "history": [],
      "automatic": false,
      "monitorStatus": "pending",
      "lastError": "",
      "lastAttempt": "",
      "source": "",
      "color": "#74b64c",
      "gradient1": "#294c1d",
      "gradient2": "#477c2f",
      "textColor": "#ffffff",
      "enabled": true,
      "intervalHours": 24,
      "scheduleMode": "daily",
      "scheduleTime": "06:30",
      "scheduleTimeZone": "Europe/Madrid",
      "telegramEnabled": true,
      "telegramNotifyEveryCheck": true,
      "telegramNotifyPriceDrop": true,
      "telegramNotifyBelowReserved": true,
      "telegramNotifyAvailability": true,
      "telegramNotifyError": true,
      "telegramNotifyRecovery": true,
      "telegramMinDropAmount": 0,
      "telegramMinDropPercent": 0,
      "title": "AutoReisen",
      "titleIcon": "🚗",
      "titleIconUrl": ""
    },
    "fuel": {
      "stations": [],
      "lastUpdated": "",
      "favorites": [],
      "history": [],
      "color": "#4da3ff",
      "gradient1": "#173b61",
      "gradient2": "#285f91",
      "textColor": "#ffffff",
      "title": "Gasolineras",
      "titleIcon": "⛽",
      "titleIconUrl": ""
    },
    "cordial": {
      "title": "Cordial Santa Águeda",
      "titleIcon": "🏨",
      "titleIconUrl": "",
      "hotel": "Cordial Santa Águeda & Perchel Beach Club",
      "checkIn": "2026-09-14",
      "checkOut": "2026-09-21",
      "adults": 2,
      "children": 0,
      "targetRoom": "Classic Duplex",
      "targetRate": "Club Cordial - Reserva Online",
      "targetBoard": "SOLO ALOJAMIENTO",
      "reservedPrice": 0,
      "currentPrice": "",
      "lastUpdated": "",
      "searchUrl": "https://www.becordial.com/gran-canaria-sur/cordial-santa-agueda/",
      "resultUrl": "",
      "history": [],
      "options": [],
      "availability": "",
      "automatic": false,
      "monitorStatus": "pending",
      "lastError": "",
      "lastAttempt": "",
      "source": "",
      "color": "#35a5d6",
      "gradient1": "#113b58",
      "gradient2": "#166b91",
      "textColor": "#ffffff",
      "enabled": true,
      "scheduleMode": "daily",
      "scheduleTime": "06:35",
      "scheduleTimeZone": "Europe/Madrid"
    },
    "vueling": {
      "title": "Vueling · precio final",
      "titleIcon": "✈️",
      "titleIconUrl": "",
      "origin": "BIO",
      "destination": "LPA",
      "departureDate": "2026-09-14",
      "returnDate": "2026-09-21",
      "outboundFlight": "VY3272",
      "returnFlight": "VY3271",
      "outboundTime": "06:50",
      "returnTime": "16:40",
      "directOnly": true,
      "adults": 2,
      "children": 0,
      "infants": 0,
      "fare": "FLY LIGHT",
      "underseatBag": true,
      "sameHandBaggageAllPassengers": true,
      "checkedBagKg": 25,
      "checkedBagCount": 1,
      "checkedBagPassenger": 1,
      "sameBaggageRoundTrip": true,
      "sameBaggageAllPassengers": false,
      "contactFirstName": "Fjie",
      "contactLastName": "Kfkfr",
      "email": "jdje@g.com",
      "country": "España",
      "phonePrefix": "+34",
      "phone": "654654654",
      "passenger1FirstName": "Fjie",
      "passenger1LastName": "Kfkfr",
      "passenger2FirstName": "Prueba",
      "passenger2LastName": "Mfe",
      "marketingConsent": false,
      "reservedPrice": 0,
      "currentPrice": "",
      "outboundPrice": "",
      "returnPrice": "",
      "baggagePrice": "",
      "availability": "",
      "lastUpdated": "",
      "lastAttempt": "",
      "lastError": "",
      "monitorStatus": "pending",
      "source": "",
      "history": [],
      "enabled": true,
      "scheduleTime": "06:40",
      "scheduleTimeZone": "Europe/Madrid",
      "telegramEnabled": true,
      "telegramNotifyEveryCheck": true,
      "telegramNotifyPriceDrop": true,
      "color": "#fff000",
      "gradient1": "#665f00",
      "gradient2": "#b8a900",
      "textColor": "#ffffff"
    }
  }
};
