import { SEED_DATA } from "./seed-data.js";
import { firebaseConfig, DEMO_MODE, TRIP_ID, FUNCTIONS_REGION } from "./firebase-config.js";
import { groupReceiptItems as groupReceiptItemsStrict, consolidateStoredTicketItems, receiptProductFingerprint as strictReceiptFingerprint, receiptItemCanBeGrouped as strictReceiptCanGroup, receiptUnitPriceCents, receiptLineTotal, parseMercadonaReceiptLine } from "./receipt-utils.js?v=2.2.126-r1";
import { buildDriveUploadMetadata } from "./drive-utils.js?v=2.2.126-r1";
import { normalizeProductImageFields, mergeAutomaticProductImage, applyManualProductImage, productUsesAutomaticImage } from "./product-image-utils.js?v=2.2.126-r1";
import { isHexColor, normalizeHexColor } from "./color-utils.js?v=2.2.126-r1";

const SDK_VERSION = "11.0.2";
const DEFAULT_PRICE_WORKER_URL = "https://mfe-viajes-precios.mikelferech.workers.dev";
const DEFAULT_VUELING_WORKER_URL = "https://mfe-viajes-vueling.mikelferech.workers.dev";
const APP_VERSION = "2.4.31";
const PRIMARY_ADMIN_EMAIL = "mikelferech@gmail.com";
const DEFAULT_APP_IDENTITY = Object.freeze({ name:"GC 26", icon:"26", iconUrl:"./icons/gc26-logo.png" });
const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const clone = (value) => structuredClone(value);
function firestoreSafe(value,{inArray=false}={}) {
  if(value===undefined)return inArray?null:undefined;
  if(value===null||typeof value!=="object")return value;
  if(Array.isArray(value))return value.map(item=>firestoreSafe(item,{inArray:true}));
  const out={};
  for(const [key,item] of Object.entries(value)){
    if(item===undefined)continue;
    const cleaned=firestoreSafe(item);
    if(cleaned!==undefined)out[key]=cleaned;
  }
  return out;
}
const uid = (prefix = "id") => `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2,8)}`;
const esc = (value = "") => String(value).replace(/[&<>'"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;",'"':"&quot;"}[c]));
const num = (value) => Number.parseFloat(String(value ?? 0).replace(",",".")) || 0;
const sum = (arr) => arr.reduce((acc, value) => acc + num(value), 0);
function coverChartPercent(value,total){
  if(!Number.isFinite(value)||!Number.isFinite(total)||total<=0)return 0;
  return Math.max(0,Math.min(100,(value/total)*100));
}
function coverBudgetDonut(label,amount,total,tone="success") {
  const pct=coverChartPercent(amount,total);
  const pctText=pct.toLocaleString('es-ES',{maximumFractionDigits:1});
  const ringClass=tone==="danger"?"danger":"success";
  return `<div class="kpi-chart-ring ${ringClass}" style="--pct:${pct.toFixed(2)}" aria-hidden="true"><div class="kpi-chart-ring-core"><strong>${pctText}%</strong><span>${esc(label)}</span></div></div>`;
}
const isValidUrl = (url) => { try { return Boolean(url) && ["http:","https:"].includes(new URL(url).protocol); } catch { return false; } };
const isImageSource = (url) => Boolean(url) && (isValidUrl(url) || String(url).startsWith("data:image/") || String(url).startsWith("blob:"));
const TRANSPARENT_IMAGE = "data:image/gif;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs=";
let pendingShoppingRepair = false;
let pendingReminderMigration = false;
let pendingOfficialDocumentMigration = false;
let pendingTicketItemMigration = false;
let pendingFlightServiceVisualMigration = false;
let pendingItineraryMigration = false;
let pendingExtrasMigration = false;
let pendingMenuMigration = false;
let pendingBudgetBusVisualMigration = false;
let pendingConceptIconMemoryMigration = false;
let busDriveVisualMigrationPromise = null;
let busDriveVisualMigrationCompleted = false;
const toLocalInput = (value = "") => value ? value.slice(0,16) : "";
const fromLocalInput = (value = "") => value || "";
const wait = (ms = 0) => new Promise(resolve => setTimeout(resolve, ms));
const isFirestorePermissionError = (error) => {
  const code=String(error?.code||"").toLowerCase();
  const message=String(error?.message||"").toLowerCase();
  return code.includes("permission-denied") || message.includes("missing or insufficient permissions") || message.includes("insufficient permissions");
};

function isIdentityImageSource(url="") {
  const value=String(url||"").trim();
  if(!value)return false;
  if(isImageSource(value))return true;
  // Los recursos empaquetados de la propia PWA son rutas relativas y, por diseño,
  // isImageSource() solo acepta URL http(s), data: o blob:. El login debe poder
  // cargar también ./icons/gc26-logo.png antes de que exista una sesión.
  return /^(?:\.\/|\.\.\/|\/)[^?#]+\.(?:png|jpe?g|webp|gif|svg)(?:[?#].*)?$/i.test(value);
}

function applyIdentityLogo(element, iconUrl="", icon="✈️") {
  if(!element)return;
  const bundledFallback="./icons/gc26-logo.png";
  const source=String(iconUrl||"").trim();
  const custom=Boolean(source && isIdentityImageSource(source));
  element.classList.toggle("has-custom-image",custom);
  if(custom){
    const img=document.createElement("img");
    img.src=source;
    img.alt="Logo de la aplicación";
    img.addEventListener("error",()=>{
      // Si un logo personalizado deja de ser accesible, el login conserva una
      // imagen real en lugar de degradar al texto «26».
      if(img.dataset.gc26Fallback!=="1" && source!==bundledFallback){
        img.dataset.gc26Fallback="1";
        img.src=bundledFallback;
        return;
      }
      element.classList.remove("has-custom-image");
      element.textContent=icon||"26";
    },{once:false});
    element.replaceChildren(img);
  }else{
    element.textContent=icon||"✈️";
  }
}

function isLegacyDefaultIdentity(identity={}) {
  const name=String(identity?.name||"").trim();
  const icon=String(identity?.icon||"").trim();
  const iconUrl=String(identity?.iconUrl||"").trim();
  const normalizedIcon=icon.replace(/[\uFE0E\uFE0F]/g,"").trim();
  const legacyName=!name || /^mfe\s*viajes$/i.test(name);
  const legacyPlane=!normalizedIcon || /^(?:✈|🛫|🛬|🛩)$/.test(normalizedIcon);
  const legacyIconUrl=!iconUrl || /(?:^|\/)icons\/(?:app-icon|maskable-icon)\.svg(?:[?#].*)?$/i.test(iconUrl);
  // Cualquier identidad todavía llamada «MFE Viajes» pertenece a la identidad anterior.
  // También migramos el avión antiguo aunque Android lo haya guardado con/sin selector emoji.
  return legacyName || (legacyPlane && legacyIconUrl);
}

function publicIdentity(identity={}) {
  if(isLegacyDefaultIdentity(identity))return {...DEFAULT_APP_IDENTITY};
  return {
    name:String(identity?.name||DEFAULT_APP_IDENTITY.name).trim()||DEFAULT_APP_IDENTITY.name,
    icon:String(identity?.icon||DEFAULT_APP_IDENTITY.icon).trim()||DEFAULT_APP_IDENTITY.icon,
    iconUrl:String(identity?.iconUrl||"").trim()
  };
}

function applyIdentityToPublicViews(identity={}) {
  const normalized=publicIdentity(identity);
  const name=normalized.name;
  const iconUrl=normalized.iconUrl;
  const icon=normalized.icon;
  applyIdentityLogo($("#boot-logo"),iconUrl,icon);
  applyIdentityLogo($("#login-brand-icon"),iconUrl,icon);
  const bootTitle=$("#boot-title"),loginName=$("#login-app-name");
  if(bootTitle)bootTitle.textContent=name;
  if(loginName)loginName.textContent=name;
  document.title=name;
}

function applyStoredIdentity() {
  try {
    let identity=JSON.parse(localStorage.getItem("mfe-viajes-identity")||"{}");
    if(!identity?.name && !identity?.iconUrl && !identity?.icon){
      try{
        const legacy=JSON.parse(localStorage.getItem(`mfe-travel:${TRIP_ID}`)||"{}");
        const settings=legacy?.settings||{};
        identity={name:settings.appName,icon:settings.appIcon,iconUrl:settings.appIconUrl};
      }catch{}
    }
    const normalized=publicIdentity(identity||{});
    if(isLegacyDefaultIdentity(identity||{})){
      try{localStorage.setItem("mfe-viajes-identity",JSON.stringify(normalized));}catch{}
    }
    applyIdentityToPublicViews(normalized);
  } catch {
    applyIdentityToPublicViews(DEFAULT_APP_IDENTITY);
  }
}

async function persistAppIdentity(settings={}) {
  const identity=publicIdentity({
    name:settings.appName,
    icon:settings.appIcon,
    iconUrl:settings.appIconUrl
  });
  const signature=`${identity.name}|${identity.icon}|${identity.iconUrl}`;
  if(signature===persistedIdentitySignature){
    applyIdentityToPublicViews(identity);
    return identity;
  }
  persistedIdentitySignature=signature;
  // La pantalla de acceso debe poder usar la identidad sin haber iniciado sesión.
  // Guardamos una copia compacta local del icono para evitar agotar localStorage.
  if(identity.iconUrl && isImageSource(identity.iconUrl)){
    try{
      const compact=await buildAdaptiveInstallIcon(identity.iconUrl,{size:160,padding:.08,background:'transparent',trimAlpha:4});
      if(compact)identity.iconUrl=compact;
    }catch{}
  }
  try{
    localStorage.setItem('mfe-viajes-identity',JSON.stringify(identity));
  }catch(error){
    console.warn('No se pudo guardar la identidad visual local completa',error);
    try{localStorage.setItem('mfe-viajes-identity',JSON.stringify({name:identity.name,icon:identity.icon,iconUrl:''}));}catch{}
  }
  applyIdentityToPublicViews(identity);
  return identity;
}

function normalizeFileList(value = []) {
  if (!Array.isArray(value)) return [];
  const usedIds = new Set();
  return value.filter(Boolean).map((file,index) => {
    const rawUrl = String(file.url || file.driveUrl || "");
    const mimeType = String(file.mimeType || "").toLowerCase();
    const looksLikeImage = file.type === "image" || mimeType.startsWith("image/") || /\.(png|jpe?g|webp|gif|svg)(?:$|[?#])/i.test(rawUrl) || /^data:image\//i.test(rawUrl);
    const type = file.type === "web" ? "web" : (looksLikeImage ? "image" : "file");
    let id = String(file.id || "").trim() || uid("file");
    while (usedIds.has(id)) id = uid("file");
    usedIds.add(id);
    return {
      ...file,
      id,
      label: file.label || file.name || `Archivo ${index + 1}`,
      url: file.url || "",
      type,
      mimeType: file.mimeType || "",
      hidden: file.hidden === true,
      keepOnArchive: file.keepOnArchive === true
    };
  });
}

function normalizedOfficialDocuments(person, value = []) {
  const docs = Array.isArray(value) ? value : [];
  const usedIds = new Set();
  return docs.map((doc,index) => {
    const slug = String(doc?.title || `documento-${index + 1}`)
      .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
      .toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || `documento-${index + 1}`;
    let id = String(doc?.id || "").trim();
    if (!id || usedIds.has(id)) {
      id = `official-${person}-${slug}-${index + 1}`;
      pendingOfficialDocumentMigration = true;
    }
    while (usedIds.has(id)) { id = `${id}-${index + 1}`; pendingOfficialDocumentMigration = true; }
    usedIds.add(id);
    return { ...doc, id, files:normalizeFileList(doc?.files) };
  });
}


function defaultFlightServiceButtons(flight={}) {
  const airport=departureAirportInfo(flight.from||"");
  const digits=String(flight.number||"").match(/(\d{3,5})/)?.[1]||"";
  const flightAwareCode=digits?`VLG${digits}`:"";
  return {
    vuelingButtonLabel:"Vueling",
    vuelingButtonUrl:"https://www.vueling.com/es/servicios-vueling/informacion-de-vuelos/estado-de-vuelos",
    vuelingButtonColor:"#FFD000",
    vuelingButtonIcon:"✈️",
    vuelingButtonIconUrl:"",
    aenaButtonLabel:`AENA ${airport.name}`,
    aenaButtonUrl:airport.departuresUrl||airport.url,
    aenaButtonColor:"#008C7A",
    aenaButtonIcon:"🛫",
    aenaButtonIconUrl:"",
    flightAwareButtonLabel:"FlightAware",
    flightAwareButtonUrl:flightAwareCode?`https://es.flightaware.com/live/flight/${flightAwareCode}`:"",
    flightAwareButtonColor:"#1675D1",
    flightAwareButtonIcon:"◉",
    flightAwareButtonIconUrl:"",
    vuelingCheckinLabel:"Check-in",
    vuelingCheckinUrl:"https://link.vueling.com/checkin",
    vuelingTripsLabel:"Mis viajes",
    vuelingTripsUrl:"https://link.vueling.com/mmbit",
    walletMikelUrl:"",
    walletNereaUrl:"",
    boardingPasses:{mikel:[],nerea:[]}
  };
}
function defaultLodgingReviewButtons(){
  return {
    googleReviewsLabel:"Google", googleReviewsColor:"#4285F4", googleReviewsIcon:"", googleReviewsIconUrl:"",
    tripadvisorReviewsLabel:"Tripadvisor", tripadvisorReviewsColor:"#34E0A1", tripadvisorReviewsIcon:"", tripadvisorReviewsIconUrl:"",
    bookingReviewsLabel:"Booking", bookingReviewsColor:"#003B95", bookingReviewsIcon:"", bookingReviewsIconUrl:""
  };
}
function spanishTripadvisorUrl(raw="") {
  const value=String(raw||"").trim();
  if(!value)return value;
  try{
    const url=new URL(value);
    if(/(^|\.)tripadvisor\.com$/i.test(url.hostname)){
      url.hostname="www.tripadvisor.es";
      return url.toString();
    }
  }catch{}
  return value;
}
function coverCarouselPlacement(carousel={}){
  return carousel?.placement==="lodging"?"lodging":"cover";
}

function normalizeStoredTicketItems(value = []) {
  const source = Array.isArray(value) ? value : [];
  const before = JSON.stringify(source.map(item => ({
    store:item?.store||'', name:item?.name||'', quantity:num(item?.quantity)||1,
    price:num(item?.price), unitPrice:num(item?.unitPrice), date:item?.date||''
  })));
  const consolidated = consolidateStoredTicketItems(source).map(item => ({
    ...item,
    id: item.id || uid('ocr'),
    quantity: Math.max(.01, num(item.quantity) || 1),
    price: Number(num(item.price).toFixed(2)),
    unitPrice: Number((num(item.unitPrice) || (num(item.price) / Math.max(.01, num(item.quantity) || 1))).toFixed(2))
  }));
  const after = JSON.stringify(consolidated.map(item => ({
    store:item.store||'', name:item.name||'', quantity:item.quantity,
    price:item.price, unitPrice:item.unitPrice, date:item.date||''
  })));
  if (before !== after || source.some(item=>!Array.isArray(item?.ticketBreakdown))) pendingTicketItemMigration = true;
  return consolidated;
}

function tripMenuDates(settings={}) {
  const start=String(settings.departureDateTime||"").slice(0,10),end=String(settings.returnDateTime||"").slice(0,10);
  if(!/^\d{4}-\d{2}-\d{2}$/.test(start)||!/^\d{4}-\d{2}-\d{2}$/.test(end)||start>end)return [];
  const out=[];let cursor=new Date(`${start}T12:00:00`),limit=new Date(`${end}T12:00:00`),guard=0;
  while(cursor<=limit&&guard++<62){out.push(cursor.toISOString().slice(0,10));cursor.setDate(cursor.getDate()+1);}
  return out;
}
function normalizeMenuDays(menu,settings){
  const existing=Array.isArray(menu?.days)?menu.days:[],byDate=new Map(existing.map(day=>[String(day.date||""),day]));
  const dates=tripMenuDates(settings);
  const normalizeDay=(date,day={})=>({date,breakfast:day.breakfast||"",lunch:day.lunch||"",dinner:day.dinner||"",notes:day.notes||"",showBreakfast:day.showBreakfast!==false,showLunch:day.showLunch!==false,showDinner:day.showDinner!==false});
  if(!dates.length)return existing.map(day=>normalizeDay(String(day.date||""),day));
  const next=dates.map((date,index)=>{
    const direct=byDate.get(date);
    if(direct)return normalizeDay(date,direct);
    const fallback=existing[index]||{};
    return normalizeDay(date,fallback);
  });
  if(JSON.stringify(next)!==JSON.stringify(existing))pendingMenuMigration=true;
  return next;
}
function syncMenuDaysWithTripDates(){
  state.data.menu=state.data.menu||{days:[]};state.data.menu.days=normalizeMenuDays(state.data.menu,state.data.settings);
}
function normalizeSuitcaseGroup(group={},index=0){
  const subgroups=(Array.isArray(group?.subgroups)?group.subgroups:[]).map((subgroup,subIndex)=>(
    {
      id:String(subgroup?.id||'').trim()||`suitcase-subgroup-${index+1}-${subIndex+1}`,
      name:String(subgroup?.name||`Subgrupo ${subIndex+1}`).trim()||`Subgrupo ${subIndex+1}`,
      icon:String(subgroup?.icon||'').trim(),
      iconUrl:String(subgroup?.iconUrl||'').trim(),
      color:String(subgroup?.color||group?.color||'#4da3ff').trim()||'#4da3ff',
      textColor:String(subgroup?.textColor||group?.textColor||'#ffffff').trim()||'#ffffff'
    }
  ));
  const allowed=new Set(subgroups.map(subgroup=>subgroup.id));
  const items=(Array.isArray(group?.items)?group.items:[]).map((item,itemIndex)=>({
    ...item,
    id:String(item?.id||'').trim()||`suitcase-item-${index+1}-${itemIndex+1}`,
    name:String(item?.name||'').trim(),
    checked:Boolean(item?.checked),
    subgroupId:allowed.has(String(item?.subgroupId||''))?String(item.subgroupId):''
  }));
  return {...group,textColor:String(group?.textColor||'#ffffff').trim()||'#ffffff',subgroups,items};
}
function normalizeSuitcaseCollection(source=[],fallback=[]){
  const groups=Array.isArray(source)?source:(Array.isArray(fallback)?fallback:[]);
  return groups.map((group,index)=>normalizeSuitcaseGroup(group,index));
}

function syncBudgetBusHeaderVisual(data={},sourceBus=null){
  const groups=Array.isArray(data?.budget?.groups)?data.budget.groups:[];
  const group=groups.find(item=>item?.id==='g-bus');
  const buses=Array.isArray(data?.cover?.buses)?data.cover.buses:[];
  const bus=sourceBus||buses.find(item=>item&&item.visible!==false)||buses[0];
  if(!group||!bus)return false;
  const next={
    gradient1:String(bus.gradient1||bus.color||group.gradient1||group.color||'#173f53'),
    gradient2:String(bus.gradient2||bus.color||group.gradient2||group.color||'#2d7895'),
    textColor:String(bus.textColor||group.textColor||'#ffffff')
  };
  let changed=false;
  for(const [key,value] of Object.entries(next)){
    if(String(group[key]||'')!==value){group[key]=value;changed=true;}
  }
  return changed;
}
// v2.4.10 · Cordial: resúmenes e históricos usan Reserva Online sin gastos, no Prepago.
// v2.4.9 · Memoria persistente de iconos por concepto/comercio.
function budgetConceptIconKey(value=''){
  return String(value||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase('es').replace(/[^a-z0-9]+/g,' ').trim().replace(/\s+/g,' ');
}
function normalizeBudgetConceptIconMemory(value={}){
  const out={};
  if(!value||typeof value!=='object'||Array.isArray(value))return out;
  for(const [rawKey,raw] of Object.entries(value)){
    const key=budgetConceptIconKey(raw?.name||rawKey),icon=String(raw?.icon||'').trim(),iconUrl=String(raw?.iconUrl||'').trim();
    if(!key||(!icon&&!iconUrl))continue;
    out[key]={name:String(raw?.name||rawKey).trim()||rawKey,icon,iconUrl};
  }
  return out;
}
function mergedBudgetConceptIconMemory(data={}){
  const out={};
  const put=(name,value={})=>{
    const label=String(name||'').trim(),key=budgetConceptIconKey(label),icon=String(value?.icon||'').trim(),iconUrl=String(value?.iconUrl||'').trim();
    if(!key||(!icon&&!iconUrl))return;
    out[key]={name:label||String(value?.name||'').trim()||key,icon,iconUrl};
  };
  // Histórico: del más antiguo al más reciente para que el último icono usado gane.
  for(const archive of [...(data.history?.archives||[])].reverse()){
    for(const group of archive?.budget?.groups||[])for(const item of group?.items||[])put(item?.name,item);
    for(const item of archive?.purchases?.extras||[])put(item?.name,item);
    for(const item of archive?.purchases?.otherExpenses||[])put(item?.name,item);
  }
  // La memoria ya guardada prevalece sobre históricos antiguos.
  for(const record of Object.values(normalizeBudgetConceptIconMemory(data.budget?.conceptIconMemory||{})))put(record.name,record);
  // Los datos del viaje activo son la referencia más reciente.
  for(const group of data.budget?.groups||[])for(const item of group?.items||[])put(item?.name,item);
  for(const item of data.purchases?.extras||[])put(item?.name,item);
  for(const item of data.purchases?.otherExpenses||[])put(item?.name,item);
  return out;
}

function normalizeData(data = {}) {
  const base = clone(SEED_DATA);
  const incoming = data || {};
  const settings = incoming.settings || {};
  const incomingCover = incoming.cover || {};
  const incomingPurchases = incoming.purchases || {};
  const normalized = {
    ...base,
    ...incoming,
    settings: {
      ...base.settings,
      ...settings,
      theme: { ...base.settings.theme, ...(settings.theme || {}) },
      sectionColors: { ...base.settings.sectionColors, ...(settings.sectionColors || {}) },
      tabIconUrls: { ...base.settings.tabIconUrls, ...(settings.tabIconUrls || {}) },
      historyDriveFolder: { ...(base.settings.historyDriveFolder || {}), ...(settings.historyDriveFolder || {}) },
      enabledTabs: Array.isArray(settings.enabledTabs) ? settings.enabledTabs : base.settings.enabledTabs,
      tabOrder: Array.isArray(settings.tabOrder) && settings.tabOrder.length ? settings.tabOrder : base.settings.tabOrder,
      coverOrder: Array.isArray(settings.coverOrder) && settings.coverOrder.length ? settings.coverOrder : base.settings.coverOrder,
      desktopCoverOrder: Array.isArray(settings.desktopCoverOrder) && settings.desktopCoverOrder.length ? settings.desktopCoverOrder : (base.settings.desktopCoverOrder || base.settings.coverOrder),
      desktopCoverWidths: { ...(base.settings.desktopCoverWidths || {}), ...(settings.desktopCoverWidths || {}) },
      coverHiddenBlocks: Array.isArray(settings.coverHiddenBlocks) ? settings.coverHiddenBlocks : (base.settings.coverHiddenBlocks || []),
      tripDataSectionOrder: Array.isArray(settings.tripDataSectionOrder) && settings.tripDataSectionOrder.length ? settings.tripDataSectionOrder : (base.settings.tripDataSectionOrder || ['travel','rental','stores']),
      tripTransportOrder: Array.isArray(settings.tripTransportOrder) && settings.tripTransportOrder.length ? settings.tripTransportOrder : (base.settings.tripTransportOrder || []),
      budgetGroupOrderCustomized: settings.budgetGroupOrderCustomized===true,
      countdownImageCrop: { ...base.settings.countdownImageCrop, ...(settings.countdownImageCrop || {}) },
      officialDocumentHeaders: {
        mikel: { ...base.settings.officialDocumentHeaders?.mikel, ...(settings.officialDocumentHeaders?.mikel || {}) },
        nerea: { ...base.settings.officialDocumentHeaders?.nerea, ...(settings.officialDocumentHeaders?.nerea || {}) }
      },
      poolPanel: {
        ...(base.settings.poolPanel || {}),
        ...(settings.poolPanel || {}),
        sectionOrder: (Array.isArray(settings.poolPanel?.sectionOrder) && settings.poolPanel.sectionOrder.length ? settings.poolPanel.sectionOrder : (base.settings.poolPanel?.sectionOrder || ['webcams','pools','temperatureChart','source'])).filter(id=>id!=='spa'),
        hiddenSections: Array.isArray(settings.poolPanel?.hiddenSections) ? settings.poolPanel.hiddenSections : (base.settings.poolPanel?.hiddenSections || []),
        poolOrder: Array.isArray(settings.poolPanel?.poolOrder) ? settings.poolPanel.poolOrder : [],
        poolStyles: { ...(base.settings.poolPanel?.poolStyles || {}), ...(settings.poolPanel?.poolStyles || {}) },
        webcams: { ...(base.settings.poolPanel?.webcams || {}), ...(settings.poolPanel?.webcams || {}) }
      }
    },
    cover: {
      ...base.cover,
      ...incomingCover,
      lodging: {
        ...base.cover.lodging,
        ...(incomingCover.lodging || {}),
        guestGuideLabel:(()=>{const v=String(incomingCover.lodging?.guestGuideLabel||base.cover.lodging.guestGuideLabel||'').trim();return (!v||/gu[ií]a del resort|piscinas y servicios|temperatura piscinas/i.test(v))?'Temp Piscinas':v;})(),
        tripadvisorReviewsUrl:spanishTripadvisorUrl(incomingCover.lodging?.tripadvisorReviewsUrl||base.cover.lodging.tripadvisorReviewsUrl||""),
        imageCrop: { ...base.cover.lodging.imageCrop, ...(incomingCover.lodging?.imageCrop || {}) }
      },
      flights: Array.isArray(incomingCover.flights)
        ? incomingCover.flights.map(f => {
            const { status, terminal, gate, checkInCounters, source, lastUpdated, flightAwareUrl, ...rest } = f || {};
            const defaults=defaultFlightServiceButtons({...rest,flightAwareUrl});
            const legacyFlightAware=String(flightAwareUrl||'').replace('https://www.flightaware.com','https://es.flightaware.com');
            const migratedRest={...rest};
            // v2.1.43: migra el deep link antiguo de Check-in y acorta la etiqueta de Mis viajes.
            if(!migratedRest.vuelingCheckinUrl || /link\.vueling\.com\/checkinen\/?(?:$|[?#])/i.test(String(migratedRest.vuelingCheckinUrl))){
              migratedRest.vuelingCheckinUrl=defaults.vuelingCheckinUrl;
            }
            if(!migratedRest.vuelingTripsLabel || String(migratedRest.vuelingTripsLabel).trim().toLowerCase()==='mis viajes / tarjetas'){
              migratedRest.vuelingTripsLabel='Mis viajes';
            }
            return {
              checkInReminderHours:25, leaveAirportReminder:"",
              ...defaults,
              ...migratedRest,
              boardingPasses:{
                mikel:normalizeFileList(migratedRest.boardingPasses?.mikel||[]),
                nerea:normalizeFileList(migratedRest.boardingPasses?.nerea||[])
              },
              flightAwareButtonUrl:migratedRest.flightAwareButtonUrl||legacyFlightAware||defaults.flightAwareButtonUrl
            };
          })
        : base.cover.flights,
      buses: (Array.isArray(incomingCover.buses) ? incomingCover.buses : (base.cover.buses || [])).map((bus,index)=>({
        id:String(bus?.id||'').trim()||`bus-${index+1}`,
        type:String(bus?.type||'IDA').trim()||'IDA',
        visible:bus?.visible!==false,
        company:String(bus?.company||'').trim(),
        serviceNumber:String(bus?.serviceNumber||'').trim(),
        from:String(bus?.from||'').trim(),
        to:String(bus?.to||'').trim(),
        date:String(bus?.date||'').trim(),
        departure:String(bus?.departure||'').trim(),
        arrival:String(bus?.arrival||'').trim(),
        durationOverride:String(bus?.durationOverride||'').trim(),
        passengers:Math.max(1,num(bus?.passengers)||num(settings.people)||1),
        pricePerPerson:Math.max(0,num(bus?.pricePerPerson)),
        status:bus?.status==='paid'?'paid':'unpaid',
        reference:String(bus?.reference||'').trim(),
        notes:String(bus?.notes||'').trim()==='Autobús al aeropuerto antes del vuelo de ida.'?'':String(bus?.notes||''),
        budgetTitle:String(bus?.budgetTitle||''),
        budgetDetail:String(bus?.budgetDetail||''),
        purchaseButtonLabel:String(bus?.purchaseButtonLabel||'Comprar billetes').trim()||'Comprar billetes',
        purchaseUrl:String(bus?.purchaseUrl||''),
        purchaseButtonColor:String(bus?.purchaseButtonColor||'#f2d600'),
        purchaseButtonIcon:String(bus?.purchaseButtonIcon||'🎫'),
        purchaseButtonIconUrl:String(bus?.purchaseButtonIconUrl||''),
        departureMapsUrl:String(bus?.departureMapsUrl||''),
        arrivalMapsUrl:String(bus?.arrivalMapsUrl||''),
        icon:String(bus?.icon||'🚌'),
        iconUrl:String(bus?.iconUrl||''),
        logoUrl:String(bus?.logoUrl||''),
        color:String(bus?.color||'#49b6d6'),
        gradient1:String(bus?.gradient1||'#173f53'),
        gradient2:String(bus?.gradient2||'#2d7895'),
        textColor:String(bus?.textColor||'#ffffff'),
        styleCustomized:bus?.styleCustomized===true,
        // Adjuntos de Presupuesto y de la ficha "Reservas y documentos" son independientes.
        // Para datos antiguos, documentFiles se inicia una sola vez con una copia de files
        // para no perder los billetes que ya se veían en Portada antes de la separación.
        files:normalizeFileList(bus?.files||[]),
        documentFiles:normalizeFileList(Array.isArray(bus?.documentFiles)?bus.documentFiles:(bus?.files||[]))
      })),
      documents: Array.isArray(incomingCover.documents)
        ? incomingCover.documents.map(doc => {
            const files=normalizeFileList(doc.files);
            const legacyUrl=doc.url||doc.driveUrl||"";
            if(isValidUrl(legacyUrl)&&!files.some(file=>file.url===legacyUrl)){
              const legacyType=doc.linkType==="web"?"web":doc.linkType==="image"?"image":"file";
              files.push({id:uid("legacy-cover-file"),label:doc.buttonLabel||doc.title||"Abrir",url:legacyUrl,type:legacyType});
            }
            return { linkType:"auto", buttonLabel:"", files:[], textColor:'#ffffff', ...doc, files };
          })
        : base.cover.documents,
      mediaCarousels: (Array.isArray(incomingCover.mediaCarousels) ? incomingCover.mediaCarousels : base.cover.mediaCarousels || []).map((carousel,index)=>{
        const title=String(carousel?.title||`Carrusel ${index+1}`).trim()||`Carrusel ${index+1}`;
        const legacyLodgingCarousel=/\b(plano|instruccion(?:es)?)\b/i.test(title.normalize('NFD').replace(/[\u0300-\u036f]/g,''));
        const placement=carousel?.placement==='lodging'||carousel?.placement==='cover'?carousel.placement:(legacyLodgingCarousel?'lodging':'cover');
        return {
          id:String(carousel?.id||'').trim()||`cover-carousel-${index+1}`,
          title,
          subtitle:String(carousel?.subtitle||''),
          placement,
          files:normalizeFileList(carousel?.files).filter(file=>file.type==='image'||String(file.mimeType||'').toLowerCase()==='application/pdf'||/\.pdf(?:$|[?#])/i.test(String(file.url||file.driveUrl||'')))
        };
      }),
      externalImages: Array.isArray(incomingCover.externalImages) ? incomingCover.externalImages : base.cover.externalImages
    },
    purchases: {
      ...base.purchases,
      ...incomingPurchases,
      records: Array.isArray(incomingPurchases.records) ? incomingPurchases.records : base.purchases.records,
      ticketItems: normalizeStoredTicketItems(Array.isArray(incomingPurchases.ticketItems) ? incomingPurchases.ticketItems : base.purchases.ticketItems),
      otherExpenses: Array.isArray(incomingPurchases.otherExpenses) ? incomingPurchases.otherExpenses : (base.purchases.otherExpenses || []),
      extras: (Array.isArray(incomingPurchases.extras) ? incomingPurchases.extras : (base.purchases.extras || [])).map(extra=>({
        id:extra?.id||uid("purchase-extra"), date:extra?.date||"", category:extra?.category||"Extra", name:extra?.name||"",
        amount:num(extra?.amount), status:extra?.status==="paid"?"paid":"unpaid", icon:extra?.icon||"✨", iconUrl:extra?.iconUrl||"",
        notes:extra?.notes||"", fileUrl:extra?.fileUrl||"", ...extra
      }))
    },
    itinerary: {
      ...base.itinerary,
      ...(incoming.itinerary || {}),
      activities: Array.isArray(incoming.itinerary?.activities) ? incoming.itinerary.activities : base.itinerary.activities,
      view: ["calendar","list"].includes(String(incoming.itinerary?.view||"").trim().toLowerCase()) ? String(incoming.itinerary.view).trim().toLowerCase() : "calendar",
      defaultCalendarApplied: incoming.itinerary?.defaultCalendarApplied===true
    },
    shopping: {
      ...base.shopping,
      ...(incoming.shopping || {}),
      stores: Array.isArray(incoming.shopping?.stores) ? incoming.shopping.stores : base.shopping.stores,
      priceTracking: {
        schedule:["daily","every2days","manual"].includes(incoming.shopping?.priceTracking?.schedule)?incoming.shopping.priceTracking.schedule:(base.shopping?.priceTracking?.schedule||"daily"),
        lastRunAt:String(incoming.shopping?.priceTracking?.lastRunAt||""),
        lastAutoRunAt:String(incoming.shopping?.priceTracking?.lastAutoRunAt||""),
        snapshots:Array.isArray(incoming.shopping?.priceTracking?.snapshots)?incoming.shopping.priceTracking.snapshots.slice(-SHOPPING_HISTORY_MAX_SNAPSHOTS):[],
        changes:Array.isArray(incoming.shopping?.priceTracking?.changes)?incoming.shopping.priceTracking.changes.slice(-SHOPPING_HISTORY_MAX_CHANGES):[],
        lastChanges:Array.isArray(incoming.shopping?.priceTracking?.lastChanges)?incoming.shopping.priceTracking.lastChanges:[],
        lastSource:String(incoming.shopping?.priceTracking?.lastSource||"")
      }
    },
    suitcases: {
      common: normalizeSuitcaseCollection(incoming.suitcases?.common,base.suitcases?.common),
      mikel: normalizeSuitcaseCollection(incoming.suitcases?.mikel,base.suitcases?.mikel),
      nerea: normalizeSuitcaseCollection(incoming.suitcases?.nerea,base.suitcases?.nerea)
    },
    tasks: {
      ...base.tasks,
      ...(incoming.tasks || {}),
      items: Array.isArray(incoming.tasks?.items) ? incoming.tasks.items : base.tasks.items
    },
    emergency: {
      ...base.emergency,
      ...(incoming.emergency || {}),
      contacts: (Array.isArray(incoming.emergency?.contacts) ? incoming.emergency.contacts : base.emergency.contacts).map(contact => ({
        icon:"☎️", iconUrl:"", color:"#4da3ff", gradient1:"", gradient2:"", textColor:"#ffffff", ...contact
      })),
      documents: {
        mikel: normalizedOfficialDocuments("mikel", Array.isArray(incoming.emergency?.documents?.mikel) ? incoming.emergency.documents.mikel : base.emergency.documents.mikel),
        nerea: normalizedOfficialDocuments("nerea", Array.isArray(incoming.emergency?.documents?.nerea) ? incoming.emergency.documents.nerea : base.emergency.documents.nerea)
      }
    },
    trackers: {
      ...base.trackers,
      order: [...new Set([...(Array.isArray(incoming.trackers?.order) ? incoming.trackers.order : []), ...base.trackers.order])].filter(id=>["autoreisen","cordial","vueling","fuel"].includes(id)),
      visible: {
        autoreisen: incoming.trackers?.visible?.autoreisen ?? base.trackers.visible.autoreisen,
        cordial: incoming.trackers?.visible?.cordial ?? base.trackers.visible.cordial,
        vueling: incoming.trackers?.visible?.vueling ?? base.trackers.visible.vueling,
        fuel: incoming.trackers?.visible?.fuel ?? base.trackers.visible.fuel
      },
      autoreisen: { ...base.trackers.autoreisen, title:"AutoReisen", titleIcon:TRACKER_DEFAULT_ICONS.autoreisen, titleIconUrl:"", color:"#74b64c", gradient1:"#294c1d", gradient2:"#477c2f", textColor:"#ffffff", lastError:"", monitorStatus:"pending", ...(incoming.trackers?.autoreisen || {}) },
      cordial: { ...base.trackers.cordial, title:"Cordial Santa Águeda", titleIcon:TRACKER_DEFAULT_ICONS.cordial, titleIconUrl:"", color:"#35a5d6", gradient1:"#113b58", gradient2:"#166b91", textColor:"#ffffff", lastError:"", monitorStatus:"pending", ...(incoming.trackers?.cordial || {}) },
      vueling: { ...base.trackers.vueling, title:"Vueling", titleIcon:TRACKER_DEFAULT_ICONS.vueling, titleIconUrl:"", color:"#fff000", gradient1:"#665f00", gradient2:"#b8a900", textColor:"#ffffff", lastError:"", monitorStatus:"pending", ...(incoming.trackers?.vueling || {}) },
      fuel: { ...base.trackers.fuel, title:"Gasolineras", titleIcon:TRACKER_DEFAULT_ICONS.fuel, titleIconUrl:"", color:"#4da3ff", gradient1:"#173b61", gradient2:"#285f91", textColor:"#ffffff", ...(incoming.trackers?.fuel || {}) }
    }
  };
  // v2.2.51: escalona los tres monitores diarios para reducir coincidencias en GitHub Actions.
  const targetTrackerTimes={autoreisen:"06:30",cordial:"06:35",vueling:"06:40"};
  const legacyTrackerTimes={autoreisen:new Set(["","07:30"]),cordial:new Set(["","08:00","06:30"]),vueling:new Set(["","09:00","06:30"])};
  for(const id of ["autoreisen","cordial","vueling"]){
    const tracker=normalized.trackers?.[id];if(!tracker)continue;
    const currentTime=String(tracker.scheduleTime||"").trim();
    if(legacyTrackerTimes[id].has(currentTime))tracker.scheduleTime=targetTrackerTimes[id];
    tracker.scheduleTimeZone="Europe/Madrid";
  }
  if(String(normalized.trackers?.vueling?.title||'').trim()==='Vueling · precio final')normalized.trackers.vueling.title='Vueling';

  // v2.4.5: selector móvil robusto de Configuración y gráficos ampliables con tooltips al pulsar.
  {const ar=normalized.trackers?.autoreisen;if(ar){
    ar.fleetTrackAll=ar.fleetTrackAll!==false;
    ar.fleetTrackGroups=[...new Set((Array.isArray(ar.fleetTrackGroups)?ar.fleetTrackGroups:[]).map(x=>String(x||'').trim()).filter(Boolean))];
    ar.fleetPrices=Array.isArray(ar.fleetPrices)?ar.fleetPrices:[];
    ar.fleetPriceHistory=Array.isArray(ar.fleetPriceHistory)?ar.fleetPriceHistory.slice(-180):[];
  }}
  {const cordial=normalized.trackers?.cordial;if(cordial){
    cordial.roomPriceHistory=Array.isArray(cordial.roomPriceHistory)?cordial.roomPriceHistory.slice(-180):[];
  }}
  // v2.4.31 · Vueling: hasta 5 pasajeros y 3 maletas facturadas configurables individualmente.
  {const vueling=normalized.trackers?.vueling;if(vueling){
    vueling.adults=Math.max(1,Math.min(5,num(vueling.adults)||1));
    vueling.children=Math.max(0,Math.min(4,num(vueling.children)||0));
    vueling.infants=Math.max(0,Math.min(4,num(vueling.infants)||0));
    const total=vueling.adults+vueling.children+vueling.infants;
    if(total>5){
      const overflow=total-5;
      if(vueling.infants>=overflow)vueling.infants-=overflow;
      else{const rest=overflow-vueling.infants;vueling.infants=0;vueling.children=Math.max(0,vueling.children-rest);}
    }
    vueling.checkedBags=normalizeVuelingCheckedBags(vueling);
    const firstBag=vueling.checkedBags[0];
    vueling.checkedBagCount=vueling.checkedBags.length;
    vueling.checkedBagKg=firstBag?.kg||25;
    vueling.checkedBagPassenger=firstBag?.passenger||1;
    vueling.sameBaggageRoundTrip=Boolean(firstBag&&vueling.checkedBags.every(b=>b.outbound&&b.return));
  }}

  // v2.3.10: los colores personalizados del autobús son propios de cada ficha y
  // nunca vuelven a ser sustituidos por la paleta global al guardar Configuración.
  for(const bus of (normalized.cover.buses||[])){
    const company=String(bus?.company||'').toLowerCase();
    const looksLegacy=!bus.styleCustomized && ['#49b6d6','#173f53','#2d7895'].includes(String(bus.color||'').toLowerCase()) || !bus.styleCustomized && String(bus.gradient1||'').toLowerCase()==='#173f53';
    if((company.includes('avanza')||company.includes('pesa'))&&looksLegacy){
      bus.color='#DA252E';bus.gradient1='#DA252E';bus.gradient2='#55135A';bus.textColor=bus.textColor||'#ffffff';bus.styleCustomized=true;
    }
  }

  // v2.4.29: los datos operativos de Aena nunca se reutilizan como plantilla.
  // Terminal, puerta, mostradores, embarque y cinta solo pueden venir del resultado
  // actual que coincida con número de vuelo + fecha exacta.
  for(const flight of (normalized.cover.flights||[])){
    if(flight?.operationalHints){
      delete flight.operationalHints;
      pendingFlightServiceVisualMigration=true;
    }
  }

  if(normalized.itinerary.defaultCalendarApplied!==true){
    normalized.itinerary.view='calendar';
    normalized.itinerary.defaultCalendarApplied=true;
    pendingItineraryMigration=true;
  }

  normalized.settings.tabOrder = [...new Set([...(normalized.settings.tabOrder || []), ...TABS.map(t => t[0])])]
    .filter(id => TABS.some(t => t[0] === id));
  const coverKeys=["countdown","weather","flights","lodging","budget","trackersSummary","documents","mediaCarousels","externalImages"];
  const hadTrackersSummaryInCover=Array.isArray(normalized.settings.coverOrder)&&normalized.settings.coverOrder.includes("trackersSummary");
  normalized.settings.coverOrder=[...new Set([...(normalized.settings.coverOrder||[]),...coverKeys])].filter(id=>coverKeys.includes(id));
  if(!hadTrackersSummaryInCover){const from=normalized.settings.coverOrder.indexOf("trackersSummary"),afterBudget=normalized.settings.coverOrder.indexOf("budget")+1;if(from>=0){normalized.settings.coverOrder.splice(from,1);normalized.settings.coverOrder.splice(Math.max(0,afterBudget),0,"trackersSummary");}}
  const carouselLayoutKeys=(normalized.cover.mediaCarousels||[]).map((carousel,index)=>({carousel,index})).filter(({carousel})=>coverCarouselPlacement(carousel)==='cover').map(({carousel,index})=>`mediaCarousel:${String(carousel?.id||`cover-carousel-${index+1}`)}`);
  const journeyHiddenKeys=[
    ...(normalized.cover.buses||[]).filter(bus=>bus&&bus.visible!==false).map((item,index)=>coverJourneyVisibilityKey('bus',item,index)),
    ...(normalized.cover.flights||[]).map((item,index)=>coverJourneyVisibilityKey('flight',item,index))
  ];
  const documentHiddenKeys=(normalized.cover.documents||[]).map((item,index)=>coverDocumentVisibilityKey(item,index));
  const allowedCoverHiddenKeys=[...coverKeys.filter(id=>id!=='flights'&&id!=='documents'),...carouselLayoutKeys,...journeyHiddenKeys,...documentHiddenKeys];
  // v2.3.19: Transportes y vuelos y Documentos y reservas se controlan ficha a ficha.
  // Los antiguos ocultados globales se descartan para que cada elemento pueda decidirse individualmente.
  normalized.settings.coverHiddenBlocks=[...new Set(normalized.settings.coverHiddenBlocks||[])].filter(id=>allowedCoverHiddenKeys.includes(id));
  const desktopKeys=["countdown","weather","flights","lodging","budget","trackersSummary","documents",...carouselLayoutKeys,"externalImages"];
  const previousDesktopOrder=Array.isArray(normalized.settings.desktopCoverOrder)?normalized.settings.desktopCoverOrder:[];
  const hadTrackersSummaryInDesktop=previousDesktopOrder.includes("trackersSummary");
  const migratedDesktopOrder=[];
  for(const id of previousDesktopOrder){
    if(id==="mediaCarousels"){for(const carouselId of carouselLayoutKeys)if(!migratedDesktopOrder.includes(carouselId))migratedDesktopOrder.push(carouselId);continue;}
    if(desktopKeys.includes(id)&&!migratedDesktopOrder.includes(id))migratedDesktopOrder.push(id);
  }
  for(const id of desktopKeys)if(!migratedDesktopOrder.includes(id))migratedDesktopOrder.push(id);
  // v2.2.52: el orden de los carruseles en Configuración manda también en la Portada de escritorio.
  // Conservamos las posiciones relativas frente a otros bloques, pero rellenamos los huecos de carrusel
  // siguiendo exactamente el orden de cover.mediaCarousels.
  let carouselOrderCursor=0;
  normalized.settings.desktopCoverOrder=migratedDesktopOrder.map(id=>{
    if(!String(id).startsWith("mediaCarousel:"))return id;
    return carouselLayoutKeys[carouselOrderCursor++]||id;
  }).filter((id,index,array)=>desktopKeys.includes(id)&&array.indexOf(id)===index);
  for(const id of desktopKeys)if(!normalized.settings.desktopCoverOrder.includes(id))normalized.settings.desktopCoverOrder.push(id);
  if(!hadTrackersSummaryInDesktop){const from=normalized.settings.desktopCoverOrder.indexOf("trackersSummary"),afterBudget=normalized.settings.desktopCoverOrder.indexOf("budget")+1;if(from>=0){normalized.settings.desktopCoverOrder.splice(from,1);normalized.settings.desktopCoverOrder.splice(Math.max(0,afterBudget),0,"trackersSummary");}}
  const oldDesktopWidths=normalized.settings.desktopCoverWidths||{},legacyCarouselWidth=oldDesktopWidths.mediaCarousels==="half"?"half":"full";
  // v2.2.61: un ancho específico de carrusel manda siempre sobre el valor legado global.
  // Antes, un `mediaCarousel:<id>` guardado explícitamente como "full" se ignoraba al recargar
  // y volvía al antiguo ancho de `mediaCarousels`, normalmente "half".
  normalized.settings.desktopCoverWidths=Object.fromEntries(desktopKeys.map(id=>{
    const explicit=oldDesktopWidths[id];
    if(explicit==="half"||explicit==="full")return [id,explicit];
    return [id,id.startsWith("mediaCarousel:")?legacyCarouselWidth:"full"];
  }));
  normalized.settings.enabledTabs = [...new Set([...(normalized.settings.enabledTabs || []), "settings"])];
  if(!normalized.budget || !Array.isArray(normalized.budget.groups)) normalized.budget=clone(base.budget);
  normalized.budget.hiddenBlocks=[...new Set((Array.isArray(normalized.budget.hiddenBlocks)?normalized.budget.hiddenBlocks:[]).map(value=>String(value||'').trim()).filter(Boolean))];
  if(!normalized.budget.groups.some(group=>group?.id==="g-bus")) {
    const busGroup=clone((base.budget.groups||[]).find(group=>group?.id==="g-bus")||{id:"g-bus",name:"Autobús aeropuerto",icon:"🚌",iconUrl:"",color:"#49b6d6",gradient1:"#173f53",gradient2:"#2d7895",items:[]});
    const flightsIndex=normalized.budget.groups.findIndex(group=>group?.id==="g-flights");
    normalized.budget.groups.splice(flightsIndex>=0?flightsIndex:0,0,busGroup);
  }
  if(normalized.settings.budgetGroupOrderCustomized!==true){
    const busIndex=normalized.budget.groups.findIndex(group=>group?.id==='g-bus');
    const flightsIndex=normalized.budget.groups.findIndex(group=>group?.id==='g-flights');
    if(busIndex>=0&&flightsIndex>=0&&busIndex>flightsIndex){const [busGroup]=normalized.budget.groups.splice(busIndex,1);normalized.budget.groups.splice(flightsIndex,0,busGroup);}
  }
  if(!normalized.budget.groups.some(group=>group?.id==="g-extras")) {
    normalized.budget.groups.push({id:"g-extras",name:"Extras",icon:"✨",iconUrl:"",color:"#f7c84b",gradient1:"#70530e",gradient2:"#a77a13",items:[]});
  }
  // v2.3.23: el título del grupo automático de autobús en Presupuesto usa
  // exactamente el mismo degradado y color de texto que la ficha de autobús.
  // Así nunca vuelve al azul legado después de cambiar la identidad visual del trayecto.
  if(syncBudgetBusHeaderVisual(normalized))pendingBudgetBusVisualMigration=true;
  // v2.1.86: convierte los antiguos conceptos manuales de Presupuesto → Extras
  // en registros editables de Compra real → Extras, sin duplicarlos.
  const extrasGroupForMigration=normalized.budget.groups.find(group=>group?.id==="g-extras");
  const legacyExtraItems=Array.isArray(extrasGroupForMigration?.items)?extrasGroupForMigration.items.filter(Boolean):[];
  if(legacyExtraItems.length){
    normalized.purchases.extras=Array.isArray(normalized.purchases.extras)?normalized.purchases.extras:[];
    for(const item of legacyExtraItems){
      const sourceId=String(item.id||"").trim()||uid("legacy-extra");
      if(normalized.purchases.extras.some(extra=>String(extra.sourceBudgetItemId||"")===sourceId))continue;
      const firstFile=Array.isArray(item.files)?item.files.find(file=>isValidUrl(file?.url||file?.driveUrl)):null;
      normalized.purchases.extras.push({
        id:`purchase-extra-${sourceId}`,sourceBudgetItemId:sourceId,date:"",category:"Extra",name:item.name||"Extra",amount:num(item.amount),
        status:item.status==="paid"?"paid":"unpaid",icon:item.icon||extrasGroupForMigration.icon||"✨",iconUrl:item.iconUrl||"",
        notes:item.detail||"",fileUrl:item.fileUrl||item.url||firstFile?.url||firstFile?.driveUrl||""
      });
    }
    extrasGroupForMigration.items=[];
    pendingExtrasMigration=true;
  }

  // v2.1.36: unifica automáticamente la identidad visual de Vueling, AENA y FlightAware
  // entre todos los vuelos existentes. Versiones anteriores podían dejar la ida con un logo
  // personalizado y la vuelta con el icono por defecto. Priorizamos cualquier imagen
  // personalizada ya guardada y la propagamos a todos los vuelos sin pedir que se vuelva a subir.
  const flightVisualPrefixes=["vuelingButton","aenaButton","flightAwareButton"];
  const normalizedFlights=normalized.cover?.flights||[];
  for(const prefix of flightVisualPrefixes){
    if(!normalizedFlights.length)continue;
    const customWithImage=normalizedFlights.find(f=>isImageSource(f?.[`${prefix}IconUrl`]));
    let source=customWithImage||null;
    if(!source){
      source=normalizedFlights.find(f=>{
        const defaults=defaultFlightServiceButtons(f);
        const icon=String(f?.[`${prefix}Icon`]||"");
        return icon && icon!==String(defaults?.[`${prefix}Icon`]||"");
      })||normalizedFlights[0];
    }
    const sharedIcon=String(source?.[`${prefix}Icon`]||"");
    const sharedIconUrl=String(source?.[`${prefix}IconUrl`]||"");
    for(const flight of normalizedFlights){
      if(String(flight?.[`${prefix}Icon`]||"")!==sharedIcon || String(flight?.[`${prefix}IconUrl`]||"")!==sharedIconUrl){
        flight[`${prefix}Icon`]=sharedIcon;
        flight[`${prefix}IconUrl`]=sharedIconUrl;
        pendingFlightServiceVisualMigration=true;
      }
    }
  }

  // Migra recordatorios existentes para que también funcionen con las notificaciones push.
  for (const task of normalized.tasks?.items || []) {
    if (task.dueAt && !num(task.notifyAt)) {
      const dueMs = new Date(task.dueAt).getTime();
      if (Number.isFinite(dueMs)) {
        task.notifyAt = dueMs - (num(task.reminderMinutes) || 0) * 60000;
        pendingReminderMigration = true;
      }
    }
  }
  for (const flight of normalized.cover?.flights || []) {
    const departureMs = flight.departure ? new Date(flight.departure).getTime() : 0;
    if (departureMs && !num(flight.checkInNotifyAt)) {
      flight.checkInNotifyAt = departureMs - (num(flight.checkInReminderHours) || 25) * 3600000;
      pendingReminderMigration = true;
    }
    if (flight.leaveAirportReminder && !num(flight.leaveNotifyAt)) {
      const leaveMs = new Date(flight.leaveAirportReminder).getTime();
      if (Number.isFinite(leaveMs)) {
        flight.leaveNotifyAt = leaveMs;
        pendingReminderMigration = true;
      }
    }
  }

  for (const group of normalized.budget?.groups || []) {
    for (const item of group.items || []) {
      item.files = normalizeFileList(item.files);
      if (item.fileUrl && !item.files.some(f => f.url === item.fileUrl)) {
        item.files.push({ id:uid("legacy-file"), label:"Ver archivo", url:item.fileUrl, type:"file" });
      }
    }
  }

  const baseProducts = new Map((base.shopping?.stores || []).flatMap(store =>
    (store.products || []).map(product => [product.id, product])
  ));
  for (const store of normalized.shopping?.stores || []) {
    // v2.1.67: configura automáticamente la zona de compra del viaje actual
    // solo cuando el supermercado todavía no tenía código postal guardado.
    // Un valor editado por el usuario siempre se conserva.
    const storeKey=String(store.id||"").trim().toLowerCase();
    const storeName=String(store.name||"").trim().toLowerCase();
    const defaultPostalCode=(storeKey==="store-mercadona"||storeName==="mercadona")?"35214":
      ((storeKey==="store-hiperdino"||storeName==="hiperdino"||storeName==="hiper dino")?"35200":"");
    if(defaultPostalCode&&!String(store.postalCode||"").trim()){
      store.postalCode=defaultPostalCode;
      pendingShoppingRepair=true;
    }
    store.active = store.active !== false;
    for (const product of store.products || []) {
      product.unit = product.unit || "ud.";
      product.imageCrop = { x:50, y:50, zoom:1, ...(product.imageCrop || {}) };
      const normalizedImage = normalizeProductImageFields(product);
      if (product.imageSource !== normalizedImage.imageSource) {
        product.imageSource = normalizedImage.imageSource;
        pendingShoppingRepair = true;
      }
      const badName = /(resultados? de b[uú]squeda|resultados? para)/i.test(String(product.name || ""));
      const badPrice = Boolean(product.priceUpdatedAt) && num(product.unitPrice) <= 0;
      if (!badName && !badPrice) continue;
      const original = baseProducts.get(product.id);
      if (badName) {
        const quoted = String(product.name || "").match(/[‘'"]([^’'"]+)[’'"]/i)?.[1];
        product.name = original?.name || (quoted ? quoted.charAt(0).toUpperCase() + quoted.slice(1) : "Producto");
      }
      if (badPrice && num(original?.unitPrice) > 0) product.unitPrice = original.unitPrice;
      pendingShoppingRepair = true;
    }
  }
  // v2.3.23 · nueva pestaña Alojamiento: activarla también en datos persistidos de versiones anteriores.
  if(!Array.isArray(normalized.settings.enabledTabs))normalized.settings.enabledTabs=[];
  if(!normalized.settings.enabledTabs.includes("lodging")){
    const coverPos=normalized.settings.enabledTabs.indexOf("cover");
    normalized.settings.enabledTabs.splice(coverPos>=0?coverPos+1:0,0,"lodging");
  }
  if(!Array.isArray(normalized.settings.tabOrder))normalized.settings.tabOrder=[];
  if(!normalized.settings.tabOrder.includes("lodging")){
    const coverPos=normalized.settings.tabOrder.indexOf("cover");
    normalized.settings.tabOrder.splice(coverPos>=0?coverPos+1:0,0,"lodging");
  }
  // v2.3.56: nueva pestaña Histórico, visible por defecto para instalaciones existentes.
  if(!normalized.settings.enabledTabs.includes("history")){
    const notesPos=normalized.settings.enabledTabs.indexOf("notes");
    normalized.settings.enabledTabs.splice(notesPos>=0?notesPos:normalized.settings.enabledTabs.length,0,"history");
  }
  if(!normalized.settings.tabOrder.includes("history")){
    const notesPos=normalized.settings.tabOrder.indexOf("notes");
    normalized.settings.tabOrder.splice(notesPos>=0?notesPos:normalized.settings.tabOrder.length,0,"history");
  }
  normalized.settings.visualStyle=String(normalized.settings.visualStyle||base.settings.visualStyle||"premium")==="classic"?"classic":"premium";
  normalized.history=normalized.history||{archives:[]};
  if(!Array.isArray(normalized.history.archives))normalized.history.archives=[];
  const mergedConceptIcons=mergedBudgetConceptIconMemory(normalized);
  if(JSON.stringify(normalizeBudgetConceptIconMemory(normalized.budget?.conceptIconMemory||{}))!==JSON.stringify(mergedConceptIcons)){
    normalized.budget.conceptIconMemory=mergedConceptIcons;
    pendingConceptIconMemoryMigration=true;
  }else normalized.budget.conceptIconMemory=mergedConceptIcons;

  normalized.menu=normalized.menu||{days:[]};
  normalized.menu.days=normalizeMenuDays(normalized.menu,normalized.settings);
  const tracking=normalized.shopping.priceTracking||(normalized.shopping.priceTracking={schedule:"daily",lastRunAt:"",lastAutoRunAt:"",snapshots:[],changes:[],lastChanges:[],lastSource:""});
  if(!Array.isArray(tracking.snapshots))tracking.snapshots=[];
  if(!tracking.snapshots.length){
    const baselineStores={},baselinePrices={};let baselineTotal=0;
    for(const store of normalized.shopping?.stores||[]){
      let storeSum=0;for(const product of store.products||[]){const price=num(product.unitPrice),qty=num(product.quantity);storeSum+=price*qty;if(product.id)baselinePrices[product.id]=price;}
      baselineStores[store.id||normalizedKey(store.name)]=Number(storeSum.toFixed(2));baselineTotal+=storeSum;
    }
    tracking.snapshots=[{t:new Date().toISOString(),source:"baseline",total:Number(baselineTotal.toFixed(2)),stores:baselineStores,prices:baselinePrices}];
    pendingShoppingRepair=true;
  }
  return normalized;
}

const els = {
  boot: $("#boot"), login: $("#login-view"), shell: $("#app-shell"), content: $("#main-content"), nav: $("#main-nav"),
  loginForm: $("#login-form"), loginEmail: $("#login-email"), loginPassword: $("#login-password"), loginMessage: $("#login-message"), demoLogin: $("#demo-login"),
  headerIcon: $("#header-icon"), appName: $("#header-app-name"), destination: $("#header-destination"), year: $("#header-year"),
  userName: $("#user-name"), userRole: $("#user-role"), logout: $("#logout-btn"), editLock: $("#edit-lock"), saveState: $("#save-state"),
  install: $("#install-app"), modalBackdrop: $("#modal-backdrop"), modal: $("#modal"), toastRoot: $("#toast-root"), footerVersion: $("#footer-version")
};

const TABS = [
  ["cover","🏝️","Portada"], ["lodging","🏨","Alojamiento"], ["budget","💶","Presupuesto"], ["suitcase-common","🧳","Maleta común"],
  ["suitcase-mikel","🎒","Maleta Mikel"], ["suitcase-nerea","👜","Maleta Nerea"], ["shopping","🛒","Lista de compra"],
  ["purchases","🧾","Compra real"], ["tasks","✅","Tareas"], ["emergency","🆘","Emergencia"], ["trackers","📡","Seguimientos"],
  ["menu","🍽️","Menú"], ["itinerary","📍","Itinerario"], ["history","🗂️","Histórico"], ["notes","📝","Otros"], ["settings","⚙️","Configuración"]
];

const TRACKER_DEFAULT_ICONS={autoreisen:"🚗",cordial:"🏨",vueling:"✈️",fuel:"⛽"};
const SHOPPING_HISTORY_MAX_SNAPSHOTS=180;
const SHOPPING_HISTORY_MAX_CHANGES=1000;

const EDIT_PIN_SESSION_KEY=`travel-pin-verified:${TRIP_ID}`;
const EDIT_UNLOCK_SESSION_KEY=`travel-unlocked:${TRIP_ID}`;
const DEVICE_AUTH_KEY_PREFIX=`mfe-device-auth:${TRIP_ID}`;
const DEVICE_AUTH_MODE='platform-local-v2';
const DRIVE_SESSION_TOKEN_KEY=`mfe-drive-session:${TRIP_ID}`;
const state = {
  data: clone(SEED_DATA), profile: null, user: null, provider: null, activeTab: "cover", unlocked: false, settingsUnlocked: false, pinVerified: false, coverLayoutEdit:false, settingsDirty:false,
  weather: null, poolMeasurements:null, poolMeasurementsLoading:false, poolAutoMonitorStarted:false, webcamEmbedCache:{}, webcamRefreshTimer:null, countdownTimer: null, notificationTimers: [], installPrompt: null, settingsPanel: "general", firebase: null, documentSlides: {}, coverCarouselSlides: {}, coverCarouselOpen: {}, coverCarouselPopup: null, fuelMap: null, currentLocation: null, fuelSort: "price", ocrWorker: null, ocrCancelled: false, monitorSyncDone: false, monitorFallbackStatus:null, monitorFallbackFetchedAt:0, autoreisenControlStatus:null, autoreisenRemoteHistory:null, cordialControlStatus:null, cordialRemoteHistory:null, notificationDiagnostics: { checked:false, fcmSupported:null, token:"", lastMessage:"" },
  integrationDiagnostics: { checked:false, worker:null, github:null, drive:null, firebase:null, calendar:null, notifications:null, weather:null, lastMessage:"" },
  mobileDeployProgress:null, mobileDeployTimer:null, updateDiagnostics:null,
  trackerRunProgress:{}, trackerRunTimers:{},
  shoppingSyncReport:null, shoppingView:"list", shoppingHistoryFilters:{store:"all",query:"",period:"30"}, shoppingAutoRunning:false, shoppingAutoTimer:null,
  driveAccessToken:"", driveAccessTokenExpiresAt:0, driveObjectUrls:new Map(), drivePersistentStatus:{checked:false,connected:false,persistentConnected:false,configured:null,temporary:false,email:"",name:"",lastMessage:""},
  flightOps:{result:null,lastError:null,fetchedAt:0,syncing:false,automationChecked:false}, flightOpsTimer:null,
  historyArchiveCache:new Map()
};
let dynamicManifestUrl = "";
let dynamicManifestSignature = "";
let persistedIdentitySignature = "";
let notificationIconSignature = "";
let drivePersistentStatusCheckedAt = 0;
const DRIVE_PERSISTENT_STATUS_CACHE_MS = 45000;
function shortHash(value=""){
  const text=String(value||"");
  let hash=2166136261;
  for(let i=0;i<text.length;i++){
    hash^=text.charCodeAt(i);
    hash=Math.imul(hash,16777619);
  }
  return (hash>>>0).toString(36);
}
async function syncInstallIcons(iconMap={}){
  if(!('serviceWorker' in navigator))return false;
  const icons=Object.entries(iconMap).map(([url,dataUrl])=>({url,dataUrl})).filter(entry=>entry.url&&entry.dataUrl);
  if(!icons.length)return false;
  try{
    const registration=await navigator.serviceWorker.ready;
    const target=registration.active||registration.waiting||navigator.serviceWorker.controller;
    if(!target)return false;
    await new Promise(resolve=>{
      const channel=new MessageChannel();
      const finish=(ok)=>resolve(Boolean(ok));
      const timer=setTimeout(()=>finish(false),2500);
      channel.port1.onmessage=event=>{clearTimeout(timer);finish(Boolean(event.data?.ok));};
      try{target.postMessage({type:'SET_INSTALL_ICONS',icons},[channel.port2]);}
      catch(error){clearTimeout(timer);console.warn('No se pudieron sincronizar los iconos de instalación',error);finish(false);}
    });
    return true;
  }catch(error){
    console.warn('No se pudieron sincronizar los iconos de instalación',error);
    return false;
  }
}
async function syncInstallManifest(manifestUrl,manifest){
  if(!('serviceWorker' in navigator)||!manifestUrl||!manifest)return false;
  try{
    const registration=await navigator.serviceWorker.ready;
    const target=registration.active||registration.waiting||navigator.serviceWorker.controller;
    if(!target)return false;
    return await new Promise(resolve=>{
      const channel=new MessageChannel();
      const finish=(ok)=>resolve(Boolean(ok));
      const timer=setTimeout(()=>finish(false),3000);
      channel.port1.onmessage=event=>{clearTimeout(timer);finish(Boolean(event.data?.ok));};
      try{target.postMessage({type:'SET_INSTALL_MANIFEST',url:manifestUrl,manifest},[channel.port2]);}
      catch(error){clearTimeout(timer);console.warn('No se pudo sincronizar el manifest de instalación',error);finish(false);}
    });
  }catch(error){
    console.warn('No se pudo sincronizar el manifest de instalación',error);
    return false;
  }
}
applyStoredIdentity();

function formatNumberEs(value, fractionDigits = 2) {
  const digits=Math.max(0,Math.min(6,Number(fractionDigits)||0));
  return new Intl.NumberFormat("es-ES", {
    useGrouping:"always",
    minimumFractionDigits:digits,
    maximumFractionDigits:digits
  }).format(num(value));
}
function formatMoney(value) {
  const s = state.data.settings;
  return new Intl.NumberFormat("es-ES", {
    style:"currency",
    currency:s.currency || "EUR",
    useGrouping:"always",
    minimumFractionDigits:2,
    maximumFractionDigits:2
  }).format(num(value));
}
function formatDate(value, opts = {day:"2-digit",month:"short",year:"numeric"}) {
  if (!value) return "—";
  const date = new Date(value.length === 10 ? `${value}T12:00:00` : value);
  return Number.isNaN(date.getTime()) ? value : new Intl.DateTimeFormat(state.data.settings.locale || "es-ES", opts).format(date);
}
function formatTime(value) {
  if (!value) return "—";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value.slice(11,16) || value;
  return new Intl.DateTimeFormat(state.data.settings.locale || "es-ES", {hour:"2-digit",minute:"2-digit"}).format(date);
}
function flightDuration(flight) {
  if (flight.durationOverride) return flight.durationOverride;
  const start = new Date(flight.departure); const end = new Date(flight.arrival);
  if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime())) return "—";
  const minutes = Math.max(0, Math.round((end - start) / 60000));
  return `${Math.floor(minutes/60)} h ${minutes%60} min`;
}
function roleCanEdit() { return ["admin","editor"].includes(state.profile?.role); }
function currentTabUnlocked() { return state.activeTab === "settings" ? state.settingsUnlocked : state.unlocked; }
function canEdit() { return roleCanEdit() && currentTabUnlocked(); }
function canManageAutomations() { return roleCanEdit(); }
function editButtons(html) { return canEdit() ? html : ""; }
function coverInlineEditButton(action,label="Editar bloque"){
  return canEdit()?`<button class="mini-btn cover-inline-edit" type="button" data-cover-block-edit="${esc(action)}" title="${esc(label)}" aria-label="${esc(label)}">✎</button>`:"";
}
function coverInlineOpenButton(tab,label="Abrir para editar"){
  return canEdit()?`<button class="mini-btn cover-inline-edit" type="button" data-cover-block-open="${esc(tab)}" title="${esc(label)}" aria-label="${esc(label)}">✎</button>`:"";
}
function safeLink(url, label, icon = "↗", extraClass = "", appHint = "") {
  let parsed;
  try { parsed = new URL(String(url || ""), location.href); } catch { parsed = null; }
  const protocol = parsed?.protocol || "";
  const allowed = ["http:","https:","tel:","mailto:"].includes(protocol);
  const className=`link-btn${String(extraClass||'').trim()?` ${esc(String(extraClass).trim())}`:''}`;
  if (!allowed) return `<span class="${className} disabled">${icon} ${esc(label)}</span>`;
  const smart=smartAppActive(url,appHint),handoff=nativeWebHandoffActive(url,appHint),href=smart?smartAppHref(url,appHint):String(url||"");
  const external = !smart && !handoff && ["http:","https:"].includes(protocol) ? ' target="_blank" rel="noopener"' : "";
  const badge=smart?'<span class="smart-app-badge" aria-hidden="true">APP</span>':'';
  return `<a class="${className}${smart?' smart-app-link':''}" href="${esc(href)}"${external}>${icon} ${esc(label)}${badge}</a>`;
}
function googleMapsIconMarkup(){
  return '<img class="maps-link-icon" src="./icons/google-maps-pin-official.png?v=2.2.126-r1" alt="" aria-hidden="true">';
}
function accuweatherIconMarkup(){
  return '<img class="accuweather-link-icon" src="./icons/accuweather-official.png?v=2.2.126-r1" alt="" aria-hidden="true">';
}
function accuWeatherForecastUrl(){
  // En escritorio abrimos exactamente la previsión web en castellano que usamos
  // para La Playa de Arguineguín.
  return 'https://www.accuweather.com/es/es/la-playa-de-arguineguin/2279587/weather-forecast/2279587';
}
function accuWeatherAndroidIntentUrl(){
  // En Android usamos el acceso genérico de AccuWeather que ya hemos comprobado
  // que abre la aplicación instalada. No intentamos forzar una ubicación concreta,
  // porque esa ruta hace que AccuWeather derive de nuevo a la web.
  const appUrl='https://one.accuweather.com/app';
  const fallback=accuWeatherForecastUrl();
  const parsed=new URL(appUrl);
  return `intent://${parsed.host}${parsed.pathname}${parsed.search}${parsed.hash}#Intent;scheme=https;package=com.accuweather.android;S.browser_fallback_url=${encodeURIComponent(fallback)};end`;
}
function renderAccuWeatherButton(extraClass=''){
  const webUrl=accuWeatherForecastUrl();
  const openNative=nativeAppsEnabled()&&androidDevice();
  const href=openNative?accuWeatherAndroidIntentUrl():webUrl;
  const external=openNative?'':' target="_blank" rel="noopener"';
  const className=`link-btn accuweather-icon-link${String(extraClass||'').trim()?` ${esc(String(extraClass).trim())}`:''}`;
  return `<a class="${className}" href="${esc(href)}"${external} title="Abrir AccuWeather" aria-label="Abrir AccuWeather">${accuweatherIconMarkup()}</a>`;
}
const SMART_APP_PACKAGES={
  vueling:"com.mo2o.vueling",
  aena:"es.aena.mobile",
  flightaware:"com.flightaware.android.liveFlightTracker",
  booking:"com.booking",
  tripadvisor:"com.tripadvisor.tripadvisor",
  mercadona:"es.mercadona.tienda",
  hiperdino:"com.hiperdino.compraonline",
  googlemaps:"com.google.android.apps.maps",
  accuweather:"com.accuweather.android"
};
function detectSmartAppService(url="",hint=""){
  const text=String(hint||"").toLowerCase();
  if(text.includes("vueling"))return "vueling";
  if(text.includes("aena"))return "aena";
  if(text.includes("flightaware"))return "flightaware";
  if(text.includes("booking"))return "booking";
  if(text.includes("tripadvisor"))return "tripadvisor";
  if(text.includes("mercadona"))return "mercadona";
  if(text.includes("hiperdino")||text.includes("hiper dino"))return "hiperdino";
  if(text.includes("google maps")||text==="googlemaps")return "googlemaps";
  if(text.includes("accuweather"))return "accuweather";
  try{
    const host=new URL(String(url||""),location.href).hostname.toLowerCase();
    if(host.includes("vueling.com"))return "vueling";
    if(host.includes("aena.es"))return "aena";
    if(host.includes("flightaware.com"))return "flightaware";
    if(host.includes("booking.com"))return "booking";
    if(host.includes("tripadvisor."))return "tripadvisor";
    if(host.includes("mercadona.es"))return "mercadona";
    if(host.includes("hiperdino.es"))return "hiperdino";
    if((host.includes("google.com")||host.includes("maps.app.goo.gl"))&&/maps|place|dir/i.test(String(url||"")))return "googlemaps";
    if(host.includes("accuweather.com"))return "accuweather";
  }catch{}
  return "";
}
function nativeAppsEnabled(){return state.data?.settings?.preferNativeApps!==false;}
function androidDevice(){return /Android/i.test(navigator.userAgent||"");}
function appleMobileDevice(){return /iPhone|iPad|iPod/i.test(navigator.userAgent||"");}
function isOfficialVuelingAppLink(url=""){
  try{return new URL(String(url||""),location.href).hostname.toLowerCase()==="link.vueling.com";}catch{return false;}
}
function vuelingQuickLinkForDevice(kind="trips",configuredUrl=""){
  const mobile=androidDevice()||appleMobileDevice();
  const type=kind==="checkin"?"checkin":"trips";
  const desktopSpanish=type==="checkin"
    ?"https://tickets.vueling.com/checkin?c=es-ES"
    :"https://tickets.vueling.com/RetrieveBooking.aspx?culture=es-ES";
  const officialDeep=type==="checkin"?"https://link.vueling.com/checkin":"https://link.vueling.com/mmbit";
  if(!mobile)return desktopSpanish;
  const raw=String(configuredUrl||"").trim();
  return isValidUrl(raw)?raw:officialDeep;
}
function nativeWebHandoffActive(url,hint=""){
  if(!nativeAppsEnabled()||!(androidDevice()||appleMobileDevice()))return false;
  const service=detectSmartAppService(url,hint);
  // AENA e HiperDino no publican una ruta externa documentada que podamos fabricar.
  // Se entrega su HTTPS real al sistema: si la app ha registrado App Links, Android/iOS
  // la abre; si no, se conserva exactamente la página solicitada en el navegador.
  return service==="aena"||service==="hiperdino"||service==="accuweather";
}
function smartAppHref(url,hint=""){
  const raw=String(url||"").trim();
  if(!isValidUrl(raw)||!nativeAppsEnabled())return raw;
  const service=detectSmartAppService(raw,hint);
  if(!service)return raw;
  // Vueling: solo usamos sus enlaces universales link.vueling.com, que ya gestionan app/web.
  // Nunca se fuerza el paquete para una URL que Vueling no haya registrado como navegable.
  if(service==="vueling")return raw;
  // AENA, HiperDino y AccuWeather se entregan como HTTPS real al sistema.
  // En AccuWeather esto permite que Android aplique la asociación de enlaces elegida por el usuario.
  if(service==="aena"||service==="hiperdino"||service==="accuweather")return raw;
  const pkg=SMART_APP_PACKAGES[service];if(!pkg)return raw;
  if(!androidDevice())return raw;
  try{
    const parsed=new URL(raw);
    if(!["http:","https:"].includes(parsed.protocol))return raw;
    const scheme=parsed.protocol.slice(0,-1);
    const target=`${parsed.host}${parsed.pathname}${parsed.search}${parsed.hash}`;
    return `intent://${target}#Intent;scheme=${scheme};package=${pkg};S.browser_fallback_url=${encodeURIComponent(raw)};end`;
  }catch{return raw;}
}
function smartAppActive(url,hint=""){
  if(!nativeAppsEnabled()||!(androidDevice()||appleMobileDevice()))return false;
  const service=detectSmartAppService(url,hint);
  if(!service)return false;
  if(service==="vueling")return isOfficialVuelingAppLink(url);
  if(service==="aena"||service==="hiperdino")return false;
  return true;
}

// v2.2.144 · Tarjetas de embarque por pasajero.
// Google Wallet ya no ofrece Compartir en muchos pases. MFE Viajes admite ahora
// una copia visual/PDF importada desde el móvil o Google Drive y conserva los
// enlaces antiguos de Wallet solo como compatibilidad.
function boardingPassMiniIconMarkup() {
  return `<svg class="boarding-pass-mini-icon" viewBox="0 0 512 512" aria-hidden="true" focusable="false"><g><path d="M148.996 284.914c-.195-.415.05-.879.493-1 .358-.099.698-.294.979-.596l.931-1c.805-.865.988-2.14.459-3.196-.911-1.818-3.385-2.112-4.696-.559l-.499.591c-.091.107-.151.23-.218.351l-6.769-14.345c-.112-.238-.085-.52.071-.731l1.333-1.81s11.54-16.777 5.223-20.346c-6.091-3.441-15.656 10.966-15.656 10.966l-3.366 4.681c-.151.209-.403.322-.66.294l-16.615-1.827c.013-.016.031-.028.044-.045l.647-.879c1.09-1.478.192-3.582-1.628-3.818l-.717-.093c-.886-.115-1.762.27-2.277.999l-1.118 1.586c-.203.287-.301.604-.311.917-.013.405-.383.702-.786.658l-15.599-1.715a.72.72 0 0 0-.616.239l-4.247 4.818c-.341.385-.176.993.313 1.154l11.949 3.954 6.929 2.293v-.001l14.986 4.959-11.764 16.357a.708.708 0 0 1-.469.289l-25.171 4.041a.717.717 0 0 0-.604.708l.002 3.648c0 .351.253.649.599.707l11.65 1.954 11.464 1.923a.715.715 0 0 1 .543.432l8.687 20.855c.111.268.373.442.663.441l3.28-.001c.412-.001.74-.348.716-.76l-1.435-24.701a.715.715 0 0 1 .145-.473l14.239-18.862 21.612 28.378c.312.409.94.367 1.194-.08l3.175-5.584a.72.72 0 0 0 .025-.66l-11.369-24.132z"/><path d="M182.118 238.638 307.275 215.691c3.667-.673 6.094-4.189 5.422-7.856-.674-3.668-4.189-6.096-7.855-5.422l-125.158 22.947c-3.667.672-6.094 4.189-5.422 7.855.598 3.257 3.436 5.535 6.631 5.535.404 0 .813-.037 1.225-.112z"/><path d="M187.454 278.314 313.293 255.242c3.668-.672 6.095-4.189 5.423-7.855-.673-3.668-4.186-6.094-7.856-5.423l-125.839 23.073c-3.667.672-6.095 4.189-5.422 7.855.597 3.257 3.436 5.535 6.631 5.535.403 0 .813-.036 1.224-.113z"/><path d="M319.066 281.4 191.294 304.827c-3.668.673-6.095 4.19-5.423 7.856.598 3.256 3.436 5.534 6.632 5.534.403 0 .813-.037 1.225-.112L321.5 294.679c3.668-.673 6.095-4.19 5.423-7.856-.673-3.669-4.191-6.093-7.857-5.423z"/><path d="M485.432 283.566 461.874 155.08c-3.204-17.47-20.023-29.087-37.496-25.877l-85.105 15.604h-.002L52.446 197.397c-17.473 3.203-29.08 20.024-25.877 37.495L50.126 363.38c2.846 15.517 16.429 26.409 31.673 26.407 1.919 0 3.869-.172 5.823-.531l286.825-52.589h.004l85.104-15.604c17.472-3.204 29.08-20.025 25.877-37.497zM370.92 317.43c-3.434.629-5.744 3.758-5.477 7.164L85.188 375.979c-10.146 1.862-19.922-4.883-21.784-15.033L39.847 232.459c-.901-4.918.167-9.893 3.005-14.006 2.84-4.114 7.111-6.876 12.027-7.777l280.188-51.372.243 1.327c.598 3.256 3.436 5.534 6.632 5.534.403 0 .813-.037 1.225-.112h.001l2.435 13.278c-3.668.673-6.096 4.19-5.423 7.856l1.461 7.969c.597 3.256 3.436 5.533 6.631 5.533.403 0 .813-.036 1.225-.111h.002l2.435 13.278c-3.668.673-6.095 4.19-5.422 7.856l1.46 7.967c.598 3.256 3.437 5.534 6.632 5.534.403 0 .813-.037 1.225-.112h.001l2.435 13.279c-3.668.672-6.096 4.189-5.423 7.855l1.461 7.969c.597 3.256 3.436 5.534 6.631 5.534.403 0 .813-.037 1.225-.112h.002l2.435 13.279c-3.668.672-6.095 4.189-5.423 7.855l1.462 7.967c.597 3.256 3.436 5.535 6.631 5.535.403 0 .813-.037 1.225-.113h.001l2.435 13.279zm9.275-121.09-2.794-15.236c-.526-2.871 1.375-5.627 4.247-6.154l35.631-6.532c2.873-.526 5.628 1.375 6.154 4.247l2.794 15.235c.526 2.873-1.375 5.628-4.247 6.155l-35.631 6.532c-2.872.526-5.627-1.375-6.154-4.247zm8.513 46.431-2.793-15.235c-.526-2.872 1.374-5.628 4.247-6.155l35.631-6.532c2.872-.526 5.628 1.375 6.154 4.247l2.794 15.235c.526 2.872-1.376 5.628-4.247 6.155l-35.632 6.532c-2.872.527-5.628-1.374-6.154-4.247zm50.299 44.147-35.631 6.532c-2.872.526-5.628-1.375-6.154-4.247l-2.794-15.236c-.526-2.871 1.375-5.627 4.247-6.153l35.632-6.534c2.872-.525 5.627 1.376 6.154 4.248l2.793 15.236c.527 2.871-1.375 5.627-4.247 6.154z"/><path d="m243.594 374.956-6.763 1.267c-3.664.686-6.077 4.213-5.391 7.878.607 3.244 3.44 5.508 6.626 5.508.412 0 .831-.038 1.251-.117l6.764-1.267c3.663-.686 6.077-4.213 5.391-7.878s-4.216-6.09-7.878-5.391z"/><path d="m357.989 353.522-86.32 16.173c-3.665.688-6.078 4.214-5.392 7.878.608 3.244 3.443 5.508 6.627 5.508.412 0 .831-.038 1.251-.117l86.321-16.174c3.664-.687 6.077-4.214 5.391-7.877-.685-3.665-4.224-6.08-7.878-5.391z"/><path d="M299.464 138.25c.412 0 .832-.038 1.251-.117l13.527-2.535c3.664-.686 6.078-4.214 5.391-7.877-.687-3.666-4.227-6.079-7.877-5.391l-13.527 2.535c-3.664.686-6.078 4.213-5.391 7.877.607 3.244 3.44 5.508 6.626 5.508z"/><path d="M185.068 159.683c.413 0 .83-.038 1.251-.117l86.321-16.173c3.664-.686 6.077-4.212 5.391-7.877-.688-3.665-4.213-6.082-7.877-5.391l-86.321 16.171c-3.664.687-6.077 4.214-5.391 7.879.607 3.244 3.441 5.508 6.626 5.508z"/><path d="M134.771 169.106c.412 0 .83-.038 1.25-.116l22.433-4.204c3.664-.687 6.076-4.214 5.39-7.879-.687-3.663-4.212-6.075-7.879-5.39l-22.428 4.202c-3.665.687-6.079 4.214-5.394 7.877.608 3.246 3.442 5.51 6.628 5.51z"/></g></svg>`;
}
function boardingPassFiles(flight={},person='mikel'){
  const key=person==='nerea'?'nerea':'mikel';return normalizeFileList(flight.boardingPasses?.[key]||[]);
}
function hasStoredBoardingPass(flight={},person='mikel'){return boardingPassFiles(flight,person).length>0;}
function hasAllStoredBoardingPasses(flight={}){return hasStoredBoardingPass(flight,'mikel')&&hasStoredBoardingPass(flight,'nerea');}
function boardingPassPersonLabel(person='mikel'){return person==='nerea'?'Nerea':'Mikel';}
function manageBoardingPassFiles(index,person='mikel'){
  const flight=state.data.cover.flights?.[index];if(!flight)return;const key=person==='nerea'?'nerea':'mikel',label=boardingPassPersonLabel(key);
  flight.boardingPasses=flight.boardingPasses||{mikel:[],nerea:[]};
  openFilesManager(flight.boardingPasses[key]||[],async files=>{flight.boardingPasses[key]=normalizeFileList(files);const saved=await saveSection('cover');if(saved===false)return false;render();return true;},`Tarjeta de embarque · ${label} · ${flight.number||flight.type||'Vuelo'}`,{autoSave:true,storeDriveLinks:true,storageFolder:`boarding-passes/${flight.id||index}/${key}`,mimeTypes:'application/pdf,image/png,image/jpeg,image/webp'});
}
function openBoardingPassViewer(index,person='mikel'){
  const flight=state.data.cover.flights?.[index];if(!flight)return;const key=person==='nerea'?'nerea':'mikel',label=boardingPassPersonLabel(key),files=boardingPassFiles(flight,key),legacy=String(key==='nerea'?flight.walletNereaUrl:flight.walletMikelUrl||'').trim();
  if(!files.length&&isValidUrl(legacy)){window.location.href=legacy;return;}
  const cards=visibleFiles(files).map(file=>{const url=String(file.url||file.driveUrl||'').trim(),title=file.label||`Tarjeta ${label}`,isImage=file.type==='image'||String(file.mimeType||'').startsWith('image/');if(isImage&&url)return `<button type="button" class="boarding-pass-preview-card" data-image-popup="${esc(url)}" data-image-title="${esc(title)}"><img src="${esc(url)}" alt="${esc(title)}"><span>${esc(title)}</span></button>`;if(url)return `<button type="button" class="boarding-pass-file-card" data-file-popup="${esc(url)}" data-file-title="${esc(title)}">${pdfFileIconMarkup('boarding-pass-file-icon')}<span>${esc(title)}</span></button>`;return '';}).join('');
  openModal(`<div class="modal-head"><div><h3>Tarjeta de embarque · ${esc(label)}</h3><small>${esc(flight.number||'')} · ${esc(flight.from||'')} → ${esc(flight.to||'')}</small></div><button class="close-btn" data-close-modal>×</button></div><div class="modal-body"><div class="boarding-pass-viewer">${cards||'<div class="empty">Todavía no hay una copia guardada.</div>'}</div><p class="help-text">La copia en MFE Viajes es para consulta rápida. Conserva siempre la tarjeta original en Google Wallet o Vueling para embarcar.</p>${canEdit()?`<div class="page-actions"><button class="btn secondary" type="button" data-manage-boarding-pass="${index}:${key}">📎 Gestionar archivos</button></div>`:''}</div>`,true);
  $$('[data-close-modal]',els.modal).forEach(b=>b.addEventListener('click',closeModal));bindMediaPopups();$('[data-manage-boarding-pass]',els.modal)?.addEventListener('click',()=>manageBoardingPassFiles(index,key));
}
async function openBoardingPassQuick(index,person='mikel'){
  const flight=state.data.cover.flights?.[index];if(!flight)return;const key=person==='nerea'?'nerea':'mikel',files=visibleFiles(boardingPassFiles(flight,key)),legacy=String(key==='nerea'?flight.walletNereaUrl:flight.walletMikelUrl||'').trim();
  if(files.length===1){
    const file=files[0]||{},title=file.label||`Tarjeta ${boardingPassPersonLabel(key)}`,isImage=file.type==='image'||String(file.mimeType||'').startsWith('image/');
    try{
      if(officialFileDriveId(file)){const resolved=await fetchDriveMediaObjectUrl(file,true,true);if(isImage)openImagePopup(resolved,title);else openFilePopup(resolved,title);return;}
      const url=String(file.url||file.driveUrl||'').trim();if(url){if(isImage)openImagePopup(url,title);else openFilePopup(url,title);return;}
    }catch(error){toast(`No se pudo abrir la tarjeta desde Drive: ${error.message}`,'error');return;}
  }
  if(!files.length&&legacy&&isValidUrl(legacy)){window.open(legacy,'_blank','noopener');return;}
  openBoardingPassViewer(index,key);
}
function editFlightWallet(index) {
  const flight=state.data.cover.flights[index];if(!flight)return;flight.boardingPasses=flight.boardingPasses||{mikel:[],nerea:[]};
  const personCard=(key,label,legacyUrl)=>{const files=boardingPassFiles(flight,key);return `<article class="boarding-pass-person-card"><div><strong>${esc(label)}</strong><small>${files.length?`${files.length} archivo${files.length===1?'':'s'} guardado${files.length===1?'':'s'}`:'Sin copia guardada'}</small></div><div class="row-actions"><button type="button" class="btn secondary small" data-wallet-manage="${key}">📎 Añadir / cambiar</button>${files.length?`<button type="button" class="btn ghost small" data-wallet-view="${key}">👁 Ver</button>`:''}</div>${isValidUrl(legacyUrl)?`<small class="boarding-pass-legacy">Enlace antiguo de Google Wallet conservado como respaldo.</small>`:''}</article>`;};
  openModal(`<div class="modal-head"><div><h3>Tarjetas de embarque · ${esc(flight.number||flight.type||'Vuelo')}</h3><small>${esc(flight.from||'')} → ${esc(flight.to||'')}</small></div><button class="close-btn" data-close-modal>×</button></div><div class="modal-body"><div class="boarding-pass-person-grid">${personCard('mikel','Mikel',flight.walletMikelUrl)}${personCard('nerea','Nerea',flight.walletNereaUrl)}</div><div class="boarding-pass-howto"><strong>¿El pase está solo en Google Wallet?</strong><span>Haz una captura de pantalla del pase y pulsa «Añadir / cambiar» → «Subir archivos». También puedes seleccionar un PDF o imagen desde Google Drive.</span></div><details class="boarding-pass-advanced"><summary>Enlaces antiguos de Google Wallet</summary><div class="form-grid"><label class="field full">Mikel<input type="url" data-wallet-legacy="mikel" value="${esc(flight.walletMikelUrl||'')}"></label><label class="field full">Nerea<input type="url" data-wallet-legacy="nerea" value="${esc(flight.walletNereaUrl||'')}"></label></div><button type="button" class="btn secondary small" data-save-wallet-legacy>Guardar enlaces antiguos</button></details></div>`,true);
  $$('[data-close-modal]',els.modal).forEach(b=>b.addEventListener('click',closeModal));$$('[data-wallet-manage]',els.modal).forEach(b=>b.addEventListener('click',()=>manageBoardingPassFiles(index,b.dataset.walletManage)));$$('[data-wallet-view]',els.modal).forEach(b=>b.addEventListener('click',()=>openBoardingPassViewer(index,b.dataset.walletView)));
  $('[data-save-wallet-legacy]',els.modal)?.addEventListener('click',async()=>{flight.walletMikelUrl=String($('[data-wallet-legacy="mikel"]',els.modal)?.value||'').trim();flight.walletNereaUrl=String($('[data-wallet-legacy="nerea"]',els.modal)?.value||'').trim();await saveSection('cover');toast('Enlaces antiguos guardados.');});
}
function walletPassButtonMarkup(flight={},index=0,person="mikel",badge="M",color="#FFD000") {
  const key=person==='nerea'?'nerea':'mikel',fullName=boardingPassPersonLabel(key),files=visibleFiles(boardingPassFiles(flight,key)),url=String(key==='nerea'?flight.walletNereaUrl:flight.walletMikelUrl||'').trim(),hasFiles=files.length>0,valid=hasFiles||isValidUrl(url);
  const style=`--service-color:${esc(color)};--service-text:${esc(readableTextColor(color))}`;
  const inner=`<span class="wallet-pass-glyph" aria-hidden="true">${boardingPassMiniIconMarkup()}</span><span class="wallet-person-badge" aria-hidden="true">${esc(badge)}</span>`;
  const title=hasFiles
    ? `Tarjeta de embarque guardada · ${fullName}`
    : valid
      ? `Tarjeta de embarque · ${fullName}`
      : `Tarjeta de embarque · ${fullName} · añade una imagen o PDF desde Drive en Configuración → Datos viaje → Vuelos`;
  if(!valid)return `<span class="wallet-pass-btn disabled" style="${style}" title="${esc(title)}" aria-label="${esc(title)}">${inner}</span>`;
  return `<button type="button" class="wallet-pass-btn${hasFiles?' is-ready':' is-available'}" style="${style}" data-open-boarding-pass="${index}:${key}" title="${esc(title)}" aria-label="${esc(title)}">${inner}</button>`;
}
function disabledServiceButtonMarkup(label,color="#FFD000",iconHtml="",extraClass="",title=""){
  const style=`--service-color:${esc(color)};--service-text:${esc(readableTextColor(color))}`;
  const content=`${iconHtml}<span>${esc(label)}</span>`;
  const accessibility=` aria-label="${esc(title||label)}" title="${esc(title||label)}"`;
  return `<span class="service-link disabled ${esc(extraClass)}" style="${style}"${accessibility}>${content}</span>`;
}

function safeStoreLink(url, label, icon = "↗", color = "", appHint = "") {
  let parsed;
  try { parsed = new URL(String(url || ""), location.href); } catch { parsed = null; }
  const protocol = parsed?.protocol || "";
  const allowed = ["http:","https:","tel:","mailto:"].includes(protocol);
  const style = color ? ` style="--store-link:${esc(color)}"` : "";
  const smart=allowed&&smartAppActive(url,appHint),handoff=allowed&&nativeWebHandoffActive(url,appHint),href=smart?smartAppHref(url,appHint):String(url||"");
  const content=`<span class="store-link-icon">${icon}</span><span class="store-link-label">${esc(label)}</span>${smart?'<span class="smart-app-badge" aria-hidden="true">APP</span>':''}`;
  if (!allowed) return `<span class="link-btn store-link-btn disabled"${style}>${content}</span>`;
  const external = !smart && !handoff && ["http:","https:"].includes(protocol) ? ' target="_blank" rel="noopener"' : "";
  return `<a class="link-btn store-link-btn${smart?' smart-app-link':''}"${style} href="${esc(href)}"${external}>${content}</a>`;
}
function pdfFileIconMarkup(className="pdf-file-link-icon") {
  return `<img class="${esc(className)}" src="./icons/pdf-file.png?v=${APP_VERSION}-r1" alt="PDF" aria-hidden="true">`;
}
function priceHistoryIconMarkup(className="price-history-icon") {
  return `<img class="${esc(className)}" src="./icons/price-history.png?v=${APP_VERSION}-r1" alt="" aria-hidden="true">`;
}
function excelFileIconMarkup(className="excel-action-icon") {
  return `<img class="${esc(className)}" src="./icons/excel-file.png?v=${APP_VERSION}-r1" alt="Excel" aria-hidden="true">`;
}
function saveDiskIconMarkup(className="save-action-icon") {
  return `<img class="${esc(className)}" src="./icons/save-disk.png?v=${APP_VERSION}-r1" alt="" aria-hidden="true">`;
}
function saveButtonContent(text="Guardar") {
  return `${saveDiskIconMarkup("save-action-icon")}<span>${esc(text)}</span>`;
}
function decorateSaveButtons(root=document){
  if(!root?.querySelectorAll)return;
  root.querySelectorAll('button').forEach(button=>{
    const label=String(button.textContent||'').trim();
    if(!/^guardar(?:\b|\s)/i.test(label))return;
    button.classList.add('canary-save-btn');
    if(!button.querySelector('.save-action-icon'))button.insertAdjacentHTML('afterbegin',saveDiskIconMarkup('save-action-icon'));
  });
}
function popupFileLink(url, label, icon = "📄") {
  const iconHtml=icon==="📄"?pdfFileIconMarkup():icon;
  return isValidUrl(url) ? `<button class="link-btn" type="button" data-file-popup="${esc(url)}" data-file-title="${esc(label)}">${iconHtml} ${esc(label)}</button>` : `<span class="link-btn disabled">${iconHtml} ${esc(label)}</span>`;
}
function isFilePreviewUrl(url) {
  if (!isValidUrl(url)) return false;
  try { const parsed=new URL(url); return parsed.hostname.includes('drive.google.com') || parsed.hostname.includes('docs.google.com') || /\.(pdf|png|jpe?g|webp)(?:$|\?)/i.test(parsed.pathname+parsed.search); } catch { return false; }
}
function resilientImageMarkup(iconUrl,className,fallbackMarkup="",allowPreview=true) {
  const raw=String(iconUrl||"").trim();
  if(!raw)return fallbackMarkup;
  const driveId=driveFileIdFromUrl(raw);
  const previewAttr=allowPreview?` data-image-popup="${esc(raw)}"`:' data-resilient-no-popup="1"';
  // Los iconos que forman parte de un enlace/botón (Vueling, AENA, FlightAware,
  // etc.) NO deben interceptar el clic para abrir el visor de imágenes.
  // Solo las imágenes visuales independientes mantienen data-image-popup.
  if(!driveId)return `<img class="${esc(className)}" src="${esc(raw)}" alt="" data-resilient-icon="1"${previewAttr}>`;
  const drivePreviewAttr=allowPreview?` data-image-popup="${TRANSPARENT_IMAGE}"`:' data-resilient-no-popup="1"';
  return `<span class="resilient-icon-shell is-fallback" data-resilient-icon-shell><img class="${esc(className)}" src="${TRANSPARENT_IMAGE}" alt="" data-resilient-icon="1" data-drive-backed-image-id="${esc(driveId)}"${drivePreviewAttr}><span class="resilient-icon-fallback">${fallbackMarkup}</span></span>`;
}
function iconMarkup(icon, iconUrl, className = "custom-icon") {
  const fallback=`<span class="${esc(className)} emoji-icon">${esc(icon || "◼")}</span>`;
  return resilientImageMarkup(iconUrl,className,fallback,true);
}
function driveIconMarkup(className="drive-service-icon") {
  return `<img class="${esc(className)}" src="./icons/google-drive.svg" alt="Google Drive">`;
}
function brandIconMarkup(service,className="brand-service-icon") {
  const icons={google:"./icons/google-g.svg",tripadvisor:"./icons/tripadvisor.svg",booking:"./icons/booking.svg"};
  const src=icons[String(service||"").toLowerCase()]||"";
  return src?`<img class="${esc(className)}" src="${esc(src)}" alt="">`:"";
}
function serviceIconMarkup(icon,iconUrl,fallbackHtml="",className="brand-service-icon"){
  const text=String(icon||"").trim();
  const fallback=text?`<span class="${esc(className)} service-emoji-icon">${esc(text)}</span>`:(fallbackHtml||"");
  // Un icono de servicio está dentro de un enlace: nunca debe abrir el visor de imágenes.
  return resilientImageMarkup(iconUrl,className,fallback,false);
}
function readableTextColor(hex="#1675D1") {
  const value=String(hex||"").trim().replace(/^#/,"");
  if(!/^[0-9a-f]{6}$/i.test(value))return "#ffffff";
  const r=parseInt(value.slice(0,2),16),g=parseInt(value.slice(2,4),16),b=parseInt(value.slice(4,6),16);
  return (r*299+g*587+b*114)/1000>160?"#151515":"#ffffff";
}
function coloredServiceLink(url,label,color="#1675D1",iconHtml="",extraClass="",appHint="") {
  const valid=isValidUrl(url),style=`--service-color:${esc(color)};--service-text:${esc(readableTextColor(color))}`;
  const smart=valid&&smartAppActive(url,appHint),handoff=valid&&nativeWebHandoffActive(url,appHint),href=smart?smartAppHref(url,appHint):String(url||"");
  const content=`${iconHtml}<span>${esc(label)}</span>${smart?'<span class="smart-app-badge" aria-hidden="true">APP</span>':''}`;
  const external=smart||handoff?'':' target="_blank" rel="noopener"';
  const accessibility=` aria-label="${esc(label)}" title="${esc(label)}"`;
  return valid?`<a class="service-link ${esc(extraClass)}${smart?' smart-app-link':''}" style="${style}" href="${esc(href)}"${accessibility}${external}>${content}</a>`:`<span class="service-link disabled ${esc(extraClass)}" style="${style}"${accessibility}>${content}</span>`;
}
function coverToolbarIcon(type) {
  const common='viewBox="0 0 24 24" aria-hidden="true" focusable="false"';
  if(type==="flight") return `<svg ${common}><path d="M3 11.5 21 5l-6.5 18-3.1-7.1L3 11.5Z"/><path d="m11.4 15.9 3.2-3.2"/><path class="icon-plus" d="M17.5 2.5v5M15 5h5"/></svg>`;
  if(type==="lodging") return `<svg ${common}><path d="M4 21V5.5A1.5 1.5 0 0 1 5.5 4h9A1.5 1.5 0 0 1 16 5.5V21"/><path d="M8 8h1M12 8h1M8 12h1M12 12h1M8 16h1M12 16h1M2 21h20M18 10h2v11"/></svg>`;
  return `<svg ${common}><path d="m9.5 12.5 5.9-5.9a3.2 3.2 0 0 1 4.5 4.5l-7.5 7.5a5 5 0 0 1-7.1-7.1l7.2-7.2"/><path class="icon-plus" d="M18.5 16.5v5M16 19h5"/></svg>`;
}
function drivePreviewUrl(rawUrl) {
  if (!isValidUrl(rawUrl)) return "";
  try {
    const url = new URL(rawUrl);
    if (url.hostname.includes("drive.google.com")) {
      const fileMatch = url.pathname.match(/\/file\/d\/([^/]+)/);
      const id = fileMatch?.[1] || url.searchParams.get("id");
      if (id) return `https://drive.google.com/file/d/${encodeURIComponent(id)}/preview`;
    }
    if (url.hostname.includes("docs.google.com")) {
      return rawUrl.replace(/\/(edit|view)(?:\?.*)?$/, "/preview");
    }
    return rawUrl;
  } catch { return rawUrl; }
}
function setSaveState(text, kind = "") { els.saveState.textContent = text; els.saveState.className = `save-state ${kind}`; }
function toast(message, kind = "success") {
  const node = document.createElement("div"); node.className = `toast ${kind}`; node.textContent = message; els.toastRoot.append(node);
  setTimeout(() => node.remove(), 3600);
}
function confirmAction(message) { return window.confirm(message); }
function hashText(value) { return crypto.subtle.digest("SHA-256", new TextEncoder().encode(value)).then(b => [...new Uint8Array(b)].map(x => x.toString(16).padStart(2,"0")).join("")); }

class LocalProvider {
  constructor() { this.key = `mfe-travel:${TRIP_ID}`; }
  async init() { return true; }
  async login(email) { return { uid:"demo-user", email:email || "demo@mfe.local", displayName:"Mikel (demo)" }; }
  async logout() { return true; }
  async profile() { return { displayName:"Mikel (demo)", role:"admin", apps:{travel:true} }; }
  async load() { const raw = localStorage.getItem(this.key); return raw ? JSON.parse(raw) : clone(SEED_DATA); }
  async saveSection(section, value) { const all = await this.load(); all[section] = clone(value); localStorage.setItem(this.key, JSON.stringify(all)); }
  async saveAll(value) { localStorage.setItem(this.key, JSON.stringify(value)); }
  async uploadFile(file, path) { return { url:URL.createObjectURL(file), path:`demo/${path}/${file.name}`, mimeType:file.type || "" }; }
  async fileObjectUrl(file) { return file?.url || ""; }
  async call(name, payload) {
    if (name === "getTravelWeather") return sampleWeather(payload?.place || state.data.settings.weatherPlace);
    if (name === "importProductFromUrl") return callPriceWorker(payload);
    return null;
  }
}

class FirebaseProvider {
  async init() {
    const base = `https://www.gstatic.com/firebasejs/${SDK_VERSION}`;
    const [appM, authM, fsM, storageM, fnM] = await Promise.all([
      import(`${base}/firebase-app.js`), import(`${base}/firebase-auth.js`), import(`${base}/firebase-firestore.js`),
      import(`${base}/firebase-storage.js`), import(`${base}/firebase-functions.js`)
    ]);
    this.m = { ...appM, ...authM, ...fsM, ...storageM, ...fnM };
    this.app = this.m.initializeApp(firebaseConfig); this.auth = this.m.getAuth(this.app); this.db = this.m.getFirestore(this.app);
    this.storage = this.m.getStorage(this.app); this.functions = this.m.getFunctions(this.app, FUNCTIONS_REGION);
    state.firebase = this;
    return new Promise(resolve => this.m.onAuthStateChanged(this.auth, user => resolve(user || null)));
  }
  async refreshSession(user=this.auth?.currentUser) {
    if(!user)return;
    await user.getIdToken(true);
    await wait(180);
  }
  async login(email, password) {
    const user=(await this.m.signInWithEmailAndPassword(this.auth, email, password)).user;
    await this.refreshSession(user);
    return user;
  }
  async logout() { return this.m.signOut(this.auth); }
  async profile(user) {
    const readProfile=async()=>{
      const snap=await this.m.getDoc(this.m.doc(this.db,"mfeUsers",user.uid));
      return snap.exists()?snap.data():null;
    };
    try{return await readProfile();}
    catch(error){
      if(!isFirestorePermissionError(error))throw error;
      await this.refreshSession(user);
      return readProfile();
    }
  }
  async load() {
    const sections = Object.keys(SEED_DATA);
    const readSections=()=>Promise.all(sections.map(async section => {
      const snap = await this.m.getDoc(this.m.doc(this.db,"travelApps",TRIP_ID,"sections",section));
      return [section, snap.exists() ? snap.data().value : null];
    }));
    let values;
    try{values=await readSections();}
    catch(error){
      if(!isFirestorePermissionError(error))throw error;
      await this.refreshSession();
      values=await readSections();
    }
    const found = Object.fromEntries(values.filter(([,v]) => v !== null));
    if (!Object.keys(found).length && roleCanEdit()) {
      await Promise.all(sections.map(section => this.saveSection(section, SEED_DATA[section])));
      return clone(SEED_DATA);
    }
    return { ...clone(SEED_DATA), ...found };
  }
  async saveSection(section, value) {
    // Firestore rechaza cualquier `undefined`, aunque esté profundamente anidado
    // en un producto. Saneamos la sección completa antes de escribir para que
    // editar/reparar un enlace antiguo nunca bloquee el guardado.
    const safeValue=firestoreSafe(clone(value));
    await this.m.setDoc(this.m.doc(this.db,"travelApps",TRIP_ID,"sections",section), { value:safeValue, updatedAt:this.m.serverTimestamp(), updatedBy:state.user?.uid || null }, { merge:true });
  }
  async saveAll(data) { await Promise.all(Object.entries(data).map(([section,value]) => this.saveSection(section,value))); }
  async uploadFile(file, path) {
    const clean = file.name.replace(/[^a-zA-Z0-9._-]/g,"_"); const storagePath = `travelApps/${TRIP_ID}/${path}/${Date.now()}-${clean}`;
    const inferredType=file.type||(/\.png$/i.test(clean)?'image/png':/\.webp$/i.test(clean)?'image/webp':/\.gif$/i.test(clean)?'image/gif':/\.svg$/i.test(clean)?'image/svg+xml':/\.jpe?g$/i.test(clean)?'image/jpeg':/\.pdf$/i.test(clean)?'application/pdf':'application/octet-stream');
    const ref = this.m.ref(this.storage, storagePath); await this.m.uploadBytes(ref,file,{contentType:inferredType});
    return { url:await this.m.getDownloadURL(ref), path:storagePath, mimeType:inferredType };
  }
  async refreshStorageUrl(storagePath) {
    if(!storagePath)throw new Error("El archivo no tiene ruta de almacenamiento.");
    return this.m.getDownloadURL(this.m.ref(this.storage, storagePath));
  }
  async fileObjectUrl(file = {}) {
    if(file.storagePath){
      const ref=this.m.ref(this.storage,file.storagePath);
      try{
        const blob=await this.m.getBlob(ref);
        return URL.createObjectURL(blob);
      }catch(error){
        console.warn("No se pudo descargar el archivo autenticado; se usará su URL pública.",error);
        return this.m.getDownloadURL(ref);
      }
    }
    return file.url || "";
  }
  async enablePush(vapidKey) {
    if(!vapidKey)throw new Error("Configura primero la clave pública VAPID de Firebase Cloud Messaging.");
    const base=`https://www.gstatic.com/firebasejs/${SDK_VERSION}`;
    const messagingM=await import(`${base}/firebase-messaging.js`);
    if(!await messagingM.isSupported())throw new Error("Firebase Messaging no es compatible con este navegador.");
    const registration=await navigator.serviceWorker.ready;
    const messaging=messagingM.getMessaging(this.app);
    const token=await messagingM.getToken(messaging,{vapidKey,serviceWorkerRegistration:registration});
    if(!token)throw new Error("Firebase no ha devuelto un token de notificaciones.");
    if(!this._foregroundMessagingBound){
      messagingM.onMessage(messaging, payload=>{
        const data=payload?.data||{};const note=payload?.notification||{};
        registration.showNotification(note.title||data.title||"MFE Viajes",{body:note.body||data.body||"Has recibido una notificación de prueba.",icon:data.icon||state.data.settings.appIconUrl||"./icons/app-icon.svg",badge:"./icons/app-icon.svg",data:{url:data.url||"./"},tag:data.tag||"mfe-viajes-fcm",renotify:true}).catch(console.warn);
      });
      this._foregroundMessagingBound=true;
    }
    await this.m.setDoc(this.m.doc(this.db,"travelApps",TRIP_ID,"pushDevices",state.user.uid),{token,enabled:true,updatedAt:this.m.serverTimestamp(),userAgent:navigator.userAgent,displayName:state.profile?.displayName||state.user?.email||"Usuario"},{merge:true});
    return token;
  }
  async messagingSupported(){
    const base=`https://www.gstatic.com/firebasejs/${SDK_VERSION}`;
    const messagingM=await import(`${base}/firebase-messaging.js`);
    return messagingM.isSupported();
  }
  async disablePush() {
    if(!state.user?.uid)return;
    await this.m.setDoc(this.m.doc(this.db,"travelApps",TRIP_ID,"pushDevices",state.user.uid),{enabled:false,updatedAt:this.m.serverTimestamp()},{merge:true});
  }
  async call(name, payload) { return (await this.m.httpsCallable(this.functions,name)(payload)).data; }
}

function sampleWeather(place = "Arguineguín") {
  const now = new Date();
  return {
    place, current:{ text:"Parcialmente soleado", temp:29, icon:"🌤️", link:"" },
    forecast:[0,1,2,3,4,5,6].map((n) => { const d = new Date(now); d.setDate(d.getDate()+n); const date=d.toISOString().slice(0,10); return { date, min:23+n%2, max:29+n%3, text:n%2?"Soleado":"Nubes y claros", icon:n%2?"☀️":"🌤️", sunrise:`${date}T07:${String(35+n).padStart(2,"0")}`, sunset:`${date}T20:${String(10-Math.min(n,6)).padStart(2,"0")}` }; })
  };
}

function weatherCodeInfo(code, isDay = 1) {
  const c = Number(code);
  if (c === 0) return { text:"Despejado", icon:isDay ? "☀️" : "🌙" };
  if (c === 1) return { text:"Principalmente despejado", icon:isDay ? "🌤️" : "🌙" };
  if (c === 2) return { text:"Nubes y claros", icon:isDay ? "⛅" : "☁️" };
  if (c === 3) return { text:"Cubierto", icon:"☁️" };
  if ([45,48].includes(c)) return { text:"Niebla", icon:"🌫️" };
  if ([51,53,55,56,57].includes(c)) return { text:"Llovizna", icon:"🌦️" };
  if ([61,63,65,66,67].includes(c)) return { text:"Lluvia", icon:"🌧️" };
  if ([71,73,75,77].includes(c)) return { text:"Nieve", icon:"🌨️" };
  if ([80,81,82].includes(c)) return { text:"Chubascos", icon:"🌦️" };
  if ([85,86].includes(c)) return { text:"Chubascos de nieve", icon:"🌨️" };
  if ([95,96,99].includes(c)) return { text:"Tormenta", icon:"⛈️" };
  return { text:"Tiempo variable", icon:"🌤️" };
}

function weatherClockTime(value) {
  const text=String(value||"").trim();
  const match=text.match(/T(\d{2}:\d{2})/);
  if(match)return match[1];
  return /^\d{2}:\d{2}$/.test(text)?text:"—";
}

async function resolveWeatherLocation() {
  const s = state.data.settings;
  const latitude = Number.parseFloat(String(s.weatherLatitude ?? "").replace(",","."));
  const longitude = Number.parseFloat(String(s.weatherLongitude ?? "").replace(",","."));
  if (Number.isFinite(latitude) && Number.isFinite(longitude)) {
    return { latitude, longitude, name:s.weatherPlace || state.data.settings.destination || "Destino" };
  }
  const query = String(s.weatherPlace || state.data.settings.destination || "").trim();
  if (!query) throw new Error("Escribe una localidad o unas coordenadas en Configuración.");
  const url = new URL("https://geocoding-api.open-meteo.com/v1/search");
  url.searchParams.set("name", query);
  url.searchParams.set("count", "8");
  url.searchParams.set("language", "es");
  url.searchParams.set("format", "json");
  const response = await fetch(url);
  if (!response.ok) throw new Error(`No se ha podido localizar el destino (HTTP ${response.status}).`);
  const data = await response.json();
  const results = Array.isArray(data.results) ? data.results : [];
  const location = results.find(x => x.country_code === "ES") || results[0];
  if (!location) throw new Error(`No se ha encontrado «${query}». Prueba a indicar latitud y longitud.`);
  return { latitude:location.latitude, longitude:location.longitude, name:location.name || query };
}

async function loadOpenMeteoWeather() {
  const location = await resolveWeatherLocation();
  const url = new URL("https://api.open-meteo.com/v1/forecast");
  url.searchParams.set("latitude", location.latitude);
  url.searchParams.set("longitude", location.longitude);
  url.searchParams.set("current", "temperature_2m,apparent_temperature,weather_code,is_day");
  url.searchParams.set("daily", "weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset");
  url.searchParams.set("timezone", "auto");
  url.searchParams.set("forecast_days", "7");
  const response = await fetch(url);
  if (!response.ok) throw new Error(`Open-Meteo ha respondido con HTTP ${response.status}.`);
  const data = await response.json();
  const currentInfo = weatherCodeInfo(data.current?.weather_code, data.current?.is_day);
  const dates = data.daily?.time || [];
  return {
    place: state.data.settings.weatherPlace || location.name,
    latitude: location.latitude,
    longitude: location.longitude,
    current: {
      temp: Math.round(num(data.current?.temperature_2m)),
      apparent: Math.round(num(data.current?.apparent_temperature)),
      text: currentInfo.text,
      icon: currentInfo.icon
    },
    forecast: dates.map((date,index) => {
      const info = weatherCodeInfo(data.daily?.weather_code?.[index], 1);
      return {
        date,
        min: Math.round(num(data.daily?.temperature_2m_min?.[index])),
        max: Math.round(num(data.daily?.temperature_2m_max?.[index])),
        text: info.text,
        icon: info.icon,
        sunrise: data.daily?.sunrise?.[index] || "",
        sunset: data.daily?.sunset?.[index] || ""
      };
    })
  };
}

async function saveSection(section) {
  if (!state.provider) return false;
  try {
    setSaveState("Guardando…","saving");
    await state.provider.saveSection(section,state.data[section]);
    if (["cover","budget","settings"].includes(section)) {
      const sync=synchronizeTrackerTripDataLocally();
      if(sync.changed.length){
        await state.provider.saveSection("trackers",state.data.trackers);
        syncTrackerWorkersFromTripData(sync.changed).catch(error=>console.warn("Sincronización automática de seguimientos pendiente:",error));
      }
    }
    setSaveState("Guardado");
    return true;
  } catch (error) {
    console.error(error);
    setSaveState("Error","error");
    toast(`No se ha podido guardar: ${error.message}`,"error");
    return false;
  }
}

function imageMimeType(source) {
  const match=String(source||"").match(/^data:([^;,]+)/i);
  if(match)return match[1];
  if(/\.png(?:$|\?)/i.test(source))return "image/png";
  if(/\.webp(?:$|\?)/i.test(source))return "image/webp";
  if(/\.jpe?g(?:$|\?)/i.test(source))return "image/jpeg";
  if(/\.svg(?:$|\?)/i.test(source))return "image/svg+xml";
  return "image/png";
}
function xmlAttributeEscape(value="") {
  return String(value).replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
}
function darkMaskableInstallIcon(source) {
  const safeSource=xmlAttributeEscape(source);
  const svg=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><rect width="512" height="512" fill="#111318"/><image href="${safeSource}" x="62" y="62" width="388" height="388" preserveAspectRatio="xMidYMid meet"/></svg>`;
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}
async function buildAdaptiveInstallIcon(source,{size=512,padding=0.16,background='transparent',trimAlpha=8,borderColor='',borderWidthRatio=0.06,borderInsetRatio=0.04}={}){
  const src=String(source||"").trim();
  if(!src)return "";
  return await new Promise(resolve=>{
    const img=new Image();
    img.decoding='async';
    img.crossOrigin='anonymous';
    img.onload=()=>{
      try{
        const sampleCanvas=document.createElement('canvas');
        sampleCanvas.width=img.width; sampleCanvas.height=img.height;
        const sampleCtx=sampleCanvas.getContext('2d',{alpha:true,willReadFrequently:true});
        sampleCtx.clearRect(0,0,img.width,img.height);
        sampleCtx.drawImage(img,0,0);
        const imageData=sampleCtx.getImageData(0,0,img.width,img.height);
        const data=imageData.data;
        let minX=img.width, minY=img.height, maxX=-1, maxY=-1;
        for(let y=0;y<img.height;y++){
          for(let x=0;x<img.width;x++){
            const idx=(y*img.width+x)*4+3;
            if(data[idx]>trimAlpha){
              if(x<minX)minX=x;
              if(y<minY)minY=y;
              if(x>maxX)maxX=x;
              if(y>maxY)maxY=y;
            }
          }
        }
        const hasContent=maxX>=minX && maxY>=minY;
        const cropX=hasContent?minX:0;
        const cropY=hasContent?minY:0;
        const cropW=hasContent?(maxX-minX+1):img.width;
        const cropH=hasContent?(maxY-minY+1):img.height;
        const canvas=document.createElement('canvas');
        canvas.width=size; canvas.height=size;
        const transparentBackground=background==='transparent';
        const ctx=canvas.getContext('2d',{alpha:transparentBackground});
        if(!transparentBackground){
          ctx.fillStyle=background;
          ctx.fillRect(0,0,size,size);
        } else {
          ctx.clearRect(0,0,size,size);
        }
        ctx.imageSmoothingEnabled=true;
        ctx.imageSmoothingQuality='high';
        if(borderColor){
          const borderWidth=Math.max(2,size*Math.max(0.02,Math.min(0.12,borderWidthRatio)));
          const borderInset=size*Math.max(0.01,Math.min(0.14,borderInsetRatio));
          const radius=(size/2)-(borderWidth/2)-borderInset;
          ctx.beginPath();
          ctx.arc(size/2,size/2,Math.max(1,radius),0,Math.PI*2);
          ctx.strokeStyle=borderColor;
          ctx.lineWidth=borderWidth;
          ctx.stroke();
        }
        const safePadding=Math.max(0.08,Math.min(0.24,padding));
        const target=size*(1-safePadding*2);
        const ratio=Math.min(target/cropW,target/cropH);
        const drawW=Math.max(1,cropW*ratio), drawH=Math.max(1,cropH*ratio);
        const dx=(size-drawW)/2, dy=(size-drawH)/2;
        ctx.drawImage(sampleCanvas,cropX,cropY,cropW,cropH,dx,dy,drawW,drawH);
        resolve(canvas.toDataURL('image/png'));
      }catch(error){
        console.warn('No se pudo generar icono adaptativo PNG',error);
        resolve(src);
      }
    };
    img.onerror=()=>resolve(src);
    img.src=src;
  });
}
let manifestRenderToken=0;
async function updateInstallManifest() {
  const s=state.data.settings||{};
  const name=String(s.appName||DEFAULT_APP_IDENTITY.name).trim()||DEFAULT_APP_IDENTITY.name;
  const icon=isImageSource(s.appIconUrl)?s.appIconUrl:new URL("./icons/app-icon.svg",location.href).href;
  const signature=`${name}|${icon}`;
  if(signature===dynamicManifestSignature)return;
  dynamicManifestSignature=signature;
  const token=++manifestRenderToken;
  const customIcon=isImageSource(s.appIconUrl);
  const iconRevision=shortHash(icon);
  let install192Url=new URL(`./icons/install-icon-192.png?v=${APP_VERSION}`,location.href).href;
  let install512Url=new URL(`./icons/install-icon-512.png?v=${APP_VERSION}`,location.href).href;
  let installMaskableUrl=new URL(`./icons/install-icon-maskable-512.png?v=${APP_VERSION}`,location.href).href;
  if(customIcon){
    const installBackground='#0f1b2d';
    const generatedInstall192=await buildAdaptiveInstallIcon(icon,{size:192,padding:0.18,background:installBackground,trimAlpha:4});
    const generatedInstall512=await buildAdaptiveInstallIcon(icon,{size:512,padding:0.18,background:installBackground,trimAlpha:4});
    const generatedInstallMaskable512=await buildAdaptiveInstallIcon(icon,{size:512,padding:0.14,background:installBackground,trimAlpha:4});
    install192Url=new URL(`./dynamic-icons/install-icon-192.png?v=${APP_VERSION}-${iconRevision}`,location.href).href;
    install512Url=new URL(`./dynamic-icons/install-icon-512.png?v=${APP_VERSION}-${iconRevision}`,location.href).href;
    installMaskableUrl=new URL(`./dynamic-icons/install-icon-maskable-512.png?v=${APP_VERSION}-${iconRevision}`,location.href).href;
    await syncInstallIcons({
      [install192Url]:generatedInstall192,
      [install512Url]:generatedInstall512,
      [installMaskableUrl]:generatedInstallMaskable512
    });
  }
  if(token!==manifestRenderToken)return;
  const manifest={
    id:new URL("./",location.href).href,
    name,
    short_name:name.length>24?name.slice(0,24):name,
    description:`Gestión privada del viaje ${s.destination||""}`.trim(),
    start_url:new URL("./",location.href).href,
    scope:new URL("./",location.href).href,
    display:"standalone",
    background_color:"#111318",
    theme_color:"#111318",
    orientation:"any",
    icons:customIcon?[
      {src:install192Url,sizes:"192x192",type:"image/png",purpose:"any"},
      {src:install512Url,sizes:"512x512",type:"image/png",purpose:"any"},
      {src:installMaskableUrl,sizes:"512x512",type:"image/png",purpose:"maskable"}
    ]:[
      {src:icon,sizes:"any",type:imageMimeType(icon),purpose:"any"},
      {src:new URL("./icons/maskable-icon.svg",location.href).href,sizes:"any",type:"image/svg+xml",purpose:"maskable"}
    ]
  };
  const manifestRevision=shortHash(`${name}|${icon}`);
  const stableManifestUrl=new URL(`./dynamic-manifest.webmanifest?v=${APP_VERSION}-${manifestRevision}`,location.href).href;
  const manifestSynced=await syncInstallManifest(stableManifestUrl,manifest);
  if(token!==manifestRenderToken)return;
  const link=document.querySelector('link[rel="manifest"]');
  if(manifestSynced){
    if(dynamicManifestUrl){URL.revokeObjectURL(dynamicManifestUrl);dynamicManifestUrl="";}
    if(link)link.href=stableManifestUrl;
  }else{
    if(dynamicManifestUrl)URL.revokeObjectURL(dynamicManifestUrl);
    dynamicManifestUrl=URL.createObjectURL(new Blob([JSON.stringify(manifest)],{type:"application/manifest+json"}));
    if(link)link.href=dynamicManifestUrl;
  }
  const appleTouchLink=document.querySelector('link[rel="apple-touch-icon"]');
  if(appleTouchLink)appleTouchLink.href=customIcon?install192Url:new URL(`./icons/apple-touch-icon.png?v=${APP_VERSION}`,location.href).href;
  const appNameMeta=document.querySelector('meta[name="application-name"]');
  if(appNameMeta)appNameMeta.content=name;
}
async function syncNotificationIcon(){
  if(!('serviceWorker' in navigator))return;
  const iconUrl=state.data.settings.appIconUrl||new URL('./icons/app-icon.svg',location.href).href;
  if(iconUrl===notificationIconSignature)return;
  notificationIconSignature=iconUrl;
  try{
    const registration=await navigator.serviceWorker.ready;
    registration.active?.postMessage({type:'SET_NOTIFICATION_ICON',iconUrl});
  }catch(error){notificationIconSignature='';console.warn('No se pudo sincronizar el icono de notificaciones',error);}
}

function applyTheme() {
  const t = state.data.settings.theme;
  const root = document.documentElement;
  const map = { accent:"--accent",accent2:"--accent-2",surface:"--surface",surface2:"--surface-2",text:"--text",muted:"--muted",success:"--success",danger:"--danger",warning:"--warning" };
  Object.entries(map).forEach(([key,css]) => t[key] && root.style.setProperty(css,t[key]));
  const premium=String(state.data.settings.visualStyle||"premium")!=="classic";
  document.body.classList.toggle("design-premium",premium);
  document.body.classList.toggle("design-classic",!premium);
  document.title = `${state.data.settings.appName} · ${state.data.settings.destination} ${state.data.settings.year}`;
  updateInstallManifest();
  syncNotificationIcon();
}

function updateHeader() {
  const s = state.data.settings;
  if(els.footerVersion)els.footerVersion.textContent=`${s.appName || DEFAULT_APP_IDENTITY.name} · v${APP_VERSION}`;
  els.appName.textContent = s.appName || DEFAULT_APP_IDENTITY.name; els.destination.textContent = s.destination || "Destino"; const headerYear=String(s.year||""); if(/^\d{4}$/.test(headerYear)){els.year.innerHTML=`<span class="header-year-blue">${esc(headerYear.slice(0,2))}</span><span class="header-year-yellow">${esc(headerYear.slice(2))}</span>`;}else{els.year.textContent=headerYear;}
  applyIdentityLogo(els.headerIcon,s.appIconUrl,s.appIcon||DEFAULT_APP_IDENTITY.icon);
  const favicon=document.querySelector('link[rel="icon"]');if(favicon&&isImageSource(s.appIconUrl))favicon.href=s.appIconUrl;
  applyIdentityToPublicViews({name:s.appName,icon:s.appIcon,iconUrl:s.appIconUrl});
  void persistAppIdentity(s);
  els.userName.textContent = state.profile?.displayName || state.user?.displayName || state.user?.email || "Usuario";
  els.userRole.textContent = state.profile?.role || "viewer";
  const currentUnlocked=currentTabUnlocked();
  els.editLock.innerHTML = currentUnlocked
    ? '<svg class="lock-symbol thin-lock" viewBox="0 0 24 24" aria-hidden="true"><rect x="5.5" y="9" width="13" height="11" rx="2.2"/><path d="M9 9V6.7a3.6 3.6 0 0 1 6.8-1.65"/><circle cx="12" cy="14.5" r="1.25"/></svg>'
    : '<svg class="lock-symbol thin-lock" viewBox="0 0 24 24" aria-hidden="true"><rect x="5.5" y="9" width="13" height="11" rx="2.2"/><path d="M8.5 9V6.5a3.5 3.5 0 0 1 7 0V9"/><circle cx="12" cy="14.5" r="1.25"/></svg>';
  els.editLock.classList.toggle("lock-open",currentUnlocked);els.editLock.classList.toggle("lock-closed",!currentUnlocked);
  els.editLock.title = roleCanEdit() ? (currentUnlocked ? "Edición desbloqueada · pulsar para bloquear" : "Edición bloqueada · pulsar para desbloquear") : "Usuario de solo lectura";
}

function renderNav() {
  const enabled = new Set(state.data.settings.enabledTabs || TABS.map(t => t[0]));
  const customIcons=state.data.settings.tabIconUrls||{};
  const order=state.data.settings.tabOrder||TABS.map(t=>t[0]);
  const lookup=new Map(TABS.map(t=>[t[0],t]));
  const ordered=[...order.map(id=>lookup.get(id)).filter(Boolean),...TABS.filter(t=>!order.includes(t[0]))];
  const bottom=state.data.settings.navigationPosition==="bottom";
  els.nav.classList.toggle("nav-bottom",bottom);
  document.body.classList.toggle("has-bottom-nav",bottom);
  els.nav.innerHTML = ordered.filter(([id]) => enabled.has(id) || id === "settings").map(([id,icon,label]) =>
    `<button class="nav-btn ${state.activeTab===id?"active":""}" data-tab="${id}"><span class="nav-icon">${isImageSource(customIcons[id])?`<img src="${esc(customIcons[id])}" alt="">`:esc(icon)}</span><span>${esc(label)}</span></button>`).join("");
  $$('[data-tab]',els.nav).forEach(btn => btn.addEventListener("click",() => navigateToTab(btn.dataset.tab)));
  const updateNavOverflow=()=>{
    const overflowing=els.nav.scrollWidth>els.nav.clientWidth+4;
    els.nav.classList.toggle('nav-overflowing',overflowing);
    els.nav.classList.toggle('nav-centered',bottom&&!overflowing);
  };
  requestAnimationFrame(()=>{updateNavOverflow();els.nav.querySelector('.nav-btn.active')?.scrollIntoView({inline:'center',block:'nearest',behavior:'smooth'});});
  if(!els.nav._mfeResizeObserver&&'ResizeObserver'in window){els.nav._mfeResizeObserver=new ResizeObserver(updateNavOverflow);els.nav._mfeResizeObserver.observe(els.nav);}
}

function lockedBanner() {
  return roleCanEdit() ? "" : `<div class="locked-banner"><span>👁️ Estás en modo de solo lectura.</span></div>`;
}
function bindUnlockButtons() { $$('[data-unlock]').forEach(b => b.addEventListener('click',toggleUnlock)); }

function pageHead(title, subtitle, actions = "") {
  return `<div class="page-head"><div><h2>${esc(title)}</h2></div><div class="page-actions">${actions}</div></div>`;
}

function closeModal() { try{if(state.webcamRefreshTimer){clearInterval(state.webcamRefreshTimer);state.webcamRefreshTimer=null;}const video=els.modal?.querySelector?.(".webcam-direct-video");video?._mfeHls?.destroy?.();}catch{} state.coverCarouselPopup=null; els.modalBackdrop.classList.add("hidden"); els.modalBackdrop.setAttribute("aria-hidden","true"); els.modal.innerHTML=""; els.modal.classList.remove("modal-wide"); }
function openModal(content, wide = false) { els.modal.classList.toggle("modal-wide",wide); els.modal.classList.toggle("settings-canary-popup",state.activeTab==="settings"); els.modal.innerHTML=content; decorateSaveButtons(els.modal); els.modalBackdrop.classList.remove("hidden"); els.modalBackdrop.setAttribute("aria-hidden","false"); $("[data-close-modal]",els.modal)?.addEventListener("click",closeModal); }
function openImagePopup(url, title = "Imagen") {
  if (!isImageSource(url)) return;
  state.coverCarouselPopup=null;
  openModal(`<div class="modal-head"><h3>${esc(title)}</h3><button class="close-btn" data-close-modal>×</button></div><div class="media-popup-body"><img class="popup-image" src="${esc(url)}" alt="${esc(title)}"></div>`,true);
}

function openFilePopup(url, title = "Archivo") {
  if (!isValidUrl(url)) return;
  state.coverCarouselPopup=null;
  const preview = drivePreviewUrl(url);
  openModal(`<div class="modal-head"><h3>${esc(title)}</h3><div class="mini-actions"><a class="link-btn" href="${esc(url)}" target="_blank" rel="noopener">↗ Abrir aparte</a><button class="close-btn" data-close-modal>×</button></div></div><div class="media-popup-body file-popup-body"><iframe class="file-preview-frame" src="${esc(preview)}" title="${esc(title)}" loading="lazy"></iframe><p class="preview-fallback">Si el archivo no se muestra, utiliza «Abrir aparte».</p></div>`,true);
}
function coverCarouselPopupIsImage(file={}){
  const mime=String(file.mimeType||'').toLowerCase(),url=String(file.url||file.driveUrl||'').toLowerCase();
  return file.type==='image'||mime.startsWith('image/')||/\.(png|jpe?g|webp|gif|svg)(?:$|[?#])/.test(url);
}
async function openCoverCarouselPopup(carouselId,target=0){
  const id=String(carouselId||''),carousel=findCoverMediaCarousel(id),files=visibleFiles(carousel?.files||[]);
  if(!carousel||!files.length)return;
  let index=typeof target==='number'?Math.trunc(target):files.findIndex(file=>String(file.id||'')===String(target||''));
  if(index<0||index>=files.length)index=Math.min(Math.max(0,num(state.coverCarouselSlides[id]||0)),files.length-1);
  const file=files[index],fileId=String(file?.id||''),title=String(file?.label||carousel.title||`Elemento ${index+1}`),total=files.length;
  state.coverCarouselSlides[id]=index;
  state.coverCarouselPopup={id,index,fileId};
  const navHint=total>1?`<small class="carousel-popup-hint">${index+1}/${total} · ← → para cambiar</small>`:`<small class="carousel-popup-hint">1/1</small>`;
  if(coverCarouselPopupIsImage(file)){
    const driveId=officialFileDriveId(file),initial=driveId?TRANSPARENT_IMAGE:String(file.url||file.driveUrl||'');
    openModal(`<div class="modal-head"><div><h3>${esc(title)}</h3>${navHint}</div><button class="close-btn" data-close-modal>×</button></div><div class="media-popup-body carousel-popup-body"><div class="carousel-popup-image-shell ${driveId?'is-loading':''}"><img class="popup-image" src="${esc(initial||TRANSPARENT_IMAGE)}" alt="${esc(title)}"><span class="carousel-popup-loading">Cargando desde Google Drive…</span><span class="carousel-popup-error"></span></div></div>`,true);
    state.coverCarouselPopup={id,index,fileId};
    if(driveId){
      try{
        const resolved=await fetchDriveMediaObjectUrl(file,true,true);
        const current=state.coverCarouselPopup;
        if(!current||current.id!==id||current.index!==index)return;
        const shell=$('.carousel-popup-image-shell',els.modal),img=$('.popup-image',els.modal);
        if(!resolved)throw new Error('La imagen no tiene una URL válida.');
        if(img)img.src=resolved;
        shell?.classList.remove('is-loading','has-error');
      }catch(error){
        const current=state.coverCarouselPopup;if(!current||current.id!==id||current.index!==index)return;
        const shell=$('.carousel-popup-image-shell',els.modal),message=$('.carousel-popup-error',els.modal);
        shell?.classList.remove('is-loading');shell?.classList.add('has-error');
        if(message)message.textContent=String(error?.message||'No se ha podido cargar la imagen desde Drive.').slice(0,320);
      }
    }
    return;
  }
  const url=coverCarouselFileUrl(file),preview=coverCarouselPdfPreviewUrl(file)||drivePreviewUrl(url);
  openModal(`<div class="modal-head"><div><h3>${esc(title)}</h3>${navHint}</div><div class="mini-actions">${isValidUrl(url)?`<a class="link-btn" href="${esc(url)}" target="_blank" rel="noopener">↗ Abrir aparte</a>`:''}<button class="close-btn" data-close-modal>×</button></div></div><div class="media-popup-body file-popup-body carousel-popup-body">${preview?`<iframe class="file-preview-frame" src="${esc(preview)}" title="${esc(title)}" loading="lazy"></iframe>`:`<div class="empty">No hay vista previa disponible.</div>`}<p class="preview-fallback">Usa ← y → para pasar al elemento anterior o siguiente del carrusel.</p></div>`,true);
  state.coverCarouselPopup={id,index,fileId};
}
function stepCoverCarouselPopup(delta){
  const current=state.coverCarouselPopup;if(!current)return;
  const carousel=findCoverMediaCarousel(current.id),files=visibleFiles(carousel?.files||[]);if(files.length<2)return;
  const next=(num(current.index)+num(delta)+files.length)%files.length;
  openCoverCarouselPopup(current.id,next);
}
function bindMediaPopups() {
  $$('[data-image-popup]').forEach(node=>node.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();if(node.dataset.coverCarouselId){const raw=node.dataset.coverCarouselPopupIndex;openCoverCarouselPopup(node.dataset.coverCarouselId,raw===''||raw===undefined?node.dataset.coverCarouselFileId:num(raw));return;}openImagePopup(node.dataset.imagePopup,node.getAttribute('alt')||node.dataset.imageTitle||'Imagen');}));
  $$('[data-file-popup]').forEach(node=>node.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();if(node.dataset.coverCarouselId){const raw=node.dataset.coverCarouselPopupIndex;openCoverCarouselPopup(node.dataset.coverCarouselId,raw===''||raw===undefined?node.dataset.coverCarouselFileId:num(raw));return;}openFilePopup(node.dataset.filePopup,node.dataset.fileTitle||'Archivo');}));
}
function fileToSquareDataUrl(file, size = 128) {
  return new Promise((resolve,reject)=>{
    if (!file || !file.type?.startsWith("image/")) { reject(new Error("Selecciona un archivo PNG, JPG, WEBP o SVG.")); return; }
    if (file.size > 8 * 1024 * 1024) { reject(new Error("La imagen es demasiado grande. Utiliza un archivo de menos de 8 MB.")); return; }
    const reader=new FileReader();
    reader.onerror=()=>reject(new Error("No se ha podido leer la imagen."));
    reader.onload=()=>{
      const img=new Image();
      img.onerror=()=>reject(new Error("La imagen no es válida o el navegador no puede abrirla."));
      img.onload=()=>{
        const canvas=document.createElement("canvas");
        canvas.width=size;canvas.height=size;
        const ctx=canvas.getContext("2d",{alpha:true});
        ctx.clearRect(0,0,size,size);
        ctx.imageSmoothingEnabled=true;ctx.imageSmoothingQuality="high";
        const scale=Math.min(size/img.width,size/img.height);
        const width=Math.max(1,img.width*scale),height=Math.max(1,img.height*scale);
        ctx.drawImage(img,(size-width)/2,(size-height)/2,width,height);
        try {
          const dataUrl=canvas.toDataURL("image/png");
          if(!dataUrl.startsWith("data:image/png"))throw new Error("No se ha podido convertir la imagen a PNG.");
          resolve(dataUrl);
        } catch(error) { reject(error); }
      };
      img.src=reader.result;
    };
    reader.readAsDataURL(file);
  });
}

els.modalBackdrop.addEventListener("click",e => { if (e.target===els.modalBackdrop) { if(typeof state.driveBrowserCancel==="function")state.driveBrowserCancel(); else closeModal(); } });
document.addEventListener("keydown",e => {
  if (e.key==="Escape") { if(typeof state.driveBrowserCancel==="function")state.driveBrowserCancel(); else closeModal(); return; }
  if((e.key==="ArrowLeft"||e.key==="ArrowRight")&&state.coverCarouselPopup&&!els.modalBackdrop.classList.contains("hidden")){
    const tag=String(e.target?.tagName||'').toLowerCase();
    if(tag==='input'||tag==='textarea'||tag==='select'||e.target?.isContentEditable)return;
    e.preventDefault();stepCoverCarouselPopup(e.key==="ArrowRight"?1:-1);
  }
});

function colorControlHtml(name, value, disabled = "", idPrefix = "") {
  const normalized=normalizeHexColor(value,"#000000");
  const id=idPrefix||`color-${String(name||'field').replace(/[^a-z0-9_-]/gi,'-')}`;
  return `<div class="hex-color-control" data-hex-color-control><input id="${esc(id)}" data-color-picker name="${esc(name)}" type="color" value="${esc(normalized)}" ${disabled}><input class="hex-color-text" data-color-hex type="text" value="${esc(normalized)}" maxlength="7" inputmode="text" autocomplete="off" spellcheck="false" aria-label="Código hexadecimal de color" placeholder="#RRGGBB" required ${disabled}></div>`;
}
function bindHexColorControls(root=document) {
  $$('[data-hex-color-control]',root).forEach(control=>{
    if(control.dataset.hexColorBound==='1')return;
    control.dataset.hexColorBound='1';
    const picker=$('[data-color-picker]',control),hex=$('[data-color-hex]',control);
    if(!picker||!hex)return;
    let syncingFromHex=false;
    const initial=normalizeHexColor(hex.value,picker.value||'#000000');
    control.dataset.lastValidHex=initial;
    hex.value=initial;picker.value=initial;
    const clearEditingState=()=>{hex.classList.remove('is-invalid');hex.setCustomValidity('');};
    const applyCompleteHex=(normalizeText=false)=>{
      if(!isHexColor(hex.value))return false;
      const normalized=normalizeHexColor(hex.value,control.dataset.lastValidHex||picker.value);
      control.dataset.lastValidHex=normalized;
      if(normalizeText)hex.value=normalized;
      if(picker.value.toUpperCase()!==normalized){
        syncingFromHex=true;
        picker.value=normalized;
        picker.dispatchEvent(new Event('input',{bubbles:true}));
        picker.dispatchEvent(new Event('change',{bubbles:true}));
        syncingFromHex=false;
      }
      clearEditingState();
      return true;
    };
    const restoreLastValid=()=>{
      const last=normalizeHexColor(control.dataset.lastValidHex||picker.value,'#000000');
      control.dataset.lastValidHex=last;hex.value=last;picker.value=last;clearEditingState();
    };
    const syncFromPicker=()=>{
      if(syncingFromHex)return;
      const normalized=normalizeHexColor(picker.value,control.dataset.lastValidHex||'#000000');
      control.dataset.lastValidHex=normalized;hex.value=normalized;clearEditingState();
    };
    picker.addEventListener('input',syncFromPicker);
    picker.addEventListener('change',syncFromPicker);
    // Mientras se escribe o se borra, no se normaliza ni se autocompleta el texto.
    // Solo un #RRGGBB completo actualiza el selector visual.
    hex.addEventListener('input',()=>{clearEditingState();applyCompleteHex(false);});
    hex.addEventListener('change',()=>{if(!applyCompleteHex(true))restoreLastValid();});
    hex.addEventListener('blur',()=>{if(!applyCompleteHex(true))restoreLastValid();});
    clearEditingState();
  });
}
function validateHexColorControls(root=document) {
  for(const control of $$('[data-hex-color-control]',root)){
    const picker=$('[data-color-picker]',control),hex=$('[data-color-hex]',control);
    if(!picker||!hex||hex.disabled)continue;
    if(!isHexColor(hex.value)){
      const last=normalizeHexColor(control.dataset.lastValidHex||picker.value,'#000000');
      control.dataset.lastValidHex=last;hex.value=last;picker.value=last;
    }else{
      const normalized=normalizeHexColor(hex.value,control.dataset.lastValidHex||picker.value);
      control.dataset.lastValidHex=normalized;hex.value=normalized;picker.value=normalized;
    }
    hex.setCustomValidity('');hex.classList.remove('is-invalid');
  }
  return true;
}

function fieldHtml(field, value) {
  const id = `f-${field.name}`; const v = value ?? field.default ?? ""; const req = field.required ? "required" : ""; const full = field.full ? "full" : "";
  const help = field.help ? `<div class="help-text${field.warning?" form-warning":""}">${esc(field.help)}</div>` : "";
  if (field.type === "textarea") return `<label class="field ${full}" for="${id}">${esc(field.label)}<textarea id="${id}" name="${esc(field.name)}" ${req}>${esc(v)}</textarea>${help}</label>`;
  if (field.type === "file") return `<label class="field ${full}" for="${id}">${esc(field.label)}<input id="${id}" name="${esc(field.name)}" type="file" accept="${esc(field.accept||'image/*')}" ${req}>${help}</label>`;
  if (field.type === "select") return `<label class="field ${full}" for="${id}">${esc(field.label)}<select id="${id}" name="${esc(field.name)}" ${req}>${(field.options||[]).map(o => { const x=typeof o==="string"?{value:o,label:o}:o; return `<option value="${esc(x.value)}" ${String(x.value)===String(v)?"selected":""}>${esc(x.label)}</option>`; }).join("")}</select>${help}</label>`;
  if (field.type === "checkbox") return `<label class="switch-row ${full}" for="${id}"><span>${esc(field.label)}</span><input id="${id}" name="${esc(field.name)}" type="checkbox" ${v?"checked":""}></label>`;
  if (field.type === "color") return `<label class="field ${full}"><span>${esc(field.label)}</span>${colorControlHtml(field.name,v,"",id)}${help}</label>`;
  const inputValue = field.type === "datetime-local" ? toLocalInput(v) : v;
  const imageUrlField=field.type==="url"&&(field.driveImage===true||/(?:image|logo|icon).*url/i.test(field.name));
  const driveSelectable=field.type==="url"&&(field.driveSelect===true||imageUrlField);
  const input=`<input id="${id}" name="${esc(field.name)}" type="${esc(field.type||"text")}" value="${esc(inputValue)}" ${field.step?`step="${esc(field.step)}"`:""} ${field.min!==undefined?`min="${esc(field.min)}"`:""} ${field.max!==undefined?`max="${esc(field.max)}"`:""} ${req}>`;
  const driveLabel=String(inputValue||"").trim()?"Sustituir desde Drive":"Seleccionar desde Drive";
  const driveButton=driveSelectable?`<button class="btn secondary small drive-url-pick" type="button" data-drive-url-input="${id}" data-drive-url-mode="${imageUrlField?'image':'file'}"${field.driveImageSize?` data-drive-image-size="${esc(field.driveImageSize)}"`:''}${field.driveLabelTarget?` data-drive-label-target="${esc(field.driveLabelTarget)}"`:''}${field.driveTypeTarget?` data-drive-type-target="${esc(field.driveTypeTarget)}"`:''} title="${esc(driveLabel)}">${driveIconMarkup()}<span>${esc(driveLabel)}</span></button>`:"";
  return `<label class="field ${full}" for="${id}">${esc(field.label)}${driveSelectable?`<div class="drive-url-field">${input}${driveButton}</div>`:input}${help}</label>`;
}

function setModalFormValue(name,value){
  const form=$("#modal-form",els.modal);if(!form)return;
  const input=form.elements[name];if(!input)return;
  if(input.type==="file"){input.value="";return;}
  input.value=value??"";
  input.dispatchEvent(new Event("input",{bubbles:true}));
  input.dispatchEvent(new Event("change",{bubbles:true}));
}
function addModalResetButton(label,onReset){
  const actions=$(".modal-actions",els.modal);if(!actions)return;
  const button=document.createElement("button");button.type="button";button.className="btn secondary";button.textContent=label;
  button.addEventListener("click",()=>{try{onReset?.();toast("Valores predeterminados restaurados. Guarda para aplicarlos.");}catch(error){toast(error.message||"No se pudieron restaurar los valores.","error");}});
  actions.prepend(button);
}

async function driveImageSelectionToDataUrl(selected,size=128){
  const driveId=selected?.driveFileId||selected?.id||driveFileIdFromUrl(selected?.driveUrl||selected?.url||'');
  if(!driveId)throw new Error('La imagen seleccionada no tiene identificador de Google Drive.');
  let token=selected?.accessToken||'';
  if(!token)token=await getGoogleDriveAccessToken('',{interactive:true});
  const response=await fetch(`https://www.googleapis.com/drive/v3/files/${encodeURIComponent(driveId)}?alt=media&supportsAllDrives=true`,{headers:{Authorization:`Bearer ${token}`},cache:'no-store'});
  if(!response.ok){const detail=await driveApiErrorDetail(response);throw new Error(`No se pudo descargar la imagen de Drive (HTTP ${response.status})${detail?`: ${detail}`:''}.`);}
  const blob=await response.blob();
  const mimeType=String(selected?.mimeType||blob.type||'image/png');
  if(!mimeType.startsWith('image/'))throw new Error('El archivo seleccionado no es una imagen compatible.');
  const name=String(selected?.label||`drive-${driveId}${extensionForMime(mimeType)||'.png'}`);
  const file=new File([blob],name,{type:mimeType});
  return fileToSquareDataUrl(file,Math.max(32,Math.min(512,num(size)||128)));
}
async function stabilizeDriveIconUrl(value,size=128){
  const raw=String(value||'').trim();
  if(!driveFileIdFromUrl(raw))return raw;
  const driveId=driveFileIdFromUrl(raw);
  return driveImageSelectionToDataUrl({id:driveId,driveFileId:driveId,driveUrl:raw,url:raw,label:'Icono de Google Drive'},size);
}
async function stabilizeLegacyBusDriveVisuals(accessToken=''){
  if(busDriveVisualMigrationCompleted||!String(accessToken||'').trim())return false;
  if(busDriveVisualMigrationPromise)return busDriveVisualMigrationPromise;
  busDriveVisualMigrationPromise=(async()=>{
    const buses=state.data?.cover?.buses||[];
    let changed=false,attempted=false;
    for(const bus of buses){
      if(!bus)continue;
      for(const key of ['iconUrl','logoUrl','purchaseButtonIconUrl']){
        const raw=String(bus[key]||'').trim(),driveId=driveFileIdFromUrl(raw);
        if(!driveId)continue;
        attempted=true;
        try{
          const dataUrl=await driveImageSelectionToDataUrl({id:driveId,driveFileId:driveId,driveUrl:raw,url:raw,label:`${bus.company||'Autobús'} · ${key}`,accessToken},128);
          if(dataUrl&&dataUrl!==raw){bus[key]=dataUrl;changed=true;}
        }catch(error){console.warn(`No se pudo independizar ${key} del autobús de Google Drive`,error);}
      }
    }
    if(changed){
      const saved=await saveSection('cover');
      if(saved!==false){
        busDriveVisualMigrationCompleted=true;
        if(state.page==='cover'||state.page==='budget')render();
        toast('Iconos del autobús guardados de forma permanente.');
      }
    }else if(attempted){
      // Se volverá a intentar con un futuro token si alguno no pudo convertirse.
      busDriveVisualMigrationCompleted=false;
    }else busDriveVisualMigrationCompleted=true;
    return changed;
  })().finally(()=>{busDriveVisualMigrationPromise=null;});
  return busDriveVisualMigrationPromise;
}

function bindModalDriveUrlPickers(root=els.modal){
  $$('[data-drive-url-input]',root).forEach(button=>button.addEventListener('click',async()=>{
    try{
      const mode=button.dataset.driveUrlMode||'file';
      const imageMode=mode==='image';
      const selected=(await selectFromDrive({multiple:false,mimeTypes:imageMode?'image/png,image/jpeg,image/webp,image/gif,image/svg+xml':'application/pdf,image/png,image/jpeg,image/webp,image/gif,image/svg+xml',includeToken:imageMode,sharedDrives:false}))[0];
      if(!selected)return;
      const input=$(`#${CSS.escape(button.dataset.driveUrlInput)}`,root);
      if(!input)return;
      if(imageMode){
        const inlineSize=Math.max(0,num(button.dataset.driveImageSize));
        if(inlineSize){
          toast('Preparando icono de Google Drive…');
          input.value=await driveImageSelectionToDataUrl(selected,inlineSize);
          toast('Icono de Drive preparado como PNG. Guarda los cambios para aplicarlo.');
        }else{
          toast('Importando imagen de Drive…');
          const imported=await importDriveImage(selected,'images');
          input.value=imported.url;
          toast('Imagen sustituida desde Google Drive.');
        }
      }else{
        input.value=selected.driveUrl||selected.url||'';
        const target=button.dataset.driveLabelTarget;
        if(target){const labelInput=$(`[name="${CSS.escape(target)}"]`,root);if(labelInput&&(!labelInput.value.trim()||button.dataset.replaceLabel==='1'))labelInput.value=selected.label||labelInput.value;}
        const typeTarget=button.dataset.driveTypeTarget;
        if(typeTarget){const typeInput=$(`[name="${CSS.escape(typeTarget)}"]`,root);if(typeInput){typeInput.value=selected.type==='image'?'image':'file';typeInput.dispatchEvent(new Event('change',{bubbles:true}));}}
        toast('Enlace seleccionado desde Google Drive.');
      }
      input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}));
      button.querySelector('span')&&(button.querySelector('span').textContent='Sustituir desde Drive');
      button.title='Sustituir desde Drive';
    }catch(error){toast(`No se pudo seleccionar desde Drive: ${error.message}`,'error');}
  }));
}

function openForm({title,fields,values={},submitText="Guardar",submitClass="",onSubmit}) {
  const submitLabel=/^\s*guardar/i.test(String(submitText||''))?saveButtonContent(String(submitText||'Guardar')):esc(submitText);
  openModal(`<div class="modal-head"><h3>${esc(title)}</h3><button class="close-btn" data-close-modal>×</button></div>
    <form id="modal-form"><div class="modal-body"><div class="form-row">${fields.map(f=>fieldHtml(f,values[f.name])).join("")}</div></div>
    <div class="modal-actions"><button class="btn ghost" type="button" data-close-modal>Cancelar</button><button class="btn primary ${esc(submitClass)}" type="submit">${submitLabel}</button></div></form>`);
  $$('[data-close-modal]',els.modal).forEach(b=>b.addEventListener('click',closeModal));
  bindHexColorControls(els.modal);
  bindModalDriveUrlPickers(els.modal);
  $("#modal-form",els.modal).addEventListener("submit",async e => {
    e.preventDefault();
    if(!validateHexColorControls(e.currentTarget))return;
    const form = new FormData(e.currentTarget); const result={};
    for (const field of fields) {
      const input = e.currentTarget.elements[field.name];
      if (field.type === "checkbox") result[field.name]=input.checked;
      else if (field.type === "file") result[field.name]=input.files?.[0] || null;
      else if (field.type === "number") result[field.name]=num(form.get(field.name));
      else if (field.type === "datetime-local") result[field.name]=fromLocalInput(form.get(field.name));
      else result[field.name]=String(form.get(field.name) ?? "").trim();
    }
    try {
      const submittedForm = e.currentTarget;
      const closeResult = await onSubmit(result);
      // Si el callback ha redibujado el modal (por ejemplo, al añadir varios archivos),
      // no cerramos el nuevo contenido por accidente.
      if (closeResult !== false && submittedForm.isConnected && els.modal.contains(submittedForm)) closeModal();
    } catch (error) { toast(error.message || "No se ha podido guardar","error"); }
  });
}

function deviceAuthStorageKey(){
  const uid=String(state.user?.uid||state.user?.email||'anonymous').trim()||'anonymous';
  return `${DEVICE_AUTH_KEY_PREFIX}:${uid}`;
}
function base64UrlFromBuffer(buffer){
  const bytes=new Uint8Array(buffer),chunk=0x8000;let binary='';
  for(let i=0;i<bytes.length;i+=chunk)binary+=String.fromCharCode(...bytes.subarray(i,i+chunk));
  return btoa(binary).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
}
function bufferFromBase64Url(value=''){
  const raw=String(value||'').replace(/-/g,'+').replace(/_/g,'/');
  const padded=raw+'='.repeat((4-raw.length%4)%4),binary=atob(padded),bytes=new Uint8Array(binary.length);
  for(let i=0;i<binary.length;i++)bytes[i]=binary.charCodeAt(i);
  return bytes;
}
function randomCredentialBytes(length=32){const bytes=new Uint8Array(length);crypto.getRandomValues(bytes);return bytes;}
function deviceAuthRawConfig(){
  try{const parsed=JSON.parse(localStorage.getItem(deviceAuthStorageKey())||'null');return parsed&&parsed.credentialId?parsed:null;}catch{return null;}
}
function deviceAuthConfig(){
  const parsed=deviceAuthRawConfig();
  return parsed?.mode===DEVICE_AUTH_MODE?parsed:null;
}
function deviceAuthLegacyConfigured(){const parsed=deviceAuthRawConfig();return Boolean(parsed?.credentialId&&parsed?.mode!==DEVICE_AUTH_MODE);}
function deviceAuthConfigured(){return Boolean(deviceAuthConfig()?.credentialId);}
function deviceAuthBasicSupported(){return Boolean(window.isSecureContext&&window.PublicKeyCredential&&navigator.credentials?.create&&navigator.credentials?.get);}
async function deviceAuthPlatformAvailable(){
  if(!deviceAuthBasicSupported())return false;
  if(typeof PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable!=='function')return false;
  try{return await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();}catch{return false;}
}
async function deviceAuthClientCapabilities(){
  if(typeof PublicKeyCredential?.getClientCapabilities!=='function')return {};
  try{return await PublicKeyCredential.getClientCapabilities();}catch{return {};}
}
function deviceAuthStatusText(){
  if(!window.isSecureContext)return 'Requiere HTTPS';
  if(!window.PublicKeyCredential||!navigator.credentials)return 'No compatible';
  if(deviceAuthLegacyConfigured())return 'Reactivar en modo local';
  return deviceAuthConfigured()?'Activo · modo local':'Disponible para activar';
}
function deviceAuthErrorMessage(error){
  const name=String(error?.name||'');
  if(name==='NotAllowedError')return 'Verificación cancelada o no autorizada por el dispositivo.';
  if(name==='InvalidStateError')return 'La credencial del dispositivo ya existe o no está disponible.';
  if(name==='SecurityError')return 'El navegador ha bloqueado WebAuthn. Comprueba que la app se abre por HTTPS.';
  return error?.message||'No se ha podido usar el desbloqueo del dispositivo.';
}
async function registerDeviceAuth(){
  if(!roleCanEdit())throw new Error('Tu usuario no tiene permisos de edición.');
  if(!deviceAuthBasicSupported())throw new Error('Este navegador o dispositivo no admite desbloqueo seguro WebAuthn.');
  if(!(await deviceAuthPlatformAvailable()))throw new Error('Android/Chrome no informa de un autenticador local con verificación de usuario en este dispositivo. Usa el PIN de MFE.');
  const capabilities=await deviceAuthClientCapabilities();
  const uid=String(state.user?.uid||state.user?.email||'mfe-user');
  const displayName=String(state.profile?.displayName||state.user?.displayName||state.user?.email||'Usuario MFE');
  const credential=await navigator.credentials.create({publicKey:{
    challenge:randomCredentialBytes(32),
    rp:{name:'MFE Viajes'},
    user:{id:randomCredentialBytes(32),name:uid.slice(0,64),displayName:displayName.slice(0,64)},
    pubKeyCredParams:[{type:'public-key',alg:-7},{type:'public-key',alg:-257}],
    timeout:60000,
    hints:['client-device'],
    authenticatorSelection:{authenticatorAttachment:'platform',residentKey:'discouraged',requireResidentKey:false,userVerification:'required'},
    extensions:{credProps:true},
    attestation:'none'
  }});
  if(!credential?.rawId)throw new Error('El dispositivo no devolvió una credencial válida.');
  if(credential.authenticatorAttachment&&credential.authenticatorAttachment!=='platform')throw new Error('El navegador ha elegido un autenticador externo. Cancela y usa el autenticador de este dispositivo.');
  const reported=typeof credential.response?.getTransports==='function'?credential.response.getTransports():[];
  if(reported.length&&!reported.includes('internal'))throw new Error('La credencial creada no pertenece al autenticador interno del dispositivo. No se guardará.');
  const record={credentialId:base64UrlFromBuffer(credential.rawId),createdAt:new Date().toISOString(),displayName,origin:location.origin,mode:DEVICE_AUTH_MODE,transports:['internal'],attachment:'platform',capabilities};
  localStorage.setItem(deviceAuthStorageKey(),JSON.stringify(record));
  return record;
}
async function authenticateWithDevice(){
  const config=deviceAuthConfig();if(!config?.credentialId)return false;
  if(!deviceAuthBasicSupported())throw new Error('El desbloqueo del dispositivo no está disponible en este navegador.');
  if(!(await deviceAuthPlatformAvailable()))throw new Error('El autenticador local del dispositivo ya no está disponible. Usa el PIN de MFE.');
  const assertion=await navigator.credentials.get({publicKey:{
    challenge:randomCredentialBytes(32),
    allowCredentials:[{type:'public-key',id:bufferFromBase64Url(config.credentialId),transports:['internal']}],
    timeout:45000,
    hints:['client-device'],
    userVerification:'required'
  },mediation:'required'});
  if(!assertion?.rawId)return false;
  if(assertion.authenticatorAttachment&&assertion.authenticatorAttachment!=='platform')throw new Error('Android ha intentado usar un proveedor externo en vez del autenticador local. Usa el PIN de MFE.');
  state.pinVerified=true;
  try{sessionStorage.setItem(EDIT_PIN_SESSION_KEY,'1');}catch{}
  return true;
}
function disableDeviceAuth(){
  try{localStorage.removeItem(deviceAuthStorageKey());}catch{}
  render();toast('Desbloqueo del dispositivo desactivado en este navegador.');
}
function openDeviceAuthActivationPrompt(){
  openModal(`<div class="modal-head"><div><h3>Activar en este dispositivo</h3><small>WebAuthn · verificación segura del sistema</small></div><button class="close-btn" data-close-modal>×</button></div><div class="modal-body"><p>Ahora pulsa el botón inferior. MFE pedirá expresamente el autenticador <strong>interno de este dispositivo</strong> con verificación de usuario.</p><p class="help-text">La credencial se solicita como local/no residente, con transporte interno y preferencia «este dispositivo». Android puede mostrar huella, rostro o PIN/patrón de pantalla. MFE nunca recibe esos datos.</p><div class="page-actions"><button type="button" class="btn primary canary-action" data-device-auth-create-now>👆 Activar ahora</button></div></div>`,true);
  $('[data-device-auth-create-now]',els.modal)?.addEventListener('click',async event=>{
    const button=event.currentTarget;button.disabled=true;
    try{await registerDeviceAuth();closeModal();render();toast('Desbloqueo del dispositivo activado.');}
    catch(error){button.disabled=false;toast(deviceAuthErrorMessage(error),'error');}
  });
}
function activateDeviceAuth(){
  if(!canEdit())return toast('Desbloquea Configuración antes de activar la biometría.','error');
  openForm({title:'Activar desbloqueo del dispositivo',submitText:'Continuar',submitClass:'canary-action',fields:[{name:'pin',label:'PIN de edición',type:'password',required:true,full:true,help:'Confirma primero el PIN de MFE. En el siguiente paso intentaremos usar exclusivamente el autenticador local del móvil o tablet.'}],onSubmit:async({pin})=>{
    await verifyEditPin(pin);openDeviceAuthActivationPrompt();return false;
  }});
}
async function testDeviceAuth(){
  if(!deviceAuthConfigured())return toast('Activa primero el desbloqueo del dispositivo.','error');
  try{const ok=await authenticateWithDevice();if(ok)toast('Verificación correcta. El desbloqueo del dispositivo funciona.');}
  catch(error){toast(deviceAuthErrorMessage(error),'error');}
}
function promptPinForSettings(){
  state.settingsUnlocked=false;updateHeader();
  openForm({title:'Acceder a Configuración',submitText:'Entrar',submitClass:'canary-action',fields:[{name:'pin',label:'PIN de edición',type:'password',required:true,full:true,help:'¡Cuidado! Zona peligrosa. Cambia cualquier cosa con cuidado. El PIN se pedirá una sola vez durante esta sesión de la app.',warning:true}],onSubmit:async({pin})=>{
    await verifyEditPin(pin);state.settingsUnlocked=true;state.activeTab='settings';render();window.scrollTo({top:0,behavior:'smooth'});toast('Configuración desbloqueada para esta sesión.');
  }});
}
function promptPinForEditUnlock(){
  openForm({title:'Desbloquear edición',submitText:'Desbloquear',submitClass:'canary-action',fields:[{name:'pin',label:'PIN de edición',type:'password',required:true,full:true,help:'Solo se pedirá una vez durante esta sesión de la app.'}],onSubmit:async({pin})=>{
    const suitcasePosition=captureSuitcaseViewPosition();
    await verifyEditPin(pin);state.unlocked=true;sessionStorage.setItem(EDIT_UNLOCK_SESSION_KEY,'1');updateHeader();renderKeepingSuitcasePosition(suitcasePosition);toast('Edición desbloqueada para esta sesión.');
  }});
}

async function verifyEditPin(pin){
  const hash=await hashText(pin);
  if(hash!==state.data.settings.editPinHash)throw new Error("PIN incorrecto.");
  state.pinVerified=true;
  try{sessionStorage.setItem(EDIT_PIN_SESSION_KEY,"1");}catch{}
  return true;
}
function editingPinAlreadyVerified(){
  return roleCanEdit()&&(state.pinVerified||sessionStorage.getItem(EDIT_PIN_SESSION_KEY)==="1");
}
async function openSettingsWithPin(){
  if(!roleCanEdit()){
    state.settingsUnlocked=false;state.activeTab='settings';render();window.scrollTo({top:0,behavior:'smooth'});return;
  }
  if(editingPinAlreadyVerified()){
    state.pinVerified=true;state.settingsUnlocked=true;state.activeTab='settings';render();window.scrollTo({top:0,behavior:'smooth'});return;
  }
  if(deviceAuthConfigured()){
    try{
      const ok=await authenticateWithDevice();
      if(ok){state.settingsUnlocked=true;state.activeTab='settings';render();window.scrollTo({top:0,behavior:'smooth'});toast('Configuración desbloqueada con el dispositivo.');return;}
    }catch(error){if(String(error?.name||'')!=='NotAllowedError')toast(deviceAuthErrorMessage(error),'error');}
  }
  promptPinForSettings();
}
function navigateToTab(tab){
  const target=String(tab||"cover");
  if(target!=="shopping")state.shoppingView="list";
  if(target==="settings"){
    if(state.activeTab==="settings"&&state.settingsUnlocked)return;
    void openSettingsWithPin();return;
  }
  if(state.activeTab==="settings")state.settingsUnlocked=false;
  state.activeTab=target;render();window.scrollTo({top:0,behavior:"smooth"});
}
function captureSuitcaseViewPosition(){
  if(!String(state.activeTab||'').startsWith('suitcase-'))return null;
  const grid=$('.suitcase-grid');
  const cards=grid?[...grid.querySelectorAll(':scope > .suitcase-group-card')]:[];
  let cardIndex=0;
  if(grid&&cards.length){
    cardIndex=cards.reduce((best,card,index)=>Math.abs(card.offsetLeft-grid.scrollLeft)<Math.abs(cards[best].offsetLeft-grid.scrollLeft)?index:best,0);
  }
  return {tab:state.activeTab,windowY:window.scrollY||document.documentElement.scrollTop||0,gridScrollLeft:grid?.scrollLeft||0,cardIndex};
}
function restoreSuitcaseViewPosition(snapshot){
  if(!snapshot||snapshot.tab!==state.activeTab)return;
  requestAnimationFrame(()=>requestAnimationFrame(()=>{
    if(snapshot.tab!==state.activeTab)return;
    const grid=$('.suitcase-grid'),cards=grid?[...grid.querySelectorAll(':scope > .suitcase-group-card')]:[];
    if(grid){
      const card=cards[snapshot.cardIndex];
      const left=card?card.offsetLeft:snapshot.gridScrollLeft;
      grid.scrollTo({left,top:0,behavior:'auto'});
    }
    window.scrollTo({top:snapshot.windowY,left:0,behavior:'auto'});
  }));
}
function renderKeepingSuitcasePosition(snapshot=captureSuitcaseViewPosition()){
  render();restoreSuitcaseViewPosition(snapshot);
}
async function toggleUnlock() {
  if(!roleCanEdit()){toast('Tu usuario no tiene permisos de edición.','error');return;}
  if(state.activeTab==='settings'){
    if(state.settingsUnlocked){state.settingsUnlocked=false;updateHeader();render();return;}
    void openSettingsWithPin();return;
  }
  if(state.unlocked){const suitcasePosition=captureSuitcaseViewPosition();state.unlocked=false;sessionStorage.removeItem(EDIT_UNLOCK_SESSION_KEY);updateHeader();renderKeepingSuitcasePosition(suitcasePosition);return;}
  if(editingPinAlreadyVerified()){
    const suitcasePosition=captureSuitcaseViewPosition();state.pinVerified=true;state.unlocked=true;sessionStorage.setItem(EDIT_UNLOCK_SESSION_KEY,'1');updateHeader();renderKeepingSuitcasePosition(suitcasePosition);toast('Edición desbloqueada.');return;
  }
  if(deviceAuthConfigured()){
    try{
      const ok=await authenticateWithDevice();
      if(ok){const suitcasePosition=captureSuitcaseViewPosition();state.unlocked=true;sessionStorage.setItem(EDIT_UNLOCK_SESSION_KEY,'1');updateHeader();renderKeepingSuitcasePosition(suitcasePosition);toast('Edición desbloqueada con el dispositivo.');return;}
    }catch(error){if(String(error?.name||'')!=='NotAllowedError')toast(deviceAuthErrorMessage(error),'error');}
  }
  promptPinForEditUnlock();
}

function render() {
  applyTheme(); updateHeader(); renderNav();
  document.body.dataset.activeTab=state.activeTab||'cover';
  const map = { cover:renderCover, lodging:renderLodgingPage, budget:renderBudget, "suitcase-common":()=>renderSuitcase("common","Maleta común"), "suitcase-mikel":()=>renderSuitcase("mikel","Maleta Mikel"), "suitcase-nerea":()=>renderSuitcase("nerea","Maleta Nerea"), shopping:renderShopping, purchases:renderPurchases, tasks:renderTasks, emergency:renderEmergency, trackers:renderTrackers, menu:renderMenu, itinerary:renderItinerary, history:renderHistory, notes:renderNotes, settings:renderSettings };
  els.content.innerHTML = (map[state.activeTab] || renderCover)(); decorateSaveButtons(els.content); bindUnlockButtons(); (binders[state.activeTab] || (()=>{}))(); bindFreeSortInteractions(); bindMediaPopups(); bindDonutInteractions(); bindTrackerChartTooltips(); bindInteractiveCharts(); enhanceResponsiveTables(); bindImageResilience();
  if(state.activeTab==="trackers")requestAnimationFrame(renderFuelMap);
}

const binders = {};

function supermarketPurchaseTotal() { return sum((state.data.purchases.records||[]).map(r=>r.amount)); }
function otherExpensesTotal() { return sum((state.data.purchases.otherExpenses||[]).map(r=>r.amount)); }
function extrasTotal() { return sum((state.data.purchases.extras||[]).map(r=>r.amount)); }
function paidExtrasTotal() { return sum((state.data.purchases.extras||[]).filter(r=>r.status==="paid").map(r=>r.amount)); }
function unpaidExtrasTotal() { return Math.max(0,extrasTotal()-paidExtrasTotal()); }
function purchaseTotal() { return supermarketPurchaseTotal()+otherExpensesTotal()+paidExtrasTotal(); }
function shoppingTotal() { return sum(state.data.shopping.stores.flatMap(s=>s.products.map(p=>num(p.quantity)*num(p.unitPrice)))); }
function itemAmount(item) { if (item.source === "shopping") return shoppingTotal(); return num(item.amount); }
function normalizedKey(value) { return String(value||"").trim().toLocaleLowerCase("es").replace(/\s+/g," "); }
function isLegacyPurchaseAggregate(item) { return item?.source === "purchases"; }

function supermarketPurchaseSummaries() {
  const grouped=new Map();
  for(const record of state.data.purchases.records||[]) {
    const rawName=String(record.store||"Sin supermercado").trim()||"Sin supermercado";
    const store=findStoreByName(rawName);
    const name=store?.name||rawName;
    const key=normalizedKey(name);
    if(!grouped.has(key))grouped.set(key,{name,amount:0,count:0,icon:store?.icon||"🛒",iconUrl:store?.logoUrl||"",color:store?.color||"#4da3ff"});
    const row=grouped.get(key);row.amount+=num(record.amount);row.count+=1;
  }
  return [...grouped.values()].sort((a,b)=>b.amount-a.amount);
}

function otherExpenseSummaries() {
  const grouped=new Map();
  for(const expense of state.data.purchases.otherExpenses||[]) {
    const groupId=expense.groupId||"g-extras";
    const category=String(expense.category||expense.name||"Otros gastos").trim()||"Otros gastos";
    const key=`${groupId}::${normalizedKey(category)}`;
    const group=state.data.budget.groups.find(g=>g.id===groupId);
    if(!grouped.has(key))grouped.set(key,{groupId,category,amount:0,count:0,icon:expense.icon||group?.icon||"💳",iconUrl:expense.iconUrl||group?.iconUrl||"",color:group?.color||"#4da3ff"});
    const row=grouped.get(key);row.amount+=num(expense.amount);row.count+=1;
    if(!row.iconUrl&&expense.iconUrl)row.iconUrl=expense.iconUrl;
    if((!row.icon||row.icon==="💳")&&expense.icon)row.icon=expense.icon;
  }
  return [...grouped.values()].sort((a,b)=>b.amount-a.amount);
}

function automaticBudgetItems(group) {
  const rows=[];
  if(group.id==="g-shopping") {
    for(const summary of supermarketPurchaseSummaries()) rows.push({
      id:`auto-store-${normalizedKey(summary.name)}`,
      name:summary.name,
      detail:`${summary.count} ${summary.count===1?"compra":"compras"}`,
      amount:summary.amount,
      status:"paid",
      automatic:true,
      autoType:"store",
      icon:summary.icon,
      iconUrl:summary.iconUrl,
      color:summary.color
    });
  }
  for(const summary of otherExpenseSummaries().filter(x=>x.groupId===group.id)) rows.push({
    id:`auto-expense-${group.id}-${normalizedKey(summary.category)}`,
    name:summary.category,
    detail:`${summary.count} ${summary.count===1?"gasto":"gastos"}`,
    amount:summary.amount,
    status:"paid",
    automatic:true,
    autoType:"other",
    icon:summary.icon,
    iconUrl:summary.iconUrl,
    color:summary.color
  });
  if(group.id==="g-bus") {
    for(const bus of (state.data.cover.buses||[]).filter(item=>item&&item.visible!==false)) rows.push({
      id:`auto-bus-${bus.id}`,sourceId:bus.id,name:String(bus.budgetTitle||'').trim()||`${bus.type||'Autobús'} · ${bus.from||'Origen'} → ${bus.to||'Destino'}`,
      detail:String(bus.budgetDetail||'').trim()||[bus.company,bus.serviceNumber,bus.date?formatDate(bus.date,{day:'2-digit',month:'short'}):'',bus.departure?formatTime(bus.departure):'',`${Math.max(1,num(bus.passengers)||1)} pasajero${Math.max(1,num(bus.passengers)||1)===1?'':'s'}`,num(bus.pricePerPerson)>0?`${formatMoney(bus.pricePerPerson)} / persona`:'' ].filter(Boolean).join(' · '),
      amount:busBudgetAmount(bus),status:bus.status==='paid'?'paid':'unpaid',automatic:true,autoType:'bus',
      icon:bus.icon||'🚌',iconUrl:busIdentityVisualUrl(bus,(state.data.cover.buses||[]).indexOf(bus)),color:bus.color||group.color||'#49b6d6',url:bus.purchaseUrl||'',webLabel:bus.purchaseButtonLabel||'Comprar billetes',files:bus.files||[]
    });
  }
  if(group.id==="g-extras") {
    for(const extra of state.data.purchases.extras||[]) rows.push({
      id:`auto-purchase-extra-${extra.id}`, sourceId:extra.id,
      name:String(extra.name||extra.category||"Extra").trim()||"Extra",
      detail:[extra.category&&extra.category!==extra.name&&String(extra.category).trim().toLocaleLowerCase('es')!=='extra'?extra.category:"",extra.date?formatDate(extra.date):"",extra.notes||""].filter(Boolean).join(" · "),
      amount:num(extra.amount), status:extra.status==="paid"?"paid":"unpaid", automatic:true, autoType:"extra",
      icon:extra.icon||"✨", iconUrl:extra.iconUrl||"", color:group.color||"#f7c84b", fileUrl:extra.fileUrl||"", notes:extra.notes||""
    });
  }
  return rows;
}

function effectiveBudgetEntries(group) {
  const manual=(group.items||[]).map((item,index)=>({item,index,automatic:false})).filter(entry=>!isLegacyPurchaseAggregate(entry.item));
  const automatic=automaticBudgetItems(group).map(item=>({item,index:null,automatic:true}));
  return [...manual,...automatic];
}

function budgetStats() {
  const items = state.data.budget.groups.flatMap(group=>effectiveBudgetEntries(group).map(entry=>entry.item));
  const total = sum(items.map(itemAmount)); const paid = sum(items.filter(i=>i.status==="paid").map(itemAmount));
  return { total, paid, unpaid:total-paid, perPerson: total / Math.max(1,num(state.data.settings.people)||1) };
}

function countdownTargetDateTime(){
  return String(state.data.settings.countdownEndDateTime||state.data.settings.departureDateTime||'').trim();
}
function countdownTargetDate(){
  const value=countdownTargetDateTime(),target=new Date(value);
  return Number.isFinite(target.getTime())?target:new Date(state.data.settings.departureDateTime);
}
function renderCountdown() {
  const target=countdownTargetDate(),now=new Date(),showSeconds=state.data.settings.countdownShowSeconds===true;
  let diff=Math.max(0,target-now);const days=Math.floor(diff/86400000);diff%=86400000;const hours=Math.floor(diff/3600000);diff%=3600000;const mins=Math.floor(diff/60000);diff%=60000;const secs=Math.floor(diff/1000);
  return `<div class="countdown"><div class="count-unit" data-cd-days-unit ${days===0?'hidden':''}><strong data-cd-days>${String(days).padStart(2,"0")}</strong><span>Días</span></div><div class="count-unit"><strong data-cd-hours>${String(hours).padStart(2,"0")}</strong><span>Horas</span></div><div class="count-unit"><strong data-cd-mins>${String(mins).padStart(2,"0")}</strong><span>Minutos</span></div>${showSeconds?`<div class="count-unit"><strong data-cd-secs>${String(secs).padStart(2,"0")}</strong><span>Segundos</span></div>`:""}</div>`;
}
function startCountdown() {
  clearInterval(state.countdownTimer);
  const showSeconds=state.data.settings.countdownShowSeconds===true;
  const update=()=>{
    const target=countdownTargetDate();let diff=Math.max(0,target-new Date());
    const days=Math.floor(diff/86400000);diff%=86400000;const hours=Math.floor(diff/3600000);diff%=3600000;const mins=Math.floor(diff/60000);diff%=60000;const secs=Math.floor(diff/1000);
    const daysUnit=$("[data-cd-days-unit]");if(daysUnit)daysUnit.hidden=days===0;
    $("[data-cd-days]") && ($("[data-cd-days]").textContent=String(days).padStart(2,"0"));
    $("[data-cd-hours]") && ($("[data-cd-hours]").textContent=String(hours).padStart(2,"0"));
    $("[data-cd-mins]") && ($("[data-cd-mins]").textContent=String(mins).padStart(2,"0"));
    $("[data-cd-secs]") && ($("[data-cd-secs]").textContent=String(secs).padStart(2,"0"));
  };
  update();state.countdownTimer=setInterval(update,showSeconds?1000:30000);
}
function renderWeather() {
  if (!state.weather) return `<div class="card weather-panel"><div class="card-body"><div class="empty">Configura la localidad o las coordenadas y pulsa «Actualizar tiempo».</div></div></div>`;
  const w=state.weather;
  return `<div class="card weather-panel"><div class="section-title" style="--g1:#183955;--g2:#315e8b"><span>🌤️ Tiempo en ${esc(w.place||state.data.settings.weatherPlace)}</span><div class="section-title-actions">${renderAccuWeatherButton('weather-accuweather-link')}${canEdit()?'<button class="mini-btn" data-refresh-weather title="Actualizar">↻</button>':''}</div></div>
  <div class="weather-current"><div class="weather-icon">${esc(w.current?.icon||"🌤️")}</div><div><div class="weather-temp">${esc(w.current?.temp ?? "—")} °C</div><div class="weather-text">${esc(w.current?.text||"")}${Number.isFinite(w.current?.apparent)?` · Sensación ${esc(w.current.apparent)} °C`:""}</div></div></div>
  <div class="forecast-row">${(w.forecast||[]).map(d=>`<div class="forecast-day"><strong>${formatDate(d.date,{weekday:"short"})}</strong><div style="font-size:26px">${esc(d.icon||"☀️")}</div><div class="temps">${esc(d.max)}° <span>${esc(d.min)}°</span></div><small class="muted">${esc(d.text||"")}</small><div class="sun-times"><span title="Amanecer" aria-label="Amanecer ${esc(weatherClockTime(d.sunrise))}">🌅 <b>${esc(weatherClockTime(d.sunrise))}</b></span><span title="Atardecer" aria-label="Atardecer ${esc(weatherClockTime(d.sunset))}">🌇 <b>${esc(weatherClockTime(d.sunset))}</b></span></div></div>`).join("")}</div></div>`;
}
function providerPalette(value={}){
  const text=`${value.id||''} ${value.title||''} ${value.subtitle||''} ${value.airline||''} ${value.name||''}`.toLocaleLowerCase('es');
  if(text.includes('vueling')||text.includes('doc-flight')||text.includes('flight-'))return {g1:'#5d4a0d',g2:'#c79a17',glow:'#f6c946'};
  if(text.includes('avanza')||text.includes('pesa')||text.includes('bus-')||text.includes('autobús')||text.includes('autobus'))return {g1:'#173f53',g2:'#2d7895',glow:'#49b6d6'};
  if(text.includes('autoreisen')||text.includes('doc-car'))return {g1:'#173d20',g2:'#478034',glow:'#74b64c'};
  if(text.includes('cordial')||text.includes('doc-lodging'))return {g1:'#29313c',g2:'#626d7b',glow:'#aeb7c4'};
  return {g1:value.gradient1||'#202936',g2:value.gradient2||'#343f50',glow:value.color||'#4da3ff'};
}
function departureAirportInfo(value="") {
  const raw=String(value||"").trim();
  const code=(raw.match(/\(([A-Z]{3})\)/i)?.[1]||"").toUpperCase();
  const infovuelos=(origin="")=>`https://www.aena.es/es/infovuelos.html${origin?`?Buscar=Buscar&accion=Inicio&origin=${encodeURIComponent(origin)}`:""}`;
  const airports={
    BIO:{code:"BIO",name:"Bilbao",url:"https://www.aena.es/es/bilbao.html",departuresUrl:infovuelos("BIO")},
    LPA:{code:"LPA",name:"Gran Canaria",url:"https://www.aena.es/es/gran-canaria.html",departuresUrl:infovuelos("LPA")}
  };
  return airports[code]||{code,name:raw.replace(/\s*\([A-Z]{3}\)\s*$/i,"")||"Aeropuerto",url:infovuelos(),departuresUrl:code?infovuelos(code):infovuelos()};
}
function vuelingStatusLinkForDevice(flight={},configuredUrl=""){
  const fallback=String(configuredUrl||"https://www.vueling.com/es/servicios-vueling/informacion-de-vuelos/estado-de-vuelos");
  const vuelingFlight=/vueling/i.test(`${flight.airline||''}`)||/^VY/i.test(String(flight.number||''));
  if(!vuelingFlight||!nativeAppsEnabled()||!(androidDevice()||appleMobileDevice()))return fallback;
  // Este enlace oficial ya está usado por MFE Viajes para “Mis viajes” y
  // permite que Vueling haga la transición app/web sin fabricar intents incompatibles.
  return "https://link.vueling.com/mmbit";
}
function aenaDeparturesLinkForFlight(flight={},configuredUrl=""){
  const airport=departureAirportInfo(flight.from||"");
  return airport.departuresUrl||String(configuredUrl||airport.url||"https://www.aena.es/es/infovuelos.html");
}
function busBudgetAmount(bus={}) { return Math.max(1,num(bus.passengers)||1)*Math.max(0,num(bus.pricePerPerson)); }
function journeyDirection(item={},fallback='outbound') {
  const type=String(item?.type||'').trim().toUpperCase();
  if(/VUELTA|REGRESO|RETURN/.test(type))return 'return';
  if(/IDA|OUTBOUND/.test(type))return 'outbound';
  return fallback;
}
function busPeerVisual(bus={},index=-1,key='iconUrl') {
  const own=String(bus?.[key]||'').trim();
  if(own)return own;
  const company=String(bus?.company||'').trim().toLowerCase();
  if(!company)return '';
  const peers=state.data.cover.buses||[];
  const peer=peers.find((candidate,i)=>i!==index&&String(candidate?.company||'').trim().toLowerCase()===company&&String(candidate?.[key]||'').trim());
  return String(peer?.[key]||'').trim();
}
function busIdentityVisualUrl(bus={},index=-1) {
  return String(bus?.iconUrl||bus?.logoUrl||busPeerVisual(bus,index,'iconUrl')||busPeerVisual(bus,index,'logoUrl')||'').trim();
}
function busPurchaseVisualUrl(bus={},index=-1) {
  return String(bus?.purchaseButtonIconUrl||busPeerVisual(bus,index,'purchaseButtonIconUrl')||'').trim();
}
function coverJourneyVisibilityKey(kind,item={},index=0){
  const stableId=String(item?.id||'').trim()||`${kind}-${index+1}`;
  return `journey:${kind}:${stableId}`;
}
function coverJourneyRows(){
  const buses=[...(state.data.cover.buses||[]).entries()].filter(([,bus])=>bus&&bus.visible!==false).map(([index,item])=>({kind:'bus',index,item,direction:journeyDirection(item,index===0?'outbound':'return'),at:Date.parse(item.departure||item.date||'')||0}));
  const flights=[...(state.data.cover.flights||[]).entries()].map(([index,item])=>({kind:'flight',index,item,direction:journeyDirection(item,index===0?'outbound':'return'),at:Date.parse(item.departure||item.date||'')||0}));
  const outboundBus=buses.find(row=>row.direction==='outbound');
  const returnBus=buses.find(row=>row.direction==='return');
  const outboundFlight=flights.find(row=>row.direction==='outbound');
  const returnFlight=flights.find(row=>row.direction==='return');
  const ordered=[outboundBus,outboundFlight,returnFlight,returnBus].filter(Boolean);
  const used=new Set(ordered.map(row=>`${row.kind}:${row.index}`));
  const leftovers=[...buses,...flights].filter(row=>!used.has(`${row.kind}:${row.index}`)).sort((a,b)=>a.at-b.at);
  return [...ordered,...leftovers];
}
function coverJourneyVisibilityEntries(){
  return coverJourneyRows().map(row=>({
    ...row,
    key:coverJourneyVisibilityKey(row.kind,row.item,row.index)
  }));
}
function coverDocumentVisibilityKey(doc={},index=0){
  const stableId=String(doc?.id||'').trim()||`doc-${index+1}`;
  return `document:${stableId}`;
}
function coverDocumentVisibilityEntries(){
  return (state.data.cover.documents||[]).map((item,index)=>({
    kind:'document',index,item,key:coverDocumentVisibilityKey(item,index)
  }));
}
function coverDocumentHideButton(doc,index){
  if(!canEdit())return '';
  const key=coverDocumentVisibilityKey(doc,index);
  const [,label]=coverVisibilityMeta(key);
  return `<button type="button" class="mini-btn cover-visibility-btn document-visibility-btn" data-cover-hide="${esc(key)}" title="Ocultar ${esc(label)}" aria-label="Ocultar ${esc(label)}">${coverEyeIconMarkup()}</button>`;
}
function coverJourneyHideButton(kind,item,index){
  if(!canEdit())return '';
  const key=coverJourneyVisibilityKey(kind,item,index);
  const [,label]=coverVisibilityMeta(key);
  return `<button type="button" class="mini-btn cover-visibility-btn journey-visibility-btn" data-cover-hide="${esc(key)}" title="Ocultar ${esc(label)}" aria-label="Ocultar ${esc(label)}">${coverEyeIconMarkup()}</button>`;
}
function renderBusCard(bus,index) {
  const palette=providerPalette(bus);
  const purchaseLink=coloredServiceLink(bus.purchaseUrl,'Comprar',bus.purchaseButtonColor||'#f2d600',serviceIconMarkup(bus.purchaseButtonIcon,busPurchaseVisualUrl(bus,index),'🎫'),'flight-service-link bus-purchase-link','bus');
  const busIdentityUrl=busIdentityVisualUrl(bus,index);
  const identity=iconMarkup(bus.icon||'🚌',busIdentityUrl,'bus-card-icon bus-card-drive-icon');
  const lineValue=String(bus.serviceNumber||'').trim()||String(bus.company||'').trim()||'—';
  return `<article class="card flight-card bus-card provider-gradient-card cover-editable" style="--flight-color:${esc(bus.color||palette.glow)};--provider-g1:${esc(bus.gradient1||palette.g1)};--provider-g2:${esc(bus.gradient2||palette.g2)};--provider-title-text:${esc(bus.textColor||'#ffffff')}">${canEdit()?`<div class="cover-inline-actions journey-inline-actions">${coverJourneyHideButton('bus',bus,index)}<button class="mini-btn cover-inline-edit" type="button" data-edit-bus="${index}" title="Editar este autobús" aria-label="Editar este autobús">✎</button></div>`:""}<div class="card-body">
    <div class="flight-top"><div class="transport-heading"><span class="transport-kicker">Autobús</span><div class="flight-badge bus-badge">${identity}<span>${esc(bus.type||'AUTOBÚS')}</span></div></div></div>
    <div class="flight-route"><div class="airport"><strong>${esc(bus.from||'Origen')}</strong><span>${formatTime(bus.departure)}</span></div><div class="route-line">➜</div><div class="airport"><strong>${esc(bus.to||'Destino')}</strong><span>${formatTime(bus.arrival)}</span></div></div>
    <div class="bus-detail-actions"><div class="flight-details flight-details-three"><div class="detail-box"><small>Fecha</small><strong>${formatDate(bus.date,{day:'2-digit',month:'short'})}</strong></div><div class="detail-box"><small>Línea</small><strong>${esc(lineValue)}</strong></div><div class="detail-box"><small>Duración</small><strong>${esc(flightDuration(bus))}</strong></div></div><div class="page-actions bus-actions">${purchaseLink}${safeLink(mapsDirectionsUrl(bus.from,bus.departureMapsUrl),'Salida',googleMapsIconMarkup(),'maps-route-link')}${safeLink(mapsDirectionsUrl(bus.to,bus.arrivalMapsUrl),'Destino',googleMapsIconMarkup(),'maps-route-link')}</div></div>
  </div></article>`;
}
function journeyGridClass(){
  const hidden=new Set(state.data.settings.coverHiddenBlocks||[]);
  const visibleBuses=(state.data.cover.buses||[]).map((bus,index)=>({bus,index})).filter(({bus,index})=>bus&&bus.visible!==false&&!hidden.has(coverJourneyVisibilityKey('bus',bus,index))).map(({bus})=>bus);
  const hasOutbound=visibleBuses.some(bus=>journeyDirection(bus)==='outbound');
  const hasReturn=visibleBuses.some(bus=>journeyDirection(bus)==='return');
  return `flight-grid journey-grid ${hasOutbound&&hasReturn?'has-both-buses':visibleBuses.length?'has-single-bus':'has-no-bus'}`;
}
function renderJourneyCards(){
  const hidden=new Set(state.data.settings.coverHiddenBlocks||[]);
  return coverJourneyVisibilityEntries()
    .filter(row=>!hidden.has(row.key))
    .map(row=>row.kind==='bus'?renderBusCard(row.item,row.index):renderFlightCard(row.item,row.index))
    .join('');
}

function airportCodeFromText(value=''){return String(value||'').toUpperCase().match(/\b([A-Z]{3})\b/)?.[1]||'';}
function flightOpsConfigFromState(){return {enabled:true,flights:(state.data.cover.flights||[]).map((f,index)=>({id:String(f.id||`flight-${index+1}`),number:String(f.number||'').trim(),date:String(f.date||f.departure||'').slice(0,10),departure:String(f.departure||''),arrival:String(f.arrival||''),origin:airportCodeFromText(f.from),destination:airportCodeFromText(f.to),from:String(f.from||''),to:String(f.to||''),operationalHints:{...(f.operationalHints||{})}})).filter(f=>f.number&&f.departure&&f.origin&&f.destination)};}
function flightOpsMonitoringWindow(flight={},now=Date.now()){
  const raw=String(flight.departure||flight.date||'').trim();
  const dep=Date.parse(raw.includes('T')?raw:`${String(flight.date||raw).slice(0,10)}T12:00:00`);
  if(!Number.isFinite(dep))return false;
  const delta=dep-now;
  return delta<=14*86400000&&delta>=-3*86400000;
}
function flightOpsForFlight(flight={},index=0){
  // Aena solo tiene sentido cerca de la salida. Esta barrera evita que un VY3272
  // de otro año/día se cuele por coincidir número y ruta en la API de dos días.
  if(!flightOpsMonitoringWindow(flight))return null;
  const results=state.flightOps?.result?.flights||[];
  const number=String(flight.number||'').replace(/\s+/g,'').toUpperCase();
  const date=String(flight.date||flight.departure||'').slice(0,10);
  const rowNumber=x=>String(x?.number||'').replace(/\s+/g,'').toUpperCase();
  const rowDate=x=>String(x?.date||x?.departure||'').slice(0,10);
  if(!number||!date)return null;
  return results.find(x=>rowNumber(x)===number&&rowDate(x)===date)||null;
}
function flightOpsFreshnessText(value=''){const stamp=Date.parse(value);if(!Number.isFinite(stamp))return '';const minutes=Math.max(0,Math.round((Date.now()-stamp)/60000));if(minutes<2)return 'ahora';if(minutes<60)return `hace ${minutes} min`;const hours=Math.round(minutes/60);return `hace ${hours} h`;}
function flightOpsStatusMarkup(flight,index){const ops=flightOpsForFlight(flight,index);if(!ops)return `<div class="flight-ops-strip is-pending is-compact"><div class="flight-ops-status"><span class="flight-ops-dot"></span><strong>Información operativa pendiente</strong><small>Aena · sin datos confirmados</small></div><button type="button" class="mini-btn flight-ops-refresh" data-flightops-refresh title="Actualizar estado del vuelo" aria-label="Actualizar estado del vuelo">↻</button></div>`;const cleanValue=value=>{const v=String(value??'').trim();return !v||/^(?:null|undefined|n\/a|na|—|-)$/i.test(v)?'':v;};const verified=ops.identityVerified===true,rawStatus=cleanValue(ops.status),terminal=cleanValue(ops.terminal),gate=cleanValue(ops.gate),checkInCounters=cleanValue(ops.checkInCounters),baggageBelt=cleanValue(ops.baggageBelt),boardingStart=cleanValue(ops.boardingStart),boardingClose=cleanValue(ops.boardingClose);const boardingLabel=boardingStart?`${boardingStart}${boardingClose?`–${boardingClose}`:''}`:'';const hasRealDetails=Boolean(terminal||gate||checkInCounters||baggageBelt||boardingStart||boardingClose);const status=(verified&&ops.statusVerified===true&&rawStatus)?rawStatus:(verified&&hasRealDetails?'Datos operativos disponibles':'Información operativa pendiente'),tone=!verified?'is-pending':/cancel/i.test(status)?'is-danger':/retras|delay/i.test(status)?'is-warning':hasRealDetails||/hora|boarding|embar|aterr|despeg/i.test(status)?'is-good':'',sources=[...(ops.sources||[])],liveAena=sources.some(x=>x?.name==='Aena'&&x?.identityVerified===true&&x?.mode!=='snapshot'),snapshotSource=sources.find(x=>x?.mode==='snapshot'&&x?.identityVerified===true),fresh=flightOpsFreshnessText(state.flightOps?.result?.checkedAt||'');const detail=(label,value,cls='')=>`<span class="flight-ops-detail ${cls}"><small>${label}</small><b>${verified&&value?esc(value):'—'}</b></span>`;let subtitle='Aena · sin datos confirmados';if(liveAena)subtitle=`Aena directo · dato real${fresh?` · ${fresh}`:''}`;else if(snapshotSource||ops.fallbackSnapshot)subtitle=`${snapshotSource?.name||ops.sourceLabel||'Última info confirmada'} · respaldo, no en vivo`;else if(verified)subtitle=`${ops.sourceLabel||'Aena'}${fresh?` · ${fresh}`:''}`;if(!hasRealDetails&&(!rawStatus||/información operativa pendiente/i.test(status))){return `<div class="flight-ops-strip is-pending is-compact"><div class="flight-ops-status"><span class="flight-ops-dot"></span><strong>Sin datos operativos todavía</strong><small>${esc(subtitle)}</small></div><button type="button" class="mini-btn flight-ops-refresh" data-flightops-refresh title="Actualizar estado del vuelo" aria-label="Actualizar estado del vuelo">↻</button></div>`;}return `<div class="flight-ops-strip ${tone}"><div class="flight-ops-status"><span class="flight-ops-dot"></span><strong>${esc(status)}</strong><small>${esc(subtitle)}</small></div><div class="flight-ops-details">${detail('Terminal',terminal)}${detail('Puerta',gate,'is-gate')}${detail('Facturación',checkInCounters)}${detail('Embarque',boardingLabel)}${detail('Cinta',baggageBelt)}</div><button type="button" class="mini-btn flight-ops-refresh" data-flightops-refresh title="Actualizar estado del vuelo" aria-label="Actualizar estado del vuelo">↻</button></div>`;}
async function loadFlightOps({silent=true}={}){if(state.flightOps.syncing)return state.flightOps.result;state.flightOps.syncing=true;try{const data=await callIntegrationWorker({action:'flightops-read'},{timeoutMs:10000});state.flightOps.result=data.result||null;state.flightOps.lastError=data.lastError||null;state.flightOps.fetchedAt=Date.now();if(!silent)toast(data.result?'Estado de vuelos actualizado.':'Aún no hay información operativa guardada.');return state.flightOps.result;}catch(error){if(!silent)toast(error.message,'error');return null;}finally{state.flightOps.syncing=false;}}
async function loadFlightOpsLive({silent=true}={}){const config=flightOpsConfigFromState();if(!config.flights.length)return null;const data=await callIntegrationWorker({action:'flightops-live',config},{timeoutMs:18000});if(data?.result){state.flightOps.result=data.result;state.flightOps.lastError=null;state.flightOps.fetchedAt=Date.now();if(!silent)toast(data.result.flights?.some(f=>f.hasOperationalData)?'Aena actualizado al momento.':'Aena todavía no publica datos operativos para ese vuelo.');return data.result;}return null;}
async function ensureFlightOpsAutomation({runWorkflow=false,silent=true}={}){if(!roleCanEdit())return null;const config=flightOpsConfigFromState();if(!config.flights.length)return null;try{const data=await callIntegrationWorker({action:'github-flightops-sync',config,runWorkflow},{timeoutMs:45000});state.flightOps.automationChecked=true;if(!silent)toast(runWorkflow?'Consulta operativa de respaldo lanzada.':'Seguimiento operativo preparado.');return data;}catch(error){if(!silent)toast(`Estado de vuelos: ${error.message}`,'error');console.warn('FlightOps:',error);return null;}}
async function refreshFlightOpsNow(){const buttons=$$('[data-flightops-refresh]');buttons.forEach(b=>b.disabled=true);try{let live=null;try{live=await loadFlightOpsLive({silent:false});}catch(error){console.warn('Aena directo:',error);toast(`Aena directo: ${error.message}. Lanzo respaldo.`, 'warning');}if(state.activeTab==='cover')render();const hasData=Boolean(live?.flights?.some(f=>f?.hasOperationalData));if(roleCanEdit())ensureFlightOpsAutomation({runWorkflow:!hasData,silent:true}).catch(()=>{});if(!hasData)setTimeout(async()=>{await loadFlightOps({silent:true});if(state.activeTab==='cover')render();},35000);}finally{buttons.forEach(b=>b.disabled=false);}}
function scheduleFlightOpsRefresh(){clearInterval(state.flightOpsTimer);state.flightOpsTimer=setInterval(async()=>{await loadFlightOps({silent:true});if(state.activeTab==='cover')render();},10*60*1000);}

function renderFlightCard(flight,index) {
  const palette=providerPalette(flight);
  const defaults=defaultFlightServiceButtons(flight);
  const buttons={...defaults,...flight};
  const vuelingFlight=/vueling/i.test(`${flight.airline||''} ${buttons.vuelingButtonLabel||''}`)||/^VY/i.test(String(flight.number||''));
  const vuelingStatusUrl=vuelingStatusLinkForDevice(flight,buttons.vuelingButtonUrl);
  const aenaDeparturesUrl=aenaDeparturesLinkForFlight(flight,buttons.aenaButtonUrl);
  const serviceLinks=[
    coloredServiceLink(vuelingStatusUrl,buttons.vuelingButtonLabel||'Vueling',buttons.vuelingButtonColor||'#FFD000',serviceIconMarkup(buttons.vuelingButtonIcon,buttons.vuelingButtonIconUrl,'✈️'),'flight-service-link flight-service-icon-only','vueling'),
    coloredServiceLink(aenaDeparturesUrl,buttons.aenaButtonLabel||defaults.aenaButtonLabel,buttons.aenaButtonColor||'#008C7A',serviceIconMarkup(buttons.aenaButtonIcon,buttons.aenaButtonIconUrl,'🛫'),'flight-service-link flight-service-icon-only','aena'),
    coloredServiceLink(buttons.flightAwareButtonUrl,buttons.flightAwareButtonLabel||'FlightAware',buttons.flightAwareButtonColor||'#1675D1',serviceIconMarkup(buttons.flightAwareButtonIcon,buttons.flightAwareButtonIconUrl,'◉'),'flight-service-link flight-service-icon-only','flightaware')
  ].join('');
  const vuelingCheckinUrl=vuelingQuickLinkForDevice('checkin',buttons.vuelingCheckinUrl||defaults.vuelingCheckinUrl);
  const vuelingTripsUrl=vuelingQuickLinkForDevice('trips',buttons.vuelingTripsUrl||defaults.vuelingTripsUrl);
  const checkinCompleted=hasAllStoredBoardingPasses(flight);
  const checkinButton=checkinCompleted
    ? disabledServiceButtonMarkup(buttons.vuelingCheckinLabel||defaults.vuelingCheckinLabel,buttons.vuelingButtonColor||defaults.vuelingButtonColor,'<span class="vueling-action-icon">✓</span>','flight-service-link vueling-quick-link','Tarjetas de embarque ya guardadas para Mikel y Nerea. Check-in desactivado.')
    : coloredServiceLink(vuelingCheckinUrl,buttons.vuelingCheckinLabel||defaults.vuelingCheckinLabel,buttons.vuelingButtonColor||defaults.vuelingButtonColor,'<span class="vueling-action-icon">✓</span>','flight-service-link vueling-quick-link','vueling');
  const vuelingQuick=vuelingFlight?`<div class="flight-vueling-actions">${checkinButton}${coloredServiceLink(vuelingTripsUrl,buttons.vuelingTripsLabel||defaults.vuelingTripsLabel,buttons.vuelingButtonColor||defaults.vuelingButtonColor,'<span class="vueling-action-icon">🎫</span>','flight-service-link vueling-quick-link','vueling')}${walletPassButtonMarkup(flight,index,'mikel','M',buttons.vuelingButtonColor||defaults.vuelingButtonColor)}${walletPassButtonMarkup(flight,index,'nerea','N',buttons.vuelingButtonColor||defaults.vuelingButtonColor)}</div>`:'';
  // La identidad principal del vuelo usa el logo de la aerolínea si existe y, para
  // Vueling, reutiliza el mismo logo configurado para su botón de servicio. Así las
  // fichas de avión muestran la marca junto a IDA/VUELTA igual que los buses.
  const flightIdentityUrl=String(flight.logoUrl||((vuelingFlight&&buttons.vuelingButtonIconUrl)?buttons.vuelingButtonIconUrl:'')||'').trim();
  const flightIdentity=flightIdentityUrl
    ? resilientImageMarkup(flightIdentityUrl,'airline-logo flight-card-airline-logo',`<span class="airline-logo flight-card-airline-logo emoji-icon">${esc(vuelingFlight?'✈️':(flight.airlineIcon||'✈️'))}</span>`)
    : '';
  return `<article class="card flight-card provider-gradient-card cover-editable" style="--flight-color:${esc(flight.color||palette.glow)};--provider-g1:${esc(flight.gradient1||palette.g1)};--provider-g2:${esc(flight.gradient2||palette.g2)};--provider-title-text:${esc(flight.textColor||'#ffffff')}">${canEdit()?`<div class="cover-inline-actions journey-inline-actions">${coverJourneyHideButton('flight',flight,index)}<button class="mini-btn cover-inline-edit" type="button" data-edit-flight="${index}" title="Editar este vuelo" aria-label="Editar este vuelo">✎</button></div>`:""}<div class="card-body">
    <div class="flight-top"><div class="transport-heading"><span class="transport-kicker">Vuelo</span><div class="flight-badge">${flightIdentity}<span>${esc(flight.type)}</span></div></div><div class="flight-service-links">${serviceLinks}</div></div>
    <div class="flight-route"><div class="airport"><strong>${esc(flight.from)}</strong><span>${formatTime(flight.departure)}</span></div><div class="route-line">➜</div><div class="airport"><strong>${esc(flight.to)}</strong><span>${formatTime(flight.arrival)}</span></div></div>${vuelingQuick}${flightOpsStatusMarkup(flight,index)}
    <div class="flight-details flight-details-three"><div class="detail-box"><small>Fecha</small><strong>${formatDate(flight.date,{day:'2-digit',month:'short'})}</strong></div><div class="detail-box"><small>Vuelo</small><strong>${esc(flight.number)}</strong></div><div class="detail-box"><small>Duración</small><strong>${esc(flightDuration(flight))}</strong></div></div>
    <div class="page-actions" style="margin-top:13px">${safeLink(mapsDirectionsUrl(flight.from,flight.departureMapsUrl),"Cómo llegar",googleMapsIconMarkup(),"maps-route-link")}</div>
  </div></article>`;
}

function busDocumentCandidates(doc={}) {
  const text=normalizedKey([doc.id,doc.title,doc.subtitle].filter(Boolean).join(' '));
  if(!/(autobus|avanza|pesa)/.test(text))return [];
  const buses=state.data.cover?.buses||[];
  const companyMatches=buses.filter(bus=>{
    const company=normalizedKey(bus.company||'');
    return company&&text.includes(company);
  });
  return companyMatches.length?companyMatches:buses;
}
function busDocumentEffectiveBuses(doc={}) {
  const buses=busDocumentCandidates(doc);
  const visible=buses.filter(bus=>bus.visible!==false);
  return visible.length?visible:buses;
}
function busDocumentFiles(doc={}) {
  // La ficha Autobús de "Reservas y documentos" tiene su colección propia.
  // No reutilizamos bus.files porque ese array pertenece a los adjuntos de Presupuesto.
  const buses=busDocumentEffectiveBuses(doc);
  const combined=[];
  for(const bus of buses)combined.push(...(bus.documentFiles||[]));
  if(!buses.length)combined.push(...(doc.files||[]));
  const seen=new Set();
  return normalizeFileList(combined).filter(file=>{
    const key=officialFileDriveId(file)||String(file.url||file.driveUrl||'')||String(file.id||'')||`${file.label||''}:${file.type||''}`;
    if(!key||seen.has(key))return false;seen.add(key);return true;
  });
}
function manageBusLinkedDocumentFiles(docIndex){
  const doc=state.data.cover.documents?.[docIndex];if(!doc)return;
  const buses=busDocumentEffectiveBuses(doc);
  if(!buses.length){
    openFilesManager(doc.files||[],async(files,meta={})=>{doc.files=normalizeFileList(files);const saved=await saveSection('cover');if(saved===false)return false;if(!meta.keepOpen)render();return true;},`Archivos · ${doc.title}`,{autoSave:true,storeDriveLinks:true,storageFolder:`cover-documents/${doc.id||'documento'}`});
    return;
  }
  if(buses.length===1){
    const busIndex=(state.data.cover.buses||[]).findIndex(bus=>String(bus.id)===String(buses[0].id));
    if(busIndex>=0)manageBusDocumentFiles(busIndex);
    return;
  }
  const buttons=buses.map(bus=>{
    const index=(state.data.cover.buses||[]).findIndex(item=>String(item.id)===String(bus.id));
    return `<button class="btn secondary" type="button" data-bus-doc-manage="${index}">${esc(bus.type||'Autobús')} · ${esc(bus.company||'Autobús')}</button>`;
  }).join('');
  openModal(`<div class="modal-head"><h3>Documentos del autobús</h3><button class="close-btn" data-close-modal>×</button></div><div class="modal-body"><p class="muted">Elige el trayecto cuyos documentos quieres gestionar. Estos archivos son independientes de los adjuntos de Presupuesto.</p><div class="page-actions" style="margin-top:14px">${buttons}</div></div>`,true);
  $$('[data-close-modal]',els.modal).forEach(button=>button.addEventListener('click',closeModal));
  $$('[data-bus-doc-manage]',els.modal).forEach(button=>button.addEventListener('click',()=>manageBusDocumentFiles(num(button.dataset.busDocManage))));
}

function renderDocumentLink(doc) {
  const url=doc.url||doc.driveUrl;
  if(!isValidUrl(url)) return `<span class="link-btn disabled">📎 Sin enlace</span>`;
  const type=doc.linkType||"auto";
  const label=doc.buttonLabel||(
    type==="web" ? "Abrir web" :
    type==="image" ? "Ver imagen" :
    "Ver archivo"
  );
  if(type==="web") return safeLink(url,label,"🌐");
  if(type==="image") return `<button class="link-btn" type="button" data-image-popup="${esc(url)}" data-image-title="${esc(doc.title||label)}">🖼️ ${esc(label)}</button>`;
  if(type==="file") return popupFileLink(url,label,"📄");
  return isFilePreviewUrl(url) ? popupFileLink(url,label,"📄") : safeLink(url,label,"🌐");
}
function renderDocument(doc,index) {
  const moveButtons=canEdit()?sortDragHandle(`cover-doc|${index}`,'Arrastrar documento'):"";
  const palette=providerPalette(doc);
  const linkedBuses=busDocumentEffectiveBuses(doc),linkedToBus=linkedBuses.length>0;
  const storedFiles=linkedToBus?busDocumentFiles(doc):normalizeFileList(doc.files||[]);
  const effectiveFiles=visibleFiles(storedFiles);
  const manageAttr=linkedToBus?`data-manage-bus-document-files="${index}"`:`data-manage-cover-files="${index}"`;
  const actions=editButtons(`<div class="mini-actions">${coverDocumentHideButton(doc,index)}${moveButtons}<button class="mini-btn action-clip" ${manageAttr} title="${linkedToBus?'Billetes de autobús':'Archivos y enlaces'}" aria-label="${linkedToBus?'Billetes de autobús':'Archivos y enlaces'}">📎</button><button class="mini-btn" data-edit-doc="${index}">✎</button><button class="mini-btn" data-delete-doc="${index}">×</button></div>`);
  const linkedBus=linkedToBus?linkedBuses[0]:null;
  const linkedBusIndex=linkedBus?(state.data.cover.buses||[]).findIndex(item=>String(item.id)===String(linkedBus.id)):-1;
  const documentIcon=linkedBus?(linkedBus.icon||doc.icon||'🚌'):(doc.icon||'📎');
  const documentIconUrl=linkedBus?busIdentityVisualUrl(linkedBus,linkedBusIndex):doc.iconUrl;
  return `<article class="card document-card provider-gradient-card" data-sort-item="cover-doc|${index}" style="--doc-color:${esc(doc.color||palette.glow)};--provider-g1:${esc(doc.gradient1||palette.g1)};--provider-g2:${esc(doc.gradient2||palette.g2)};--provider-title-text:${esc(doc.textColor||'#ffffff')}"><div class="card-body"><div class="provider-card-head"><div class="provider-card-identity"><div class="document-icon ${doc.id==='doc-lodging'?'is-lodging-icon':''}">${iconMarkup(documentIcon,documentIconUrl,"document-icon-image")}</div><div class="provider-card-copy"><h3 class="card-title">${esc(doc.title)}</h3><p class="card-subtitle">${esc(doc.subtitle||"")}</p></div></div>${actions}</div><div class="page-actions file-button-list" data-file-count="${effectiveFiles.length}">${effectiveFiles.map(f=>renderFileButton(f,doc.title)).join("")||(!storedFiles.length&&!linkedToBus?renderDocumentLink(doc):'')}</div>${isImageSource(doc.imageUrl)?`<img class="document-image clickable-image" src="${esc(doc.imageUrl)}" alt="${esc(doc.title)}" data-image-popup="${esc(doc.imageUrl)}">`:""}</div></article>`;
}

function findCoverMediaCarousel(carouselId){
  return (state.data.cover?.mediaCarousels||[]).find(item=>String(item.id)===String(carouselId));
}
function coverCarouselFileUrl(file={}){
  return officialFileDriveId(file)?driveFileViewUrl(file):String(file.url||file.driveUrl||'');
}
function coverCarouselPdfPreviewUrl(file={}){
  return officialFileDriveId(file)?driveFilePreviewUrl(file):drivePreviewUrl(file.url||file.driveUrl||'');
}
function renderCoverMediaCarousel(carousel,index){
  const files=visibleFiles(carousel?.files||[]);
  const id=String(carousel?.id||`cover-carousel-${index+1}`);
  const current=Math.min(Math.max(0,num(state.coverCarouselSlides[id]||0)),Math.max(0,files.length-1));
  state.coverCarouselSlides[id]=current;
  const file=files[current];
  let slide='';
  if(!file){
    slide='<div class="cover-media-empty">Añade imágenes o PDF desde Google Drive en Configuración → Contenido.</div>';
  }else if(file.type==='image'){
    const driveImage=Boolean(officialFileDriveId(file));
    const src=driveImage?TRANSPARENT_IMAGE:String(file.url||'');
    slide=`<div class="cover-media-image-frame ${driveImage?'is-loading':''}"><img class="cover-media-image clickable-image" src="${esc(src||TRANSPARENT_IMAGE)}" alt="${esc(file.label||carousel.title||'Imagen')}" data-image-popup="${esc(src||TRANSPARENT_IMAGE)}" data-cover-carousel-image="1" data-cover-carousel-id="${esc(id)}" data-cover-carousel-file-id="${esc(file.id)}" data-cover-carousel-popup-index="${current}"><div class="cover-media-loading">Cargando desde Google Drive…</div><div class="cover-media-image-error"><span>No se ha podido cargar la imagen desde Drive.</span><div class="page-actions"><button class="btn small secondary" type="button" data-repair-cover-carousel-image data-cover-carousel-id="${esc(id)}" data-cover-carousel-file-id="${esc(file.id)}">${driveIconMarkup()} Reintentar</button><button class="btn small canary-action-btn" type="button" data-repair-cover-carousel-account data-cover-carousel-id="${esc(id)}" data-cover-carousel-file-id="${esc(file.id)}">👤 Cambiar cuenta</button></div></div></div>`;
  }else{
    const openUrl=coverCarouselFileUrl(file),previewUrl=coverCarouselPdfPreviewUrl(file);
    slide=`<div class="cover-media-pdf"><div class="cover-media-pdf-frame">${previewUrl?`<iframe src="${esc(previewUrl)}" title="${esc(file.label||carousel.title||'PDF')}" loading="lazy"></iframe>`:''}</div><button class="link-btn cover-media-open-pdf" type="button" data-file-popup="${esc(openUrl)}" data-file-title="${esc(file.label||carousel.title||'PDF')}" data-cover-carousel-id="${esc(id)}" data-cover-carousel-file-id="${esc(file.id)}" data-cover-carousel-popup-index="${current}">${pdfFileIconMarkup()} Abrir PDF</button></div>`;
  }
  const dots=files.length>1?`<div class="cover-media-dots" aria-label="Páginas del carrusel">${files.map((_,i)=>`<button type="button" class="cover-media-dot ${i===current?'active':''}" data-cover-carousel-go="${esc(id)}:${i}" aria-label="Ir al elemento ${i+1}"></button>`).join('')}</div>`:'';
  return `<article class="card cover-media-carousel" data-cover-carousel="${esc(id)}"><div class="cover-media-head"><div><span class="header-kicker">Galería</span><h3>${esc(carousel.title||'Carrusel')}</h3>${String(carousel.subtitle||'').trim()?`<p>${esc(carousel.subtitle)}</p>`:''}</div>${canEdit()?`<div class="mini-actions"><button class="mini-btn" type="button" data-cover-carousel-edit="${index}" title="Editar título y subtítulo" aria-label="Editar carrusel">✎</button><button class="mini-btn action-clip" type="button" data-cover-carousel-manage="${index}" title="Gestionar imágenes y PDF" aria-label="Gestionar imágenes y PDF">📎</button></div>`:''}</div><div class="cover-media-stage">${slide}</div><div class="cover-media-controls"><button class="mini-btn cover-media-arrow" type="button" data-cover-carousel-step="${esc(id)}:-1" ${files.length<2?'disabled':''} aria-label="Anterior">‹</button><span>${files.length?`${current+1}/${files.length} · ${esc(file?.label||'')}`:'0/0'}</span><button class="mini-btn cover-media-arrow" type="button" data-cover-carousel-step="${esc(id)}:1" ${files.length<2?'disabled':''} aria-label="Siguiente">›</button></div>${dots}</article>`;
}
function renderCoverMediaCarousels(){
  const carousels=(state.data.cover?.mediaCarousels||[]).map((carousel,index)=>({carousel,index})).filter(({carousel})=>coverCarouselPlacement(carousel)==='cover');
  if(!carousels.length)return '';
  return `<section class="cover-media-carousels">${carousels.map(({carousel,index})=>renderCoverMediaCarousel(carousel,index)).join('')}</section>`;
}
function renderLodgingCarouselAccordion(carousel,index){
  const id=String(carousel?.id||`cover-carousel-${index+1}`);
  const files=visibleFiles(carousel?.files||[]);
  const isOpen=state.coverCarouselOpen[id]===true;
  return `<details class="lodging-carousel-details" data-lodging-carousel-details="${esc(id)}"${isOpen?' open':''}><summary><span class="lodging-carousel-summary-copy"><span class="header-kicker">Galería</span><strong>${esc(carousel.title||'Carrusel')}</strong>${String(carousel.subtitle||'').trim()?`<small>${esc(carousel.subtitle)}</small>`:''}</span><span class="lodging-carousel-summary-meta">${files.length} archivo${files.length===1?'':'s'} <span class="lodging-carousel-chevron" aria-hidden="true">⌄</span></span></summary><div class="lodging-carousel-body">${renderCoverMediaCarousel(carousel,index)}</div></details>`;
}
async function hydrateCoverCarouselImage(img,interactive=false){
  if(!img?.dataset?.coverCarouselImage)return;
  const carousel=findCoverMediaCarousel(img.dataset.coverCarouselId);
  const file=(carousel?.files||[]).find(item=>String(item.id)===String(img.dataset.coverCarouselFileId));
  if(!file)throw new Error('No se ha encontrado la imagen del carrusel.');
  const frame=img.closest('.cover-media-image-frame');frame?.classList.add('is-loading');
  try{
    const resolved=officialFileDriveId(file)?await fetchDriveMediaObjectUrl(file,interactive,interactive):String(file.url||'');
    if(!resolved)throw new Error('La imagen no tiene una URL válida.');
    img.src=resolved;img.dataset.imagePopup=resolved;frame?.classList.remove('is-loading','has-error');return resolved;
  }catch(error){
    frame?.classList.remove('is-loading');frame?.classList.add('has-error');
    const message=frame?.querySelector('.cover-media-image-error span');
    if(message)message.textContent=String(error?.message||'No se ha podido cargar la imagen desde Drive.').slice(0,320);
    throw error;
  }
}
async function stabilizeCoverCarouselDriveFile(carouselId,fileId){
  const carousel=findCoverMediaCarousel(carouselId),file=(carousel?.files||[]).find(item=>String(item.id)===String(fileId));
  const driveId=officialFileDriveId(file||{});
  if(!carousel||!file||!driveId||file.storagePath)return false;
  const imported=await importDriveFile({id:driveId,driveFileId:driveId,label:file.label||'Archivo de Drive',mimeType:file.mimeType||'',type:file.type||'file',driveUrl:file.driveUrl||driveFileViewUrl(file),url:file.driveUrl||driveFileViewUrl(file)},'cover-media');
  const stable={...file,...imported,id:file.id,label:file.label||imported.label,source:'storage',driveFileId:'',driveUrl:'',originalDriveUrl:file.driveUrl||driveFileViewUrl(file)};
  const target=(carousel.files||[]).findIndex(item=>String(item.id)===String(fileId));
  if(target<0)return false;
  carousel.files[target]=stable;
  await saveSection('cover');
  return true;
}
function bindCoverCarouselImage(img){
  if(!img?.dataset?.coverCarouselImage||img.dataset.coverCarouselBound)return;
  img.dataset.coverCarouselBound='1';
  img.addEventListener('load',()=>{if(img.src!==TRANSPARENT_IMAGE)img.closest('.cover-media-image-frame')?.classList.remove('is-loading','has-error');});
  img.addEventListener('error',()=>img.closest('.cover-media-image-frame')?.classList.add('has-error'));
  hydrateCoverCarouselImage(img,false).catch(error=>console.warn('Carrusel de Portada · Google Drive:',error.message));
}
function openCoverCarouselEditor(index=null){
  const current=index===null?{title:'Instrucciones',subtitle:'',placement:'cover',files:[]}:state.data.cover.mediaCarousels[index];
  openForm({title:index===null?'Añadir carrusel':'Editar carrusel',fields:[{name:'title',label:'Título',required:true,full:true},{name:'subtitle',label:'Subtítulo',full:true},{name:'placement',label:'Ubicación',type:'select',full:true,options:[['cover','Fuera en la Portada'],['lodging','Dentro de Alojamiento · desplegable']]}],values:{...current,placement:coverCarouselPlacement(current)},onSubmit:async values=>{
    const item={id:current.id||uid('cover-carousel'),files:normalizeFileList(current.files||[]),...current,...values};
    if(index===null)state.data.cover.mediaCarousels.push(item);else state.data.cover.mediaCarousels[index]=item;
    await saveSection('cover');render();
  }});
}
function manageCoverCarouselFiles(index){
  const carousel=state.data.cover.mediaCarousels?.[index];if(!carousel)return;
  openFilesManager(carousel.files||[],async(files,meta={})=>{
    const target=state.data.cover.mediaCarousels?.find(item=>String(item.id)===String(carousel.id));
    if(!target)throw new Error('El carrusel ya no existe.');
    target.files=normalizeFileList(files).filter(file=>file.type==='image'||String(file.mimeType||'').toLowerCase()==='application/pdf'||/\.pdf(?:$|[?#])/i.test(String(file.url||file.driveUrl||'')));
    const saved=await saveSection('cover');if(!saved)throw new Error('No se han podido guardar los archivos del carrusel.');
    if(!meta.keepOpen)render();return true;
  },`${carousel.title} · Imágenes y PDF`,{autoSave:true,driveOnly:true,storeDriveLinks:true,storageFolder:'cover-media',mimeTypes:'application/pdf,image/png,image/jpeg,image/webp,image/gif,image/svg+xml'});
}

function editCoverCountdown(){
  const s=state.data.settings,crop=s.countdownImageCrop||{x:50,y:50,zoom:1};
  openForm({title:"Editar cuenta atrás",fields:[
    {name:"countdownTitle",label:"Título",full:true},{name:"countdownSubtitle",label:"Subtítulo",full:true},
    {name:"countdownImageUrl",label:"Imagen (URL o Google Drive)",type:"url",full:true,driveImage:true},
    {name:"countdownGradient1",label:"Degradado inicio",type:"color"},{name:"countdownGradient2",label:"Degradado fin",type:"color"},
    {name:"countdownTextColor",label:"Color del texto",type:"color"},
    {name:"countdownEndDateTime",label:"Momento final de la cuenta atrás",type:"datetime-local",full:true,help:"El contador llegará a cero exactamente en esta fecha y hora. Si lo dejas vacío, se usará «Inicio del viaje / vuelo»."},
    {name:"countdownShowSeconds",label:"Mostrar segundos",type:"checkbox",full:true},
    {name:"countdownOverlayOpacity",label:"Oscurecimiento",type:"number",step:"0.05"},
    {name:"countdownCropX",label:"Encuadre horizontal",type:"number"},{name:"countdownCropY",label:"Encuadre vertical",type:"number"},
    {name:"countdownZoom",label:"Zoom",type:"number",step:"0.1"}
  ],values:{...s,countdownCropX:crop.x??50,countdownCropY:crop.y??50,countdownZoom:crop.zoom||1},onSubmit:async v=>{
    Object.assign(s,{countdownTitle:v.countdownTitle,countdownSubtitle:v.countdownSubtitle,countdownImageUrl:v.countdownImageUrl,countdownGradient1:v.countdownGradient1,countdownGradient2:v.countdownGradient2,countdownTextColor:v.countdownTextColor,countdownEndDateTime:String(v.countdownEndDateTime||'').trim(),countdownShowSeconds:Boolean(v.countdownShowSeconds),countdownOverlayOpacity:Math.min(.95,Math.max(0,num(v.countdownOverlayOpacity))),countdownImageCrop:{x:Math.min(100,Math.max(0,num(v.countdownCropX))),y:Math.min(100,Math.max(0,num(v.countdownCropY))),zoom:Math.min(3,Math.max(1,num(v.countdownZoom)||1))}});
    await saveSection("settings");render();
  }});
}
function editCoverWeather(){
  const s=state.data.settings;
  openForm({title:"Editar tiempo de la Portada",fields:[
    {name:"weatherPlace",label:"Localidad",required:true,full:true},
    {name:"weatherLatitude",label:"Latitud",type:"number",step:"any"},
    {name:"weatherLongitude",label:"Longitud",type:"number",step:"any"}
  ],values:s,onSubmit:async v=>{s.weatherPlace=v.weatherPlace;s.weatherLatitude=v.weatherLatitude;s.weatherLongitude=v.weatherLongitude;await saveSection("settings");try{state.weather=await loadOpenMeteoWeather();}catch{}render();}});
}
function editCoverMap(){
  const s=state.data.settings;
  openForm({title:"Editar mapa de la Portada",fields:[
    {name:"mapQuery",label:"Lugar o dirección",full:true},
    {name:"mapEmbedUrl",label:"URL de iframe personalizada",type:"url",full:true},
    {name:"mapType",label:"Tipo de mapa",type:"select",options:[["satellite","Satélite"],["hybrid","Híbrido"],["terrain","Terreno"],["map","Mapa"]]}
  ],values:s,onSubmit:async v=>{s.mapQuery=v.mapQuery;s.mapEmbedUrl=v.mapEmbedUrl;s.mapType=v.mapType||"satellite";await saveSection("settings");render();}});
}
function editExternalImage(index=null){
  const current=index===null?{title:"",url:""}:state.data.cover.externalImages[index];
  openForm({title:index===null?"Enlazar imagen":"Editar imagen enlazada",fields:[
    {name:"title",label:"Título",full:true},{name:"url",label:"URL de la imagen",type:"url",required:true,full:true,driveImage:true}
  ],values:current,onSubmit:async v=>{const item={id:current?.id||uid("img"),...current,...v};if(index===null)state.data.cover.externalImages.push(item);else state.data.cover.externalImages[index]=item;await saveSection("cover");render();}});
}
async function addExternalImagesFromDrive(){
  try{
    const selected=await selectFromDrive({multiple:true,mimeTypes:'image/png,image/jpeg,image/webp,image/gif,image/svg+xml',includeToken:true,sharedDrives:false,title:'Seleccionar varias imágenes para la Portada'});
    if(!selected.length)return;
    toast(`Importando ${selected.length} imagen${selected.length===1?'':'es'} desde Google Drive…`);
    const imported=[];
    for(const item of selected){
      const ready=await importDriveImage(item,'images');
      imported.push({id:uid('img'),title:item.label||ready.label||'Imagen',url:ready.url});
    }
    state.data.cover.externalImages.push(...imported);
    await saveSection('cover');render();
    toast(`${imported.length} imagen${imported.length===1?'':'es'} añadida${imported.length===1?'':'s'} a la Portada.`);
  }catch(error){toast(`No se pudieron añadir las imágenes desde Drive: ${error.message}`,'error');}
}

function coverMediaLayoutKey(carousel,index=0){return `mediaCarousel:${String(carousel?.id||`cover-carousel-${index+1}`)}`;}
function desktopCoverAvailableKeys(){
  const carouselKeys=(state.data.cover.mediaCarousels||[]).map((carousel,index)=>({carousel,index})).filter(({carousel})=>coverCarouselPlacement(carousel)==='cover').map(({carousel,index})=>coverMediaLayoutKey(carousel,index));
  return ["countdown","weather","flights","lodging","budget","trackersSummary","documents",...carouselKeys,"externalImages"];
}
function desktopCoverOrder(){
  const keys=desktopCoverAvailableKeys(),carouselKeys=keys.filter(x=>x.startsWith("mediaCarousel:")),configured=state.data.settings.desktopCoverOrder||[],raw=[];
  for(const id of configured){
    if(id==="mediaCarousels"){for(const carouselId of carouselKeys)if(!raw.includes(carouselId))raw.push(carouselId);continue;}
    if(keys.includes(id)&&!raw.includes(id))raw.push(id);
  }
  for(const id of keys)if(!raw.includes(id))raw.push(id);
  // Los carruseles respetan siempre el orden definido en Configuración, incluso si antes
  // se habían movido individualmente en el editor de escritorio.
  let cursor=0;
  const out=raw.map(id=>String(id).startsWith("mediaCarousel:")?(carouselKeys[cursor++]||id):id)
    .filter((id,index,array)=>keys.includes(id)&&array.indexOf(id)===index);
  for(const id of keys)if(!out.includes(id))out.push(id);
  return out;
}
function desktopCoverWidth(id){return state.data.settings.desktopCoverWidths?.[id]==="half"?"half":"full";}
function coverLayoutControls(id){
  if(!canEdit()||!state.coverLayoutEdit)return "";
  const half=desktopCoverWidth(id)==="half";
  return `<div class="cover-layout-controls" data-layout-controls><button type="button" class="mini-btn ${half?"active":""}" data-cover-layout-width="half" data-cover-layout-target="${esc(id)}" title="Media fila">½</button><button type="button" class="mini-btn ${!half?"active":""}" data-cover-layout-width="full" data-cover-layout-target="${esc(id)}" title="Ancho completo">1/1</button></div>`;
}
function coverVisibilityMeta(id){
  if(String(id).startsWith('document:')){
    const entry=coverDocumentVisibilityEntries().find(row=>row.key===id);
    if(entry)return ['📎',String(entry.item?.title||'Documento o reserva')];
    return ['📎','Documento o reserva'];
  }
  if(String(id).startsWith('journey:')){
    const entry=coverJourneyVisibilityEntries().find(row=>row.key===id);
    if(entry){
      if(entry.kind==='bus'){
        const direction=entry.direction==='return'?'vuelta':'ida';
        const company=String(entry.item?.company||'').trim();
        return ['🚌',`Autobús ${direction}${company?` · ${company}`:''}`];
      }
      const direction=entry.direction==='return'?'vuelta':'ida';
      const number=String(entry.item?.number||'').trim();
      return ['✈️',`Vuelo de ${direction}${number?` · ${number}`:''}`];
    }
    return ['▣','Transporte'];
  }
  const base={
    countdown:['⏳','Cuenta atrás'],weather:['🌤️','Tiempo'],flights:['✈️','Transportes y vuelos'],lodging:['🏨','Alojamiento'],budget:['💶','Presupuesto'],trackersSummary:['📡','Seguimientos'],documents:['📎','Documentos y reservas'],mediaCarousels:['🗂️','Galerías y carruseles'],externalImages:['🖼️','Imágenes adicionales']
  };
  if(String(id).startsWith('mediaCarousel:')){
    const list=state.data.cover?.mediaCarousels||[];
    const index=list.findIndex((carousel,i)=>coverMediaLayoutKey(carousel,i)===id);
    const carousel=index>=0?list[index]:null;
    return ['🗂️',String(carousel?.title||'Galería')];
  }
  return base[id]||['▣',String(id||'Elemento')];
}
function coverEyeIconMarkup(className='cover-eye-icon'){
  return `<svg class="${esc(className)}" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M2.2 12s3.5-6.1 9.8-6.1S21.8 12 21.8 12 18.3 18.1 12 18.1 2.2 12 2.2 12Z"/><circle cx="12" cy="12" r="3.1"/></svg>`;
}
function coverVisibilityButton(id){
  if(!canEdit()||id==='flights'||id==='documents')return '';
  const [,label]=coverVisibilityMeta(id);
  return `<div class="cover-visibility-row"><button type="button" class="mini-btn cover-visibility-btn" data-cover-hide="${esc(id)}" title="Ocultar ${esc(label)}" aria-label="Ocultar ${esc(label)}">${coverEyeIconMarkup()}</button></div>`;
}
function renderCoverHiddenList(hiddenSet,expandedOrder,blocks){
  if(!canEdit())return '';
  const ids=[];
  const push=id=>{if(id&&!ids.includes(id))ids.push(id);};
  if(hiddenSet.has('mediaCarousels'))push('mediaCarousels');
  for(const entry of coverJourneyVisibilityEntries())if(hiddenSet.has(entry.key))push(entry.key);
  for(const entry of coverDocumentVisibilityEntries())if(hiddenSet.has(entry.key))push(entry.key);
  for(const id of expandedOrder){
    if(id==='flights'||id==='documents')continue;
    if(!String(blocks[id]||'').trim())continue;
    if(hiddenSet.has(id))push(id);
  }
  if(!ids.length)return '';
  return `<section class="card cover-hidden-list"><div class="cover-hidden-list-head"><strong>Elementos ocultos</strong><small>Solo aparece mientras la edición está desbloqueada</small></div><div class="cover-hidden-list-items">${ids.map(id=>{const[icon,label]=coverVisibilityMeta(id);return `<div class="cover-hidden-list-row"><span>${icon} ${esc(label)}</span><button type="button" class="mini-btn cover-show-btn" data-cover-show="${esc(id)}" title="Volver a mostrar ${esc(label)}" aria-label="Volver a mostrar ${esc(label)}">${coverEyeIconMarkup()}</button></div>`;}).join('')}</div></section>`;
}
function coverLayoutItem(id,html){
  if(!String(html||"").trim())return "";
  const order=desktopCoverOrder(),desktopIndex=Math.max(0,order.indexOf(id)),width=desktopCoverWidth(id);
  return `<div class="cover-layout-item is-${width}${state.coverLayoutEdit?" layout-editing":""}${canEdit()?" has-cover-edit-tools":""}" data-cover-layout-id="${esc(id)}" data-sort-item="cover-layout|${encodeURIComponent(id)}" style="--desktop-order:${desktopIndex}">${coverVisibilityButton(id)}${canEdit()?`<button type="button" class="mini-btn free-drag-handle cover-direct-drag" data-sort-handle="cover-layout|${encodeURIComponent(id)}" title="Arrastrar bloque de Portada" aria-label="Arrastrar bloque de Portada">⋮⋮</button>`:''}${coverLayoutControls(id)}${html}</div>`;
}
function renderCoverLayoutToolbar(){
  if(!canEdit())return "";
  return `<div class="cover-layout-toolbar"><button type="button" class="btn small ${state.coverLayoutEdit?"primary":"secondary"}" data-cover-layout-toggle>${state.coverLayoutEdit?"✓ Terminar distribución":"▦ Editar distribución"}</button>${state.coverLayoutEdit?'<button type="button" class="btn small secondary" data-cover-layout-reset>↺ Restaurar escritorio</button><span class="cover-layout-hint">Arrastra los bloques · el orden interno de las galerías sigue Configuración · ½ = dos por fila · 1/1 = ancho completo</span>':''}</div>`;
}
function resetDesktopCoverLayout(){
  state.data.settings.desktopCoverOrder=desktopCoverAvailableKeys();
  state.data.settings.desktopCoverWidths=Object.fromEntries(state.data.settings.desktopCoverOrder.map(id=>[id,"full"]));
}

function premiumCoverDateLabel(settings={}){
  const start=String(settings.departureDateTime||'').slice(0,10),end=String(settings.returnDateTime||'').slice(0,10);
  if(!start&&!end)return 'Fechas por configurar';
  if(start&&!end)return formatDate(start,{day:'2-digit',month:'short',year:'numeric'});
  if(!start&&end)return formatDate(end,{day:'2-digit',month:'short',year:'numeric'});
  return `${formatDate(start,{day:'2-digit',month:'short'})} – ${formatDate(end,{day:'2-digit',month:'short',year:'numeric'})}`;
}
function premiumCoverHero(settings={},cover={},stats={},lodging={}){
  const title=[settings.destination||'Viaje',settings.year||''].filter(Boolean).join(' ');
  const heroImage=[settings.coverImageUrl,settings.countdownImageUrl,lodging.imageUrl].find(isImageSource)||'';
  const imageStyle=heroImage?`--premium-hero-image:url('${esc(heroImage)}')`:'';
  const dateLabel=premiumCoverDateLabel(settings);
  const paidPct=stats.total>0?Math.min(100,Math.max(0,Math.round((num(stats.paid)/num(stats.total))*100))):0;
  const flights=(cover.flights||[]).filter(Boolean).slice().sort((a,b)=>(Date.parse(a.departure||a.date||0)||0)-(Date.parse(b.departure||b.date||0)||0));
  const now=Date.now(),nextFlight=flights.find(f=>(Date.parse(f.departure||f.date||0)||0)>=now)||flights[0]||null;
  const flightText=nextFlight?[nextFlight.from,nextFlight.to].filter(Boolean).join(' → '):'Sin vuelos configurados';
  const lodgingText=String(lodging.name||'').trim()||'Sin alojamiento configurado';
  return `<section class="premium-cover-hero" style="${imageStyle}"><div class="premium-cover-hero-shade"></div><div class="premium-cover-hero-copy"><span class="premium-cover-eyebrow">VIAJE ACTUAL</span><h2>${esc(title||'Tu viaje')}</h2><p>${esc(dateLabel)} · ${num(settings.people)||1} viajero${num(settings.people)===1?'':'s'}</p><div class="premium-cover-progress"><span><b>${formatMoney(stats.paid||0)}</b> pagado de ${formatMoney(stats.total||0)}</span><strong>${paidPct}%</strong></div><div class="premium-cover-progress-bar"><i style="--premium-progress:${paidPct}%"></i></div></div><div class="premium-cover-quick-grid"><div><span class="premium-cover-quick-icon">✈</span><small>Vuelo</small><strong>${esc(flightText)}</strong></div><div><span class="premium-cover-quick-icon">▰</span><small>Alojamiento</small><strong>${esc(lodgingText)}</strong></div><div><span class="premium-cover-quick-icon">€</span><small>Presupuesto</small><strong>${formatMoney(stats.total||0)}</strong></div><div><span class="premium-cover-quick-icon">✓</span><small>Pagado</small><strong>${formatMoney(stats.paid||0)}</strong></div></div></section>`;
}

function renderCover() {
  const s=state.data.settings, c=state.data.cover, b=budgetStats(), l=c.lodging;
  const cordialTracker=state.data.trackers?.cordial||{};
  const mapMode={satellite:'k',hybrid:'h',terrain:'p',map:'m'}[s.mapType]||'k';
  const mapUrl=s.mapEmbedUrl || (s.mapQuery?`https://www.google.com/maps?q=${encodeURIComponent(s.mapQuery)}&output=embed&t=${mapMode}`:"");
  const crop=s.countdownImageCrop||{x:50,y:50,zoom:1};
  const hasCountdownImage=isImageSource(s.countdownImageUrl);
  const countdownStyle=`--hero1:${esc(s.countdownGradient1||s.theme.gradientStart||"#244c78")};--hero2:${esc(s.countdownGradient2||s.theme.gradientEnd||"#402b73")};--countdown-text:${esc(s.countdownTextColor||"#ffffff")};--countdown-overlay:${Math.min(.95,Math.max(0,num(s.countdownOverlayOpacity??.58)))};--countdown-unit-bg:${esc(s.countdownUnitBackground||"rgba(7,9,13,.56)")};--countdown-img:${hasCountdownImage?`url('${esc(s.countdownImageUrl)}')`:'none'};--countdown-x:${Number.isFinite(Number(crop.x))?num(crop.x):50}%;--countdown-y:${Number.isFinite(Number(crop.y))?num(crop.y):50}%;--countdown-zoom:${Math.max(1,num(crop.zoom)||1)}`;
  const lc=l.imageCrop||{x:50,y:50,zoom:1};
  const countdownTitle=s.countdownTitle??'Nos vamooooos';
  const countdownSubtitle=s.countdownSubtitle??'Hasta el inicio del vuelo de ida';
  const coverHiddenSet=new Set(s.coverHiddenBlocks||[]);
  const visibleCoverDocuments=(c.documents||[]).map((doc,index)=>({doc,index,key:coverDocumentVisibilityKey(doc,index)})).filter(entry=>!coverHiddenSet.has(entry.key));
  const documentColsLg=Math.max(1,Math.min(4,visibleCoverDocuments.length||1));const documentColsMd=Math.max(1,Math.min(2,visibleCoverDocuments.length||1));const documentSection=visibleCoverDocuments.length||canEdit()?`<section class="cover-documents">${visibleCoverDocuments.length?`<div class="documents-grid" style="--documents-grid-cols:${documentColsLg};--documents-grid-cols-md:${documentColsMd}">${visibleCoverDocuments.map(({doc,index})=>renderDocument(doc,index)).join("")}</div>`:(canEdit()?'<div class="empty card">Todas las fichas de documentos y reservas están ocultas.</div>':'')}${canEdit()?`<div class="cover-document-add"><button class="btn small secondary" data-add-document>📎 Añadir documento</button></div>`:''}</section>`:'';
  const reviewDefaults=defaultLodgingReviewButtons();
  const reviewLinks=[
    isValidUrl(l.googleReviewsUrl)?coloredServiceLink(l.googleReviewsUrl,l.googleReviewsLabel||reviewDefaults.googleReviewsLabel,l.googleReviewsColor||reviewDefaults.googleReviewsColor,serviceIconMarkup(l.googleReviewsIcon,l.googleReviewsIconUrl,brandIconMarkup('google')),'lodging-review-link','googlemaps'):'',
    isValidUrl(l.tripadvisorReviewsUrl)?coloredServiceLink(l.tripadvisorReviewsUrl,l.tripadvisorReviewsLabel||reviewDefaults.tripadvisorReviewsLabel,l.tripadvisorReviewsColor||reviewDefaults.tripadvisorReviewsColor,serviceIconMarkup(l.tripadvisorReviewsIcon,l.tripadvisorReviewsIconUrl,brandIconMarkup('tripadvisor')),'lodging-review-link','tripadvisor'):'',
    isValidUrl(l.bookingReviewsUrl)?coloredServiceLink(l.bookingReviewsUrl,l.bookingReviewsLabel||reviewDefaults.bookingReviewsLabel,l.bookingReviewsColor||reviewDefaults.bookingReviewsColor,serviceIconMarkup(l.bookingReviewsIcon,l.bookingReviewsIconUrl,brandIconMarkup('booking')),'lodging-review-link booking-review-link','booking'):''
  ].filter(Boolean).join('');
  const lodgingEmbeddedCarousels=(c.mediaCarousels||[]).map((carousel,index)=>coverCarouselPlacement(carousel)==='lodging'?renderLodgingCarouselAccordion(carousel,index):'').join('');
  const lodgingEmbeddedMedia=lodgingEmbeddedCarousels?`<div class="lodging-embedded-media" aria-label="Planos e instrucciones del alojamiento">${lodgingEmbeddedCarousels}</div>`:'';
  const lodgingMap=`<div class="lodging-map-section cover-editable">${canEdit()?`<div class="cover-inline-actions lodging-map-edit">${coverInlineEditButton("map","Editar ubicación y mapa")}</div>`:""}<div class="section-title map-section-title lodging-map-title" style="--g1:#173b61;--g2:#285f91"><span>📍 UBICACIÓN · ${esc(({satellite:'SATÉLITE',hybrid:'HÍBRIDO',terrain:'TERRENO',map:'MAPA'})[s.mapType]||'SATÉLITE')}</span></div>${mapUrl?`<iframe class="map-frame lodging-map-frame" src="${esc(mapUrl)}" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>`:`<div class="map-placeholder lodging-map-placeholder">Añade una ubicación o URL de mapa en Configuración.</div>`}</div>`;
  const journeyCards=renderJourneyCards();
  const blocks={
    countdown:`<section class="card countdown-strip countdown-photo cover-editable${hasCountdownImage?' has-image':''}" style="${countdownStyle}">${canEdit()?`<div class="cover-inline-actions">${coverInlineEditButton("countdown","Editar cuenta atrás")}</div>`:""}<div class="countdown-photo-layer"></div><div class="countdown-copy"><strong>${esc(countdownTitle)}</strong>${String(countdownSubtitle).trim()?`<span>${esc(countdownSubtitle)}</span>`:''}</div>${renderCountdown()}</section>`,
    weather:`<div class="cover-editable cover-block-wrapper">${canEdit()?`<div class="cover-inline-actions">${coverInlineEditButton("weather","Editar tiempo")}</div>`:""}${renderWeather()}</div>`,
    flights:journeyCards?`<section class="${journeyGridClass()}">${journeyCards}</section>`:'',
    lodging:`<section class="card lodging-card compact-lodging provider-gradient-card cover-editable" style="margin-top:18px;--provider-g1:${esc(l.gradient1||providerPalette(l).g1)};--provider-g2:${esc(l.gradient2||providerPalette(l).g2)};--lodging-color:${esc(l.gradient2||providerPalette(l).glow)};--provider-title-text:${esc(l.textColor||'#ffffff')}">${canEdit()?`<div class="cover-inline-actions"><button class="mini-btn cover-inline-edit" type="button" data-edit-lodging title="Editar alojamiento" aria-label="Editar alojamiento">✎</button></div>`:""}<div class="lodging-info"><div class="flight-top"><div class="lodging-title-row">${String(cordialTracker.titleIconUrl||'').trim()?resilientImageMarkup(String(cordialTracker.titleIconUrl||'').trim(),'airline-logo flight-card-airline-logo lodging-title-icon',`<span class="airline-logo flight-card-airline-logo lodging-title-icon emoji-icon">${esc(cordialTracker.titleIcon||TRACKER_DEFAULT_ICONS.cordial||'🏨')}</span>`,false):`<span class="airline-logo flight-card-airline-logo lodging-title-icon emoji-icon">${esc(cordialTracker.titleIcon||TRACKER_DEFAULT_ICONS.cordial||'🏨')}</span>`}<div><span class="header-kicker">Alojamiento</span><h3 class="lodging-title">${esc(l.name)}</h3></div></div></div><div class="lodging-date-actions"><div class="date-range"><div class="date-chip"><small class="muted">Entrada</small><br><strong>${formatDate(l.checkIn)}</strong></div><div class="date-chip"><small class="muted">Salida</small><br><strong>${formatDate(l.checkOut)}</strong></div></div><div class="lodging-quick-actions" aria-label="Accesos del alojamiento">${safeLink(l.website,"Web","🌐","lodging-quick-link")}${safeLink(mapsDirectionsUrl(l.address||l.name,l.mapsUrl),"Cómo llegar",googleMapsIconMarkup(),"lodging-quick-link lodging-route-link maps-route-link")}${reviewLinks}</div></div></div>${isImageSource(l.imageUrl)?`<button class="lodging-image clickable-image" style="--lodging-img:url('${esc(l.imageUrl)}');--lodging-pos:${num(lc.x)||50}% ${num(lc.y)||50}%;--lodging-zoom:${Math.max(1,num(lc.zoom)||1)}" data-image-popup="${esc(l.imageUrl)}" data-image-title="${esc(l.name)}" aria-label="Ampliar imagen del alojamiento"></button>`:`<div class="lodging-image"></div>`}${lodgingEmbeddedMedia}${lodgingMap}</section>`,
    budget:`<section class="kpi-grid cover-editable cover-budget-block">${canEdit()?`<div class="cover-inline-actions">${coverInlineOpenButton("budget","Abrir Presupuesto para editar")}</div>`:""}<div class="kpi accent"><span>Presupuesto total</span><strong>${formatMoney(b.total)}</strong></div><div class="kpi"><span>Total por persona</span><strong>${formatMoney(b.perPerson)}</strong></div><div class="kpi success kpi-with-chart"><div class="kpi-copy"><span>Pagado</span><strong>${formatMoney(b.paid)}</strong></div>${coverBudgetDonut("Pagado",b.paid,b.total,"success")}</div><div class="kpi danger kpi-with-chart"><div class="kpi-copy"><span>Por pagar</span><strong>${formatMoney(b.unpaid)}</strong></div>${coverBudgetDonut("Pendiente",b.unpaid,b.total,"danger")}</div></section>`,
    trackersSummary:`<section class="cover-trackers-summary cover-editable"><div class="section-title cover-trackers-summary-title" style="--g1:#173b61;--g2:#285f91"><span>📡 SEGUIMIENTOS</span>${canEdit()?`<div class="row-actions"><button type="button" class="mini-btn cover-inline-edit" data-cover-block-open="trackers" title="Abrir Seguimientos" aria-label="Abrir Seguimientos">✎</button></div>`:''}</div>${trackerSummaryStrip('cover')}</section>`,
    documents:documentSection,
    externalImages:`${c.externalImages?.length?`<section class="cover-external-images">${c.externalImages.map((x,i)=>`<article class="card cover-editable"><div class="card-body"><div class="flight-top"><h3>${esc(x.title||"Imagen")}</h3>${editButtons(`<div class="mini-actions"><button class="mini-btn" data-edit-external-image="${i}" title="Editar imagen">✎</button><button class="mini-btn" data-delete-external-image="${i}" title="Eliminar imagen">×</button></div>`)}</div><img class="document-image external-image clickable-image" src="${esc(x.url)}" alt="${esc(x.title||'Imagen')}" data-image-popup="${esc(x.url)}"></div></article>`).join("")}</section>`:""}`
  };
  const carouselBlocks=(c.mediaCarousels||[]).map((carousel,index)=>({carousel,index,key:coverMediaLayoutKey(carousel,index),html:renderCoverMediaCarousel(carousel,index)})).filter(item=>coverCarouselPlacement(item.carousel)==='cover');
  for(const item of carouselBlocks)blocks[item.key]=item.html;
  const mobileOrder=s.coverOrder||["countdown","weather","flights","lodging","budget","trackersSummary","documents","mediaCarousels","externalImages"],expandedOrder=[];
  for(const key of mobileOrder){
    if(key==="mediaCarousels"){for(const item of carouselBlocks)expandedOrder.push(item.key);continue;}
    expandedOrder.push(key);
  }
  for(const item of carouselBlocks)if(!expandedOrder.includes(item.key))expandedOrder.push(item.key);
  const hiddenCoverBlocks=coverHiddenSet;
  const isHiddenCoverKey=key=>hiddenCoverBlocks.has(key)||(String(key).startsWith("mediaCarousel:")&&hiddenCoverBlocks.has("mediaCarousels"));
  const visibleOrder=expandedOrder.filter(key=>!isHiddenCoverKey(key));
  const ordered=visibleOrder.map(key=>coverLayoutItem(key,blocks[key]||'')).join('');
  const hiddenList=renderCoverHiddenList(hiddenCoverBlocks,expandedOrder,blocks);
  const premiumHero=premiumCoverHero(s,c,b,l);
  return `${lockedBanner()}${renderCoverLayoutToolbar()}${premiumHero}<div class="cover-layout-grid${state.coverLayoutEdit?" is-editing":""}">${ordered}</div>${hiddenList}`;
}

binders.cover = () => {
  startCountdown();
  $$('[data-refresh-weather]').forEach(b=>b.addEventListener('click',refreshWeather));
  $$('[data-test-price-worker]').forEach(b=>b.addEventListener('click',testPriceWorker));
  $$('[data-add-flight]').forEach(b=>b.addEventListener('click',()=>editFlight()));
  $$('[data-edit-flight]').forEach(b=>b.addEventListener('click',()=>editFlight(num(b.dataset.editFlight))));
  $$('[data-open-boarding-pass]').forEach(b=>b.addEventListener('click',()=>{const[indexRaw,person]=String(b.dataset.openBoardingPass||'').split(':');openBoardingPassQuick(num(indexRaw),person);}));
  $$('[data-flightops-refresh]').forEach(b=>b.addEventListener('click',refreshFlightOpsNow));
  $$('[data-edit-bus]').forEach(b=>b.addEventListener('click',()=>editBus(num(b.dataset.editBus))));
  $$('[data-delete-flight]').forEach(b=>b.addEventListener('click',async()=>{ if(confirmAction("¿Eliminar este vuelo?")){state.data.cover.flights.splice(num(b.dataset.deleteFlight),1);await saveSection("cover");render();}}));
  $$('[data-edit-lodging]').forEach(b=>b.addEventListener('click',editLodging));
  $$('[data-add-document]').forEach(b=>b.addEventListener('click',()=>editDocument()));
  $$('[data-edit-doc]').forEach(b=>b.addEventListener('click',()=>editDocument(num(b.dataset.editDoc))));
  $$('[data-move-doc]').forEach(b=>b.addEventListener('click',async()=>{const[index,delta]=b.dataset.moveDoc.split(':').map(num);const target=index+delta;if(target<0||target>=state.data.cover.documents.length)return;const[doc]=state.data.cover.documents.splice(index,1);state.data.cover.documents.splice(target,0,doc);await saveSection("cover");render();}));
  $$('[data-manage-cover-files]').forEach(b=>b.addEventListener('click',()=>{const i=num(b.dataset.manageCoverFiles),doc=state.data.cover.documents[i];openFilesManager(doc.files||[],async(files,meta={})=>{doc.files=normalizeFileList(files);const saved=await saveSection('cover');if(saved===false)return false;if(!meta.keepOpen)render();return true;},`Archivos · ${doc.title}`,{autoSave:true,storeDriveLinks:true,archivePersistence:true,storageFolder:`cover-documents/${doc.id||'documento'}`});}));
  $$('[data-manage-bus-document-files]').forEach(b=>b.addEventListener('click',()=>manageBusLinkedDocumentFiles(num(b.dataset.manageBusDocumentFiles))));
  $$('[data-delete-doc]').forEach(b=>b.addEventListener('click',async()=>{if(confirmAction("¿Eliminar este documento?")){state.data.cover.documents.splice(num(b.dataset.deleteDoc),1);await saveSection("cover");render();}}));
  $$('[data-cover-carousel-step]').forEach(b=>b.addEventListener('click',()=>{const[id,deltaRaw]=b.dataset.coverCarouselStep.split(':');const carousel=findCoverMediaCarousel(id),count=carousel?.files?.length||0;if(count<2)return;const current=num(state.coverCarouselSlides[id]||0),delta=num(deltaRaw);state.coverCarouselSlides[id]=(current+delta+count)%count;render();}));
  $$('[data-cover-carousel-go]').forEach(b=>b.addEventListener('click',()=>{const[id,indexRaw]=b.dataset.coverCarouselGo.split(':');state.coverCarouselSlides[id]=num(indexRaw);render();}));
  $$('[data-cover-carousel-edit]').forEach(b=>b.addEventListener('click',()=>openCoverCarouselEditor(num(b.dataset.coverCarouselEdit))));
  $$('[data-cover-carousel-manage]').forEach(b=>b.addEventListener('click',()=>manageCoverCarouselFiles(num(b.dataset.coverCarouselManage))));
  $$('[data-lodging-carousel-details]').forEach(node=>node.addEventListener('toggle',()=>{const id=String(node.dataset.lodgingCarouselDetails||'');if(!id)return;state.coverCarouselOpen[id]=node.open;if(node.open){$$('[data-lodging-carousel-details]').forEach(other=>{if(other===node||!other.open)return;const otherId=String(other.dataset.lodgingCarouselDetails||'');other.open=false;if(otherId)state.coverCarouselOpen[otherId]=false;});}}));
  $$('[data-repair-cover-carousel-image]').forEach(b=>b.addEventListener('click',async()=>{const carousel=findCoverMediaCarousel(b.dataset.coverCarouselId),file=(carousel?.files||[]).find(item=>String(item.id)===String(b.dataset.coverCarouselFileId)),img=b.closest('.cover-media-image-frame')?.querySelector('img');try{b.disabled=true;if(!file||!img)throw new Error('No se ha encontrado la imagen.');await hydrateCoverCarouselImage(img,true);const copied=await stabilizeCoverCarouselDriveFile(b.dataset.coverCarouselId,b.dataset.coverCarouselFileId).catch(()=>false);toast(copied?'Documento recuperado y guardado como copia estable en la app.':'Imagen cargada desde Google Drive.');}catch(error){toast(error.message,'error');b.disabled=false;}}));
  $$('[data-repair-cover-carousel-account]').forEach(b=>b.addEventListener('click',()=>{const carousel=findCoverMediaCarousel(b.dataset.coverCarouselId),file=(carousel?.files||[]).find(item=>String(item.id)===String(b.dataset.coverCarouselFileId)),img=b.closest('.cover-media-image-frame')?.querySelector('img');if(!file||!img){toast('No se ha encontrado el archivo.','error');return;}let request;try{request=requestDriveBrowserAccountTokenFromClick();}catch(error){toast(error.message,'error');return;}b.disabled=true;request.then(async token=>{await updateDriveBrowserAccountIdentity(token);await hydrateCoverCarouselImage(img,true);const copied=await stabilizeCoverCarouselDriveFile(b.dataset.coverCarouselId,b.dataset.coverCarouselFileId).catch(()=>false);toast(copied?'Cuenta cambiada. Documento recuperado y guardado como copia estable.':'Cuenta cambiada. Documento recuperado desde Drive.');}).catch(error=>{toast(`No se pudo recuperar el documento: ${error.message}`,'error');}).finally(()=>{b.disabled=false;});}));
  $$('[data-cover-carousel]').forEach(node=>{let startX=0,startY=0;node.addEventListener('touchstart',event=>{const touch=event.changedTouches?.[0];if(touch){startX=touch.clientX;startY=touch.clientY;}},{passive:true});node.addEventListener('touchend',event=>{const touch=event.changedTouches?.[0];if(!touch)return;const dx=touch.clientX-startX,dy=touch.clientY-startY;if(Math.abs(dx)<45||Math.abs(dx)<Math.abs(dy))return;const id=node.dataset.coverCarousel,carousel=findCoverMediaCarousel(id),count=carousel?.files?.length||0;if(count<2)return;const current=num(state.coverCarouselSlides[id]||0);state.coverCarouselSlides[id]=(current+(dx<0?1:-1)+count)%count;render();},{passive:true});});
  $$('[data-cover-block-edit]').forEach(b=>b.addEventListener('click',()=>{const action=b.dataset.coverBlockEdit;if(action==="countdown")editCoverCountdown();else if(action==="weather")editCoverWeather();else if(action==="map")editCoverMap();}));
  $$('[data-cover-block-open]').forEach(b=>b.addEventListener('click',()=>navigateToTab(b.dataset.coverBlockOpen)));
  $$('[data-cover-tracker-open]').forEach(b=>{const open=()=>{const id=String(b.dataset.coverTrackerOpen||'');navigateToTab('trackers');setTimeout(()=>{const card=$(`[data-tracker-card="${id}"]`);if(card)card.scrollIntoView({behavior:'smooth',block:'start'});},80);};b.addEventListener('click',open);b.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();open();}});});
  $$('[data-tracker-summary-refresh]').forEach(button=>button.addEventListener('click',async event=>{event.preventDefault();event.stopPropagation();if(button.disabled)return;const id=String(button.dataset.trackerSummaryRefresh||'');const actions={autoreisen:runAutoreisenNow,cordial:runCordialNow,vueling:runVuelingNow};const action=actions[id];if(!action)return;const original=button.innerHTML;button.disabled=true;button.setAttribute('aria-busy','true');button.classList.add('is-running');try{await action();}catch(error){toast(error.message||String(error),'error');}finally{if(button.isConnected){button.disabled=false;button.removeAttribute('aria-busy');button.classList.remove('is-running');button.innerHTML=original;}}}));
  $$('[data-cover-hide]').forEach(b=>b.addEventListener('click',async()=>{const id=String(b.dataset.coverHide||'');if(!id)return;const hidden=new Set(state.data.settings.coverHiddenBlocks||[]);hidden.add(id);state.data.settings.coverHiddenBlocks=[...hidden];await saveSection('settings');const[,label]=coverVisibilityMeta(id);render();toast(`${label}: oculto en Portada.`);}));
  $$('[data-cover-show]').forEach(b=>b.addEventListener('click',async()=>{const id=String(b.dataset.coverShow||'');if(!id)return;const hidden=new Set(state.data.settings.coverHiddenBlocks||[]);hidden.delete(id);state.data.settings.coverHiddenBlocks=[...hidden];await saveSection('settings');const[,label]=coverVisibilityMeta(id);render();toast(`${label}: visible de nuevo en su posición original.`);}));
  $$('[data-edit-external-image]').forEach(b=>b.addEventListener('click',()=>editExternalImage(num(b.dataset.editExternalImage))));
  $$('[data-delete-external-image]').forEach(b=>b.addEventListener('click',async()=>{if(!confirmAction('¿Eliminar esta imagen enlazada?'))return;state.data.cover.externalImages.splice(num(b.dataset.deleteExternalImage),1);await saveSection("cover");render();}));
  $('[data-cover-layout-toggle]')?.addEventListener('click',()=>{state.coverLayoutEdit=!state.coverLayoutEdit;render();});
  $('[data-cover-layout-reset]')?.addEventListener('click',async()=>{resetDesktopCoverLayout();await saveSection('settings');render();toast('Distribución de escritorio restaurada.');});
  $$('[data-cover-layout-width]').forEach(b=>b.addEventListener('click',async event=>{event.stopPropagation();const id=b.dataset.coverLayoutTarget,width=b.dataset.coverLayoutWidth;if(!id)return;state.data.settings.desktopCoverWidths=state.data.settings.desktopCoverWidths||{};state.data.settings.desktopCoverWidths[id]=width==='half'?'half':'full';state.data.settings.desktopCoverOrder=desktopCoverOrder();await saveSection('settings');render();}));
  let draggedId='';
  $$('[data-cover-layout-id][draggable="true"]').forEach(item=>{
    item.addEventListener('dragstart',event=>{draggedId=item.dataset.coverLayoutId||'';item.classList.add('is-dragging');event.dataTransfer?.setData('text/plain',draggedId);if(event.dataTransfer)event.dataTransfer.effectAllowed='move';});
    item.addEventListener('dragend',()=>{item.classList.remove('is-dragging');$$('[data-cover-layout-id]').forEach(x=>x.classList.remove('drag-over'));draggedId='';});
    item.addEventListener('dragover',event=>{if(!draggedId||draggedId===item.dataset.coverLayoutId)return;event.preventDefault();item.classList.add('drag-over');if(event.dataTransfer)event.dataTransfer.dropEffect='move';});
    item.addEventListener('dragleave',()=>item.classList.remove('drag-over'));
    item.addEventListener('drop',async event=>{event.preventDefault();item.classList.remove('drag-over');const source=draggedId||event.dataTransfer?.getData('text/plain'),target=item.dataset.coverLayoutId;if(!source||!target||source===target)return;const order=desktopCoverOrder(),from=order.indexOf(source),to=order.indexOf(target);if(from<0||to<0)return;order.splice(to,0,...order.splice(from,1));state.data.settings.desktopCoverOrder=order;await saveSection('settings');render();});
  });
};

function editFlight(index = null) {
  const seed=index===null?{type:"IDA",color:"#f6c946",from:"Bilbao (BIO)",number:"VY3272"}:state.data.cover.flights[index];
  const defaults=defaultFlightServiceButtons(seed);
  const current={...defaults,textColor:"#ffffff",...seed};
  openForm({title:index===null?"Añadir vuelo":"Editar vuelo",fields:[
    {name:"type",label:"Tipo",type:"select",options:["IDA","VUELTA","ESCALA","OTRO"]},{name:"airline",label:"Aerolínea"},{name:"from",label:"Origen"},{name:"to",label:"Destino"},
    {name:"date",label:"Fecha",type:"date"},{name:"number",label:"Número de vuelo"},{name:"departure",label:"Salida",type:"datetime-local"},{name:"arrival",label:"Llegada",type:"datetime-local"},
    {name:"durationOverride",label:"Duración manual",help:"Déjalo vacío para calcularla por resta."},{name:"color",label:"Color",type:"color"},{name:"gradient1",label:"Degradado inicio",type:"color"},{name:"gradient2",label:"Degradado fin",type:"color"},{name:"textColor",label:"Color del texto del título",type:"color"},
    {name:"logoUrl",label:"URL del logo de la aerolínea",type:"url",full:true},{name:"logoFile",label:"Subir logo 128×128",type:"file",accept:"image/png,image/jpeg,image/webp,image/svg+xml",full:true,help:"Se redimensiona automáticamente y se guarda con el viaje."},
    {name:"departureMapsUrl",label:"Google Maps aeropuerto de salida",type:"url",full:true},
    {name:"vuelingButtonLabel",label:"Botón Vueling · etiqueta"},{name:"vuelingButtonUrl",label:"Botón Vueling · URL",type:"url",full:true},{name:"vuelingButtonColor",label:"Botón Vueling · color",type:"color"},{name:"vuelingButtonIcon",label:"Vueling · emoji/icono alternativo (común ida/vuelta)"},{name:"vuelingButtonIconUrl",label:"Vueling · URL del logo/icono (común ida/vuelta)",type:"url",full:true},{name:"vuelingButtonIconFile",label:"Vueling · subir PNG/SVG/WebP/JPG (común ida/vuelta)",type:"file",accept:"image/png,image/jpeg,image/webp,image/svg+xml",full:true,help:"Al cambiar el icono o logo de Vueling se aplica automáticamente a todos los vuelos. La etiqueta, URL y color siguen siendo independientes por vuelo."},
    {name:"vuelingCheckinLabel",label:"Vueling · etiqueta Check-in"},{name:"vuelingCheckinUrl",label:"Vueling · enlace profundo de Check-in",type:"url",full:true,help:"En móvil/tablet usa este enlace para intentar abrir la app. En PC la app fuerza la web oficial de Check-in en español."},{name:"vuelingTripsLabel",label:"Vueling · etiqueta Mis viajes"},{name:"vuelingTripsUrl",label:"Vueling · enlace Mis viajes",type:"url",full:true,help:"En móvil/tablet usa este enlace universal. En PC abre directamente Gestiona tu reserva en español."},
    {name:"aenaButtonLabel",label:"Botón AENA · etiqueta"},{name:"aenaButtonUrl",label:"Botón AENA · URL",type:"url",full:true},{name:"aenaButtonColor",label:"Botón AENA · color",type:"color"},{name:"aenaButtonIcon",label:"AENA · emoji/icono alternativo (común ida/vuelta)"},{name:"aenaButtonIconUrl",label:"AENA · URL del logo/icono (común ida/vuelta)",type:"url",full:true},{name:"aenaButtonIconFile",label:"AENA · subir PNG/SVG/WebP/JPG (común ida/vuelta)",type:"file",accept:"image/png,image/jpeg,image/webp,image/svg+xml",full:true,help:"Al cambiar el icono o logo de AENA se aplica automáticamente a todos los vuelos. La etiqueta, URL y color siguen siendo independientes por vuelo."},
    {name:"flightAwareButtonLabel",label:"Botón FlightAware · etiqueta"},{name:"flightAwareButtonUrl",label:"Botón FlightAware · URL",type:"url",full:true},{name:"flightAwareButtonColor",label:"Botón FlightAware · color",type:"color"},{name:"flightAwareButtonIcon",label:"FlightAware · emoji/icono alternativo (común ida/vuelta)"},{name:"flightAwareButtonIconUrl",label:"FlightAware · URL del logo/icono (común ida/vuelta)",type:"url",full:true},{name:"flightAwareButtonIconFile",label:"FlightAware · subir PNG/SVG/WebP/JPG (común ida/vuelta)",type:"file",accept:"image/png,image/jpeg,image/webp,image/svg+xml",full:true,help:"Al cambiar el icono o logo de FlightAware se aplica automáticamente a todos los vuelos. La etiqueta, URL y color siguen siendo independientes por vuelo."},
    {name:"checkInReminderHours",label:"Aviso check-in (horas antes)",type:"number",step:"1"},{name:"leaveAirportReminder",label:"Aviso para salir al aeropuerto",type:"datetime-local"}
  ],values:current,onSubmit:async v=>{
    if(v.logoFile)v.logoUrl=await fileToSquareDataUrl(v.logoFile);delete v.logoFile;
    const sharedIconChanges={};
    for(const prefix of ["vuelingButton","aenaButton","flightAwareButton"]){
      const file=v[`${prefix}IconFile`];
      const previousIcon=String(current[`${prefix}Icon`]||"");
      const previousUrl=String(current[`${prefix}IconUrl`]||"");
      if(file)v[`${prefix}IconUrl`]=await fileToSquareDataUrl(file,128);
      delete v[`${prefix}IconFile`];
      const nextIcon=String(v[`${prefix}Icon`]||"");
      const nextUrl=String(v[`${prefix}IconUrl`]||"");
      if(file||nextIcon!==previousIcon||nextUrl!==previousUrl)sharedIconChanges[prefix]={icon:nextIcon,iconUrl:nextUrl};
    }
    const departureMs=v.departure?new Date(v.departure).getTime():0;
    const value={id:current.id||uid("flight"),...current,...v,checkInNotifyAt:departureMs?departureMs-(num(v.checkInReminderHours)||25)*3600000:0,leaveNotifyAt:v.leaveAirportReminder?new Date(v.leaveAirportReminder).getTime():0};
    delete value.status;delete value.terminal;delete value.gate;delete value.checkInCounters;delete value.source;delete value.lastUpdated;delete value.flightAwareUrl;delete value.arrivalMapsUrl;
    if(index===null)state.data.cover.flights.push(value);else state.data.cover.flights[index]=value;
    // La identidad visual del servicio (icono/logo) es común para ida y vuelta.
    // De este modo, cambiar Vueling/AENA/FlightAware en cualquiera de los vuelos
    // actualiza también el otro, evitando que la vuelta conserve el icono antiguo.
    for(const [prefix,visual] of Object.entries(sharedIconChanges)){
      for(const flight of state.data.cover.flights){flight[`${prefix}Icon`]=visual.icon;flight[`${prefix}IconUrl`]=visual.iconUrl;}
    }
    const saved=await saveSection("cover");
    if(saved===false)throw new Error("No se han podido guardar los cambios del vuelo en Firebase.");
    ensureFlightOpsAutomation({runWorkflow:false,silent:true}).catch(()=>{});
    render();
  }});
  addModalResetButton("↺ Restaurar botones de vuelo",()=>{
    const form=$("#modal-form",els.modal);const liveDefaults=defaultFlightServiceButtons({from:form?.elements?.from?.value||current.from,number:form?.elements?.number?.value||current.number});
    for(const [name,value] of Object.entries(liveDefaults))setModalFormValue(name,value);
    for(const name of ["vuelingButtonIconFile","aenaButtonIconFile","flightAwareButtonIconFile"])setModalFormValue(name,"");
  });
}

function editBus(index=null) {
  const defaults={type:'IDA',visible:true,company:'Avanza Gipuzkoa',serviceNumber:'',from:'',to:'',date:'',departure:'',arrival:'',durationOverride:'',passengers:Math.max(1,num(state.data.settings.people)||2),pricePerPerson:0,status:'unpaid',reference:'',notes:'',budgetTitle:'',budgetDetail:'',purchaseButtonLabel:'Comprar billetes',purchaseUrl:'https://online.pesa.net/',purchaseButtonColor:'#f2d600',purchaseButtonIcon:'🎫',purchaseButtonIconUrl:'',departureMapsUrl:'',arrivalMapsUrl:'',icon:'🚌',iconUrl:'',logoUrl:'',color:'#49b6d6',gradient1:'#173f53',gradient2:'#2d7895',textColor:'#ffffff',files:[],documentFiles:[]};
  const current=index===null?defaults:{...defaults,...state.data.cover.buses[index]};
  openForm({title:index===null?'Añadir autobús':'Editar autobús',fields:[
    {name:'type',label:'Trayecto',type:'select',options:[{value:'IDA',label:'Ida al aeropuerto'},{value:'VUELTA',label:'Vuelta desde el aeropuerto'},{value:'OTRO',label:'Otro'}]},
    {name:'visible',label:'Mostrar este trayecto',type:'select',options:[{value:'true',label:'Sí · mostrar en Portada y Presupuesto'},{value:'false',label:'No · ocultar este trayecto'}]},
    {name:'company',label:'Compañía',required:true},{name:'serviceNumber',label:'Línea / servicio'},{name:'from',label:'Origen',required:true},{name:'to',label:'Destino',required:true},
    {name:'date',label:'Fecha',type:'date'},{name:'departure',label:'Salida',type:'datetime-local'},{name:'arrival',label:'Llegada',type:'datetime-local'},{name:'durationOverride',label:'Duración manual',help:'Déjalo vacío para calcularla a partir de salida y llegada.'},
    {name:'passengers',label:'Pasajeros',type:'number',step:'1',min:'1'},{name:'pricePerPerson',label:'Precio por persona',type:'number',step:'0.01',min:'0'},{name:'status',label:'Estado en Presupuesto',type:'select',options:[{value:'paid',label:'Pagado'},{value:'unpaid',label:'No pagado'}]},
    {name:'reference',label:'Localizador / referencia'},{name:'notes',label:'Notas',type:'textarea',full:true},
    {name:'budgetTitle',label:'Presupuesto · texto del concepto',full:true,help:'Opcional. Si lo dejas vacío se genera automáticamente con trayecto, origen y destino.'},
    {name:'budgetDetail',label:'Presupuesto · texto del detalle',full:true,help:'Opcional. Si lo dejas vacío se genera automáticamente con compañía, línea, fecha, hora, pasajeros y precio.'},
    {name:'purchaseButtonLabel',label:'Compra billetes · etiqueta'},{name:'purchaseUrl',label:'Compra billetes · URL',type:'url',full:true},{name:'purchaseButtonColor',label:'Compra billetes · color',type:'color'},{name:'purchaseButtonIcon',label:'Compra billetes · emoji/icono'},{name:'purchaseButtonIconUrl',label:'Compra billetes · icono URL o Google Drive',type:'url',full:true,driveImage:true,driveImageSize:128},{name:'purchaseButtonIconFile',label:'Compra billetes · subir icono',type:'file',accept:'image/png,image/jpeg,image/webp,image/svg+xml',full:true},
    {name:'departureMapsUrl',label:'Google Maps · punto de salida',type:'url',full:true},{name:'arrivalMapsUrl',label:'Google Maps · destino',type:'url',full:true},
    {name:'icon',label:'Icono del autobús'},{name:'iconUrl',label:'Icono del autobús · URL o Google Drive',type:'url',full:true,driveImage:true,driveImageSize:128,help:'La imagen se muestra antes de IDA/VUELTA en la tarjeta de Portada y también en Presupuesto.'},{name:'iconFile',label:'Subir icono 128×128',type:'file',accept:'image/png,image/jpeg,image/webp,image/svg+xml',full:true},
    {name:'logoUrl',label:'Logo de la compañía · URL o Google Drive',type:'url',full:true,driveImage:true,driveImageSize:128},{name:'logoFile',label:'Subir logo de la compañía',type:'file',accept:'image/png,image/jpeg,image/webp,image/svg+xml',full:true},
    {name:'color',label:'Color principal',type:'color'},{name:'gradient1',label:'Degradado inicio',type:'color'},{name:'gradient2',label:'Degradado fin',type:'color'},{name:'textColor',label:'Color del texto del título',type:'color'}
  ],values:{...current,visible:String(current.visible!==false)},onSubmit:async v=>{
    if(v.iconFile)v.iconUrl=await fileToSquareDataUrl(v.iconFile,128);delete v.iconFile;
    if(v.logoFile)v.logoUrl=await fileToSquareDataUrl(v.logoFile,128);delete v.logoFile;
    if(v.purchaseButtonIconFile)v.purchaseButtonIconUrl=await fileToSquareDataUrl(v.purchaseButtonIconFile,128);delete v.purchaseButtonIconFile;
    // Los iconos de autobús deben ser autosuficientes: si queda un enlace privado de Drive
    // de versiones anteriores, conviértelo a PNG embebido antes de persistir el trayecto.
    for(const key of ['iconUrl','logoUrl','purchaseButtonIconUrl']){
      if(driveFileIdFromUrl(v[key])){
        try{v[key]=await stabilizeDriveIconUrl(v[key],128);}catch(error){console.warn(`No se pudo estabilizar ${key} desde Drive`,error);throw new Error(`No se pudo guardar el icono de Google Drive: ${error.message}`);}
      }
    }
    v.visible=String(v.visible)!=='false';
    v.styleCustomized=true;
    v.passengers=Math.max(1,num(v.passengers)||1);v.pricePerPerson=Math.max(0,num(v.pricePerPerson));
    const value={id:current.id||uid('bus'),files:current.files||[],documentFiles:current.documentFiles||[],...current,...v};
    state.data.cover.buses=state.data.cover.buses||[];
    if(index===null)state.data.cover.buses.push(value);else state.data.cover.buses[index]=value;
    const budgetVisualChanged=syncBudgetBusHeaderVisual(state.data,value);
    const saved=await saveSection('cover');if(saved===false)throw new Error('No se han podido guardar los cambios del autobús en Firebase.');
    if(budgetVisualChanged){const budgetSaved=await saveSection('budget');if(budgetSaved===false)throw new Error('Se guardó el autobús, pero no se pudo sincronizar el color del título en Presupuesto.');}
    render();
  }});
  addModalResetButton('↺ Restaurar estilo de autobús',()=>{
    setModalFormValue('icon','🚌');setModalFormValue('iconUrl','');setModalFormValue('logoUrl','');setModalFormValue('color','#49b6d6');setModalFormValue('gradient1','#173f53');setModalFormValue('gradient2','#2d7895');setModalFormValue('textColor','#ffffff');setModalFormValue('purchaseButtonColor','#f2d600');setModalFormValue('purchaseButtonIcon','🎫');setModalFormValue('purchaseButtonIconUrl','');
    for(const name of ['iconFile','logoFile','purchaseButtonIconFile'])setModalFormValue(name,'');
  });
}
function manageBusFiles(index){
  const current=state.data.cover.buses?.[index];if(!current)return;
  const stableBusId=String(current.id||'');
  const findBus=()=> (state.data.cover.buses||[]).find(bus=>String(bus?.id||'')===stableBusId);
  openFilesManager(current.files||[],async(files,meta={})=>{
    const bus=findBus();
    if(!bus)throw new Error('El trayecto de autobús ya no existe.');
    bus.files=normalizeFileList(files);
    const saved=await saveSection('cover');
    if(saved===false)throw new Error('No se han podido guardar los billetes del autobús.');
    if(!meta.keepOpen)render();
    return true;
  },`Billetes y enlaces · ${current.company||'Autobús'} · Drive directo`,{
    storageFolder:'bus',
    autoSave:true,
    storeDriveLinks:true,
    mimeTypes:'application/pdf'
  });
}


function manageBusDocumentFiles(index){
  const current=state.data.cover.buses?.[index];if(!current)return;
  const stableBusId=String(current.id||'');
  const findBus=()=> (state.data.cover.buses||[]).find(bus=>String(bus?.id||'')===stableBusId);
  openFilesManager(current.documentFiles||[],async(files,meta={})=>{
    const bus=findBus();
    if(!bus)throw new Error('El trayecto de autobús ya no existe.');
    bus.documentFiles=normalizeFileList(files);
    const saved=await saveSection('cover');
    if(saved===false)throw new Error('No se han podido guardar los documentos de la ficha Autobús.');
    if(!meta.keepOpen)render();
    return true;
  },`Documentos de Portada · ${current.company||'Autobús'} · Drive directo`,{
    storageFolder:'bus-documents',
    autoSave:true,
    storeDriveLinks:true,
    mimeTypes:'application/pdf'
  });
}

function editLodging() {
  const current=state.data.cover.lodging;const crop=current.imageCrop||{x:50,y:50,zoom:1};const palette=providerPalette(current);const reviewDefaults=defaultLodgingReviewButtons();const cordialTracker=state.data.trackers.cordial||{};
  const values={...reviewDefaults,gradient1:current.gradient1||palette.g1,gradient2:current.gradient2||palette.g2,textColor:current.textColor||'#ffffff',...current,cropX:crop.x,cropY:crop.y,zoom:crop.zoom,cordialTitleIcon:cordialTracker.titleIcon||TRACKER_DEFAULT_ICONS.cordial,cordialTitleIconUrl:cordialTracker.titleIconUrl||''};
  openForm({title:"Editar alojamiento",fields:[
    {name:"name",label:"Nombre",full:true},{name:"address",label:"Dirección para navegación",full:true},{name:"checkIn",label:"Entrada",type:"date"},{name:"checkOut",label:"Salida",type:"date"},{name:"website",label:"Web",type:"url",full:true},{name:"mapsUrl",label:"Google Maps",type:"url",full:true},{name:"guestGuideUrl",label:"Fuente de temperatura de piscinas",type:"url",full:true},{name:"guestGuideLabel",label:"Etiqueta temperatura piscinas"},
    {name:"googleReviewsUrl",label:"Opiniones en Google",type:"url",full:true},{name:"googleReviewsLabel",label:"Google · etiqueta"},{name:"googleReviewsColor",label:"Google · color",type:"color"},{name:"googleReviewsIcon",label:"Google · emoji/icono alternativo"},{name:"googleReviewsIconUrl",label:"Google · URL del logo/icono",type:"url",full:true},{name:"googleReviewsIconFile",label:"Google · subir PNG/SVG/WebP/JPG",type:"file",accept:"image/png,image/jpeg,image/webp,image/svg+xml",full:true},
    {name:"tripadvisorReviewsUrl",label:"Opiniones en Tripadvisor",type:"url",full:true},{name:"tripadvisorReviewsLabel",label:"Tripadvisor · etiqueta"},{name:"tripadvisorReviewsColor",label:"Tripadvisor · color",type:"color"},{name:"tripadvisorReviewsIcon",label:"Tripadvisor · emoji/icono alternativo"},{name:"tripadvisorReviewsIconUrl",label:"Tripadvisor · URL del logo/icono",type:"url",full:true},{name:"tripadvisorReviewsIconFile",label:"Tripadvisor · subir PNG/SVG/WebP/JPG",type:"file",accept:"image/png,image/jpeg,image/webp,image/svg+xml",full:true},
    {name:"bookingReviewsUrl",label:"Opiniones en Booking",type:"url",full:true},{name:"bookingReviewsLabel",label:"Booking · etiqueta"},{name:"bookingReviewsColor",label:"Booking · color",type:"color"},{name:"bookingReviewsIcon",label:"Booking · emoji/icono alternativo"},{name:"bookingReviewsIconUrl",label:"Booking · URL del logo/icono",type:"url",full:true},{name:"bookingReviewsIconFile",label:"Booking · subir PNG/SVG/WebP/JPG",type:"file",accept:"image/png,image/jpeg,image/webp,image/svg+xml",full:true},
    {name:"cordialTitleIcon",label:"Seguimiento Cordial/Alojamiento · emoji alternativo"},{name:"cordialTitleIconUrl",label:"Seguimiento Cordial/Alojamiento · icono PNG / Google Drive",type:"url",full:true,driveImage:true,driveImageSize:128,help:"Cambia el icono de la pastilla superior y de la cabecera del seguimiento Cordial."},{name:"cordialTitleIconFile",label:"Seguimiento Cordial/Alojamiento · subir icono local",type:"file",accept:"image/png,image/jpeg,image/webp,image/svg+xml",full:true},
    {name:"imageUrl",label:"Imagen: URL web o Drive",type:"url",full:true,driveImage:true},{name:"gradient1",label:"Degradado inicio",type:"color"},{name:"gradient2",label:"Degradado fin",type:"color"},{name:"textColor",label:"Color del texto del título",type:"color"},{name:"cropX",label:"Encuadre horizontal (0-100)",type:"number",min:"0"},{name:"cropY",label:"Encuadre vertical (0-100)",type:"number",min:"0"},{name:"zoom",label:"Zoom (1-3)",type:"number",step:"0.1",min:"1"}
  ],values,onSubmit:async v=>{
    for(const prefix of ["googleReviews","tripadvisorReviews","bookingReviews"]){const file=v[`${prefix}IconFile`];if(file)v[`${prefix}IconUrl`]=await fileToSquareDataUrl(file,128);delete v[`${prefix}IconFile`];}
    await applyTrackerIconEditorValues(cordialTracker,{titleIcon:v.cordialTitleIcon,titleIconUrl:v.cordialTitleIconUrl,titleIconFile:v.cordialTitleIconFile},TRACKER_DEFAULT_ICONS.cordial||'🏨');
    delete v.cordialTitleIcon;delete v.cordialTitleIconUrl;delete v.cordialTitleIconFile;
    const imageCrop={x:Math.min(100,Math.max(0,num(v.cropX))),y:Math.min(100,Math.max(0,num(v.cropY))),zoom:Math.min(3,Math.max(1,num(v.zoom)||1))};delete v.cropX;delete v.cropY;delete v.zoom;state.data.cover.lodging={...current,...v,imageCrop};await Promise.all([saveSection("cover"),saveSection('trackers')]);render();}});
  addModalResetButton("↺ Restaurar estilo de opiniones",()=>{
    for(const [name,value] of Object.entries(reviewDefaults))setModalFormValue(name,value);
    for(const name of ["googleReviewsIconFile","tripadvisorReviewsIconFile","bookingReviewsIconFile"])setModalFormValue(name,"");
  });
  addModalResetButton("↺ Restaurar degradado del alojamiento",()=>{
    setModalFormValue("gradient1","#29313c");setModalFormValue("gradient2","#626d7b");setModalFormValue("textColor","#ffffff");
  });
}
function editDocument(index = null) {
  const current=index===null?{icon:"📎",color:"#4da3ff",gradient1:"#202936",gradient2:"#343f50",textColor:"#ffffff",linkType:"auto",buttonLabel:"",files:[]}:state.data.cover.documents[index];
  openForm({title:index===null?"Añadir ficha":"Editar ficha",fields:[
    {name:"title",label:"Título",required:true},
    {name:"icon",label:"Emoji alternativo"},
    {name:"iconUrl",label:"Icono · URL o Google Drive",type:"url",full:true,driveImage:true},
    {name:"iconFile",label:"Subir icono 128×128",type:"file",accept:"image/*",full:true},
    {name:"subtitle",label:"Descripción",full:true},
    {name:"linkType",label:"Tipo de enlace",type:"select",options:[
      {value:"auto",label:"Detectar automáticamente"},
      {value:"file",label:"Archivo, PDF o Google Drive"},
      {value:"web",label:"Página web"},
      {value:"image",label:"Imagen"}
    ]},
    {name:"url",label:"Enlace a archivo, Drive, imagen o página web",type:"url",full:true,driveSelect:true,driveTypeTarget:"linkType"},
    {name:"keepLinkOnArchive",label:"📌 Conservar este enlace al archivar",type:"checkbox",full:true,help:"Úsalo para webs permanentes como Vueling, AutoReisen o Cordial. El enlace seguirá en la ficha del siguiente viaje."},
    {name:"buttonLabel",label:"Texto del botón",help:"Opcional: por ejemplo «Abrir reserva» o «Visitar web»",full:true},
    {name:"imageUrl",label:"Imagen adicional de la ficha",type:"url",full:true,driveImage:true},
    {name:"color",label:"Color",type:"color"},{name:"gradient1",label:"Degradado inicio",type:"color"},{name:"gradient2",label:"Degradado fin",type:"color"},{name:"textColor",label:"Color del texto del título",type:"color"}
  ],values:{textColor:"#ffffff",linkType:"auto",buttonLabel:"",...current},onSubmit:async v=>{
    if(v.iconFile)v.iconUrl=await fileToSquareDataUrl(v.iconFile);
    delete v.iconFile;
    const value={id:current.id||uid("doc"),...current,...v};
    if(index===null)state.data.cover.documents.push(value);else state.data.cover.documents[index]=value;
    await saveSection("cover");render();
  }});
}
function uploadCoverDocument(index) {
  const input=document.createElement("input"); input.type="file"; input.accept="application/pdf,image/*";
  input.addEventListener("change",async()=>{const file=input.files?.[0];if(!file)return;try{toast("Subiendo archivo…");const result=await state.provider.uploadFile(file,"documents");state.data.cover.documents[index].url=result.url;state.data.cover.documents[index].linkType="file";state.data.cover.documents[index].storagePath=result.path;await saveSection("cover");render();toast("Documento guardado.");}catch(error){toast(error.message,"error");}});
  input.click();
}

async function refreshWeather() {
  try { toast("Actualizando tiempo…"); state.weather=await loadOpenMeteoWeather(); render(); toast("Previsión actualizada."); }
  catch(error){toast(`No se ha podido cargar el tiempo: ${error.message}`,"error");}
}

function trackerBudgetPreviewImage(kind) {
  if(kind==='autoreisen'){
    const tracker=state.data.trackers?.autoreisen||{};
    const url=isImageSource(tracker.manualImageUrl)?String(tracker.manualImageUrl):isImageSource(tracker.imageUrl)?String(tracker.imageUrl):'';
    return url?{url,title:tracker.model||'Vehículo AutoReisen'}:null;
  }
  if(kind==='cordial'){
    const tracker=state.data.trackers?.cordial||{};
    const targetRoom=tracker.targetRoom||'Classic Duplex';
    const meta=cordialRoomMeta(tracker,targetRoom)||{};
    const workerImage=isImageSource(meta.imageUrl)?String(meta.imageUrl):'';
    if(workerImage)return {url:workerImage,title:targetRoom};
    const lodging=state.data.cover?.lodging||{};
    const fallback=isImageSource(lodging.imageUrl)?String(lodging.imageUrl):'';
    return fallback?{url:fallback,title:lodging.name||'Alojamiento'}:null;
  }
  return null;
}
function budgetPreviewAsset(group,item) {
  const text=`${group?.id||''} ${group?.name||''} ${item?.name||''} ${item?.detail||''}`.toLocaleLowerCase('es');
  if(/autoreisen|alquiler\s*coche|rva\d+/i.test(text)){
    const preview=trackerBudgetPreviewImage('autoreisen');
    return preview?{...preview,kind:'autoreisen'}:null;
  }
  if(/cordial|santa\s*águeda|santa\s*agueda|rol\d+/i.test(text)){
    const preview=trackerBudgetPreviewImage('cordial');
    return preview?{...preview,kind:'cordial'}:null;
  }
  return null;
}

function budgetAirportCode(value=''){
  const source=String(value||'').toUpperCase();
  return source.match(/\(([A-Z]{3})\)/)?.[1]||source.match(/\b([A-Z]{3})\b/)?.[1]||'';
}
function budgetFlightForItem(item){
  const flights=state.data.cover.flights||[];
  if(!flights.length||!item)return null;
  const itemKey=String(item.name||'').toUpperCase().replace(/[^A-Z0-9]+/g,'-').replace(/^-|-$/g,'');
  const byRoute=flights.find(f=>{
    const from=budgetAirportCode(f.from),to=budgetAirportCode(f.to);
    return from&&to&&(itemKey===`${from}-${to}`||itemKey.includes(`${from}-${to}`));
  });
  if(byRoute)return byRoute;
  const number=String(item.detail||'').toUpperCase().match(/VY\s*\d{3,5}/)?.[0]?.replace(/\s+/g,'');
  if(number)return flights.find(f=>String(f.number||'').toUpperCase().replace(/\s+/g,'')===number)||null;
  return null;
}

function poolPanelConfig(){
  const defaults=SEED_DATA.settings.poolPanel||{};
  const cfg=state.data?.settings?.poolPanel||{};
  const merged={...defaults,...cfg,webcams:{...(defaults.webcams||{}),...(cfg.webcams||{})},poolStyles:{...(defaults.poolStyles||{}),...(cfg.poolStyles||{})}};
  // v2.3.43 · Se retira la webcam El Perchel: eliminar también configuraciones antiguas ya guardadas en Firebase/local.
  merged.webcams=Object.fromEntries(Object.entries(merged.webcams||{}).filter(([id])=>id==='santa-agueda'));
  merged.sectionOrder=(Array.isArray(merged.sectionOrder)?merged.sectionOrder:['webcams','pools','temperatureChart','source']).filter(id=>id!=='spa');
  merged.hiddenSections=(Array.isArray(merged.hiddenSections)?merged.hiddenSections:[]).filter(id=>id!=='spa');
  return merged;
}
function poolConfigKey(name=''){return String(name||'Piscina').trim().toLocaleLowerCase('es').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'')||'piscina';}
function orderedPoolList(pools=[]){const cfg=poolPanelConfig(),order=cfg.poolOrder||[];return [...pools].sort((a,b)=>{const ai=order.indexOf(poolConfigKey(a?.name)),bi=order.indexOf(poolConfigKey(b?.name));return (ai<0?999:ai)-(bi<0?999:bi);});}
function poolStyleFor(pool={}){const cfg=poolPanelConfig(),specific=cfg.poolStyles?.[poolConfigKey(pool.name)]||{};return {background:specific.background||cfg.cardBackground||'#171a20',border:specific.border||cfg.cardBorder||'#343b49',temperatureBackground:specific.temperatureBackground||cfg.temperatureBackground||'#10263a',temperatureText:specific.temperatureText||cfg.temperatureText||'#ffffff',metricBackground:specific.metricBackground||cfg.metricBackground||'#20242d'};}
function poolSectionVisible(id){return !(poolPanelConfig().hiddenSections||[]).includes(id);}
function poolPayloadTimestamp(payload={},fallback=''){
  const candidates=[payload?.clientFetchedAt,payload?.checkedAt,payload?.receivedAt,payload?.fetchedAt,payload?.updatedAt,fallback]
    .map(value=>value?new Date(value):null)
    .filter(date=>date&&Number.isFinite(date.getTime()));
  if(!candidates.length)return null;
  return candidates.reduce((latest,date)=>date.getTime()>latest.getTime()?date:latest,candidates[0]);
}
function poolMeasurementTimestamp(measurement={},fallback=''){
  const raw=[measurement.date,measurement.time].filter(Boolean).join('T');
  const parsed=raw?new Date(raw):null;
  if(parsed&&Number.isFinite(parsed.getTime()))return parsed;
  const fallbackDate=fallback?new Date(fallback):null;
  return fallbackDate&&Number.isFinite(fallbackDate.getTime())?fallbackDate:null;
}
function poolMeasurementTemperatureForChart(measurement={}){
  const direct=measurement?.temperature;
  if(direct!==null&&direct!==undefined&&direct!==''){
    const n=num(String(direct).replace(',','.'));if(Number.isFinite(n)&&n>-5&&n<60)return n;
  }
  for(const metric of measurement?.metrics||[]){
    if(!/temperatura|temperature|temp\.?\b/i.test(String(metric?.label||'')))continue;
    const hit=String(metric?.value??'').replace(',','.').match(/-?\d+(?:\.\d+)?/),n=hit?Number(hit[0]):NaN;
    if(Number.isFinite(n)&&n>-5&&n<60)return n;
  }
  return null;
}
function poolTemperatureSeries(poolName,payload=state.poolMeasurements){
  const key=String(poolName||'').trim().toLocaleLowerCase('es'),points=[];
  const add=(time,temp,label='')=>{const n=num(temp);if(!Number.isFinite(n)||n<-5||n>60)return;const date=time instanceof Date?time:new Date(time);if(!Number.isFinite(date.getTime()))return;points.push({time:date,temp:n,label});};
  for(const snap of payload?.history||[]){
    const pool=(snap.pools||[]).find(p=>String(p.name||'').trim().toLocaleLowerCase('es')===key);if(!pool)continue;
    const latest=poolLatestMeasurement(pool),temp=poolTemperatureValue(pool,latest);
    if(temp!==null&&temp!==undefined){const snapTime=poolPayloadTimestamp(snap);if(snapTime)add(snapTime,temp,'Histórico');}
  }
  const current=(payload?.pools||[]).find(p=>String(p.name||'').trim().toLocaleLowerCase('es')===key);
  for(const m of poolNormalizedMeasurements(current||{})){
    const temp=poolMeasurementTemperatureForChart(m);if(temp===null||temp===undefined)continue;
    const ts=poolMeasurementTimestamp(m,poolPayloadTimestamp(payload)?.toISOString()||'');if(ts)add(ts,temp,m.measurement||'Medición');
  }
  // La ficha actual y el gráfico deben compartir siempre el mismo dato. Aunque el histórico del Worker
  // todavía no haya guardado la lectura, inyectamos el valor que la app acaba de consultar como último punto.
  if(current){
    const temp=poolTemperatureValue(current,poolLatestMeasurement(current));
    const currentTime=poolPayloadTimestamp(payload,payload?.clientFetchedAt||new Date().toISOString());
    if(temp!==null&&temp!==undefined&&currentTime)add(currentTime,temp,'Actual');
  }
  const dedup=new Map();for(const point of points.sort((a,b)=>a.time-b.time)){const k=`${point.time.getTime()}|${point.temp}`;dedup.set(k,point);}return [...dedup.values()].slice(-80);
}
function renderPoolTemperatureChart(payload=state.poolMeasurements){
  const pools=payload?.pools||[];if(!pools.length)return '<div class="pool-chart-empty">Todavía no hay mediciones para dibujar el gráfico.</div>';
  const series=pools.map((pool,index)=>({name:pool.name,index,points:poolTemperatureSeries(pool.name,payload)})).filter(s=>s.points.length);
  const all=series.flatMap(s=>s.points);if(all.length<2)return '<div class="pool-chart-empty">El histórico de temperatura se irá formando automáticamente con las siguientes mediciones.</div>';
  const temps=all.map(p=>p.temp),min=Math.floor(Math.min(...temps)-1),max=Math.ceil(Math.max(...temps)+1),span=Math.max(1,max-min);
  const times=all.map(p=>p.time.getTime()),tMin=Math.min(...times),tMax=Math.max(...times),tSpan=Math.max(1,tMax-tMin);
  const W=720,H=250,left=44,right=18,top=18,bottom=38,plotW=W-left-right,plotH=H-top-bottom;
  const x=t=>left+((t-tMin)/tSpan)*plotW,y=v=>top+((max-v)/span)*plotH;
  const palette=['#4da3ff','#f6d51f','#4bd1a0','#ff7f66','#b58cff','#ffb455','#55d8ff'];
  const grid=[0,.25,.5,.75,1].map(f=>{const val=max-span*f,yy=top+plotH*f;return `<g><line x1="${left}" y1="${yy.toFixed(1)}" x2="${W-right}" y2="${yy.toFixed(1)}" class="pool-chart-grid"/><text x="${left-8}" y="${(yy+4).toFixed(1)}" text-anchor="end" class="pool-chart-axis">${val.toFixed(0)}°</text></g>`}).join('');
  const lines=series.map((s,i)=>{const color=palette[i%palette.length],pts=s.points.map(p=>`${x(p.time.getTime()).toFixed(1)},${y(p.temp).toFixed(1)}`).join(' ');const dots=s.points.map(p=>{const text=`${s.name} · ${p.temp.toLocaleString('es-ES',{maximumFractionDigits:1})} °C · ${p.time.toLocaleString('es-ES',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'})}`;return `<circle cx="${x(p.time.getTime()).toFixed(1)}" cy="${y(p.temp).toFixed(1)}" r="4" fill="${color}" class="tracker-chart-hover-point" tabindex="0" data-tracker-chart-tooltip="${esc(text)}"><title>${esc(text)}</title></circle>`;}).join('');return `<polyline points="${pts}" fill="none" stroke="${color}" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>${dots}`}).join('');
  const start=new Date(tMin).toLocaleString('es-ES',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}),end=new Date(tMax).toLocaleString('es-ES',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'});
  const legend=series.map((s,i)=>`<span><i style="--pool-series:${palette[i%palette.length]}"></i>${esc(s.name)}</span>`).join('');
  return `<div class="pool-chart-wrap"><svg class="pool-temp-chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="Evolución de temperatura de las piscinas">${grid}${lines}<text x="${left}" y="${H-10}" class="pool-chart-axis">${esc(start)}</text><text x="${W-right}" y="${H-10}" text-anchor="end" class="pool-chart-axis">${esc(end)}</text></svg><div class="pool-chart-legend">${legend}</div></div>`;
}
function poolMetricDisplayLabel(label=''){
  const text=String(label||'').trim();
  if(/turbidez|turbidity/i.test(text))return 'Turbidez (UNF)';
  if(/recirculaci[oó]n|recirculation/i.test(text))return 'Índice de recirculación (h)';
  return text;
}
function poolMetricClass(label=''){
  const text=String(label).toLocaleLowerCase('es');if(/temperatura|temperature|temp\.?\b/.test(text))return 'is-temperature';if(/\bph\b/.test(text))return 'is-ph';if(/cloro|chlor/.test(text))return 'is-chlorine';if(/recirculaci[oó]n|recirculation/.test(text))return 'is-recirculation';return '';
}
function poolMetricNumber(value=''){
  const hit=String(value??'').replace(',','.').match(/-?\d+(?:\.\d+)?/);return hit?Number(hit[0]):NaN;
}
function poolNormalizedMeasurements(pool={}){
  const source=(Array.isArray(pool.measurements)&&pool.measurements.length)?pool.measurements:(pool.latest?[pool.latest]:[]);
  const measurements=source.map(m=>({...m,metrics:(Array.isArray(m?.metrics)?m.metrics:[]).map(metric=>({...metric}))}));
  const latest=measurements.find(m=>/última|ultima|last/i.test(String(m?.measurement||'')))||measurements[0]||null;
  const latestTurbidity=(latest?.metrics||[]).find(metric=>/turbidez|turbidity/i.test(String(metric?.label||'')));
  const latestTurbidityValue=poolMetricNumber(latestTurbidity?.value);
  for(const measurement of measurements){
    if(/última|ultima|last/i.test(String(measurement?.measurement||'')))continue;
    const metrics=measurement.metrics||[];
    if(metrics.some(metric=>/recirculaci[oó]n|recirculation/i.test(String(metric?.label||''))))continue;
    if(metrics.length!==1)continue;
    const metric=metrics[0];
    if(!/turbidez|turbidity/i.test(String(metric?.label||'')))continue;
    const value=poolMetricNumber(metric?.value);
    if(Number.isFinite(value)&&Number.isInteger(value)&&value>=1&&value<=24&&Number.isFinite(latestTurbidityValue)&&latestTurbidityValue<1){metric.label='Índice de recirculación (h)';}
  }
  return measurements;
}
function poolLatestMeasurement(pool={}){
  const measurements=poolNormalizedMeasurements(pool);
  return measurements.find(m=>/última|ultima|last/i.test(String(m?.measurement||'')))||measurements[0]||{};
}
function poolHighlightedMetrics(pool={},latest=poolLatestMeasurement(pool)){
  const metrics=(latest?.metrics||[]).filter(m=>!(/fecha|date|hora|time/i.test(String(m?.label||'')))).map(m=>({...m}));
  const seen=new Set(metrics.map(m=>poolMetricDisplayLabel(m.label).toLocaleLowerCase('es')));
  for(const measurement of poolNormalizedMeasurements(pool)){
    for(const metric of measurement.metrics||[]){
      if(!/recirculaci[oó]n|recirculation/i.test(String(metric?.label||'')))continue;
      const key=poolMetricDisplayLabel(metric.label).toLocaleLowerCase('es');
      if(!seen.has(key)){metrics.push({...metric});seen.add(key);}
    }
  }
  return metrics.slice(0,6);
}
function poolTemperatureValue(pool={},latest=poolLatestMeasurement(pool)){
  const direct=[pool.temperature,latest?.temperature].find(v=>v!==null&&v!==undefined&&v!=='');
  if(direct!==undefined){const n=Number(String(direct).replace(',','.'));if(Number.isFinite(n)&&n>-5&&n<60)return n;}
  const metrics=Array.isArray(latest?.metrics)?latest.metrics:[];
  for(const metric of metrics){if(!/temperatura|temperature|temp\.?\b/i.test(String(metric?.label||'')))continue;const hit=String(metric?.value??'').replace(',','.').match(/-?\d+(?:\.\d+)?/);const n=hit?Number(hit[0]):NaN;if(Number.isFinite(n)&&n>-5&&n<60)return n;}
  return null;
}
function renderPoolMeasurementDetails(pool){
  const measurements=poolNormalizedMeasurements(pool);
  if(!measurements.length)return '<div class="empty">Sin controles detallados.</div>';
  return measurements.map((m,index)=>{const when=[m.date?formatDate(m.date,{day:'2-digit',month:'short'}):'',m.time||''].filter(Boolean).join(' · ');const rows=(m.metrics||[]).map(metric=>`<div class="pool-metric-row ${poolMetricClass(metric.label)}"><span>${esc(poolMetricDisplayLabel(metric.label))}</span><strong>${esc(metric.value)}</strong></div>`).join('');return `<section class="pool-measurement-set"><div class="pool-measurement-head"><strong>${esc(m.measurement||`Medición ${index+1}`)}</strong>${when?`<small>${esc(when)}</small>`:''}</div><div class="pool-metric-grid">${rows||'<span class="muted">Sin parámetros.</span>'}</div></section>`}).join('');
}
function renderPoolCard(pool){
  const latest=poolLatestMeasurement(pool),temperature=poolTemperatureValue(pool,latest),style=poolStyleFor(pool);
  const currentMetrics=poolHighlightedMetrics(pool,latest);
  const when=[latest.date?formatDate(latest.date,{day:'2-digit',month:'short'}):'',latest.time||''].filter(Boolean).join(' · ');
  return `<article class="pool-live-card" style="--pool-card-bg:${esc(style.background)};--pool-card-border:${esc(style.border)};--pool-temp-bg:${esc(style.temperatureBackground)};--pool-temp-text:${esc(style.temperatureText)};--pool-metric-bg:${esc(style.metricBackground)}"><div class="pool-live-head"><div><span class="pool-live-kicker">${esc(latest.measurement||'Última medición')}</span><h4>${esc(pool.name||'Piscina')}</h4>${when?`<small>${esc(when)}</small>`:''}</div><div class="pool-temperature ${temperature===null||temperature===undefined?'is-empty':''}"><span>${temperature===null||temperature===undefined?'—':esc(Number(temperature).toLocaleString('es-ES',{maximumFractionDigits:1}))}</span><small>°C</small></div></div><div class="pool-live-metrics">${currentMetrics.map(m=>`<div class="pool-metric-chip ${poolMetricClass(m.label)}"><small>${esc(poolMetricDisplayLabel(m.label))}</small><strong>${esc(m.value)}</strong></div>`).join('')||'<span class="muted">Sin parámetros destacados.</span>'}</div><details class="pool-details"><summary>Todos los controles y mediciones</summary><div class="pool-details-body">${renderPoolMeasurementDetails(pool)}</div></details></article>`;
}

function renderLivePools(){
  const p=state.poolMeasurements;
  if(state.poolMeasurementsLoading&&!p)return '<div class="pool-live-loading"><span class="spinner"></span><span>Leyendo las mediciones de las piscinas…</span></div>';
  if(!p)return '<div class="pool-live-loading is-idle"><span>Los datos se cargan automáticamente desde el control diario de piscinas.</span><button class="btn secondary small" type="button" data-refresh-pools>↻ Cargar ahora</button></div>';
  const fetched=poolPayloadTimestamp(p),stamp=fetched&&Number.isFinite(fetched.getTime())?fetched.toLocaleString('es-ES',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'}):'—';
  const warning=p.warning?`<div class="pool-warning">⚠ ${esc(p.warning)}</div>`:'',cfg=poolPanelConfig();
  const webcams=Object.entries(cfg.webcams||{}).filter(([,v])=>v?.enabled!==false).map(([id,v])=>`<button class="btn secondary small pool-webcam-btn" style="--webcam-btn-bg:${esc(cfg.webcamButtonColor||'#244c78')};--webcam-btn-text:${esc(cfg.webcamButtonText||'#ffffff')}" type="button" data-pool-webcam="${esc(id)}">📹 ${esc(v.label||id)}</button>`).join('');
  const d=p.diagnostics||{};const poolEmpty=p.diagnostics?`<div class="empty">Sin piscinas interpretadas.<br><small>${d.mode?`Modo ${esc(d.mode)} · `:''}selectores ${esc(d.selects??0)} · opciones ${esc((d.options??0)+(d.customOptions??0))} · intentos ${esc(d.attempted??d.tried??0)}${d.networkResponses!==undefined?` · respuestas de red ${esc(d.networkResponses)}`:''}${d.detectedPools!==undefined?` · piscinas ${esc(d.detectedPools)}`:''}</small></div>`:'<div class="empty">La fuente no ha devuelto piscinas.</div>';
  const parts={webcams:webcams?`<div class="pool-webcam-actions">${webcams}</div>`:'',pools:`<div class="pool-live-grid">${orderedPoolList(p.pools||[]).map(renderPoolCard).join('')||poolEmpty}</div>`,temperatureChart:`<section class="pool-temperature-history"><div class="pool-history-title"><div><span class="header-kicker">Temperatura</span><h4>Evolución de las piscinas</h4></div></div>${renderPoolTemperatureChart(p)}</section>`};
  const main=(cfg.sectionOrder||['webcams','pools','temperatureChart']).filter(id=>['webcams','pools','temperatureChart'].includes(id)&&poolSectionVisible(id)).map(id=>parts[id]||'').join('');
  return `${warning}<div class="pool-live-toolbar"><div><strong>Control diario de piscinas</strong><small>Fuente: Galileus · SILOE · consulta ${esc(stamp)}</small></div><button class="mini-btn" type="button" data-refresh-pools title="Actualizar mediciones">↻</button></div>${main}`;
}
async function fetchPoolMeasurementsWorker(){
  const clientFetchedAt=new Date().toISOString();
  const latest=await callIntegrationWorker({action:'pools'},{authenticated:false,timeoutMs:22000});
  const result=latest?.result||latest;
  let historyPayload=null;
  try{historyPayload=await callIntegrationWorker({action:'monitor-history',type:'pools'},{authenticated:false,timeoutMs:22000});}catch(error){console.warn('Histórico piscinas Worker:',error);}
  const history=(historyPayload?.results||[]).map((item,index)=>{
    const stamp=poolPayloadTimestamp(item);
    return {
      ...item,
      id:`worker-${index}-${String(stamp?.toISOString()||'')}`,
      fetchedAt:stamp?.toISOString()||item?.fetchedAt||item?.checkedAt||item?.receivedAt||'',
      pools:Array.isArray(item?.pools)?item.pools:[]
    };
  }).filter(item=>item.fetchedAt||item.pools.length);
  const warning=[result?.warning,latest?.lastError?.error?`La última consulta automática falló: ${latest.lastError.error}`:''].filter(Boolean).join(' · ');
  return {...result,clientFetchedAt,history,warning,diagnostics:{...(result?.diagnostics||{}),transport:'cloudflare-worker+github-playwright'}};
}
async function waitForPoolsMonitor(startedAt,{timeoutMs=110000}={}){
  const start=Number(startedAt)||Date.now();let last=null;
  while(Date.now()-start<timeoutMs){
    await new Promise(resolve=>setTimeout(resolve,3500));
    try{
      last=await callIntegrationWorker({action:'github-tracker-run-status',type:'pools',startedAfter:new Date(start).toISOString()},{timeoutMs:22000});
      const pct=Number(last?.progress?.percentage)||0;
      if(state.activeTab==='lodging'){
        state.poolMeasurements={...(state.poolMeasurements||{}),source:'Galileus · SILOE · navegador real',fetchedAt:new Date().toISOString(),pools:state.poolMeasurements?.pools||[],history:state.poolMeasurements?.history||[],warning:`Actualizando piscinas con navegador real… ${Math.max(2,pct)}%`,diagnostics:{...(state.poolMeasurements?.diagnostics||{}),monitorRunning:true,progress:pct}};
        render();
      }
      if(last?.run?.status==='completed'){
        if(last.run.conclusion!=='success')throw new Error(last?.diagnostic?.summary||'La consulta de piscinas en GitHub Actions no terminó correctamente.');
        await new Promise(resolve=>setTimeout(resolve,1200));
        return await fetchPoolMeasurementsWorker();
      }
    }catch(error){
      if(/no se encontraron|runfound|en cola/i.test(String(error?.message||'')))continue;
      throw error;
    }
  }
  throw new Error('La consulta de piscinas sigue ejecutándose. Vuelve a pulsar actualizar en unos segundos.');
}
async function runPoolsMonitorNow(){
  const startedAt=Date.now();
  const launch=await callIntegrationWorker({action:'github-pools-run'},{timeoutMs:35000});
  if(launch?.workflowTriggered!==true)throw new Error('No se pudo lanzar el monitor de piscinas.');
  toast(launch?.automationUpdated?'Monitor de piscinas preparado. Leyendo Galileus…':'Leyendo Galileus con navegador real…');
  return waitForPoolsMonitor(startedAt);
}
function compactPoolError(error){
  const code=String(error?.code||'').replace(/^functions\//,'').trim();
  const details=(typeof error?.details==='string'?error.details:(error?.details?.message||'')).trim();
  const raw=[code,error?.message,details].map(v=>String(v||'').trim()).filter(Boolean);
  const unique=[];for(const item of raw){if(!unique.some(x=>x.toLocaleLowerCase('es')===item.toLocaleLowerCase('es')))unique.push(item);}
  return unique.join(' · ')||'No se pudieron actualizar las piscinas.';
}
async function loadPoolMeasurements({force=false,silent=true}={}){
  if(state.poolMeasurementsLoading)return state.poolMeasurements;state.poolMeasurementsLoading=true;if(state.activeTab==='lodging')render();
  try{
    const data=force?await runPoolsMonitorNow():await fetchPoolMeasurementsWorker();
    state.poolMeasurements=data||{source:'Galileus · SILOE',fetchedAt:new Date().toISOString(),pools:[],history:[],warning:'La fuente no ha devuelto datos todavía.'};
    if(!silent)toast((state.poolMeasurements.pools||[]).length?'Mediciones de piscinas actualizadas.':'Consulta realizada; revisa el diagnóstico mostrado.');
    return state.poolMeasurements;
  }catch(error){
    const message=compactPoolError(error);
    const noPrevious=!state.poolMeasurements||(state.poolMeasurements.pools||[]).length===0;
    const firstRunMissing=/todav[ií]a no hay resultados|ejecuta primero el monitor|no hay resultados autom[aá]ticos/i.test(message);
    if(noPrevious)state.poolMeasurements={source:'Galileus · SILOE · navegador real',fetchedAt:new Date().toISOString(),pools:[],history:[],warning:firstRunMissing?'Preparando la primera lectura automática de las piscinas…':message,diagnostics:{fatal:!firstRunMissing,clientError:{message},transport:'cloudflare-worker+github-playwright'}};
    else state.poolMeasurements={...state.poolMeasurements,warning:message,diagnostics:{...(state.poolMeasurements.diagnostics||{}),clientError:{message}}};
    if(silent&&firstRunMissing&&!state.poolAutoMonitorStarted){state.poolAutoMonitorStarted=true;setTimeout(()=>loadPoolMeasurements({force:true,silent:true}).catch(()=>{}),250);}
    if(!silent)toast(message,'error');console.warn('Piscinas:',error);return state.poolMeasurements;
  }finally{state.poolMeasurementsLoading=false;if(state.activeTab==='lodging')render();}
}
function loadHlsLibrary(){
  if(window.Hls)return Promise.resolve(window.Hls);return new Promise((resolve,reject)=>{const existing=document.querySelector('script[data-hls-lib]');if(existing){existing.addEventListener('load',()=>resolve(window.Hls),{once:true});existing.addEventListener('error',reject,{once:true});return;}const script=document.createElement('script');script.src='https://cdn.jsdelivr.net/npm/hls.js@1/dist/hls.min.js';script.async=true;script.dataset.hlsLib='1';script.onload=()=>resolve(window.Hls);script.onerror=()=>reject(new Error('No se pudo cargar el reproductor HLS.'));document.head.appendChild(script);});
}
function webcamResponseLooksLikeWholePage(data,key=''){
  const mode=String(data?.mode||'').toLowerCase();
  if(mode!=='iframe')return false;
  try{
    const u=new URL(String(data?.url||''),location.href),host=u.hostname.toLowerCase(),path=u.pathname.replace(/\/+$/,'').toLowerCase();
    if(key==='el-perchel'){
      // Lista blanca: nunca aceptar páginas normales de CanariasLife/Skyline.
      if(/(^|\.)canariaslife\.com$/i.test(host))return true;
      if(/(^|\.)skylinewebcams\.com$/i.test(host))return true;
      // Solo un host de embed inequívoco puede pasar como iframe.
      if(!/(^|\.)embed\.skylinewebcams\.com$/i.test(host))return true;
      if(!path||path==='/')return true;
    }
    return false;
  }catch{return true;}
}
function webcamResponseIsStrictlyPlayable(data,key=''){
  if(!data?.url)return false;
  const mode=String(data.mode||'').toLowerCase();
  try{
    const u=new URL(String(data.url),location.href),host=u.hostname.toLowerCase(),path=u.pathname.toLowerCase();
    if(mode==='video')return /\.(?:m3u8|mp4)(?:$|\?)/i.test(`${path}${u.search}`);
    if(mode==='iframe'){
      if(key==='el-perchel')return /(^|\.)embed\.skylinewebcams\.com$/i.test(host)&&path!=='/'&&!/\/img\//i.test(path);
      return !webcamResponseLooksLikeWholePage(data,key);
    }
    if(mode==='image')return true;
    return false;
  }catch{return false;}
}
async function mountDirectWebcam(player,data){
  if(!player||!data?.url)return;
  if(state.webcamRefreshTimer){clearInterval(state.webcamRefreshTimer);state.webcamRefreshTimer=null;}
  if(data.mode==='image'){
    const base=String(data.url);const bust=()=>`${base}${base.includes('?')?'&':'?'}_mfe=${Date.now()}`;
    const badge=data.live===false?'● FOTOGRAMA ACTUALIZADO':'● EN DIRECTO';
    player.innerHTML=`<div class="webcam-live-image-wrap"><img class="webcam-live-image" src="${esc(bust())}" alt="${esc(data.title||'Webcam')}"><div class="webcam-live-badge">${esc(badge)}</div>${data.note?`<small>${esc(data.note)}</small>`:''}</div>`;
    const img=player.querySelector('.webcam-live-image');if(img){img.addEventListener('error',()=>{if(!img.isConnected)return;player.innerHTML=`<div class="webcam-error"><strong>No se ha podido cargar la imagen de la webcam.</strong><span>El proveedor no ha devuelto un fotograma válido en este momento.</span></div>`;if(state.webcamRefreshTimer){clearInterval(state.webcamRefreshTimer);state.webcamRefreshTimer=null;}},{once:true});}state.webcamRefreshTimer=setInterval(()=>{if(!img?.isConnected){clearInterval(state.webcamRefreshTimer);state.webcamRefreshTimer=null;return;}img.src=bust();},Math.max(8000,Number(data.refreshMs)||15000));return;
  }
  if(data.mode==='iframe'){player.innerHTML=`<iframe class="webcam-direct-frame" src="${esc(data.url)}" title="${esc(data.title||'Webcam en directo')}" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen referrerpolicy="no-referrer-when-downgrade"></iframe>`;return;}
  player.innerHTML=`<video class="webcam-direct-video" controls autoplay muted playsinline></video>`;const video=player.querySelector('video');
  if(video.canPlayType('application/vnd.apple.mpegurl')){video.src=data.url;video.play().catch(()=>{});return;}
  try{const Hls=await loadHlsLibrary();if(Hls?.isSupported?.()){const hls=new Hls({enableWorker:true,lowLatencyMode:true});hls.loadSource(data.url);hls.attachMedia(video);hls.on(Hls.Events.MANIFEST_PARSED,()=>video.play().catch(()=>{}));video._mfeHls=hls;return;}}catch(error){console.warn(error);}
  video.src=data.url;video.play().catch(()=>{});
}
async function openPoolWebcam(key){
  const titles={'santa-agueda':'Santa Águeda · El Pajar','el-perchel':'Playa de El Perchel'},title=titles[key]||'Webcam en directo';
  openModal(`<div class="modal-head webcam-modal-head"><div><span class="header-kicker">EN DIRECTO</span><h3>${esc(title)}</h3></div><button class="close-btn" data-close-modal>×</button></div><div class="webcam-player-shell" data-webcam-player><div class="webcam-loading"><span class="spinner"></span><span>Conectando con la webcam…</span></div></div>`,true);
  try{
    // v2.3.41 · Webcam El Perchel: whitelist estricta + fotograma sin caché; nunca cargar páginas completas.
    // El fotograma queda únicamente como respaldo si el proveedor no expone un directo compatible.
    let data;
    data=state.webcamEmbedCache?.[key];
    if(!data){
      try{
        data=await callIntegrationWorker({action:'webcam',key,preferImage:false,preferLive:true},{authenticated:false,timeoutMs:30000});
        if(webcamResponseLooksLikeWholePage(data,key)||!webcamResponseIsStrictlyPlayable(data,key)){
          console.warn('Webcam: respuesta no reproducible o página completa; se rechaza.',data);
          throw new Error('El proveedor no ofrece un reproductor externo compatible.');
        }
      }
      catch(workerError){
        console.warn('Webcam Worker',workerError);
        if(key==='el-perchel'){
          // No volver jamás a Firebase/CanariasLife para El Perchel: ese fallback podía cargar la web completa.
          data=await callIntegrationWorker({action:'webcam',key,preferImage:true,preferLive:false},{authenticated:false,timeoutMs:30000});
          if(!data||String(data.mode||'').toLowerCase()!=='image')throw workerError;
        }else{
          data=await state.provider.call('getTravelWebcam',{key});
          if(webcamResponseLooksLikeWholePage(data,key)||!webcamResponseIsStrictlyPlayable(data,key))throw workerError;
        }
      }
      state.webcamEmbedCache[key]=data;
    }
    const kicker=$('.webcam-modal-head .header-kicker',els.modal);if(kicker)kicker.textContent=data?.live===false?'FOTOGRAMA ACTUALIZADO':'EN DIRECTO';
    const target=$('[data-webcam-player]',els.modal);if(target)await mountDirectWebcam(target,data);
  }catch(error){const target=$('[data-webcam-player]',els.modal);if(target)target.innerHTML=`<div class="webcam-error"><strong>No se ha podido abrir la webcam.</strong><span>${esc(error.message||'El proveedor no expone un reproductor compatible en este momento.')}</span></div>`;}
}

function renderLodgingPage(){
  const l=state.data.cover?.lodging||{};
  const cordialTracker=state.data.trackers?.cordial||{};
  const s=state.data.settings||{};
  const lc=l.imageCrop||{x:50,y:50,zoom:1};
  const reviewDefaults=defaultLodgingReviewButtons();
  const reviewLinks=[
    isValidUrl(l.googleReviewsUrl)?coloredServiceLink(l.googleReviewsUrl,l.googleReviewsLabel||reviewDefaults.googleReviewsLabel,l.googleReviewsColor||reviewDefaults.googleReviewsColor,serviceIconMarkup(l.googleReviewsIcon,l.googleReviewsIconUrl,brandIconMarkup('google')),'lodging-review-link','googlemaps'):'',
    isValidUrl(l.tripadvisorReviewsUrl)?coloredServiceLink(l.tripadvisorReviewsUrl,l.tripadvisorReviewsLabel||reviewDefaults.tripadvisorReviewsLabel,l.tripadvisorReviewsColor||reviewDefaults.tripadvisorReviewsColor,serviceIconMarkup(l.tripadvisorReviewsIcon,l.tripadvisorReviewsIconUrl,brandIconMarkup('tripadvisor')),'lodging-review-link','tripadvisor'):'',
    isValidUrl(l.bookingReviewsUrl)?coloredServiceLink(l.bookingReviewsUrl,l.bookingReviewsLabel||reviewDefaults.bookingReviewsLabel,l.bookingReviewsColor||reviewDefaults.bookingReviewsColor,serviceIconMarkup(l.bookingReviewsIcon,l.bookingReviewsIconUrl,brandIconMarkup('booking')),'lodging-review-link booking-review-link','booking'):''
  ].filter(Boolean).join('');
  const budgetGroup=(state.data.budget?.groups||[]).find(g=>g.id==='g-lodging'||/cordial|alojamiento/i.test(String(g.name||'')));
  const reservedTotal=budgetGroup?sum((budgetGroup.items||[]).map(i=>num(i.amount))):0;
  const paidTotal=budgetGroup?sum((budgetGroup.items||[]).filter(i=>i.status==='paid').map(i=>num(i.amount))):0;
  const reservationCode=(budgetGroup?.items||[]).map(i=>i.name).filter(Boolean).join(' · ');
  const lodgingDoc=(state.data.cover?.documents||[]).find(d=>String(d.id||'')==='doc-lodging'||/alojamiento|cordial/i.test(`${d.title||''} ${d.subtitle||''}`));
  const storedGuideLabel=String(l.guestGuideLabel||'').trim();const guideDisplayLabel=(!storedGuideLabel||/gu[ií]a del resort|piscinas y servicios|temperatura piscinas/i.test(storedGuideLabel))?'Temp Piscinas':storedGuideLabel;const guideButton=`<button type="button" class="link-btn lodging-guide-link" data-scroll-pools>🌡️ <span>${esc(guideDisplayLabel)}</span></button>`;const sourceGuideLink=isValidUrl(l.guestGuideUrl)?safeLink(l.guestGuideUrl,'Abrir fuente original','↗','lodging-guide-source-link'):'';
  const carousels=(state.data.cover?.mediaCarousels||[]).map((carousel,index)=>coverCarouselPlacement(carousel)==='lodging'?renderLodgingCarouselAccordion(carousel,index):'').join('');
  const mapMode={satellite:'k',hybrid:'h',terrain:'p',map:'m'}[s.mapType]||'k';
  const mapUrl=s.mapEmbedUrl || (s.mapQuery?`https://www.google.com/maps?q=${encodeURIComponent(s.mapQuery)}&output=embed&t=${mapMode}`:'');
  const titleIcon=String(cordialTracker.titleIconUrl||'').trim()?resilientImageMarkup(String(cordialTracker.titleIconUrl||'').trim(),'airline-logo flight-card-airline-logo lodging-title-icon',`<span class="airline-logo flight-card-airline-logo lodging-title-icon emoji-icon">${esc(cordialTracker.titleIcon||TRACKER_DEFAULT_ICONS.cordial||'🏨')}</span>`,false):`<span class="airline-logo flight-card-airline-logo lodging-title-icon emoji-icon">${esc(cordialTracker.titleIcon||TRACKER_DEFAULT_ICONS.cordial||'🏨')}</span>`;
  const photo=isImageSource(l.imageUrl)?`<button class="lodging-image lodging-page-image clickable-image" style="--lodging-img:url('${esc(l.imageUrl)}');--lodging-pos:${num(lc.x)||50}% ${num(lc.y)||50}%;--lodging-zoom:${Math.max(1,num(lc.zoom)||1)}" data-image-popup="${esc(l.imageUrl)}" data-image-title="${esc(l.name)}" aria-label="Ampliar imagen del alojamiento"></button>`:'';
  return `${lockedBanner()}${pageHead('Alojamiento','',canEdit()?'<button class="btn secondary" data-edit-lodging>✎ Editar</button>':'')}
  <section class="card lodging-page-hero provider-gradient-card" style="--provider-g1:${esc(l.gradient1||providerPalette(l).g1)};--provider-g2:${esc(l.gradient2||providerPalette(l).g2)};--provider-title-text:${esc(l.textColor||'#ffffff')}">
    <div class="lodging-page-title">${titleIcon}<div><span class="header-kicker">Estancia actual</span><h3>${esc(l.name||'Alojamiento')}</h3></div></div>
    <div class="lodging-page-dates"><div class="date-chip"><small class="muted">Entrada</small><br><strong>${formatDate(l.checkIn)}</strong></div><div class="date-chip"><small class="muted">Salida</small><br><strong>${formatDate(l.checkOut)}</strong></div></div>
    <div class="lodging-page-actions">${safeLink(l.website,'Web','🌐','lodging-quick-link')}${safeLink(mapsDirectionsUrl(l.address||l.name,l.mapsUrl),'Cómo llegar',googleMapsIconMarkup(),'lodging-quick-link maps-route-link')}${guideButton}${reviewLinks}</div>
    ${photo}
  </section>
  <div class="lodging-page-grid">
    <section class="card lodging-info-panel"><div class="card-body"><h3>Reserva</h3><div class="lodging-reservation-kpis"><div><small>Localizador</small><strong>${esc(reservationCode||lodgingDoc?.subtitle||'—')}</strong></div><div><small>Importe reservado</small><strong>${reservedTotal?formatMoney(reservedTotal):'—'}</strong></div><div><small>Pagado</small><strong>${reservedTotal?formatMoney(paidTotal):'—'}</strong></div></div>${lodgingDoc?`<div class="lodging-reservation-doc">${renderDocument(lodgingDoc,(state.data.cover.documents||[]).indexOf(lodgingDoc))}</div>`:''}<div class="page-actions"><button class="btn secondary small" type="button" data-lodging-open-tab="budget">💶 Abrir presupuesto</button><button class="btn secondary small" type="button" data-lodging-open-tab="trackers">📈 Seguimiento de precio</button></div></div></section>
    ${poolPanelConfig().enabled===false?'':(()=>{const pc=poolPanelConfig(),extras={source:sourceGuideLink?`<div class="lodging-guide-callout"><span>También puedes consultar la fuente original si necesitas comprobar el parte completo.</span>${sourceGuideLink}</div>`:''},extraMarkup=(pc.sectionOrder||[]).filter(id=>id==='source'&&poolSectionVisible(id)).map(id=>extras[id]||'').join('');return `<section class="card lodging-info-panel lodging-pools-panel"><div class="card-body"><div class="lodging-pools-heading"><div><span class="header-kicker">${esc(pc.kicker||'DATOS EN DIRECTO')}</span><h3>${esc(pc.title||'Piscinas y servicios')}</h3></div></div>${renderLivePools()}${extraMarkup}</div></section>`;})()}
  </div>
  ${carousels?`<section class="lodging-page-section"><div class="section-title"><span>🗂️ PLANOS E INSTRUCCIONES</span></div><div class="lodging-embedded-media">${carousels}</div></section>`:''}
  <section class="lodging-page-section"><div class="section-title"><span>📍 UBICACIÓN · ${esc(({satellite:'SATÉLITE',hybrid:'HÍBRIDO',terrain:'TERRENO',map:'MAPA'})[s.mapType]||'SATÉLITE')}</span></div>${mapUrl?`<iframe class="map-frame lodging-map-frame" src="${esc(mapUrl)}" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>`:'<div class="map-placeholder lodging-map-placeholder">Añade una ubicación o URL de mapa en Configuración.</div>'}</section>`;
}

binders.lodging=()=>{
  $$('[data-edit-lodging]').forEach(b=>b.addEventListener('click',editLodging));
  $$('[data-scroll-pools]').forEach(b=>b.addEventListener('click',()=>document.querySelector('.lodging-pools-panel')?.scrollIntoView({behavior:'smooth',block:'start'})));
  $$('[data-lodging-open-tab]').forEach(b=>b.addEventListener('click',()=>navigateToTab(String(b.dataset.lodgingOpenTab||'cover'))));
  $$('[data-refresh-pools]').forEach(b=>b.addEventListener('click',()=>loadPoolMeasurements({force:true,silent:false})));
  $$('[data-pool-webcam]').forEach(b=>b.addEventListener('click',()=>openPoolWebcam(String(b.dataset.poolWebcam||''))));
  $$('[data-lodging-carousel-details]').forEach(node=>node.addEventListener('toggle',()=>{const id=String(node.dataset.lodgingCarouselDetails||'');if(!id)return;state.coverCarouselOpen[id]=node.open;if(node.open){$$('[data-lodging-carousel-details]').forEach(other=>{if(other===node||!other.open)return;const otherId=String(other.dataset.lodgingCarouselDetails||'');other.open=false;if(otherId)state.coverCarouselOpen[otherId]=false;});}}));
  if(!state.poolMeasurements&&!state.poolMeasurementsLoading)void loadPoolMeasurements({silent:true});
};

function renderBudgetPaidProgress(stats){
  const total=Math.max(0,num(stats.total)),paid=Math.max(0,num(stats.paid));
  const pct=total>0?Math.max(0,Math.min(100,paid/total*100)):0;
  return `<section class="budget-paid-progress" aria-label="Progreso de pago del presupuesto"><div class="budget-paid-progress-head"><div><span>Progreso de pago</span><strong>${pct.toLocaleString('es-ES',{maximumFractionDigits:1})}%</strong></div><div class="budget-paid-progress-values"><span>Pagado <b>${formatMoney(paid)}</b></span><span>Total <b>${formatMoney(total)}</b></span></div></div><div class="budget-paid-progress-track" role="progressbar" aria-valuemin="0" aria-valuemax="${total}" aria-valuenow="${Math.min(paid,total)}" aria-label="${formatMoney(paid)} pagados de ${formatMoney(total)}"><span class="budget-paid-progress-fill" style="width:${pct.toFixed(2)}%"></span><span class="budget-paid-progress-dot" style="left:${pct.toFixed(2)}%"></span></div><div class="budget-paid-progress-scale"><span>${formatMoney(0)}</span><span>${formatMoney(total)}</span></div></section>`;
}

function renderBudgetGroup(group,gIndex) {
  const isFlightGroup=group.id==='g-flights';
  const entries=effectiveBudgetEntries(group);
  const total=sum(entries.map(entry=>itemAmount(entry.item)));
  const rows=entries.map(({item,index,automatic})=>{
    const rowIconUrl=item.iconUrl||group.iconUrl||"";
    const rowIcon=item.icon||group.icon||"💳";
    const compactRowIcon=iconMarkup(rowIcon,rowIconUrl,'budget-item-icon');
    const sourceLabel=!automatic&&item.source?`<small class="muted">Automático: Lista de compra</small>`:"";
    const concept=`<div class="budget-item-concept" style="display:flex!important;align-items:center!important;gap:10px!important;min-width:0!important"><span class="budget-item-icon-frame" style="display:grid!important;place-items:center!important;flex:0 0 36px!important;width:36px!important;height:36px!important;min-width:36px!important;min-height:36px!important;max-width:36px!important;max-height:36px!important;overflow:hidden!important"><span class="budget-item-icon-inner">${compactRowIcon}</span></span><span class="budget-item-copy" style="display:flex!important;flex-direction:column!important;justify-content:center!important;min-width:0!important"><strong>${esc(item.name)}</strong>${sourceLabel}</span></div>`;
    const detailLinks=automatic
      ? (item.autoType==="bus"
        ? `${(item.files||[]).map(f=>renderFileButton(f,item.name)).join('')}`
        : `${item.autoType==="extra"&&isValidUrl(item.fileUrl)?popupFileLink(item.fileUrl,"Ver archivo","📄"):""}<button class="link-btn" type="button" data-open-real-purchases="${item.autoType||""}">🧾 ${item.autoType==="extra"?"Ver":"Ver compras"}</button>`)
      : `${isValidUrl(item.url)?(isFilePreviewUrl(item.url)?popupFileLink(item.url,item.webLabel||"Ver archivo","📄"):safeLink(item.url,item.webLabel||"Web","↗")):''}${(item.files||[]).map(f=>renderFileButton(f,item.name)).join('')}`;
    const preview=budgetPreviewAsset(group,item);
    const previewMarkup=preview?`<button class="budget-detail-preview ${preview.kind==='cordial'?'is-cover':''} clickable-image" type="button" data-image-popup="${esc(preview.url)}" data-image-title="${esc(preview.title)}" aria-label="Ampliar imagen de ${esc(preview.title)}"><img src="${esc(preview.url)}" alt="${esc(preview.title)}" loading="lazy"></button>`:'';
    const status=automatic
      ? (item.autoType==="extra"
        ? `<button class="status-pill ${item.status==="paid"?"paid":"unpaid"}" data-toggle-extra-paid="${esc(item.sourceId)}" ${canEdit()?"":"disabled"}>${item.status==="paid"?"PAGADO":"NO PAGADO"}</button>`
        : item.autoType==="bus"
          ? `<button class="status-pill ${item.status==="paid"?"paid":"unpaid"}" data-toggle-bus-paid="${esc(item.sourceId)}" ${canEdit()?"":"disabled"}>${item.status==="paid"?"PAGADO":"NO PAGADO"}</button>`
          : `<span class="status-pill paid automatic-status">PAGADO</span>`)
      : `<button class="status-pill ${item.status==="paid"?"paid":"unpaid"}" data-toggle-paid="${gIndex}:${index}" ${canEdit()?"":"disabled"}>${item.status==="paid"?"PAGADO":"NO PAGADO"}</button>`;
    const actions=canEdit()
      ? (automatic
        ? `<td data-label="Acciones"><span class="budget-actions-wrap">${item.autoType==="extra"?`<div class="row-actions"><button class="mini-btn" data-edit-source-extra="${esc(item.sourceId)}" title="Editar en Compra real">✎</button><span class="auto-row-mark auto-row-sync" title="Sincronizado automáticamente con Compra real" aria-label="Sincronizado automáticamente con Compra real">↻</span></div>`:item.autoType==="bus"?`<div class="row-actions"><button class="mini-btn action-clip" data-manage-source-bus-files="${esc(item.sourceId)}" title="Billetes PDF y archivos" aria-label="Billetes PDF y archivos">📎</button><button class="mini-btn" data-edit-source-bus="${esc(item.sourceId)}" title="Editar autobús">✎</button><span class="auto-row-mark auto-row-sync" title="Sincronizado automáticamente con Datos del viaje" aria-label="Sincronizado automáticamente con Datos del viaje">↻</span></div>`:`<span class="auto-row-mark auto-row-sync" title="Elemento automático" aria-label="Elemento automático">↻</span>`}</span></td>`
        : `<td data-label="Acciones"><div class="row-actions"><button class="mini-btn" data-manage-budget-files="${gIndex}:${index}" title="Archivos y enlaces" aria-label="Archivos y enlaces">📎</button><button class="mini-btn" data-edit-budget-item="${gIndex}:${index}" title="Editar concepto, texto e icono">✎</button><button class="mini-btn" data-delete-budget-item="${gIndex}:${index}">×</button></div></td>`)
      : "";
    const detailClass=`budget-detail${preview?' has-preview':''}`;
    const flight=isFlightGroup?budgetFlightForItem(item):null;
    const flightCells=isFlightGroup?`<td data-label="Horario" class="budget-flight-meta">${flight?`${formatTime(flight.departure)}–${formatTime(flight.arrival)}`:''}</td><td data-label="Duración" class="budget-flight-meta">${flight?esc(flightDuration(flight)):''}</td><td data-label="Vuelo" class="budget-flight-meta budget-flight-number">${flight?esc(flight.number||''):''}</td>`:'';
    return `<tr class="${automatic?"automatic-budget-row ":""}${preview?'budget-row-has-preview':''}${flight?' budget-flight-data-row':''}"><td data-label="Concepto">${concept}</td><td data-label="Detalle y archivos"><div class="${detailClass}"><div class="budget-detail-copy"><span>${esc(item.detail||"")}</span><div class="budget-links">${detailLinks}</div></div>${previewMarkup}</div></td>${flightCells}<td data-label="Importe" class="amount">${formatMoney(itemAmount(item))}</td><td data-label="Estado">${status}</td>${actions}</tr>`;
  }).join("");
  const headerBus=group.id==='g-bus'?(state.data.cover.buses||[]).find(bus=>bus&&bus.visible!==false)||(state.data.cover.buses||[])[0]:null;
  // En el bloque automático de autobús manda siempre el icono actual del trayecto.
  // Evita que quede fijada una imagen antigua guardada previamente en el grupo.
  const headerIconUrl=headerBus?busIdentityVisualUrl(headerBus,(state.data.cover.buses||[]).indexOf(headerBus)):(group.iconUrl||'');
  const headerIcon=headerBus?(headerBus.icon||group.icon||'🚌'):(group.icon||'◼');
  const flightCols=isFlightGroup?'<col class="budget-col-flight-time"><col class="budget-col-flight-duration"><col class="budget-col-flight-number">':'';
  const flightHeaders=isFlightGroup?'<th>Horario</th><th>Duración</th><th>Vuelo</th>':'';
  const titleGradient1=headerBus?(headerBus.gradient1||headerBus.color||group.gradient1||group.color):(group.gradient1||group.color);
  const titleGradient2=headerBus?(headerBus.gradient2||headerBus.color||group.gradient2||group.color):(group.gradient2||group.color);
  const titleTextColor=headerBus?(headerBus.textColor||group.textColor||'#ffffff'):(group.textColor||'#ffffff');
  const columnCount=(isFlightGroup?7:4)+(canEdit()?1:0);
  return `<article class="card budget-group-card" data-sort-item="budget-group|${gIndex}" style="--group-color:${esc(group.color)}"><div class="section-title" style="--g1:${esc(titleGradient1)};--g2:${esc(titleGradient2)};--title-text:${esc(titleTextColor)}"><span class="section-title-label">${iconMarkup(headerIcon,headerIconUrl,"section-icon")} ${esc(group.name)}</span>${editButtons(`<div class="section-actions">${sortDragHandle(`budget-group|${gIndex}`,'Arrastrar bloque')}<button class="mini-btn" data-add-budget-item="${gIndex}">＋</button><button class="mini-btn" data-edit-budget-group="${gIndex}">✎</button><button class="mini-btn" data-delete-budget-group="${gIndex}">×</button></div>`)}</div><div class="table-wrap"><table class="budget-table ${isFlightGroup?'budget-flight-table':''}"><colgroup><col class="budget-col-name"><col class="budget-col-detail">${flightCols}<col class="budget-col-amount"><col class="budget-col-status">${canEdit()?'<col class="budget-col-actions">':''}</colgroup><thead><tr><th>Concepto</th><th>Detalle y archivos</th>${flightHeaders}<th class="amount">Importe</th><th>Estado</th>${canEdit()?"<th></th>":""}</tr></thead><tbody>${rows||`<tr><td colspan="${columnCount}" class="empty">Todavía no hay conceptos.</td></tr>`}</tbody></table></div><div class="group-total"><span>Total</span><strong>${formatMoney(total)}</strong></div></article>`;
}
function donutData() {
  const groups=state.data.budget.groups.map(g=>({name:g.name,color:g.color,value:sum(effectiveBudgetEntries(g).map(entry=>itemAmount(entry.item)))})).filter(x=>x.value>0); const total=sum(groups.map(x=>x.value)); let acc=0;
  groups.forEach(g=>{g.percentage=total?g.value/total*100:0;g.start=acc;acc+=g.percentage;});
  return {groups,total};
}
function renderDonutChart(chart) {
  const circumference=2*Math.PI*48;
  const segments=chart.groups.map((g,i)=>{const length=g.percentage/100*circumference;const offset=-(g.start/100*circumference);return `<circle class="donut-segment" cx="60" cy="60" r="48" fill="none" stroke="${esc(g.color)}" stroke-width="18" stroke-dasharray="${length} ${circumference}" stroke-dashoffset="${offset}" transform="rotate(-90 60 60)" data-chart-name="${esc(g.name)}" data-chart-value="${g.value}" data-chart-pct="${g.percentage.toFixed(1)}" data-tracker-chart-tooltip="${esc(`${g.name} · ${formatMoney(g.value)} · ${g.percentage.toFixed(1)}%`)}" tabindex="0"><title>${esc(g.name)} · ${formatMoney(g.value)} · ${g.percentage.toFixed(1)}%</title></circle>`;}).join('');
  return `<div class="donut-wrap"><div class="donut-chart"><svg class="donut-svg" viewBox="0 0 120 120" role="img" aria-label="Distribución del gasto"><circle cx="60" cy="60" r="48" fill="none" stroke="rgba(255,255,255,.06)" stroke-width="18"></circle>${segments}</svg><div class="donut-center" data-donut-center data-total="${formatMoney(chart.total)}"><strong>${formatMoney(chart.total)}</strong><span>Total</span></div></div></div><div class="chart-legend">${chart.groups.map(g=>`<div class="legend-row"><span class="legend-dot" style="background:${esc(g.color)}"></span><span>${esc(g.name)} <small>${g.percentage.toFixed(1)}%</small></span><strong>${formatMoney(g.value)}</strong></div>`).join("")}</div>`;
}
function bindDonutInteractions(root=document) {
  $$('[data-donut-center]',root).forEach(center=>{
    const scope=center.closest('.donut-wrap')||root;
    const restore=()=>{center.innerHTML=`<strong>${esc(center.dataset.total||'')}</strong><span>Total</span>`;};
    $$('[data-chart-name]',scope).forEach(segment=>{
      const show=()=>{center.innerHTML=`<strong class="donut-hover-name">${esc(segment.dataset.chartName)}</strong><span>${formatMoney(segment.dataset.chartValue)} · ${esc(segment.dataset.chartPct)}%</span>`;segment.classList.add('active');};
      const hide=()=>{segment.classList.remove('active');restore();};
      segment.addEventListener('mouseenter',show);segment.addEventListener('focus',show);segment.addEventListener('mouseleave',hide);segment.addEventListener('blur',hide);segment.addEventListener('pointerdown',show);
    });
  });
}
function trackerChartTooltipElement(){
  let tip=document.getElementById('tracker-chart-tooltip');
  if(!tip){tip=document.createElement('div');tip.id='tracker-chart-tooltip';tip.className='tracker-chart-tooltip';tip.setAttribute('role','tooltip');document.body.appendChild(tip);}
  return tip;
}
function bindTrackerChartTooltips(root=document){
  const nodes=$$('[data-tracker-chart-tooltip]',root);if(!nodes.length)return;
  const tip=trackerChartTooltipElement();let hideTimer=null;
  const move=e=>{const gap=14,maxX=Math.max(gap,window.innerWidth-tip.offsetWidth-gap),maxY=Math.max(gap,window.innerHeight-tip.offsetHeight-gap);tip.style.left=`${Math.min(maxX,Math.max(gap,e.clientX+14))}px`;tip.style.top=`${Math.min(maxY,Math.max(gap,e.clientY-16))}px`;};
  const show=(node,e,sticky=false)=>{if(hideTimer){clearTimeout(hideTimer);hideTimer=null;}tip.textContent=node.dataset.trackerChartTooltip||'';tip.classList.add('is-visible');move(e);if(sticky)hideTimer=setTimeout(()=>tip.classList.remove('is-visible'),4200);};
  const hide=()=>{if(!hideTimer)tip.classList.remove('is-visible');};
  nodes.forEach(node=>{
    if(node.dataset.chartTooltipBound==='1')return;node.dataset.chartTooltipBound='1';
    node.addEventListener('pointerenter',e=>show(node,e));node.addEventListener('pointermove',move);node.addEventListener('pointerleave',hide);
    node.addEventListener('focus',()=>{const r=node.getBoundingClientRect();show(node,{clientX:r.left+r.width/2,clientY:r.top+r.height/2});});node.addEventListener('blur',hide);
    node.addEventListener('pointerdown',e=>{e.stopPropagation();show(node,e,true);});
  });
}
function chartExpansionTitle(wrapper){
  const svg=wrapper?.querySelector?.('svg[aria-label]');
  return String(svg?.getAttribute('aria-label')||'Gráfico').trim()||'Gráfico';
}
function chartExpansionCompanionMarkup(wrapper){
  const accepted=/\b(?:tracker-multi-chart-legend|vueling-chart-legend|shopping-history-chart-legend|chart-legend)\b/;
  const prev=wrapper?.previousElementSibling,next=wrapper?.nextElementSibling;
  const before=prev&&accepted.test(String(prev.className||''))?prev.outerHTML:'';
  const after=next&&accepted.test(String(next.className||''))?next.outerHTML:'';
  return {before,after};
}
function openExpandedChart(wrapper){
  if(!wrapper)return;
  const title=chartExpansionTitle(wrapper),companions=chartExpansionCompanionMarkup(wrapper),clone=wrapper.cloneNode(true);
  clone.classList.remove('chart-expandable');clone.removeAttribute('data-chart-expand-bound');clone.classList.add('chart-expanded-copy');
  clone.querySelectorAll('[data-chart-tooltip-bound]').forEach(node=>node.removeAttribute('data-chart-tooltip-bound'));
  openModal(`<div class="modal-head chart-zoom-head"><div><span class="header-kicker">GRÁFICO AMPLIADO</span><h3>${esc(title)}</h3><small>Pulsa cualquier punto para ver su dato exacto.</small></div><button class="close-btn" data-close-modal>×</button></div><div class="chart-zoom-shell">${companions.before}${clone.outerHTML}${companions.after}</div>`,true);
  bindTrackerChartTooltips(els.modal);bindDonutInteractions(els.modal);
}
function bindInteractiveCharts(root=document){
  const selector='.pool-chart-wrap,.cordial-chart-wrap,.shopping-history-chart-wrap,.donut-wrap';
  $$(selector,root).forEach(wrapper=>{
    if(wrapper.closest('.chart-zoom-shell'))return;
    if(wrapper.dataset.chartExpandBound==='1')return;wrapper.dataset.chartExpandBound='1';wrapper.classList.add('chart-expandable');wrapper.setAttribute('title','Pulsa para ampliar el gráfico');
    wrapper.addEventListener('click',event=>{if(event.target.closest('[data-chart-name],a,button,input,select,label'))return;openExpandedChart(wrapper);});
  });
}

const BUDGET_SIDE_CARD_DEFAULTS={
  carKm:{title:'Kilómetros coche',icon:'🚗',iconUrl:'',gradient1:'#173b61',gradient2:'#285f91',textColor:'#ffffff'},
  distribution:{title:'Distribución del gasto',icon:'📊',iconUrl:'',gradient1:'#312250',gradient2:'#5e3f92',textColor:'#ffffff'}
};
function budgetSideCardConfig(key){
  return {...(BUDGET_SIDE_CARD_DEFAULTS[key]||BUDGET_SIDE_CARD_DEFAULTS.carKm),...(state.data.budget?.sideCards?.[key]||{})};
}
function editBudgetSideCard(key){
  const defaults=BUDGET_SIDE_CARD_DEFAULTS[key]||BUDGET_SIDE_CARD_DEFAULTS.carKm;
  const current=budgetSideCardConfig(key);
  openForm({title:`Icono · ${current.title}`,fields:[
    {name:'title',label:'Título',full:true,required:true},
    {name:'icon',label:'Emoji alternativo'},
    {name:'iconUrl',label:'Icono PNG / Google Drive',type:'url',full:true,driveImage:true,driveImageSize:128},
    {name:'iconFile',label:'Subir icono PNG/SVG/WebP/JPG',type:'file',accept:'image/png,image/jpeg,image/webp,image/svg+xml',full:true},
    {name:'gradient1',label:'Degradado inicio',type:'color'},{name:'gradient2',label:'Degradado fin',type:'color'},{name:'textColor',label:'Color del texto del título',type:'color'}
  ],values:{...defaults,...current},onSubmit:async v=>{
    if(v.iconFile)v.iconUrl=await fileToSquareDataUrl(v.iconFile,128);delete v.iconFile;
    state.data.budget.sideCards={...(state.data.budget.sideCards||{}),[key]:{...defaults,...current,...v}};
    await saveSection('budget');render();
  }});
}
const PURCHASE_BLOCK_DEFAULTS={
  supermarkets:{title:'Compras de supermercado',icon:'🧾',iconUrl:'',gradient1:'#1f3e17',gradient2:'#355e25',textColor:'#ffffff'},
  extras:{title:'Extras',icon:'✨',iconUrl:'',gradient1:'#70530e',gradient2:'#a77a13',textColor:'#ffffff'},
  otherExpenses:{title:'Otros gastos reales',icon:'⛽',iconUrl:'',gradient1:'#6b3e13',gradient2:'#a66b25',textColor:'#ffffff'},
  ticketItems:{title:'Productos extraídos de tickets',icon:'🔎',iconUrl:'',gradient1:'#47356a',gradient2:'#704e9c',textColor:'#ffffff'}
};
function purchaseBlockConfig(id){
  return {...(PURCHASE_BLOCK_DEFAULTS[id]||PURCHASE_BLOCK_DEFAULTS.supermarkets),...(state.data.purchases?.blockHeaders?.[id]||{})};
}
function purchaseBlockTitleMarkup(id){
  const cfg=purchaseBlockConfig(id);
  return `<span class="section-title-label">${iconMarkup(cfg.icon,cfg.iconUrl,'section-icon')} ${esc(cfg.title)}</span>`;
}
function purchaseBlockSectionStyle(id){
  const cfg=purchaseBlockConfig(id);
  return `--g1:${esc(cfg.gradient1)};--g2:${esc(cfg.gradient2)};--title-text:${esc(cfg.textColor||'#ffffff')}`;
}
function editPurchaseBlockHeader(id){
  const defaults=PURCHASE_BLOCK_DEFAULTS[id]||PURCHASE_BLOCK_DEFAULTS.supermarkets;
  const current=purchaseBlockConfig(id);
  openForm({title:`Icono · ${current.title}`,fields:[
    {name:'title',label:'Título',full:true,required:true},
    {name:'icon',label:'Emoji alternativo'},
    {name:'iconUrl',label:'Icono PNG / Google Drive',type:'url',full:true,driveImage:true,driveImageSize:128},
    {name:'iconFile',label:'Subir icono PNG/SVG/WebP/JPG',type:'file',accept:'image/png,image/jpeg,image/webp,image/svg+xml',full:true},
    {name:'gradient1',label:'Degradado inicio',type:'color'},{name:'gradient2',label:'Degradado fin',type:'color'},{name:'textColor',label:'Color del texto del título',type:'color'}
  ],values:{...defaults,...current},onSubmit:async v=>{
    if(v.iconFile)v.iconUrl=await fileToSquareDataUrl(v.iconFile,128);delete v.iconFile;
    state.data.purchases.blockHeaders={...(state.data.purchases.blockHeaders||{}),[id]:{...defaults,...current,...v}};
    await saveSection('purchases');render();
  }});
}

function budgetVisibilityMeta(id){
  const key=String(id||'');
  if(key==='summary')return ['💶','Resumen del presupuesto'];
  if(key==='progress')return ['📊','Progreso de pago'];
  if(key==='side:carKm'){const cfg=budgetSideCardConfig('carKm');return [cfg.icon||'🚗',cfg.title||'Kilómetros coche'];}
  if(key==='side:distribution'){const cfg=budgetSideCardConfig('distribution');return [cfg.icon||'📈',cfg.title||'Distribución'];}
  if(key.startsWith('group:')){
    const groupId=key.slice(6),group=(state.data.budget.groups||[]).find((item,index)=>String(item?.id||`group-${index}`)===groupId);
    return [group?.icon||'💳',group?.name||'Grupo de presupuesto'];
  }
  return ['▣',key||'Elemento'];
}
function budgetVisibilityButton(id,label=''){
  if(!canEdit())return '';
  const meta=budgetVisibilityMeta(id),title=label||meta[1];
  return `<button type="button" class="mini-btn budget-visibility-btn" data-budget-hide="${esc(id)}" title="Ocultar ${esc(title)}" aria-label="Ocultar ${esc(title)}">${coverEyeIconMarkup('budget-eye-icon')}</button>`;
}
function renderBudgetHiddenList(hiddenSet){
  if(!canEdit()||!hiddenSet.size)return '';
  const order=[];
  const push=id=>{if(hiddenSet.has(id)&&!order.includes(id))order.push(id);};
  push('summary');push('progress');
  (state.data.budget.groups||[]).forEach((group,index)=>push(`group:${String(group?.id||`group-${index}`)}`));
  push('side:carKm');push('side:distribution');
  for(const id of hiddenSet)push(id);
  if(!order.length)return '';
  return `<section class="card cover-hidden-list budget-hidden-list"><div class="cover-hidden-list-head"><strong>Elementos ocultos</strong><small>Solo aparece mientras la edición está desbloqueada</small></div><div class="cover-hidden-list-items">${order.map(id=>{const[icon,label]=budgetVisibilityMeta(id);return `<div class="cover-hidden-list-row"><span>${esc(icon)} ${esc(label)}</span><button type="button" class="mini-btn cover-show-btn" data-budget-show="${esc(id)}" title="Volver a mostrar ${esc(label)}" aria-label="Volver a mostrar ${esc(label)}">${coverEyeIconMarkup('budget-eye-icon')}</button></div>`;}).join('')}</div></section>`;
}
function renderBudget() {
  const stats=budgetStats(), chart=donutData(), km=state.data.budget.carKm, driven=(km.initial!==""&&km.final!=="")?num(km.final)-num(km.initial):null;
  const kmCard=budgetSideCardConfig('carKm'),distributionCard=budgetSideCardConfig('distribution');
  const hidden=new Set(state.data.budget.hiddenBlocks||[]);
  const summary=hidden.has('summary')?'':`<div class="budget-hideable-block">${canEdit()?`<div class="budget-visibility-row">${budgetVisibilityButton('summary')}</div>`:''}<section class="kpi-grid budget-summary-grid"><div class="kpi accent"><span>Presupuesto total</span><strong>${formatMoney(stats.total)}</strong></div><div class="kpi"><span>Total por persona</span><strong>${formatMoney(stats.perPerson)}</strong></div><div class="kpi success kpi-with-chart"><div class="kpi-copy"><span>Pagado</span><strong>${formatMoney(stats.paid)}</strong></div>${coverBudgetDonut("Pagado",stats.paid,stats.total,"success")}</div><div class="kpi danger kpi-with-chart"><div class="kpi-copy"><span>Por pagar</span><strong>${formatMoney(stats.unpaid)}</strong></div>${coverBudgetDonut("Pendiente",stats.unpaid,stats.total,"danger")}</div></section></div>`;
  const progress=hidden.has('progress')?'':`<div class="budget-hideable-block">${canEdit()?`<div class="budget-visibility-row">${budgetVisibilityButton('progress')}</div>`:''}${renderBudgetPaidProgress(stats)}</div>`;
  const groups=(state.data.budget.groups||[]).map((group,index)=>{
    const key=`group:${String(group?.id||`group-${index}`)}`;
    if(hidden.has(key))return '';
    return renderBudgetGroup(group,index).replace('<div class="section-actions">',`<div class="section-actions">${budgetVisibilityButton(key,group?.name||'grupo')}`);
  }).join('');
  const kmMarkup=hidden.has('side:carKm')?'':`<article class="card budget-side-card"><div class="section-title" style="--g1:${esc(kmCard.gradient1)};--g2:${esc(kmCard.gradient2)};--title-text:${esc(kmCard.textColor||'#ffffff')}"><span class="section-title-label">${iconMarkup(kmCard.icon,kmCard.iconUrl,'section-icon')} ${esc(kmCard.title)}</span>${editButtons(`<div class="section-actions">${budgetVisibilityButton('side:carKm',kmCard.title)}<button class="mini-btn" data-edit-budget-side="carKm" title="Editar icono y título">✎</button></div>`)}</div><div class="card-body"><div class="km-grid"><label class="field">Iniciales<input data-km="initial" type="number" step="0.1" value="${esc(km.initial)}" ${canEdit()?"":"disabled"}></label><label class="field">Finales<input data-km="final" type="number" step="0.1" value="${esc(km.final)}" ${canEdit()?"":"disabled"}></label><div class="km-result">${driven===null?"—":`${driven.toLocaleString("es-ES")} km`}</div></div></div></article>`;
  const distributionMarkup=hidden.has('side:distribution')?'':`<article class="card budget-side-card"><div class="section-title" style="--g1:${esc(distributionCard.gradient1)};--g2:${esc(distributionCard.gradient2)};--title-text:${esc(distributionCard.textColor||'#ffffff')}"><span class="section-title-label">${iconMarkup(distributionCard.icon,distributionCard.iconUrl,'section-icon')} ${esc(distributionCard.title)}</span>${editButtons(`<div class="section-actions">${budgetVisibilityButton('side:distribution',distributionCard.title)}<button class="mini-btn" data-edit-budget-side="distribution" title="Editar icono y título">✎</button></div>`)}</div>${renderDonutChart(chart)}</article>`;
  const side=[kmMarkup,distributionMarkup].filter(Boolean).join('');
  return `${lockedBanner()}${pageHead("Presupuesto","Control editable de vuelos, autobuses, reservas, compras, extras y pagos",`<button class="btn secondary pdf-action-btn" data-export-budget-pdf>${pdfFileIconMarkup("pdf-action-icon")} Exportar PDF</button>${canEdit()?'<button class="btn primary canary-action-btn" data-add-budget-group>＋ Crear grupo</button>':''}`)}
  ${summary}${progress}
  <div class="budget-layout"><div class="budget-groups">${groups}</div>${side?`<aside class="budget-side">${side}</aside>`:''}</div>${renderBudgetHiddenList(hidden)}`;
}

binders.budget = () => {
  $$('[data-export-budget-pdf]').forEach(b=>b.addEventListener('click',generateBudgetPdf));
  $$('[data-budget-hide]').forEach(b=>b.addEventListener('click',async event=>{event.preventDefault();event.stopPropagation();const id=String(b.dataset.budgetHide||'');if(!id)return;const hidden=new Set(state.data.budget.hiddenBlocks||[]);hidden.add(id);state.data.budget.hiddenBlocks=[...hidden];await saveSection('budget');const[,label]=budgetVisibilityMeta(id);render();toast(`${label}: oculto en Presupuesto.`);}));
  $$('[data-budget-show]').forEach(b=>b.addEventListener('click',async()=>{const id=String(b.dataset.budgetShow||'');if(!id)return;const hidden=new Set(state.data.budget.hiddenBlocks||[]);hidden.delete(id);state.data.budget.hiddenBlocks=[...hidden];await saveSection('budget');const[,label]=budgetVisibilityMeta(id);render();toast(`${label}: visible de nuevo.`);}));
  $$('[data-add-budget-group]').forEach(b=>b.addEventListener('click',()=>editBudgetGroup()));
  $$('[data-edit-budget-side]').forEach(b=>b.addEventListener('click',()=>editBudgetSideCard(String(b.dataset.editBudgetSide||''))));
  $$('[data-move-budget-group]').forEach(b=>b.addEventListener('click',async()=>{const[index,delta]=b.dataset.moveBudgetGroup.split(':').map(num);if(!moveArrayItem(state.data.budget.groups,index,delta))return;state.data.settings.budgetGroupOrderCustomized=true;await Promise.all([saveSection('budget'),saveSection('settings')]);render();}));
  $$('[data-edit-budget-group]').forEach(b=>b.addEventListener('click',()=>editBudgetGroup(num(b.dataset.editBudgetGroup))));
  $$('[data-delete-budget-group]').forEach(b=>b.addEventListener('click',async()=>{if(confirmAction("¿Eliminar el grupo y todos sus conceptos?")){state.data.budget.groups.splice(num(b.dataset.deleteBudgetGroup),1);await saveSection("budget");render();}}));
  $$('[data-add-budget-item]').forEach(b=>b.addEventListener('click',()=>editBudgetItem(num(b.dataset.addBudgetItem))));
  $$('[data-edit-budget-item]').forEach(b=>b.addEventListener('click',()=>{const [g,i]=b.dataset.editBudgetItem.split(':').map(num);editBudgetItem(g,i);}));
  $$('[data-delete-budget-item]').forEach(b=>b.addEventListener('click',async()=>{const [g,i]=b.dataset.deleteBudgetItem.split(':').map(num);if(confirmAction("¿Eliminar este concepto?")){state.data.budget.groups[g].items.splice(i,1);await saveSection("budget");render();}}));
  $$('[data-manage-budget-files]').forEach(b=>b.addEventListener('click',()=>{const[g,i]=b.dataset.manageBudgetFiles.split(':').map(num);openFilesManager(state.data.budget.groups[g].items[i].files||[],async files=>{state.data.budget.groups[g].items[i].files=files;await saveSection('budget');render();},'Archivos del presupuesto');}));
  $$('[data-toggle-paid]').forEach(b=>b.addEventListener('click',async()=>{if(!canEdit())return;const[g,i]=b.dataset.togglePaid.split(':').map(num);const item=state.data.budget.groups[g].items[i];item.status=item.status==="paid"?"unpaid":"paid";await saveSection("budget");render();}));
  $$('[data-toggle-extra-paid]').forEach(b=>b.addEventListener('click',async()=>{
    if(!canEdit())return;const extra=(state.data.purchases.extras||[]).find(x=>String(x.id)===String(b.dataset.toggleExtraPaid));if(!extra)return;
    extra.status=extra.status==="paid"?"unpaid":"paid";await saveSection("purchases");render();toast(extra.status==="paid"?"Extra marcado como pagado.":"Extra marcado como no pagado.");
  }));
  $$('[data-edit-source-extra]').forEach(b=>b.addEventListener('click',()=>{const i=(state.data.purchases.extras||[]).findIndex(x=>String(x.id)===String(b.dataset.editSourceExtra));if(i>=0)editExtra(i);}));
  $$('[data-toggle-bus-paid]').forEach(b=>b.addEventListener('click',async()=>{if(!canEdit())return;const bus=(state.data.cover.buses||[]).find(x=>String(x.id)===String(b.dataset.toggleBusPaid));if(!bus)return;bus.status=bus.status==='paid'?'unpaid':'paid';await saveSection('cover');render();toast(bus.status==='paid'?'Autobús marcado como pagado.':'Autobús marcado como no pagado.');}));
  $$('[data-manage-source-bus-files]').forEach(b=>b.addEventListener('click',()=>{const i=(state.data.cover.buses||[]).findIndex(x=>String(x.id)===String(b.dataset.manageSourceBusFiles));if(i>=0)manageBusFiles(i);}));
  $$('[data-edit-source-bus]').forEach(b=>b.addEventListener('click',()=>{const i=(state.data.cover.buses||[]).findIndex(x=>String(x.id)===String(b.dataset.editSourceBus));if(i>=0)editBus(i);}));
  $$('[data-km]').forEach(input=>input.addEventListener('change',async()=>{state.data.budget.carKm[input.dataset.km]=input.value;await saveSection("budget");render();}));
  $$('[data-open-real-purchases]').forEach(b=>b.addEventListener('click',()=>{state.activeTab="purchases";render();requestAnimationFrame(()=>{const target=b.dataset.openRealPurchases==="extra"?document.querySelector('[data-extras-section]'):null;(target||document.documentElement).scrollIntoView?.({top:0,behavior:"smooth",block:"start"});if(!target)window.scrollTo({top:0,behavior:"smooth"});});}));
};
function budgetConceptIconMemory(){
  state.data.budget=state.data.budget||{groups:[]};
  state.data.budget.conceptIconMemory=normalizeBudgetConceptIconMemory(state.data.budget.conceptIconMemory||{});
  return state.data.budget.conceptIconMemory;
}
function rememberedBudgetConceptIcon(name=''){
  const key=budgetConceptIconKey(name);return key?budgetConceptIconMemory()[key]||null:null;
}
function rememberBudgetConceptIcon(name='',value={},options={}){
  const label=String(name||'').trim(),key=budgetConceptIconKey(label);if(!key)return false;
  const memory=budgetConceptIconMemory(),icon=String(value?.icon||'').trim(),iconUrl=String(value?.iconUrl||'').trim();
  if(!icon&&!iconUrl){
    if(options.removeWhenBlank===true&&memory[key]){delete memory[key];return true;}
    return false;
  }
  const next={name:label,icon,iconUrl};
  if(JSON.stringify(memory[key]||null)===JSON.stringify(next))return false;
  memory[key]=next;return true;
}
function bindBudgetConceptIconMemoryForm({defaultIcon=''}={}){
  const form=$('#modal-form',els.modal),nameInput=form?.elements?.name,iconInput=form?.elements?.icon,iconUrlInput=form?.elements?.iconUrl,iconFileInput=form?.elements?.iconFile;
  if(!form||!nameInput||!iconInput||!iconUrlInput)return {applyTo:values=>values,touched:()=>false};
  let touched=false,applying=false;
  const markTouched=()=>{if(!applying)touched=true;};
  iconInput.addEventListener('input',markTouched);iconInput.addEventListener('change',markTouched);
  iconUrlInput.addEventListener('input',markTouched);iconUrlInput.addEventListener('change',markTouched);
  iconFileInput?.addEventListener('change',markTouched);
  const applyRemembered=()=>{
    if(touched)return;
    const saved=rememberedBudgetConceptIcon(nameInput.value);if(!saved)return;
    applying=true;iconInput.value=saved.icon||'';iconUrlInput.value=saved.iconUrl||'';applying=false;
  };
  nameInput.addEventListener('change',applyRemembered);nameInput.addEventListener('blur',applyRemembered);
  return {
    touched:()=>touched,
    applyTo(values={}){
      if(touched||values.iconFile)return values;
      const saved=rememberedBudgetConceptIcon(values.name);if(!saved)return values;
      const icon=String(values.icon||'').trim(),iconUrl=String(values.iconUrl||'').trim();
      // Los emojis genéricos de los formularios no bloquean la recuperación del logo guardado.
      if(!iconUrl&&(!icon||icon===String(defaultIcon||'').trim())){values.icon=saved.icon||'';values.iconUrl=saved.iconUrl||'';}
      return values;
    }
  };
}

function editBudgetGroup(index=null) {
  const current=index===null?{icon:"💳",color:"#4da3ff",gradient1:"#173b61",gradient2:"#285f91",textColor:"#ffffff"}:state.data.budget.groups[index];
  const isBusGroup=current?.id==='g-bus';
  openForm({title:index===null?"Crear grupo":"Editar grupo",fields:[{name:"name",label:"Nombre",required:true},{name:"icon",label:"Emoji alternativo"},{name:"iconUrl",label:"URL del icono",type:"url",full:true},{name:"iconFile",label:"Subir icono 128×128",type:"file",accept:"image/*",full:true},{name:"color",label:"Color de total",type:"color"},{name:"gradient1",label:"Degradado inicio",type:"color",help:isBusGroup?"En Autobús aeropuerto este color se comparte con la ficha del trayecto para que no vuelva al azul anterior.":""},{name:"gradient2",label:"Degradado fin",type:"color",help:isBusGroup?"En Autobús aeropuerto este color se comparte con la ficha del trayecto para que no vuelva al azul anterior.":""},{name:"textColor",label:"Color del texto del título",type:"color"}],values:{textColor:"#ffffff",...current},onSubmit:async v=>{
    if(v.iconFile)v.iconUrl=await fileToSquareDataUrl(v.iconFile);delete v.iconFile;
    const value={id:current.id||uid("group"),items:current.items||[],...current,...v};
    if(index===null)state.data.budget.groups.push(value);else state.data.budget.groups[index]=value;
    let busVisualChanged=false;
    if(value.id==='g-bus'){
      const bus=(state.data.cover.buses||[]).find(item=>item&&item.visible!==false)||(state.data.cover.buses||[])[0];
      if(bus){
        for(const key of ['gradient1','gradient2','textColor'])if(String(bus[key]||'')!==String(value[key]||'')){bus[key]=value[key];busVisualChanged=true;}
        if(busVisualChanged)bus.styleCustomized=true;
      }
    }
    const budgetSaved=await saveSection("budget");if(budgetSaved===false)throw new Error('No se han podido guardar los colores del grupo en Presupuesto.');
    if(busVisualChanged){const coverSaved=await saveSection('cover');if(coverSaved===false)throw new Error('Se guardó Presupuesto, pero no se pudo sincronizar el color con la ficha del autobús.');}
    render();
  }});
}
function editBudgetItem(groupIndex,itemIndex=null) {
  const current=itemIndex===null?{status:"unpaid",source:"manual",icon:"",iconUrl:""}:state.data.budget.groups[groupIndex].items[itemIndex];
  let iconMemoryBinding=null;
  openForm({title:itemIndex===null?"Añadir concepto":"Editar concepto",fields:[
    {name:"name",label:"Concepto",required:true},
    {name:"icon",label:"Emoji alternativo"},
    {name:"iconUrl",label:"URL del icono",type:"url",full:true},
    {name:"iconFile",label:"Subir icono 128×128",type:"file",accept:"image/*",full:true,help:"Opcional. Si no añades uno, la app reutiliza el último icono guardado para este concepto; si no existe, usa el icono del grupo."},
    {name:"detail",label:"Detalle",full:true},
    {name:"amount",label:"Importe",type:"number",step:"0.01"},
    {name:"status",label:"Estado",type:"select",options:[{value:"paid",label:"Pagado"},{value:"unpaid",label:"No pagado"}]},
    {name:"source",label:"Origen del importe",type:"select",options:[{value:"manual",label:"Manual"},{value:"shopping",label:"Total previsto de Lista de compra"}],help:"Las compras, otros gastos reales y los Extras creados desde Compra real aparecen automáticamente; no hace falta duplicarlos aquí."},
    {name:"url",label:"Enlace web",type:"url",full:true},
    {name:"fileUrl",label:"Enlace a archivo, PDF o Google Drive",type:"url",full:true,driveSelect:true}
  ],values:{...current,source:current.source||"manual"},onSubmit:async v=>{
    if(v.iconFile)v.iconUrl=await fileToSquareDataUrl(v.iconFile);
    iconMemoryBinding?.applyTo(v);delete v.iconFile;
    if(v.source==="manual")delete v.source;
    const value={id:current.id||uid("item"),...current,...v};
    rememberBudgetConceptIcon(value.name,value,{removeWhenBlank:itemIndex!==null&&iconMemoryBinding?.touched()===true});
    if(itemIndex===null)state.data.budget.groups[groupIndex].items.push(value);else state.data.budget.groups[groupIndex].items[itemIndex]=value;
    await saveSection("budget");render();
  }});
  iconMemoryBinding=bindBudgetConceptIconMemoryForm({defaultIcon:''});
}
function uploadBudgetIcon(groupIndex,itemIndex) {
  const input=document.createElement('input');input.type='file';input.accept='image/*';
  input.addEventListener('change',async()=>{const file=input.files?.[0];if(!file)return;try{toast('Preparando icono…');const item=state.data.budget.groups[groupIndex].items[itemIndex];item.iconUrl=await fileToSquareDataUrl(file);await saveSection('budget');render();toast('Icono guardado.');}catch(error){toast(error.message,'error');}});input.click();
}

function uploadBudgetFile(groupIndex,itemIndex) {
  const input=document.createElement('input');input.type='file';input.accept='application/pdf,image/*';
  input.addEventListener('change',async()=>{const file=input.files?.[0];if(!file)return;try{toast('Subiendo archivo…');const result=await state.provider.uploadFile(file,'budget');const item=state.data.budget.groups[groupIndex].items[itemIndex];item.fileUrl=result.url;item.fileStoragePath=result.path;await saveSection('budget');render();toast('Archivo enlazado al presupuesto.');}catch(error){toast(error.message,'error');}});input.click();
}

function checkedLastIndexed(items=[]) {
  return (Array.isArray(items)?items:[]).map((item,index)=>({item,index})).sort((a,b)=>Number(Boolean(a.item?.checked))-Number(Boolean(b.item?.checked)));
}

function reorderSuitcaseChecklist(list){
  if(!list)return;
  const rows=[...list.querySelectorAll(':scope > .check-row')];
  rows.sort((a,b)=>{
    const aChecked=Boolean(a.querySelector('[data-suitcase-check]')?.checked);
    const bChecked=Boolean(b.querySelector('[data-suitcase-check]')?.checked);
    if(aChecked!==bChecked)return Number(aChecked)-Number(bChecked);
    const aIndex=num(String(a.dataset.sortItem||'').split('|').at(-1));
    const bIndex=num(String(b.dataset.sortItem||'').split('|').at(-1));
    return aIndex-bIndex;
  });
  rows.forEach(row=>list.appendChild(row));
}

function suitcaseSubgroupMeta(group,subgroupId=''){
  const id=String(subgroupId||'');
  return (group?.subgroups||[]).find(subgroup=>String(subgroup.id)===id)||null;
}
function suitcaseSubgroupOptions(group,{includeGeneral=true}={}){
  const out=includeGeneral?[{value:'',label:'General · sin subgrupo'}]:[];
  for(const subgroup of group?.subgroups||[])out.push({value:String(subgroup.id),label:`${subgroup.icon?`${subgroup.icon} `:''}${subgroup.name}`});
  return out;
}
function suitcaseGroupBuckets(group){
  const subgroups=Array.isArray(group?.subgroups)?group.subgroups:[];
  const buckets=[{id:'',name:'General',icon:'',color:group?.color||'#4da3ff',items:[]} ,...subgroups.map(subgroup=>({...subgroup,items:[]}))];
  const byId=new Map(buckets.map(bucket=>[String(bucket.id||''),bucket]));
  (group?.items||[]).forEach((item,index)=>{
    const id=byId.has(String(item?.subgroupId||''))?String(item.subgroupId||''):'';
    byId.get(id).items.push({item,index});
  });
  if(!subgroups.length)return [buckets[0]];
  return buckets.filter(bucket=>bucket.id||bucket.items.length);
}
function suitcaseCheckedLastEntries(entries=[]){
  return [...(Array.isArray(entries)?entries:[])].sort((a,b)=>Number(Boolean(a?.item?.checked))-Number(Boolean(b?.item?.checked)));
}
function suitcaseBucketMarkup(key,gIndex,group,bucket){
  const subgroupId=String(bucket.id||''),isGeneral=!subgroupId,checked=bucket.items.filter(entry=>entry.item.checked).length;
  const showHeading=(group.subgroups||[]).length>0;
  const subgroupIcon=bucket.iconUrl?resilientImageMarkup(bucket.iconUrl,'suitcase-subgroup-icon-image',bucket.icon?`<span class="suitcase-subgroup-icon-emoji">${esc(bucket.icon)}</span>`:'',true):(bucket.icon?`<span class="suitcase-subgroup-icon-emoji">${esc(bucket.icon)}</span>`:'');
  const heading=showHeading?`<div class="suitcase-subgroup-head" style="--subgroup-color:${esc(bucket.color||group.color||'#4da3ff')};--subgroup-text:${esc(bucket.textColor||group.textColor||'#ffffff')}"><div class="suitcase-subgroup-title"><span class="suitcase-subgroup-name">${subgroupIcon}${subgroupIcon?' ':''}${esc(bucket.name||'General')}</span><small data-suitcase-subgroup-count="${esc(key)}:${gIndex}:${esc(subgroupId)}">${checked}/${bucket.items.length}</small></div>${canEdit()?`<div class="row-actions"><button class="mini-btn" data-add-suitcase-subgroup-item="${esc(key)}:${gIndex}:${esc(subgroupId)}" title="Añadir elemento a ${esc(bucket.name||'General')}">＋</button>${!isGeneral?`<button class="mini-btn" data-edit-suitcase-subgroup="${esc(key)}:${gIndex}:${esc(subgroupId)}" title="Editar subgrupo">✎</button><button class="mini-btn" data-delete-suitcase-subgroup="${esc(key)}:${gIndex}:${esc(subgroupId)}" title="Eliminar subgrupo">×</button>`:''}</div>`:''}</div>`:'';
  const rows=suitcaseCheckedLastEntries(bucket.items).map(entry=>{const item=entry.item,index=entry.index;return `<div class="check-row ${item.checked?'checked':''}" data-sort-item="suitcase|${encodeURIComponent(key)}|${gIndex}|${index}"><input type="checkbox" data-suitcase-check="${key}:${gIndex}:${index}" ${item.checked?'checked':''} ${roleCanEdit()?'':'disabled'}><span class="check-name">${esc(item.name)}</span>${canEdit()?`<div class="row-actions">${sortDragHandle(`suitcase|${encodeURIComponent(key)}|${gIndex}|${index}`,'Arrastrar elemento · también entre subgrupos y bloques')}<button class="mini-btn" data-transfer-suitcase-item="${key}:${gIndex}:${index}" title="Mover a otra maleta, bloque o subgrupo" aria-label="Mover ${esc(item.name)} a otra maleta, bloque o subgrupo">⇄</button><button class="mini-btn" data-edit-suitcase-item="${key}:${gIndex}:${index}">✎</button><button class="mini-btn" data-delete-suitcase-item="${key}:${gIndex}:${index}">×</button></div>`:''}</div>`;}).join('');
  return `<section class="suitcase-subgroup ${isGeneral?'is-general':''}" data-suitcase-subgroup="${esc(subgroupId)}">${heading}<div class="check-list" data-sort-container="suitcase|${encodeURIComponent(key)}|${gIndex}|sg=${encodeURIComponent(subgroupId)}|end">${rows}</div></section>`;
}
function renderSuitcase(key,title) {
  const groups=state.data.suitcases[key]||[];
  const total=sum(groups.map(g=>g.items.length)), done=sum(groups.map(g=>g.items.filter(i=>i.checked).length));
  const overallPct=total?Math.round(done/total*100):0;
  const overallProgress=`<section class="suitcase-overall-progress" aria-label="Progreso total de ${esc(title)}"><div class="suitcase-overall-head"><span>Progreso total</span><strong>${done}/${total} · ${overallPct}%</strong></div><div class="suitcase-overall-bar"><span style="width:${overallPct}%"></span></div></section>`;
  return `${lockedBanner()}${pageHead(title,`${done} de ${total} elementos preparados`,`<button class="btn secondary pdf-action-btn" data-export-suitcase-pdf="${key}">${pdfFileIconMarkup("pdf-action-icon")} Generar PDF</button>${canEdit()?`<button class="btn primary canary-action-btn" data-add-suitcase-group="${key}">＋ Crear grupo</button>`:""}`)}${overallProgress}
  <div class="suitcase-grid">${groups.map((group,gIndex)=>{const checked=group.items.filter(i=>i.checked).length,pct=group.items.length?checked/group.items.length*100:0;return `<article class="card suitcase-group-card" style="--group-color:${esc(group.color||'#4da3ff')}"><div class="section-title" style="--g1:${esc(group.color||'#4da3ff')};--g2:color-mix(in srgb,${esc(group.color||'#4da3ff')} 45%,#111);--title-text:${esc(group.textColor||'#ffffff')}"><span class="section-title-label">${iconMarkup(group.icon||'🧳',group.iconUrl,'section-icon')} ${esc(group.name)}</span>${editButtons(`<div class="section-actions"><button class="mini-btn" data-add-suitcase-item="${key}:${gIndex}" title="Añadir elemento">＋</button><button class="mini-btn" data-add-suitcase-subgroup="${key}:${gIndex}" title="Crear subgrupo">⊞</button><button class="mini-btn" data-edit-suitcase-group="${key}:${gIndex}" title="Editar grupo">✎</button><button class="mini-btn" data-delete-suitcase-group="${key}:${gIndex}" title="Eliminar grupo">×</button></div>`)}</div><div class="progress-bar"><span style="width:${pct}%"></span></div><div class="progress-label">${checked}/${group.items.length}</div><div class="suitcase-subgroup-list">${suitcaseGroupBuckets(group).map(bucket=>suitcaseBucketMarkup(key,gIndex,group,bucket)).join('')}</div>${roleCanEdit()?`<div class="suitcase-uncheck-all-wrap"><button class="btn secondary suitcase-uncheck-all-btn" data-uncheck-suitcase-group="${key}:${gIndex}" ${checked?'':'disabled'}>Desmarcar todas</button></div>`:''}</article>`;}).join('')}</div>`;
}
["suitcase-common","suitcase-mikel","suitcase-nerea"].forEach(tab=>binders[tab]=bindSuitcase);
function updateSuitcaseSubgroupCountDom(key,groupIndex,subgroupId=''){
  const group=state.data.suitcases?.[key]?.[groupIndex];if(!group)return;
  const items=(group.items||[]).filter(item=>String(item.subgroupId||'')===String(subgroupId||''));
  const checked=items.filter(item=>item.checked).length;
  const selector=`[data-suitcase-subgroup-count="${CSS.escape(String(key))}:${groupIndex}:${CSS.escape(String(subgroupId||''))}"]`;
  const label=$(selector);if(label)label.textContent=`${checked}/${items.length}`;
}
function bindSuitcase() {
  $$('[data-add-suitcase-group]').forEach(b=>b.addEventListener('click',()=>editSuitcaseGroup(b.dataset.addSuitcaseGroup)));
  $$('[data-edit-suitcase-group]').forEach(b=>b.addEventListener('click',()=>{const[k,g]=b.dataset.editSuitcaseGroup.split(':');editSuitcaseGroup(k,num(g));}));
  $$('[data-delete-suitcase-group]').forEach(b=>b.addEventListener('click',async()=>{const[k,g]=b.dataset.deleteSuitcaseGroup.split(':');if(confirmAction("¿Eliminar este grupo?")){state.data.suitcases[k].splice(num(g),1);await saveSection("suitcases");render();}}));
  $$('[data-add-suitcase-subgroup]').forEach(b=>b.addEventListener('click',()=>{const[k,g]=b.dataset.addSuitcaseSubgroup.split(':');editSuitcaseSubgroup(k,num(g));}));
  $$('[data-edit-suitcase-subgroup]').forEach(b=>b.addEventListener('click',()=>{const[k,g,id]=b.dataset.editSuitcaseSubgroup.split(':');editSuitcaseSubgroup(k,num(g),id);}));
  $$('[data-add-suitcase-subgroup-item]').forEach(b=>b.addEventListener('click',()=>{const[k,g,id]=b.dataset.addSuitcaseSubgroupItem.split(':');editSuitcaseItem(k,num(g),null,id);}));
  $$('[data-delete-suitcase-subgroup]').forEach(b=>b.addEventListener('click',async()=>{const[k,g,id]=b.dataset.deleteSuitcaseSubgroup.split(':');const group=state.data.suitcases?.[k]?.[num(g)];if(!group)return;if(!confirmAction('¿Eliminar este subgrupo? Sus elementos pasarán a General.'))return;group.subgroups=(group.subgroups||[]).filter(subgroup=>String(subgroup.id)!==String(id));for(const item of group.items||[])if(String(item.subgroupId||'')===String(id))item.subgroupId='';await saveSection('suitcases');render();}));
  $$('[data-add-suitcase-item]').forEach(b=>b.addEventListener('click',()=>{const[k,g]=b.dataset.addSuitcaseItem.split(':');editSuitcaseItem(k,num(g));}));
  $$('[data-edit-suitcase-item]').forEach(b=>b.addEventListener('click',()=>{const[k,g,i]=b.dataset.editSuitcaseItem.split(':');editSuitcaseItem(k,num(g),num(i));}));
  $$('[data-delete-suitcase-item]').forEach(b=>b.addEventListener('click',async()=>{const[k,g,i]=b.dataset.deleteSuitcaseItem.split(':');if(!confirmAction('¿Eliminar este elemento de la maleta?'))return;state.data.suitcases[k][num(g)].items.splice(num(i),1);await saveSection("suitcases");render();}));
  $$('[data-uncheck-suitcase-group]').forEach(button=>button.addEventListener('click',async()=>{
    const [k,g]=button.dataset.uncheckSuitcaseGroup.split(':'),groupIndex=num(g),group=state.data.suitcases?.[k]?.[groupIndex];
    if(!group)return;
    const previous=(group.items||[]).map(item=>Boolean(item.checked));
    if(!previous.some(Boolean))return;
    const position=captureSuitcaseViewPosition();
    (group.items||[]).forEach(item=>{item.checked=false;});
    button.disabled=true;
    try{
      await saveSection('suitcases');
      renderKeepingSuitcasePosition(position);
      toast(`${group.name||'Maleta'} · todas desmarcadas.`);
    }catch(error){
      (group.items||[]).forEach((item,index)=>{item.checked=previous[index];});
      renderKeepingSuitcasePosition(position);
      toast(error.message||'No se han podido desmarcar los elementos.','error');
    }
  }));
  $$('[data-suitcase-check]').forEach(input=>input.addEventListener('change',async()=>{
    const[k,g,i]=input.dataset.suitcaseCheck.split(':'),groupIndex=num(g),itemIndex=num(i);
    const group=state.data.suitcases?.[k]?.[groupIndex],item=group?.items?.[itemIndex];
    if(!group||!item)return;
    item.checked=input.checked;
    const row=input.closest('.check-row');
    row?.classList.toggle('checked',input.checked);
    const card=input.closest('.suitcase-group-card'),groupChecked=group.items.filter(entry=>entry.checked).length,groupPct=group.items.length?groupChecked/group.items.length*100:0;
    const groupBar=card?.querySelector('.progress-bar > span'),groupLabel=card?.querySelector('.progress-label');
    if(groupBar)groupBar.style.width=`${groupPct}%`;
    if(groupLabel)groupLabel.textContent=`${groupChecked}/${group.items.length}`;
    updateSuitcaseSubgroupCountDom(k,groupIndex,item.subgroupId||'');
    const groups=state.data.suitcases?.[k]||[],total=sum(groups.map(entry=>entry.items?.length||0)),done=sum(groups.map(entry=>(entry.items||[]).filter(child=>child.checked).length)),overallPct=total?Math.round(done/total*100):0;
    const overallLabel=$('.suitcase-overall-head strong'),overallBar=$('.suitcase-overall-bar > span'),pageSubtitle=$('.page-head p');
    if(overallLabel)overallLabel.textContent=`${done}/${total} · ${overallPct}%`;
    if(overallBar)overallBar.style.width=`${overallPct}%`;
    if(pageSubtitle)pageSubtitle.textContent=`${done} de ${total} elementos preparados`;
    const checklist=row?.closest('.check-list');
    reorderSuitcaseChecklist(checklist);
    try{await saveSection('suitcases');}catch(error){
      item.checked=!input.checked;input.checked=item.checked;row?.classList.toggle('checked',item.checked);reorderSuitcaseChecklist(checklist);updateSuitcaseSubgroupCountDom(k,groupIndex,item.subgroupId||'');toast(error.message||'No se ha podido guardar el cambio.','error');
    }
  }));
  $$('[data-move-suitcase-item]').forEach(b=>b.addEventListener('click',async()=>{const[k,g,i,d]=b.dataset.moveSuitcaseItem.split(':');moveArrayItem(state.data.suitcases[k][num(g)].items,num(i),num(d));await saveSection('suitcases');render();}));
  $$('[data-transfer-suitcase-item]').forEach(b=>b.addEventListener('click',()=>{const[k,g,i]=b.dataset.transferSuitcaseItem.split(':');openSuitcaseMoveDialog(k,num(g),num(i));}));
  $$('[data-export-suitcase-pdf]').forEach(b=>b.addEventListener('click',()=>generateSuitcasePdf(b.dataset.exportSuitcasePdf)));
}
const SUITCASE_LABELS={common:"Maleta común",mikel:"Maleta Mikel",nerea:"Maleta Nerea"};
function openSuitcaseMoveDialog(sourceKey,sourceGroupIndex,itemIndex){
  const sourceGroup=state.data.suitcases?.[sourceKey]?.[sourceGroupIndex],item=sourceGroup?.items?.[itemIndex];
  if(!sourceGroup||!item)return;
  const options=[];
  for(const targetKey of ['common','mikel','nerea']){
    const targetGroups=state.data.suitcases?.[targetKey]||[];
    targetGroups.forEach((group,targetGroupIndex)=>{
      const subgroupOptions=suitcaseSubgroupOptions(group,{includeGeneral:true});
      subgroupOptions.forEach(subgroup=>{
        const sameLocation=targetKey===sourceKey&&targetGroupIndex===sourceGroupIndex&&String(subgroup.value||'')===String(item.subgroupId||'');
        if(sameLocation)return;
        options.push({value:`${targetKey}:${targetGroupIndex}:${encodeURIComponent(subgroup.value||'')}`,label:`${SUITCASE_LABELS[targetKey]} · ${group.name||`Bloque ${targetGroupIndex+1}`} · ${subgroup.label}`});
      });
    });
  }
  if(!options.length){toast('No hay otro destino disponible.','error');return;}
  openForm({title:`Mover «${item.name}»`,submitText:'Mover',fields:[{name:'destination',label:'Mover a',type:'select',options,required:true,full:true,help:'Puedes mover el elemento entre maletas, bloques y subgrupos.'}],values:{destination:options[0].value},onSubmit:async v=>{
    const [targetKey,targetGroupRaw,targetSubgroupRaw='']=String(v.destination||'').split(':'),targetGroupIndex=num(targetGroupRaw),targetSubgroupId=decodeURIComponent(targetSubgroupRaw||'');
    const currentSource=state.data.suitcases?.[sourceKey]?.[sourceGroupIndex],targetGroup=state.data.suitcases?.[targetKey]?.[targetGroupIndex];
    if(!currentSource?.items?.[itemIndex]||!targetGroup)throw new Error('El destino ya no está disponible. Vuelve a intentarlo.');
    const [moved]=currentSource.items.splice(itemIndex,1);moved.subgroupId=targetSubgroupId;
    targetGroup.items.push(moved);
    await saveSection('suitcases');
    render();
    const subgroup=suitcaseSubgroupMeta(targetGroup,targetSubgroupId);
    toast(`Movido a ${SUITCASE_LABELS[targetKey]} · ${targetGroup.name}${subgroup?` · ${subgroup.name}`:' · General'}.`);
  }});
}
function editSuitcaseGroup(key,index=null) {
  const current=index===null?{icon:"🧳",color:"#4da3ff",textColor:"#ffffff",subgroups:[]}:state.data.suitcases[key][index];
  openForm({title:index===null?"Crear grupo de maleta":"Editar grupo",fields:[{name:"name",label:"Nombre",required:true},{name:"icon",label:"Emoji alternativo"},{name:"iconUrl",label:"URL del icono",type:"url",full:true},{name:"iconFile",label:"Subir icono 128×128",type:"file",accept:"image/*",full:true},{name:"color",label:"Color",type:"color"},{name:"textColor",label:"Color del texto del título",type:"color"}],values:{textColor:"#ffffff",...current},onSubmit:async v=>{if(v.iconFile)v.iconUrl=await fileToSquareDataUrl(v.iconFile);delete v.iconFile;const value={id:current.id||uid("suitcase-group"),items:current.items||[],subgroups:current.subgroups||[],...current,...v};if(index===null)state.data.suitcases[key].push(value);else state.data.suitcases[key][index]=value;await saveSection("suitcases");render();}});
}
function editSuitcaseSubgroup(key,groupIndex,subgroupId=null){
  const group=state.data.suitcases?.[key]?.[groupIndex];if(!group)return;
  const index=subgroupId===null?-1:(group.subgroups||[]).findIndex(subgroup=>String(subgroup.id)===String(subgroupId));
  const current=index<0?{name:'',icon:'',iconUrl:'',color:group.color||'#4da3ff',textColor:group.textColor||'#ffffff'}:group.subgroups[index];
  openForm({title:index<0?'Crear subgrupo':'Editar subgrupo',fields:[{name:'name',label:'Nombre del subgrupo',required:true,full:true},{name:'icon',label:'Emoji alternativo'},{name:'iconUrl',label:'URL del icono PNG',type:'url',full:true},{name:'iconFile',label:'Subir icono 128×128',type:'file',accept:'image/*',full:true},{name:'color',label:'Color',type:'color'},{name:'textColor',label:'Color del texto',type:'color'}],values:{textColor:'#ffffff',...current},onSubmit:async v=>{
    if(v.iconFile)v.iconUrl=await fileToSquareDataUrl(v.iconFile);delete v.iconFile;
    const value={id:current.id||uid('suitcase-subgroup'),...current,...v};
    group.subgroups=Array.isArray(group.subgroups)?group.subgroups:[];
    if(index<0)group.subgroups.push(value);else group.subgroups[index]=value;
    await saveSection('suitcases');render();
  }});
}
function editSuitcaseItem(key,groupIndex,itemIndex=null,initialSubgroupId='') {
  const group=state.data.suitcases?.[key]?.[groupIndex];if(!group)return;
  const current=itemIndex===null?{checked:false,subgroupId:String(initialSubgroupId||'')}:group.items[itemIndex];
  const fields=[{name:"name",label:"Elemento",required:true,full:true},{name:'subgroupId',label:'Subgrupo',type:'select',options:suitcaseSubgroupOptions(group,{includeGeneral:true}),full:true},{name:"checked",label:"Ya preparado",type:"checkbox",full:true}];
  openForm({title:itemIndex===null?"Añadir elemento":"Editar elemento",fields,values:current,onSubmit:async v=>{const value={id:current.id||uid("suitcase-item"),...current,...v};if(itemIndex===null)group.items.push(value);else group.items[itemIndex]=value;await saveSection("suitcases");render();}});
}

function storeTotal(store) { return sum(store.products.map(p=>num(p.quantity)*num(p.unitPrice))); }
function workerProductImageUrl(productUrl, revision="", productName="") {
  const worker=String(state.data.settings.priceWorkerUrl||DEFAULT_PRICE_WORKER_URL).trim();
  if(!isValidUrl(worker)||!isValidUrl(productUrl))return "";
  const proxy=new URL(worker);
  proxy.searchParams.set("action","product-image");
  proxy.searchParams.set("url",productUrl);
  if(productName)proxy.searchParams.set("productName",String(productName));
  if(revision)proxy.searchParams.set("rev",String(revision));
  return proxy.href;
}
function productImageDisplayUrl(product={}) {
  if(productUsesAutomaticImage(product)) {
    // Las URLs de imagen ya resueltas se muestran directamente. Un <img> puede
    // cargar recursos cross-origin sin CORS; si el CDN bloquea hotlink, el
    // manejador de error prueba después el proxy del Worker. Esto evita que un
    // fallo temporal del proxy deje vacías todas las miniaturas a la vez.
    if(isValidUrl(product.imageUrl)) return String(product.imageUrl);
    if(isValidUrl(product.url)) return workerProductImageUrl(product.url,product.imageUpdatedAt||"",product.name||"");
  }
  return isImageSource(product.imageUrl)?String(product.imageUrl):"";
}
function renderProductThumb(product,storeIndex,productIndex) {
  const src=productImageDisplayUrl(product);
  if(!src)return "";
  return `<img class="product-thumb clickable-image" src="${esc(src)}" data-product-image="${storeIndex}:${productIndex}" data-product-image-source="${esc(product.imageSource||"")}" alt="${esc(product.name)}" data-image-popup="${esc(src)}">`;
}
function likelyOcrShoppingCopies(){
  const ticketItems=state.data.purchases?.ticketItems||[];
  const matches=[];
  for(const [storeIndex,store] of (state.data.shopping?.stores||[]).entries()){
    const storeKey=normalizedKey(store.name);
    for(const [productIndex,product] of (store.products||[]).entries()){
      if(!product?.checked||product?.url||product?.imageUrl||product?.priceUpdatedAt)continue;
      const productKey=receiptProductFingerprint(product.name);
      const unitCents=Math.round(num(product.unitPrice)*100);
      if(!productKey||unitCents<=0)continue;
      const found=ticketItems.some(item=>normalizedKey(item.store)===storeKey&&receiptProductFingerprint(item.name)===productKey&&receiptUnitPriceCents(item)===unitCents);
      if(found)matches.push({storeIndex,productIndex,name:product.name});
    }
  }
  return matches;
}
function countLikelyOcrShoppingCopies(){return likelyOcrShoppingCopies().length;}
async function cleanLikelyOcrShoppingCopies(){
  const matches=likelyOcrShoppingCopies();
  if(!matches.length){toast('No se han encontrado copias OCR en Lista de la compra.');return;}
  if(!confirmAction(`Se retirarán ${matches.length} producto${matches.length===1?'':'s'} que coincide${matches.length===1?'':'n'} exactamente con líneas OCR y que no tiene${matches.length===1?'':'n'} enlace ni precio actualizado. ¿Continuar?`))return;
  const grouped=new Map();
  for(const match of matches){if(!grouped.has(match.storeIndex))grouped.set(match.storeIndex,[]);grouped.get(match.storeIndex).push(match.productIndex);}
  for(const [storeIndex,indexes] of grouped){for(const index of indexes.sort((a,b)=>b-a))state.data.shopping.stores[storeIndex].products.splice(index,1);}
  await saveSection('shopping');render();toast(`${matches.length} copia${matches.length===1?'':'s'} OCR retirada${matches.length===1?'':'s'} de Lista de la compra.`);
}
function shoppingTracking(){
  const shopping=state.data.shopping||(state.data.shopping={stores:[]});
  const current=shopping.priceTracking||{};
  shopping.priceTracking={
    schedule:["daily","every2days","manual"].includes(current.schedule)?current.schedule:"daily",
    lastRunAt:String(current.lastRunAt||""),lastAutoRunAt:String(current.lastAutoRunAt||""),
    snapshots:Array.isArray(current.snapshots)?current.snapshots.slice(-SHOPPING_HISTORY_MAX_SNAPSHOTS):[],
    changes:Array.isArray(current.changes)?current.changes.slice(-SHOPPING_HISTORY_MAX_CHANGES):[],
    lastChanges:Array.isArray(current.lastChanges)?current.lastChanges:[],lastSource:String(current.lastSource||"")
  };
  return shopping.priceTracking;
}
function shoppingProductMap(){
  const map=new Map();
  for(const [storeIndex,store] of (state.data.shopping?.stores||[]).entries())for(const [productIndex,product] of (store.products||[]).entries())if(product?.id)map.set(String(product.id),{store,storeIndex,product,productIndex});
  return map;
}
function shoppingCurrentPriceMap(){const out={};for(const {product} of shoppingProductMap().values())out[product.id]=num(product.unitPrice);return out;}
function shoppingSnapshot(source="manual",at=new Date().toISOString()){
  const stores={},prices={};let total=0;
  for(const store of state.data.shopping?.stores||[]){let subtotal=0;for(const product of store.products||[]){const price=num(product.unitPrice),qty=num(product.quantity);subtotal+=price*qty;if(product.id)prices[product.id]=Number(price.toFixed(4));}const id=store.id||normalizedKey(store.name);stores[id]=Number(subtotal.toFixed(2));total+=subtotal;}
  return {t:at,source,total:Number(total.toFixed(2)),stores,prices};
}
function shoppingChangeRows(beforePrices={},at=new Date().toISOString()){
  const rows=[];
  for(const {store,product} of shoppingProductMap().values()){
    if(!(product.id in beforePrices))continue;
    const previous=num(beforePrices[product.id]),current=num(product.unitPrice),delta=current-previous;
    if(Math.abs(delta)<0.005)continue;
    const quantity=Math.max(0,num(product.quantity));
    rows.push({t:at,storeId:store.id||normalizedKey(store.name),productId:product.id,name:product.name||"Producto",previous:Number(previous.toFixed(4)),current:Number(current.toFixed(4)),delta:Number(delta.toFixed(4)),pct:previous>0?Number((delta/previous*100).toFixed(2)):null,quantity:Number(quantity.toFixed(3)),impact:Number((delta*quantity).toFixed(4))});
  }
  return rows;
}
function recordShoppingPriceSnapshot({source="manual",beforePrices=null,at=new Date().toISOString()}={}){
  const tracking=shoppingTracking(),snapshot=shoppingSnapshot(source,at),changes=beforePrices?shoppingChangeRows(beforePrices,at):[];
  tracking.snapshots=[...(tracking.snapshots||[]).filter(row=>String(row?.t||"")!==at),snapshot].slice(-SHOPPING_HISTORY_MAX_SNAPSHOTS);
  tracking.changes=[...(tracking.changes||[]),...changes].slice(-SHOPPING_HISTORY_MAX_CHANGES);
  tracking.lastChanges=changes;tracking.lastRunAt=at;tracking.lastSource=source;if(source==="auto")tracking.lastAutoRunAt=at;
  return {snapshot,changes};
}
function shoppingScheduleLabel(value=shoppingTracking().schedule){return value==="daily"?"Diaria":value==="every2days"?"Cada 2 días":"Solo manual";}
function shoppingAutomaticDue(){
  const tracking=shoppingTracking(),days=tracking.schedule==="daily"?1:tracking.schedule==="every2days"?2:0;if(!days)return false;
  const stamp=Date.parse(tracking.lastAutoRunAt||tracking.lastRunAt||"");if(!Number.isFinite(stamp))return true;return Date.now()-stamp>=days*86400000;
}
function shoppingNextAutomaticText(){
  const tracking=shoppingTracking(),days=tracking.schedule==="daily"?1:tracking.schedule==="every2days"?2:0;if(!days)return "Automático desactivado";
  const stamp=Date.parse(tracking.lastAutoRunAt||tracking.lastRunAt||"");if(!Number.isFinite(stamp))return "Pendiente en la próxima apertura";
  const next=new Date(stamp+days*86400000);return `Próxima revisión al abrir la app después de ${formatDate(next.toISOString(),{day:"2-digit",month:"short",hour:"2-digit",minute:"2-digit"})}`;
}
function shoppingHistoryPeriodDays(){const raw=String(state.shoppingHistoryFilters?.period||"30");return raw==="all"?Infinity:Math.max(1,num(raw)||30);}
function shoppingHistorySnapshots(){
  const rows=[...(shoppingTracking().snapshots||[])].filter(x=>x?.t).sort((a,b)=>Date.parse(a.t)-Date.parse(b.t)),days=shoppingHistoryPeriodDays();
  if(!Number.isFinite(days))return rows;const cutoff=Date.now()-days*86400000;return rows.filter(row=>Date.parse(row.t)>=cutoff);
}
function shoppingStoreById(id){return (state.data.shopping?.stores||[]).find(store=>String(store.id||normalizedKey(store.name))===String(id))||null;}
function shoppingStoreLogoMarkup(store,cls="shopping-history-store-logo"){
  if(isImageSource(store?.logoUrl))return `<img class="${cls}" src="${esc(store.logoUrl)}" alt="${esc(store.name||"Supermercado")}" data-image-popup="${esc(store.logoUrl)}">`;
  return `<span class="${cls} is-icon">${esc(store?.icon||"🛒")}</span>`;
}
function shoppingDiffMarkup(current,previous,{compact=false}={}){
  if(previous===null||previous===undefined||!Number.isFinite(Number(previous)))return `<span class="shopping-history-diff neutral">Sin referencia anterior</span>`;
  const diff=num(current)-num(previous),pct=num(previous)>0?diff/num(previous)*100:0,cls=diff<-.004?"better":diff>.004?"worse":"neutral";
  if(Math.abs(diff)<.005)return `<span class="shopping-history-diff neutral">Sin cambio</span>`;
  return `<span class="shopping-history-diff ${cls}">${diff>0?"+":""}${formatMoney(diff)}${compact?"":` · ${pct>0?"+":""}${pct.toFixed(1)}%`}</span>`;
}
function shoppingSvgSeries(rows,series,{width=760,height=220,padX=44,padY=30}={}){
  if(rows.length<2)return '<p class="help-text">El gráfico aparecerá cuando haya al menos dos comprobaciones guardadas.</p>';
  const all=[];for(const row of rows)for(const item of series){const v=item.value(row);if(Number.isFinite(v)&&v>=0)all.push(v);}if(!all.length)return '<p class="help-text">No hay datos para el periodo seleccionado.</p>';
  const lo=Math.min(...all),hi=Math.max(...all),range=Math.max(.5,hi-lo),min=Math.max(0,lo-range*.12),max=hi+range*.12;
  const xFor=i=>padX+(width-padX*2)*(rows.length===1?0:i/(rows.length-1)),yFor=v=>padY+(height-padY*2)*(1-(v-min)/(max-min));
  const paths=series.map((item,index)=>{const pts=rows.map((row,i)=>({x:xFor(i),y:yFor(item.value(row)),v:item.value(row),t:row.t})).filter(p=>Number.isFinite(p.v));if(pts.length<2)return "";const d=pts.map((p,i)=>`${i?"L":"M"} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(" ");return `<path d="${d}" class="shopping-history-chart-line series-${index}" style="--series-color:${esc(item.color||"#4da3ff")}" fill="none"/><g>${pts.map(p=>{const text=`${item.label} · ${formatDate(p.t,{day:"2-digit",month:"short"})} · ${formatMoney(p.v)}`;return `<circle cx="${p.x.toFixed(1)}" cy="${p.y.toFixed(1)}" r="3.4" class="shopping-history-chart-point series-${index} tracker-chart-hover-point" style="--series-color:${esc(item.color||"#4da3ff")}" tabindex="0" data-tracker-chart-tooltip="${esc(text)}"><title>${esc(text)}</title></circle>`;}).join("")}</g>`;}).join("");
  const first=rows[0],last=rows.at(-1),legend=series.map((item,index)=>`<span><i style="--series-color:${esc(item.color||"#4da3ff")}"></i>${esc(item.label)}</span>`).join("");
  const topValueY=Math.max(16,padY-8);
  return `<div class="shopping-history-chart-legend">${legend}</div><div class="shopping-history-chart-wrap"><svg class="shopping-history-chart" viewBox="0 0 ${width} ${height}" role="img" aria-label="Evolución de precios de la compra"><line x1="${padX}" y1="${height-padY}" x2="${width-padX}" y2="${height-padY}" class="shopping-history-chart-axis"/>${paths}<text x="${padX}" y="${height-7}" class="shopping-history-chart-label">${esc(formatDate(first.t,{day:"2-digit",month:"short"}))}</text><text x="${width-padX}" y="${height-7}" text-anchor="end" class="shopping-history-chart-label">${esc(formatDate(last.t,{day:"2-digit",month:"short"}))}</text><text x="${padX}" y="${topValueY}" class="shopping-history-chart-value">${esc(formatMoney(hi))}</text></svg></div>`;
}
function shoppingTotalsHistoryChart(rows=shoppingHistorySnapshots()){
  const stores=(state.data.shopping?.stores||[]).filter(s=>s.active!==false),series=[{label:"Total",color:state.data.settings?.theme?.warning||"#ffc857",value:r=>num(r.total)},...stores.map(store=>({label:store.name,color:store.color||"#4da3ff",value:r=>num(r.stores?.[store.id||normalizedKey(store.name)] )}))];
  return shoppingSvgSeries(rows,series);
}
function shoppingProductHistory(productId){return shoppingHistorySnapshots().map(row=>({t:row.t,price:Number(row.prices?.[productId])})).filter(x=>Number.isFinite(x.price)&&x.price>=0);}
function shoppingProductMiniChart(productId,color="#4da3ff"){
  const rows=shoppingProductHistory(productId);if(rows.length<2)return '<div class="shopping-product-chart-empty">Sin histórico suficiente</div>';
  return shoppingSvgSeries(rows,[{label:"Precio",color,value:r=>r.price}],{width:360,height:118,padX:22,padY:24});
}
function shoppingHistoryChangesMarkup(){
  const tracking=shoppingTracking(),rows=tracking.lastChanges||[];if(!tracking.lastRunAt)return '<div class="shopping-changes-empty">Todavía no se ha realizado una comprobación de precios.</div>';
  if(!rows.length)return `<div class="shopping-changes-empty success">✓ Sin cambios de precio en la última comprobación · ${esc(formatDate(tracking.lastRunAt,{day:"2-digit",month:"short",hour:"2-digit",minute:"2-digit"}))}</div>`;
  const map=shoppingProductMap(),impact=sum(rows.map(x=>Number.isFinite(Number(x.impact))?num(x.impact):num(x.delta)*Math.max(0,num(map.get(String(x.productId))?.product?.quantity))));
  return `<div class="shopping-changes-summary"><strong>${rows.length} producto${rows.length===1?"":"s"} con cambios</strong><span class="${impact>0?"worse":impact<0?"better":"neutral"}">Impacto en la lista ${impact>0?"+":""}${formatMoney(impact)}</span></div><div class="shopping-change-list">${rows.map(change=>{const found=map.get(String(change.productId)),store=found?.store||shoppingStoreById(change.storeId),product=found?.product||{name:change.name},src=productImageDisplayUrl(product),qty=Number.isFinite(Number(change.quantity))?num(change.quantity):num(product.quantity),lineImpact=Number.isFinite(Number(change.impact))?num(change.impact):num(change.delta)*Math.max(0,qty);return `<article class="shopping-change-row">${src?`<img src="${esc(src)}" alt="${esc(product.name||change.name)}" data-image-popup="${esc(src)}">`:shoppingStoreLogoMarkup(store,"shopping-change-logo")}<div class="shopping-change-main"><strong>${esc(product.name||change.name||"Producto")}</strong><small>${esc(store?.name||"Supermercado")} · ${formatMoney(change.previous)} → ${formatMoney(change.current)}${qty>1?` · ${qty} uds.`:""}</small><small>Impacto en la lista ${lineImpact>0?"+":""}${formatMoney(lineImpact)}</small></div>${shoppingDiffMarkup(change.current,change.previous)}</article>`;}).join("")}</div>`;
}
function shoppingStoreHistoryCards(rows){
  const snapshots=rows||shoppingHistorySnapshots(),current=snapshots.at(-1),previous=snapshots.length>1?snapshots.at(-2):null;
  return `<div class="shopping-history-store-grid">${(state.data.shopping?.stores||[]).filter(s=>s.active!==false).map(store=>{const id=store.id||normalizedKey(store.name),now=current?num(current.stores?.[id]):storeTotal(store),before=previous?num(previous.stores?.[id]):null;return `<article class="card shopping-history-store-card" style="--store-color:${esc(store.color||"#4da3ff")}"><div class="shopping-history-store-head">${shoppingStoreLogoMarkup(store)}<div><strong>${esc(store.name)}</strong><small>${(store.products||[]).length} productos</small></div></div><div class="shopping-history-store-price">${formatMoney(now)}</div>${shoppingDiffMarkup(now,before)}${shoppingSvgSeries(snapshots,[{label:store.name,color:store.color||"#4da3ff",value:r=>num(r.stores?.[id])}],{width:360,height:118,padX:22,padY:24})}</article>`;}).join("")}</div>`;
}
function shoppingProductsHistoryMarkup(){
  const storeFilter=String(state.shoppingHistoryFilters?.store||"all"),query=normalizedKey(state.shoppingHistoryFilters?.query||""),snapshots=shoppingHistorySnapshots(),latest=snapshots.at(-1),previous=snapshots.length>1?snapshots.at(-2):null;
  const cards=[];for(const [storeIndex,store] of (state.data.shopping?.stores||[]).entries())for(const [productIndex,product] of (store.products||[]).entries()){
    const storeId=store.id||normalizedKey(store.name);if(storeFilter!=="all"&&storeId!==storeFilter)continue;if(query&&!normalizedKey(product.name).includes(query))continue;
    const current=latest&&product.id in (latest.prices||{})?num(latest.prices[product.id]):num(product.unitPrice),before=previous&&product.id in (previous.prices||{})?num(previous.prices[product.id]):null,history=shoppingProductHistory(product.id),prices=history.map(x=>x.price),min=prices.length?Math.min(...prices):current,max=prices.length?Math.max(...prices):current,src=productImageDisplayUrl(product);
    cards.push(`<article class="card shopping-product-history-card" style="--store-color:${esc(store.color||"#4da3ff")}"><div class="shopping-product-history-head">${src?`<img class="shopping-product-history-photo" src="${esc(src)}" alt="${esc(product.name)}" data-image-popup="${esc(src)}">`:`<div class="shopping-product-history-photo placeholder">${esc(store.icon||"🛒")}</div>`}<div class="shopping-product-history-title"><div class="shopping-product-store-line">${shoppingStoreLogoMarkup(store,"shopping-product-store-logo")}<span>${esc(store.name)}</span></div><strong>${esc(product.name)}</strong><small>${num(product.quantity).toLocaleString("es-ES")} ${esc(product.unit||"ud.")} · ${history.length} registros</small></div></div><div class="shopping-product-price-row"><div><span>Actual</span><strong>${formatMoney(current)}</strong></div><div><span>Anterior</span><strong>${before===null?"—":formatMoney(before)}</strong></div><div><span>Mín. / Máx.</span><strong>${formatMoney(min)} / ${formatMoney(max)}</strong></div></div>${shoppingDiffMarkup(current,before)}<div class="shopping-product-mini-chart">${shoppingProductMiniChart(product.id,store.color||"#4da3ff")}</div></article>`);
  }
  return cards.length?`<div class="shopping-product-history-grid">${cards.join("")}</div>`:'<div class="empty">No hay productos que coincidan con los filtros.</div>';
}
function shoppingChangeTimelineMarkup(){
  const rows=[...(shoppingTracking().changes||[])].sort((a,b)=>Date.parse(b.t)-Date.parse(a.t)).slice(0,80),map=shoppingProductMap();if(!rows.length)return '<div class="empty">Todavía no hay cambios registrados.</div>';
  return `<div class="shopping-change-timeline">${rows.map(change=>{const found=map.get(String(change.productId)),store=found?.store||shoppingStoreById(change.storeId),product=found?.product||{name:change.name},src=productImageDisplayUrl(product);return `<div class="shopping-timeline-row"><time>${esc(formatDate(change.t,{day:"2-digit",month:"short",hour:"2-digit",minute:"2-digit"}))}</time>${src?`<img src="${esc(src)}" alt="${esc(product.name||change.name)}" data-image-popup="${esc(src)}">`:shoppingStoreLogoMarkup(store,"shopping-timeline-logo")}<div><strong>${esc(product.name||change.name)}</strong><small>${esc(store?.name||"Supermercado")} · ${formatMoney(change.previous)} → ${formatMoney(change.current)}</small></div>${shoppingDiffMarkup(change.current,change.previous,{compact:true})}</div>`;}).join("")}</div>`;
}
function renderShoppingHistory(){
  const tracking=shoppingTracking(),rows=shoppingHistorySnapshots(),latest=rows.at(-1),previous=rows.length>1?rows.at(-2):null,currentTotal=latest?num(latest.total):shoppingTotal(),previousTotal=previous?num(previous.total):null;
  const storeOptions=(state.data.shopping?.stores||[]).map(store=>`<option value="${esc(store.id||normalizedKey(store.name))}" ${String(state.shoppingHistoryFilters.store)===String(store.id||normalizedKey(store.name))?"selected":""}>${esc(store.name)}</option>`).join("");
  const actions=`<button class="btn small secondary" data-shopping-history-back>← Lista de la compra</button>${roleCanEdit()?'<button class="btn small secondary" data-sync-all-products>↻ Actualizar ahora</button>':''}${canEdit()?'<button class="btn small secondary" data-shopping-tracking-config>⚙ Frecuencia</button>':''}`;
  return `${lockedBanner()}${pageHead("Histórico de precios","Evolución de Mercadona, HiperDino y cada producto, sin añadir una pestaña nueva al menú",actions)}<section class="shopping-history-hero card"><div><span>Total estimado actual</span><strong>${formatMoney(currentTotal)}</strong>${shoppingDiffMarkup(currentTotal,previousTotal)}</div><div><span>Frecuencia</span><strong>${esc(shoppingScheduleLabel(tracking.schedule))}</strong><small>${esc(shoppingNextAutomaticText())}</small></div><div><span>Última comprobación</span><strong>${tracking.lastRunAt?esc(formatDate(tracking.lastRunAt,{day:"2-digit",month:"short",hour:"2-digit",minute:"2-digit"})):"—"}</strong><small>${tracking.lastSource==="auto"?"Automática":tracking.lastSource==="manual"?"Manual":"Histórico inicial"}</small></div><div><span>Registros</span><strong>${(tracking.snapshots||[]).length}</strong><small>Se conservan hasta ${SHOPPING_HISTORY_MAX_SNAPSHOTS} comprobaciones.</small></div></section><section class="card shopping-history-changes"><div class="shopping-history-section-head"><div><h3>Cambios desde la última consulta</h3><p>Precio anterior, precio nuevo y diferencia de los productos que realmente han variado.</p></div></div>${shoppingHistoryChangesMarkup()}</section><section class="card shopping-history-total-chart"><div class="shopping-history-section-head"><div><h3>Evolución del total</h3><p>Total combinado y evolución por supermercado.</p></div></div>${shoppingTotalsHistoryChart(rows)}</section>${shoppingStoreHistoryCards(rows)}<section class="card shopping-history-products"><div class="shopping-history-section-head"><div><h3>Histórico por producto</h3><p>Fotos, precio actual/anterior, mínimo, máximo y gráfico individual.</p></div></div><div class="shopping-history-filters"><label>Supermercado<select data-shopping-history-store><option value="all">Todos</option>${storeOptions}</select></label><label>Buscar producto<input type="search" data-shopping-history-query value="${esc(state.shoppingHistoryFilters.query||"")}" placeholder="Nombre del producto"></label><label>Periodo<select data-shopping-history-period><option value="7" ${state.shoppingHistoryFilters.period==="7"?"selected":""}>7 días</option><option value="30" ${state.shoppingHistoryFilters.period==="30"?"selected":""}>30 días</option><option value="90" ${state.shoppingHistoryFilters.period==="90"?"selected":""}>90 días</option><option value="all" ${state.shoppingHistoryFilters.period==="all"?"selected":""}>Todo</option></select></label></div>${shoppingProductsHistoryMarkup()}</section><section class="card shopping-history-timeline"><div class="shopping-history-section-head"><div><h3>Registro cronológico de cambios</h3><p>Últimos cambios detectados en los precios de la lista.</p></div></div>${shoppingChangeTimelineMarkup()}</section><p class="help-text shopping-auto-note">La frecuencia automática se comprueba al abrir MFE Viajes y mientras la app permanece abierta. Si la app está cerrada, la revisión pendiente se ejecutará en la siguiente apertura.</p>`;
}
function editShoppingTrackingConfig(){
  const tracking=shoppingTracking();openForm({title:"Frecuencia de seguimiento de precios",fields:[{name:"schedule",label:"Actualización automática",type:"select",options:[{value:"daily",label:"Una vez al día"},{value:"every2days",label:"Cada 2 días"},{value:"manual",label:"Solo manual"}],full:true,help:"La app comprueba si toca actualizar al abrirse y periódicamente mientras permanece abierta. Las actualizaciones manuales siempre están disponibles."}],values:tracking,onSubmit:async v=>{tracking.schedule=v.schedule;await saveSection("shopping");render();scheduleShoppingAutoPriceChecks();toast(`Seguimiento de precios: ${shoppingScheduleLabel(v.schedule)}.`);}});
}
async function maybeRunAutomaticShoppingSync(){
  if(state.shoppingAutoRunning||!roleCanEdit()||!shoppingAutomaticDue())return false;
  const queue=(state.data.shopping?.stores||[]).flatMap(store=>(store.products||[]).filter(product=>isValidUrl(product.url)));if(!queue.length)return false;
  state.shoppingAutoRunning=true;try{await syncAllProducts({source:"auto",silent:true});return true;}finally{state.shoppingAutoRunning=false;}
}
function scheduleShoppingAutoPriceChecks(){
  if(state.shoppingAutoTimer){clearInterval(state.shoppingAutoTimer);state.shoppingAutoTimer=null;}
  setTimeout(()=>maybeRunAutomaticShoppingSync().catch(error=>console.warn("Seguimiento automático de precios",error)),3500);
  state.shoppingAutoTimer=setInterval(()=>maybeRunAutomaticShoppingSync().catch(error=>console.warn("Seguimiento automático de precios",error)),60*60*1000);
}
function shoppingSyncReportMarkup(){
  const report=state.shoppingSyncReport;
  if(!report?.failures?.length)return "";
  const when=report.completedAt?formatDate(report.completedAt,{day:"2-digit",month:"short",hour:"2-digit",minute:"2-digit"}):"";
  return `<section class="card shopping-sync-report"><div class="shopping-sync-report-head"><div><strong>⚠️ Errores de la última actualización (${report.failures.length})</strong><small>${when?`Finalizada ${esc(when)} · `:""}${report.refreshed||0}/${report.total||0} productos correctos. Corrige el enlace o reintenta solo el producto afectado.</small></div><button class="mini-btn" type="button" data-shopping-sync-clear-report title="Ocultar informe">×</button></div><div class="shopping-sync-error-list">${report.failures.map(item=>`<div class="shopping-sync-error-row"><div class="shopping-sync-error-main"><strong>${esc(item.storeName||"Supermercado")} · ${esc(item.name||"Producto")}</strong><span>${esc(item.message||"No se pudo actualizar el precio.")}</span><code title="${esc(item.url||"")}">${esc(item.url||"Sin enlace")}</code></div><div class="shopping-sync-error-actions">${isValidUrl(item.url)?`<a class="mini-btn" href="${esc(item.url)}" target="_blank" rel="noopener" title="Abrir enlace del producto">↗</a>`:""}<button class="mini-btn" type="button" data-shopping-error-retry="${item.storeIndex}:${item.productIndex}" title="Reintentar">↻</button><button class="mini-btn" type="button" data-shopping-error-edit="${item.storeIndex}:${item.productIndex}" title="Corregir producto o enlace">✎</button></div></div>`).join("")}</div></section>`;
}
function renderShopping() {
  if(state.shoppingView==="history")return renderShoppingHistory();
  const stores=state.data.shopping.stores,total=shoppingTotal(),checked=sum(stores.flatMap(s=>s.products).map(p=>p.checked?1:0)),count=sum(stores.map(s=>s.products.length));
  const copiedOcrCount=countLikelyOcrShoppingCopies();
  const tracking=shoppingTracking();
  const shoppingActions=`<button class="btn small secondary pdf-action-btn" data-export-shopping-pdf>${pdfFileIconMarkup("pdf-action-icon")} Generar PDF</button><button class="btn small secondary" data-shopping-open-history>${priceHistoryIconMarkup("price-history-icon")} Histórico de precios</button>${roleCanEdit()?`<button class="btn small secondary" data-uncheck-all-products ${checked?'':'disabled'}>☐ Desmarcar todos</button><button class="btn small secondary" data-sync-all-products>↻ Actualizar todos los precios</button>`:""}${canEdit()&&copiedOcrCount?`<button class="btn small secondary" data-clean-ocr-shopping title="Retirar posibles productos copiados automáticamente por versiones anteriores">🧹 Limpiar copias OCR (${copiedOcrCount})</button>`:""}${canEdit()?'<button class="btn small primary canary-action-btn" data-add-store>＋ Supermercado</button>':""}`;
  const pending=Math.max(0,count-checked);
  return `${lockedBanner()}${pageHead("Lista de la compra","Productos por supermercado, cantidades, enlaces y precios",shoppingActions)}
  <section class="shopping-summary"><div class="kpi accent"><span>Total previsto</span><strong>${formatMoney(total)}</strong></div><div class="kpi"><span>Productos</span><strong>${count}</strong></div><div class="kpi success"><span>Marcados</span><strong>${checked}</strong></div><div class="kpi"><span>Por marcar</span><strong>${pending}</strong></div></section>
  <div class="shopping-tracking-strip"><span>${priceHistoryIconMarkup("price-history-inline-icon")} Seguimiento de precios: <strong>${esc(shoppingScheduleLabel(tracking.schedule))}</strong></span><span>${tracking.lastRunAt?`Última revisión ${esc(formatDate(tracking.lastRunAt,{day:"2-digit",month:"short",hour:"2-digit",minute:"2-digit"}))}`:"Histórico preparado · pendiente de primera actualización"}</span>${tracking.lastChanges?.length?`<span class="shopping-tracking-changed">${tracking.lastChanges.length} cambio${tracking.lastChanges.length===1?"":"s"} en la última revisión</span>`:""}</div>
  ${shoppingSyncReportMarkup()}
  <div class="store-grid">${stores.map((store,sIndex)=>`<article class="card store-card ${store.active===false?'store-inactive':''}" style="--store-color:${esc(store.color)}"><div class="section-title" style="--g1:${esc(store.gradient1||store.color)};--g2:${esc(store.gradient2||store.color)};--title-text:${esc(store.textColor||'#ffffff')}"><span class="section-title-label">${isImageSource(store.logoUrl)?`<img class="store-logo" src="${esc(store.logoUrl)}" alt="${esc(store.name)}" data-image-popup="${esc(store.logoUrl)}">`:esc(store.icon||"🛒")} ${esc(store.name)}</span>${editButtons(`<div class="section-actions"><button class="mini-btn" data-add-product="${sIndex}">＋</button><button class="mini-btn" data-edit-store="${sIndex}">✎</button><button class="mini-btn" data-delete-store="${sIndex}">×</button></div>`)}</div><div class="table-wrap shopping-table-wrap"><table class="shopping-table"><thead><tr><th>✓</th><th>Producto</th><th class="amount">Cantidad</th><th class="amount">PVP unidad</th><th class="amount">Total</th><th class="amount">URL</th>${canEdit()?"<th class=\"shopping-actions-col\"></th>":""}</tr></thead><tbody>${checkedLastIndexed(store.products).map(({item:p,index:pIndex})=>`<tr class="${p.checked?"row-done":""}" data-sort-item="shopping-product|${sIndex}|${pIndex}"><td><input type="checkbox" data-product-check="${sIndex}:${pIndex}" ${p.checked?"checked":""} ${roleCanEdit()?"":"disabled"}></td><td><div class="product-cell">${renderProductThumb(p,sIndex,pIndex)}<span><span class="product-name">${esc(p.name)}</span>${p.priceUpdatedAt?`<small class="price-updated">Actualizado ${formatDate(p.priceUpdatedAt,{day:"2-digit",month:"short",hour:"2-digit",minute:"2-digit"})}</small>`:""}</span></div></td><td class="amount">${num(p.quantity).toLocaleString("es-ES")}</td><td class="amount">${formatMoney(p.unitPrice)}</td><td class="amount">${formatMoney(num(p.quantity)*num(p.unitPrice))}</td><td class="amount store-url-cell">${safeStoreLink(p.url,"Producto","↗",store.color||store.gradient2||store.gradient1||"",store.name)}</td>${canEdit()?`<td class="shopping-actions-col"><div class="row-actions">${isValidUrl(p.url)?`<button class="mini-btn" data-sync-product="${sIndex}:${pIndex}" title="Intentar actualizar desde URL">↻</button>`:""}${sortDragHandle(`shopping-product|${sIndex}|${pIndex}`,'Arrastrar producto')}<button class="mini-btn" data-edit-product="${sIndex}:${pIndex}">✎</button><button class="mini-btn" data-delete-product="${sIndex}:${pIndex}">×</button></div></td>`:""}</tr>`).join("")}</tbody></table></div><div class="group-total"><span>Total ${esc(store.name)}</span><strong class="store-total">${formatMoney(storeTotal(store))}</strong></div></article>`).join("")}</div>`;
}
binders.shopping = () => {
  $$('[data-add-store]').forEach(b=>b.addEventListener('click',()=>editStore()));
  $$('[data-edit-store]').forEach(b=>b.addEventListener('click',()=>editStore(num(b.dataset.editStore))));
  $$('[data-delete-store]').forEach(b=>b.addEventListener('click',async()=>{if(confirmAction("¿Eliminar este supermercado y sus productos?")){state.data.shopping.stores.splice(num(b.dataset.deleteStore),1);await saveSection("shopping");render();}}));
  $$('[data-add-product]').forEach(b=>b.addEventListener('click',()=>editProduct(num(b.dataset.addProduct))));
  $$('[data-edit-product]').forEach(b=>b.addEventListener('click',()=>{const[s,p]=b.dataset.editProduct.split(':').map(num);editProduct(s,p);}));
  $$('[data-delete-product]').forEach(b=>b.addEventListener('click',async()=>{const[s,p]=b.dataset.deleteProduct.split(':').map(num);if(!confirmAction('¿Eliminar este producto de la lista de la compra?'))return;state.data.shopping.stores[s].products.splice(p,1);await saveSection("shopping");render();}));
  $$('[data-product-check]').forEach(input=>input.addEventListener('change',async()=>{const[s,p]=input.dataset.productCheck.split(':').map(num);state.data.shopping.stores[s].products[p].checked=input.checked;await saveSection("shopping");render();}));
  $$('[data-uncheck-all-products]').forEach(b=>b.addEventListener('click',async()=>{for(const store of state.data.shopping.stores||[])for(const product of store.products||[])product.checked=false;await saveSection('shopping');render();toast('Todos los productos están desmarcados.');}));
  $$('[data-sync-product]').forEach(b=>b.addEventListener('click',()=>{const[s,p]=b.dataset.syncProduct.split(':').map(num);syncProduct(s,p);}));
  $$('[data-sync-all-products]').forEach(b=>b.addEventListener('click',()=>syncAllProducts({source:'manual'})));
  $$('[data-shopping-open-history]').forEach(b=>b.addEventListener('click',()=>{state.shoppingView='history';render();window.scrollTo({top:0,behavior:'smooth'});}));
  $$('[data-shopping-history-back]').forEach(b=>b.addEventListener('click',()=>{state.shoppingView='list';render();window.scrollTo({top:0,behavior:'smooth'});}));
  $$('[data-shopping-tracking-config]').forEach(b=>b.addEventListener('click',editShoppingTrackingConfig));
  $$('[data-shopping-history-store]').forEach(input=>input.addEventListener('change',()=>{state.shoppingHistoryFilters.store=input.value;render();}));
  $$('[data-shopping-history-period]').forEach(input=>input.addEventListener('change',()=>{state.shoppingHistoryFilters.period=input.value;render();}));
  $$('[data-shopping-history-query]').forEach(input=>input.addEventListener('input',()=>{state.shoppingHistoryFilters.query=input.value;const cursor=input.selectionStart;render();const next=$('[data-shopping-history-query]');if(next){next.focus();next.setSelectionRange(Math.min(cursor,next.value.length),Math.min(cursor,next.value.length));}}));
  $$('[data-move-product]').forEach(b=>b.addEventListener('click',async()=>{const[s,p,d]=b.dataset.moveProduct.split(':').map(num);moveArrayItem(state.data.shopping.stores[s].products,p,d);await saveSection('shopping');render();}));
  $$('[data-export-shopping-pdf]').forEach(b=>b.addEventListener('click',generateShoppingPdf));
  $$('[data-clean-ocr-shopping]').forEach(b=>b.addEventListener('click',cleanLikelyOcrShoppingCopies));
  $$('[data-shopping-sync-clear-report]').forEach(b=>b.addEventListener('click',()=>{state.shoppingSyncReport=null;render();}));
  $$('[data-shopping-error-edit]').forEach(b=>b.addEventListener('click',()=>{const[s,p]=b.dataset.shoppingErrorEdit.split(':').map(num);editProduct(s,p);}));
  $$('[data-shopping-error-retry]').forEach(b=>b.addEventListener('click',()=>{const[s,p]=b.dataset.shoppingErrorRetry.split(':').map(num);syncProduct(s,p);}));
};
function editStore(index=null) {
  const current=index===null?{icon:"🛒",color:"#4da3ff",gradient1:"#173b61",gradient2:"#285f91",postalCode:"",active:true}:state.data.shopping.stores[index];
  openForm({title:index===null?"Añadir supermercado":"Editar supermercado",fields:[{name:"name",label:"Nombre",required:true},{name:"icon",label:"Emoji alternativo"},{name:"logoUrl",label:"URL del logo",type:"url",full:true},{name:"logoFile",label:"Subir logo 128×128",type:"file",accept:"image/*",full:true},{name:"postalCode",label:"Código postal",help:"Código postal de la zona donde comprarás. En este viaje: Mercadona 35214 y HiperDino 35200. Mercadona lo convierte automáticamente al almacén real para consultar precios y disponibilidad."},{name:"active",label:"Supermercado activo",type:"checkbox",full:true},{name:"color",label:"Color de totales",type:"color"},{name:"gradient1",label:"Degradado inicio",type:"color"},{name:"gradient2",label:"Degradado fin",type:"color"},{name:"textColor",label:"Color del texto del título",type:"color"}],values:{textColor:"#ffffff",...current},onSubmit:async v=>{if(v.logoFile)v.logoUrl=await fileToSquareDataUrl(v.logoFile);delete v.logoFile;const value={id:current.id||uid("store"),products:current.products||[],...current,...v};if(index===null)state.data.shopping.stores.push(value);else state.data.shopping.stores[index]=value;await saveSection("shopping");render();}});
}
function normalizeProductUrlInput(raw="") {
  const value=String(raw||"").trim();
  if(!value)return "";
  const candidate=/^www\./i.test(value)?`https://${value}`:/^hiperdino\.es\//i.test(value)?`https://www.${value}`:value;
  try{return new URL(candidate).toString();}catch{return candidate;}
}
function productFallbackName(url="",storeName="") {
  try{
    const parsed=new URL(String(url||""));
    const hash=decodeURIComponent(String(parsed.hash||"").replace(/^#/,"")).trim();
    if(hash){
      const words=hash.replace(/^hiperdino-/i,"").split("-").filter(Boolean);
      if(words.length){
        const text=words.join(" ").replace(/\bgr\b/gi,"g").replace(/\bud\b/gi,"ud").trim();
        if(text)return text.charAt(0).toUpperCase()+text.slice(1);
      }
    }
    const host=parsed.hostname.replace(/^www\./i,"");
    if(/hiperdino\.es$/i.test(host))return "Producto HiperDino";
  }catch{}
  return `Producto ${String(storeName||"").trim()||"pendiente"}`;
}
async function refreshSavedProductFromUrl(storeIndex,productId) {
  const store=state.data.shopping.stores[storeIndex];
  if(!store)return;
  let index=(store.products||[]).findIndex(product=>product.id===productId);
  if(index<0)return;
  const snapshot={...store.products[index]};
  if(!isValidUrl(snapshot.url))return;
  try{
    const updated=await fetchProductUpdate(store,snapshot);
    index=(store.products||[]).findIndex(product=>product.id===productId);
    if(index<0)return;
    // Conservamos cualquier cambio posterior del usuario y aplicamos únicamente
    // los datos que el Worker ha podido actualizar desde la tienda.
    store.products[index]={...store.products[index],...updated,id:productId};
    await saveSection("shopping");
    if(state.shoppingSyncReport?.failures?.length){
      state.shoppingSyncReport.failures=state.shoppingSyncReport.failures.filter(item=>!(item.storeIndex===storeIndex&&item.productIndex===index));
      state.shoppingSyncReport.failed=state.shoppingSyncReport.failures.length;
      if(!state.shoppingSyncReport.failures.length)state.shoppingSyncReport=null;
    }
    if(state.activeTab==="shopping")render();
    toast("Producto actualizado desde el enlace.");
  }catch(error){
    console.warn("Actualización automática de producto",error);
    index=(store.products||[]).findIndex(product=>product.id===productId);
    state.shoppingSyncReport={completedAt:new Date().toISOString(),total:1,refreshed:0,changed:0,failed:1,failures:[{storeIndex,productIndex:Math.max(0,index),storeName:store.name||"Supermercado",name:snapshot.name||"Producto",url:snapshot.url||"",message:error?.message||"No se ha podido actualizar el producto."}]};
    if(state.activeTab==="shopping")render();
    toast(`Producto guardado. No se pudo actualizar automáticamente desde la tienda: ${error.message}`,"error");
  }
}
function editProduct(storeIndex,productIndex=null,prefill=null) {
  const current=prefill || (productIndex===null?{quantity:1,unitPrice:0,checked:false,imageSource:"auto"}:state.data.shopping.stores[storeIndex].products[productIndex]);
  const normalizedCurrent=normalizeProductImageFields(current);
  const formValues={...normalizedCurrent,imageUrl:normalizedCurrent.imageSource==="manual"?(normalizedCurrent.imageUrl||""):""};
  openForm({
    title:productIndex===null?"Añadir producto":"Editar producto",
    fields:[
      {name:"url",label:"Enlace web",type:"text",full:true,help:"Pega el enlace del producto. Se guardará inmediatamente y después la app intentará obtener nombre, precio e imagen en segundo plano."},
      {name:"name",label:"Producto (opcional si hay enlace)",full:true},
      {name:"quantity",label:"Cantidad",type:"number",step:"0.01"},
      {name:"unit",label:"Unidad"},
      {name:"unitPrice",label:"PVP unidad",type:"number",step:"0.01"},
      {name:"imageUrl",label:"Imagen manual (opcional)",type:"url",full:true,help:"Si añades una imagen manual, se conservará al actualizar precio y nombre. Déjala vacía para obtenerla automáticamente desde la URL del producto."},
      {name:"checked",label:"Ya comprado / marcado",type:"checkbox",full:true}
    ],
    values:formValues,
    onSubmit:async v=>{
      const manualImage=String(v.imageUrl||"").trim();
      v.url=normalizeProductUrlInput(v.url);
      let value={id:current.id||uid("product"),...normalizedCurrent,...v};
      value=applyManualProductImage(value,manualImage);
      const hasUrl=isValidUrl(value.url);
      if(!String(value.name||"").trim()&&!hasUrl)throw new Error("Introduce un enlace web válido o el nombre del producto.");
      if(hasUrl&&!String(value.name||"").trim())value.name=productFallbackName(value.url,state.data.shopping.stores[storeIndex]?.name);
      const productId=value.id;
      if(productIndex===null)state.data.shopping.stores[storeIndex].products.push(value);
      else state.data.shopping.stores[storeIndex].products[productIndex]=value;
      const saved=await saveSection("shopping");
      if(!saved)throw new Error("No se ha podido guardar el producto en Firebase.");
      // El error anterior se mantiene visible hasta que la actualización en
      // segundo plano confirme que el nuevo enlace devuelve datos válidos.
      render();
      toast(hasUrl?"Producto guardado. Actualizando datos en segundo plano…":"Producto guardado.");
      if(hasUrl)setTimeout(()=>{void refreshSavedProductFromUrl(storeIndex,productId);},0);
    }
  });
}

async function callPriceWorker(payload = {}, {timeoutMs=18000} = {}) {
  const workerUrl = String(state.data.settings.priceWorkerUrl || DEFAULT_PRICE_WORKER_URL).trim();
  if (!isValidUrl(workerUrl)) throw new Error("Configura una URL válida para el actualizador de precios.");
  const controller=new AbortController();
  const timer=setTimeout(()=>controller.abort(),Math.max(3000,Number(timeoutMs)||18000));
  let response;
  try{
    response = await fetch(workerUrl, {
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify(payload),
      signal:controller.signal
    });
  }catch(error){
    if(error?.name==="AbortError")throw new Error("El actualizador ha tardado demasiado en responder. Se continúa con el siguiente producto.");
    throw error;
  }finally{clearTimeout(timer);}
  let data;
  try { data = await response.json(); } catch { throw new Error(`El actualizador ha respondido con HTTP ${response.status}.`); }
  if (!response.ok || data?.ok === false) throw new Error(data?.error || `El actualizador ha respondido con HTTP ${response.status}.`);
  return data;
}
async function testPriceWorker() {
  try {
    toast("Comprobando actualizador…");
    const workerUrl=String(state.data.settings.priceWorkerUrl||DEFAULT_PRICE_WORKER_URL).trim();
    const response=await fetch(workerUrl,{cache:"no-store"});
    const data=await response.json();
    if(!response.ok||data?.ok===false)throw new Error(data?.error||`HTTP ${response.status}`);
    toast(`Actualizador conectado${data.version?` · v${data.version}`:""}.`);
  } catch(error) { toast(`No se ha podido conectar: ${error.message}`,"error"); }
}
function integrationTone(ok, pending=false){return ok?'good':pending?'warn':'bad';}
function integrationStatusBadge(label,tone='warn'){return `<span class="integration-status ${esc(tone)}">${esc(label)}</span>`;}
function integrationExternalButton(url,label){return isValidUrl(url)?`<a class="btn secondary small" href="${esc(url)}" target="_blank" rel="noopener">↗ ${esc(label)}</a>`:`<span class="btn secondary small disabled" aria-disabled="true">↗ ${esc(label)}</span>`;}
function combineTripDateWithTrackerTime(tripDateTime,trackerDateTime,fallback='09:00'){
  const date=String(tripDateTime||'').slice(0,10);
  const time=String(trackerDateTime||'').match(/T(\d{2}:\d{2})/)?.[1]||fallback;
  return date?`${date}T${time}`:String(trackerDateTime||'');
}
function dateOnly(value=''){
  return String(value||'').match(/^(\d{4}-\d{2}-\d{2})/)?.[1]||'';
}
function shiftIsoDate(date,days=0){
  if(!/^\d{4}-\d{2}-\d{2}$/.test(String(date||'')))return String(date||'');
  const [y,m,d]=String(date).split('-').map(Number),dt=new Date(Date.UTC(y,m-1,d)+Number(days||0)*86400000);
  return `${dt.getUTCFullYear()}-${String(dt.getUTCMonth()+1).padStart(2,'0')}-${String(dt.getUTCDate()).padStart(2,'0')}`;
}
function calendarDayOffset(fromDate,toDate){
  if(!/^\d{4}-\d{2}-\d{2}$/.test(String(fromDate||''))||!/^\d{4}-\d{2}-\d{2}$/.test(String(toDate||'')))return 0;
  const a=Date.parse(`${fromDate}T00:00:00Z`),b=Date.parse(`${toDate}T00:00:00Z`);
  return Number.isFinite(a)&&Number.isFinite(b)?Math.round((b-a)/86400000):0;
}
function replaceDatePreservingRest(value,newDate){
  const raw=String(value||'');
  if(!newDate)return raw;
  if(/^\d{4}-\d{2}-\d{2}/.test(raw))return raw.replace(/^\d{4}-\d{2}-\d{2}/,newDate);
  return raw;
}
function synchronizeTravelDatesFromMasterLocally(){
  const settings=state.data.settings||{},cover=state.data.cover||{},trackers=state.data.trackers||{};
  const start=dateOnly(settings.departureDateTime),end=dateOnly(settings.returnDateTime);
  if(!start&&!end)return {changed:false};
  let changed=false;
  const set=(obj,key,value)=>{if(!obj||!value||String(obj[key]||'')===String(value))return;obj[key]=value;changed=true;};
  const flights=Array.isArray(cover.flights)?cover.flights:[];
  flights.forEach((flight,index)=>{
    const type=String(flight?.type||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toUpperCase();
    let target='';
    if(/VUELTA|RETURN|REGRESO/.test(type))target=end;
    else if(/IDA|OUTBOUND|SALIDA/.test(type))target=start;
    else if(flights.length===1)target=start;
    else if(index===0)target=start;
    else if(index===flights.length-1)target=end;
    if(!target)return;
    const oldDep=dateOnly(flight.departure)||dateOnly(flight.date),oldArr=dateOnly(flight.arrival);
    const arrivalOffset=oldDep&&oldArr?calendarDayOffset(oldDep,oldArr):0;
    set(flight,'date',target);
    if(flight.departure)set(flight,'departure',replaceDatePreservingRest(flight.departure,target));
    if(flight.arrival)set(flight,'arrival',replaceDatePreservingRest(flight.arrival,shiftIsoDate(target,arrivalOffset)));
  });
  const lodging=cover.lodging||{};
  if(start)set(lodging,'checkIn',start);
  if(end)set(lodging,'checkOut',end);
  const cordial=trackers.cordial;
  if(cordial){if(start)set(cordial,'checkIn',start);if(end)set(cordial,'checkOut',end);}
  const vueling=trackers.vueling;
  if(vueling){if(start)set(vueling,'departureDate',start);if(end)set(vueling,'returnDate',end);}
  const autoreisen=trackers.autoreisen;
  if(autoreisen&&settings.autoreisenSyncWithTripDates!==false){
    const pickup=combineTripDateWithTrackerTime(settings.departureDateTime,autoreisen.pickupAt,'09:00');
    const dropoff=combineTripDateWithTrackerTime(settings.returnDateTime,autoreisen.dropoffAt,'15:00');
    if(start)set(autoreisen,'pickupAt',pickup);
    if(end)set(autoreisen,'dropoffAt',dropoff);
  }
  return {changed};
}
function synchronizeAutoreisenDatesLocally(){
  const settings=state.data.settings,tracker=state.data.trackers.autoreisen;
  tracker.pickupAt=combineTripDateWithTrackerTime(settings.departureDateTime,tracker.pickupAt,'09:00');
  tracker.dropoffAt=combineTripDateWithTrackerTime(settings.returnDateTime,tracker.dropoffAt,'15:00');
  return {pickupAt:tracker.pickupAt,dropoffAt:tracker.dropoffAt};
}
function tripIata(value=""){
  const raw=String(value||'').trim();
  return (raw.match(/\(([A-Z]{3})\)/i)?.[1]||raw.match(/\b([A-Z]{3})\b/)?.[1]||'').toUpperCase();
}
function tripClock(value=""){
  const raw=String(value||'');
  return raw.match(/T(\d{2}:\d{2})/)?.[1]||raw.match(/\b(\d{2}:\d{2})\b/)?.[1]||'';
}
function trackerBudgetReference(kind,tracker={}){
  const normalize=value=>String(value||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toUpperCase();
  const ids={autoreisen:'g-car',cordial:'g-lodging'};
  const hints={autoreisen:/AUTOREISEN|ALQUILER.*COCHE/,cordial:/CORDIAL|ALOJAMIENTO/};
  const groups=state.data.budget?.groups||[];
  const group=groups.find(g=>g.id===ids[kind])||groups.find(g=>hints[kind]?.test(normalize(g.name)));
  if(!group){const fallback=num(tracker.reservedPrice);return {total:fallback,label:'Reservado',source:fallback>0?'Configuración':'',matched:0};}
  let items=effectiveBudgetEntries(group).map(entry=>entry.item).filter(Boolean);
  if(kind==='autoreisen'){
    const matches=items.filter(item=>/AUTOREISEN|RVA\s*\d+/i.test(normalize(`${item.name||''} ${item.detail||''}`)));
    if(matches.length)items=matches;
  }
  if(kind==='cordial'){
    const matches=items.filter(item=>/CORDIAL|ROL\s*\w+/i.test(normalize(`${item.name||''} ${item.detail||''}`)));
    if(matches.length)items=matches;
  }
  const total=sum(items.map(itemAmount)),paid=items.length>0&&items.every(item=>item.status==='paid');
  return {total:total||num(tracker.reservedPrice),label:paid?'Pagado':'Reservado',source:total>0?'Presupuesto':num(tracker.reservedPrice)>0?'Configuración':'',matched:items.length};
}
function synchronizeTrackerTripDataLocally(){
  const changed=[];const mark=id=>{if(!changed.includes(id))changed.push(id);};
  const set=(id,obj,key,value)=>{if(value===undefined||value===null||value==='')return;if(String(obj?.[key]??'')!==String(value)){obj[key]=value;mark(id);}};
  const trackers=state.data.trackers||{},settings=state.data.settings||{},cover=state.data.cover||{};
  const a=trackers.autoreisen;if(a){
    // v2.3.52: las fechas propias de AutoReisen solo se pisan con las del viaje cuando
    // el usuario mantiene activada expresamente esa sincronización. Las búsquedas
    // manuales pueden usar otro viaje/periodo sin volver a septiembre al renderizar.
    if(settings.autoreisenSyncWithTripDates!==false){
      const before=`${a.pickupAt}|${a.dropoffAt}`;synchronizeAutoreisenDatesLocally();if(before!==`${a.pickupAt}|${a.dropoffAt}`)mark('autoreisen');
    }
    const ref=trackerBudgetReference('autoreisen',a);if(ref.total>0)set('autoreisen',a,'reservedPrice',ref.total);
  }
  const c=trackers.cordial,lodging=cover.lodging||{};if(c){
    set('cordial',c,'hotel',lodging.name||c.hotel);set('cordial',c,'checkIn',lodging.checkIn||c.checkIn);set('cordial',c,'checkOut',lodging.checkOut||c.checkOut);
    if(num(settings.people)>0)set('cordial',c,'adults',Math.max(1,num(settings.people)));
    const ref=trackerBudgetReference('cordial',c);if(ref.total>0)set('cordial',c,'reservedPrice',ref.total);
  }
  const v=trackers.vueling,flights=Array.isArray(cover.flights)?cover.flights:[];if(v&&flights.length){
    const outbound=flights.find(f=>/IDA/i.test(String(f.type||'')))||flights[0];
    const returned=flights.find(f=>/VUELTA/i.test(String(f.type||'')))||flights.find(f=>f!==outbound)||null;
    if(outbound){set('vueling',v,'origin',tripIata(outbound.from)||v.origin);set('vueling',v,'destination',tripIata(outbound.to)||v.destination);set('vueling',v,'departureDate',String(outbound.date||outbound.departure||'').slice(0,10));set('vueling',v,'outboundFlight',String(outbound.number||v.outboundFlight).toUpperCase());set('vueling',v,'outboundTime',tripClock(outbound.departure)||v.outboundTime);}
    if(returned){set('vueling',v,'returnDate',String(returned.date||returned.departure||'').slice(0,10));set('vueling',v,'returnFlight',String(returned.number||v.returnFlight).toUpperCase());set('vueling',v,'returnTime',tripClock(returned.departure)||v.returnTime);}
    // Vueling mantiene su propia composición de pasajeros: puede diferir del contador general del viaje.
    const ref=vuelingBudgetReference(v);if(ref.total>0)set('vueling',v,'reservedPrice',ref.total);
  }
  return {changed};
}
async function syncTrackerWorkersFromTripData(ids=[]){
  if(DEMO_MODE||typeof state.user?.getIdToken!=='function')return;
  const wanted=new Set(ids);
  const tasks=[];
  if(wanted.has('autoreisen'))tasks.push(callIntegrationWorker({action:'github-sync-autoreisen',config:state.data.trackers.autoreisen,runWorkflow:false}));
  if(wanted.has('cordial'))tasks.push(callIntegrationWorker({action:'github-sync-cordial',config:state.data.trackers.cordial,runWorkflow:false}));
  if(wanted.has('vueling'))tasks.push(callVuelingWorker({action:'github-vueling-sync',config:state.data.trackers.vueling},{authenticated:true,timeoutMs:30000}));
  if(tasks.length)await Promise.allSettled(tasks);
}
async function currentFirebaseIdToken({timeoutMs=12000}={}){
  if(DEMO_MODE||typeof state.user?.getIdToken!=='function')throw new Error('La sincronización segura necesita una sesión real de Firebase.');
  let timer=null;
  try{
    return await Promise.race([
      state.user.getIdToken(false),
      new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('Firebase ha tardado demasiado en preparar la sesión segura.')),Math.max(4000,Number(timeoutMs)||12000));})
    ]);
  }finally{if(timer)clearTimeout(timer);}
}
async function callIntegrationWorker(payload={}, {timeoutMs=15000,authenticated=true,token=''}={}){
  const workerUrl=String(state.data.settings.priceWorkerUrl||DEFAULT_PRICE_WORKER_URL).trim();
  if(!isValidUrl(workerUrl))throw new Error('Configura una URL válida para el Worker de Cloudflare.');
  const headers={'Content-Type':'application/json'};
  if(authenticated){
    const authToken=String(token||await currentFirebaseIdToken({timeoutMs:Math.min(Math.max(5000,Number(timeoutMs)||15000),15000)})).trim();
    if(!authToken)throw new Error('No se pudo obtener la sesión segura de Firebase.');
    headers['X-Requested-With']='XmlHttpRequest';
    headers.Authorization=`Bearer ${authToken}`;
  }
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),Math.max(4000,Number(timeoutMs)||15000));
  try{
    const response=await fetch(workerUrl,{method:'POST',headers,body:JSON.stringify(payload),cache:'no-store',signal:controller.signal});
    let data;try{data=await response.json();}catch{throw new Error(`El Worker respondió con HTTP ${response.status}.`);}
    if(!response.ok||data?.ok===false)throw new Error(data?.error||`El Worker respondió con HTTP ${response.status}.`);
    return data;
  }catch(error){
    if(error?.name==='AbortError')throw new Error('El Worker de integraciones ha tardado demasiado en responder.');
    if(error instanceof TypeError&&/failed to fetch|networkerror|load failed/i.test(String(error.message||'')))throw new Error('No se pudo conectar con el Worker de integraciones. Comprueba la conexión y vuelve a intentarlo.');
    throw error;
  }finally{clearTimeout(timer);}
}
async function fetchIntegrationHealth({timeoutMs=8000}={}){
  const workerUrl=String(state.data.settings.priceWorkerUrl||DEFAULT_PRICE_WORKER_URL).trim();
  if(!isValidUrl(workerUrl))throw new Error('URL del Worker no válida.');
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),Math.max(3000,Number(timeoutMs)||8000));
  try{
    const response=await fetch(workerUrl,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'integration-health'}),cache:'no-store',signal:controller.signal});
    let data;try{data=await response.json();}catch{throw new Error(`HTTP ${response.status}`);}
    if(!response.ok||data?.ok===false)throw new Error(data?.error||`HTTP ${response.status}`);
    return data;
  }catch(error){
    if(error?.name==='AbortError')throw new Error('Cloudflare Worker ha tardado demasiado en responder.');
    throw error;
  }finally{clearTimeout(timer);}
}
async function callVuelingWorker(payload={}, {authenticated=false,timeoutMs=22000}={}){
  const workerUrl=String(state.data.settings.vuelingWorkerUrl||DEFAULT_VUELING_WORKER_URL).trim();
  if(!isValidUrl(workerUrl))throw new Error('Configura una URL válida para el Worker Vueling.');
  const headers={'Content-Type':'application/json'};
  if(authenticated){headers['X-Requested-With']='XmlHttpRequest';headers.Authorization=`Bearer ${await currentFirebaseIdToken()}`;}
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),Math.max(4000,Number(timeoutMs)||22000));
  try{
    const response=await fetch(workerUrl,{method:'POST',headers,body:JSON.stringify(payload),cache:'no-store',signal:controller.signal});
    let data;try{data=await response.json();}catch{throw new Error(`Worker Vueling respondió HTTP ${response.status}.`);}
    if(!response.ok||data?.ok===false)throw new Error(data?.error||`Worker Vueling respondió HTTP ${response.status}.`);
    return data;
  }catch(error){if(error?.name==='AbortError')throw new Error('El Worker Vueling ha tardado demasiado en responder.');throw error;}finally{clearTimeout(timer);}
}
async function fetchVuelingHealth(){return callVuelingWorker({action:'integration-health'});}

async function testDriveIntegration(){
  const response=await authorizedDriveFetch('https://www.googleapis.com/drive/v3/about?fields=user(displayName,emailAddress)');
  if(!response.ok){let detail='';try{detail=(await response.json())?.error?.message||'';}catch{}throw new Error(detail||`Google Drive respondió HTTP ${response.status}.`);}
  const data=await response.json();return {ok:true,label:data?.user?.emailAddress||data?.user?.displayName||'Cuenta autorizada'};
}
async function runIntegrationDiagnostics({silent=false}={}){
  const d=state.integrationDiagnostics;
  d.checked=true;d.firebase={ok:state.provider instanceof FirebaseProvider,label:state.provider instanceof FirebaseProvider?'Conectado':'No conectado'};
  const driveConfigured=Boolean(state.data.settings.googleDriveApiKey&&state.data.settings.googleDriveClientId&&state.data.settings.googleDriveAppId);
  const drivePersistent=driveConfigured?await refreshDrivePersistentStatus({silent:true}):{connected:false,persistentConnected:false,configured:false,temporary:false,email:""};
  const driveTemporary=driveTemporaryConnected(drivePersistent);
  d.drive={ok:Boolean(driveConfigured&&(drivePersistent.connected||driveTemporary)),label:!driveConfigured?'Pendiente':driveConnectionLabel(drivePersistent),detail:{...drivePersistent,temporary:driveTemporary}};
  d.calendar={ok:true,label:'Disponible'};
  d.notifications={ok:notificationPermissionInfo().tone==='good'&&Boolean(currentVapidKey()),label:notificationPermissionInfo().tone==='good'?(currentVapidKey()?'Preparado':'Falta VAPID'):notificationPermissionInfo().label};
  d.weather={ok:true,label:'Sin clave'};
  try{const health=await fetchIntegrationHealth();d.worker={ok:true,label:`Activo${health.version?` · v${health.version}`:''}`,detail:health};d.github={ok:Boolean(health.githubConfigured),label:health.githubConfigured?'Configurado':'Pendiente',detail:health};d.lastMessage='Diagnóstico actualizado.';}
  catch(error){d.worker={ok:false,label:'Sin conexión',error:error.message};d.github={ok:false,label:'Sin comprobar'};d.lastMessage=error.message;if(!silent)toast(`Centro de integraciones: ${error.message}`,'error');}
  if(state.activeTab==='settings'&&['integrations','updates'].includes(state.settingsPanel))render();
  if(!silent&&d.worker?.ok)toast('Centro de integraciones actualizado.');
  return d;
}
async function synchronizeAutoreisenWithTrip({runWorkflow=null,silent=false}={}){
  if(!canEdit())throw new Error('Desbloquea la edición para sincronizar las fechas.');
  const dates=synchronizeAutoreisenDatesLocally();
  await saveSection('trackers');
  const shouldRun=runWorkflow??Boolean(state.data.settings.githubRunWorkflowAfterSync);
  try{
    const result=await callIntegrationWorker({action:'github-sync-autoreisen',config:state.data.trackers.autoreisen,runWorkflow:shouldRun});
    state.integrationDiagnostics.github={ok:true,label:'Sincronizado',detail:result};
    if(!silent)toast(`AutoReisen sincronizado con GitHub${result.workflowTriggered?' y monitor iniciado':''}.`);
    return {...result,...dates};
  }catch(error){
    state.integrationDiagnostics.github={ok:false,label:'Error de sincronización',error:error.message};
    if(!silent)toast(`Las fechas se actualizaron en la app, pero GitHub no se pudo actualizar: ${error.message}`,'error');
    throw error;
  }
}

function fileToRawBase64(file){
  return new Promise((resolve,reject)=>{
    const reader=new FileReader();
    reader.onload=()=>{const value=String(reader.result||'');resolve(value.includes(',')?value.split(',').pop():value);};
    reader.onerror=()=>reject(reader.error||new Error('No se ha podido leer el ZIP.'));
    reader.readAsDataURL(file);
  });
}
const MOBILE_DEPLOY_REQUEST_KEY='mfe-mobile-deploy-request-id';
function mobileDeployRequestId(){return String(state.mobileDeployProgress?.requestId||localStorage.getItem(MOBILE_DEPLOY_REQUEST_KEY)||'').trim();}
function mobileDeployRunLabel(progress=state.mobileDeployProgress){
  if(!progress)return 'Preparado';if(progress.error)return 'Error de seguimiento';if(!progress.runFound)return 'Esperando GitHub…';
  const status=String(progress.run?.status||''),conclusion=String(progress.run?.conclusion||'');
  if(status==='completed')return conclusion==='success'?'Actualización completada':'Actualización fallida';
  if(status==='in_progress')return 'Actualizando…';return 'En cola…';
}
function mobileDeployStepIcon(step={}){const status=String(step.status||''),conclusion=String(step.conclusion||'');if(status==='completed')return conclusion==='success'?'✓':(conclusion==='skipped'?'—':'✕');if(status==='in_progress')return '⏳';return '○';}
function mobileDeployProgressMarkup(progress=state.mobileDeployProgress){
  if(!progress)return '<div class="mobile-deploy-progress is-idle"><small>El progreso de la próxima actualización aparecerá aquí sin salir de MFE Viajes.</small></div>';
  if(progress.clientPhase){
    const pct=Math.max(2,Math.min(100,Number(progress.percentage)||2));
    const tone=progress.error?'is-error':'is-running';
    return `<div class="mobile-deploy-progress ${tone}"><div class="mobile-deploy-progress-head"><strong>${esc(progress.label||'Preparando actualización…')}</strong><span>${Math.round(pct)}%</span></div><div class="mobile-deploy-progress-bar"><span style="width:${pct}%"></span></div>${progress.detail?`<small>${esc(progress.detail)}</small>`:''}</div>`;
  }
  const run=progress.run||{},steps=(progress.steps||[]).filter(step=>!/^Set up job$|^Complete job$/i.test(String(step.name||'')));
  const total=steps.length||Number(progress.progress?.totalSteps)||0,done=steps.filter(step=>String(step.status)==='completed').length,pct=total?Math.round(done*100/total):(progress.runFound?5:2);
  const status=String(run.status||''),conclusion=String(run.conclusion||''),cls=status==='completed'?(conclusion==='success'?'is-success':'is-error'):(status==='in_progress'?'is-running':'is-waiting'),time=run.startedAt||run.createdAt||'';
  return `<div class="mobile-deploy-progress ${cls}"><div class="mobile-deploy-progress-head"><strong>${esc(mobileDeployRunLabel(progress))}</strong><span>${done}/${total||'—'}</span></div><div class="mobile-deploy-progress-bar"><span style="width:${Math.max(2,Math.min(100,pct))}%"></span></div>${time?`<small>Iniciado: ${esc(formatDate(time,{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'}))}</small>`:''}${steps.length?`<div class="mobile-deploy-steps">${steps.map(step=>`<div class="mobile-deploy-step ${String(step.status||'')==='in_progress'?'is-active':''} ${String(step.conclusion||'')==='failure'?'is-error':''}"><span>${mobileDeployStepIcon(step)}</span><em>${esc(step.name||'Paso')}</em></div>`).join('')}</div>`:'<small>GitHub está creando la ejecución…</small>'}${run.htmlUrl?`<a class="btn ghost small mobile-deploy-github" href="${esc(run.htmlUrl)}" target="_blank" rel="noopener">Abrir log completo</a>`:''}</div>`;
}

const TRACKER_PROGRESS_STORAGE_PREFIX=`mfe-tracker-run:${TRIP_ID}:`;
function trackerRunLabel(type,progress=state.trackerRunProgress?.[type]){
  const names={autoreisen:'AutoReisen',cordial:'Cordial',vueling:'Vueling',fuel:'Gasolineras',flightops:'Estado de vuelos'},name=names[type]||type;
  if(!progress)return `${name} · preparado`;
  if(progress.error)return `${name} · error`;
  if(progress.localLabel)return `${name} · ${progress.localLabel}`;
  if(!progress.runFound)return `${name} · esperando GitHub…`;
  const status=String(progress.run?.status||''),conclusion=String(progress.run?.conclusion||'');
  if(status==='completed')return conclusion==='success'?`${name} · completado`:`${name} · fallido`;
  if(status==='in_progress')return `${name} · ejecutando…`;
  return `${name} · en cola…`;
}
function trackerRunProgressMarkup(type,progress=state.trackerRunProgress?.[type]){
  if(!progress)return '<div class="mobile-deploy-progress is-idle tracker-run-progress"><small>El progreso aparecerá aquí al ejecutar una comprobación.</small></div>';
  const run=progress.run||{},steps=(progress.steps||[]).filter(step=>!/^Set up job$|^Complete job$/i.test(String(step.name||'')));
  const total=steps.length||Number(progress.progress?.totalSteps)||Number(progress.localTotal)||0;
  const done=steps.length?steps.filter(step=>String(step.status)==='completed').length:Number(progress.localDone)||0;
  const pct=Number(progress.progress?.percentage)||Number(progress.localPercentage)||(total?Math.round(done*100/total):(progress.runFound?5:2));
  const status=String(run.status||''),conclusion=String(run.conclusion||''),cls=progress.error?'is-error':progress.localDone===progress.localTotal&&progress.localTotal>0?'is-success':status==='completed'?(conclusion==='success'?'is-success':'is-error'):(status==='in_progress'||progress.localLabel?'is-running':'is-waiting');
  const time=run.startedAt||run.createdAt||progress.startedAfter||'';
  const localSteps=Array.isArray(progress.localSteps)?progress.localSteps:[];
  const items=steps.length?steps:localSteps;
  const diagnostic=progress.error||progress.diagnostic?.summary||'';
  return `<div class="mobile-deploy-progress ${cls} tracker-run-progress"><div class="mobile-deploy-progress-head"><strong>${esc(trackerRunLabel(type,progress))}</strong><span>${Math.max(0,Math.min(100,Math.round(pct)))}%</span></div><div class="mobile-deploy-progress-bar"><span style="width:${Math.max(2,Math.min(100,pct))}%"></span></div>${time?`<small>Inicio: ${esc(formatDate(time,{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'}))}</small>`:''}${items.length?`<div class="mobile-deploy-steps">${items.map(step=>{const st=String(step.status||''),co=String(step.conclusion||'');const icon=st==='completed'?(co==='failure'?'✕':'✓'):st==='in_progress'?'⏳':'○';return `<div class="mobile-deploy-step ${st==='in_progress'?'is-active':''} ${co==='failure'?'is-error':''}"><span>${icon}</span><em>${esc(step.name||'Paso')}</em></div>`;}).join('')}</div>`:''}${diagnostic?`<small class="tracker-run-diagnostic">${esc(diagnostic)}</small>`:''}${run.htmlUrl?`<a class="btn ghost small mobile-deploy-github" href="${esc(run.htmlUrl)}" target="_blank" rel="noopener">Abrir log completo</a>`:''}</div>`;
}
function paintTrackerRunProgress(type){const node=$(`[data-tracker-run-progress="${CSS.escape(type)}"]`);if(node)node.innerHTML=trackerRunProgressMarkup(type);}
function clearTrackerRunTimer(type){const timer=state.trackerRunTimers?.[type];if(timer)clearInterval(timer);if(state.trackerRunTimers)state.trackerRunTimers[type]=null;}
async function fetchTrackerRunProgress(type,{startedAfter='',silent=true}={}){
  const current=state.trackerRunProgress?.[type]||{},started=String(startedAfter||current.startedAfter||'').trim();if(!started)return null;
  try{
    const result=await callIntegrationWorker({action:'github-tracker-run-status',type,startedAfter:started,runId:current.run?.id||''},{timeoutMs:20000});
    state.trackerRunProgress[type]={...result,startedAfter:started};paintTrackerRunProgress(type);
    if(result.run?.status==='completed'){clearTrackerRunTimer(type);try{localStorage.removeItem(`${TRACKER_PROGRESS_STORAGE_PREFIX}${type}`);}catch{}if(!silent&&result.run?.conclusion!=='success')toast(`${trackerRunLabel(type,result)}${result.diagnostic?.summary?` · ${result.diagnostic.summary}`:''}`,'error');}
    return result;
  }catch(error){state.trackerRunProgress[type]={...current,startedAfter:started,error:error.message,runFound:false};paintTrackerRunProgress(type);if(!silent)toast(`Progreso ${type}: ${error.message}`,'error');return null;}
}
function startTrackerRunProgress(type,startedAt=Date.now()){
  const startedAfter=new Date(Number(startedAt)||Date.now()).toISOString();
  state.trackerRunProgress[type]={runFound:false,startedAfter,progress:{percentage:2},steps:[]};paintTrackerRunProgress(type);
  try{localStorage.setItem(`${TRACKER_PROGRESS_STORAGE_PREFIX}${type}`,startedAfter);}catch{}
  clearTrackerRunTimer(type);fetchTrackerRunProgress(type,{startedAfter,silent:true}).catch(()=>{});state.trackerRunTimers[type]=setInterval(()=>fetchTrackerRunProgress(type,{startedAfter,silent:true}).catch(()=>{}),5000);
}
function setTrackerRunError(type,error,startedAt=Date.now()){clearTrackerRunTimer(type);state.trackerRunProgress[type]={runFound:false,startedAfter:new Date(Number(startedAt)||Date.now()).toISOString(),error:String(error?.message||error||'Error desconocido')};paintTrackerRunProgress(type);}
function resumeTrackerRunProgress(){for(const type of ['autoreisen','cordial','vueling']){let started='';try{started=localStorage.getItem(`${TRACKER_PROGRESS_STORAGE_PREFIX}${type}`)||'';}catch{}if(started&&!state.trackerRunTimers[type])startTrackerRunProgress(type,Date.parse(started)||Date.now());}}
function setFuelLocalProgress({label,percentage,steps,done=0,total=0,error=''}){state.trackerRunProgress.fuel={localLabel:label,localPercentage:percentage,localSteps:steps||[],localDone:done,localTotal:total,error};paintTrackerRunProgress('fuel');}
function updateDiagnosticLevel(item={}){return String(item?.level||(item?.ok===true?'ok':'warn'));}
function updateDiagnosticsMarkup(){const d=state.updateDiagnostics;if(!d)return '<div class="mobile-deploy-progress is-idle"><small>El diagnóstico comprueba los dos Workers y el acceso real a GitHub. Es informativo y nunca bloquea el botón de actualización.</small></div>';const rows=[['Worker principal',d.mainWorker],['GitHub principal',d.mainGithub],['Worker Vueling',d.vuelingWorker],['GitHub Vueling',d.vuelingGithub]];const errors=rows.filter(([,x])=>updateDiagnosticLevel(x)==='error').length,warnings=rows.filter(([,x])=>updateDiagnosticLevel(x)==='warn').length,ok=rows.filter(([,x])=>updateDiagnosticLevel(x)==='ok').length,tone=errors?'is-error':warnings?'is-waiting':'is-success',title=errors?'Diagnóstico con incidencias':warnings?'Diagnóstico con avisos · actualización permitida':'Diagnóstico correcto';return `<div class="mobile-deploy-progress ${tone}"><div class="mobile-deploy-progress-head"><strong>${title}</strong><span>${ok}/${rows.length}</span></div><div class="mobile-deploy-steps">${rows.map(([label,x])=>{const level=updateDiagnosticLevel(x),icon=level==='ok'?'✓':level==='error'?'✕':'⚠';return `<div class="mobile-deploy-step ${level==='error'?'is-error':level==='warn'?'is-active':''}"><span>${icon}</span><em>${esc(label)} · ${esc(x?.label||'Sin comprobar')}</em></div>`;}).join('')}</div>${warnings&&!errors?'<small>Los avisos de versión antigua no bloquean la actualización: el ZIP puede publicar precisamente los Workers que faltan.</small>':''}${d.checkedAt?`<small>Comprobado: ${esc(formatDate(d.checkedAt,{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'}))}</small>`:''}</div>`;}
function updateDiagnosticAuthLevel(message='',workerCurrent=false){const text=String(message||'').toLowerCase();if(/401|403|bad credentials|credenciales|token.*(caduc|revoc|invalid)|permis/.test(text))return 'error';if(!workerCurrent||/no validado|no reconoc|unsupported|not supported|acción.*no reconoc/.test(text))return 'warn';return 'error';}
async function runUpdateDiagnostics({silent=false}={}){
  const out={checkedAt:new Date().toISOString()};let mainCurrent=false,vuelingCurrent=false;
  try{const h=await fetchIntegrationHealth();mainCurrent=h?.version==='2.2.53';out.mainWorker={ok:mainCurrent,level:mainCurrent?'ok':'warn',label:mainCurrent?`v${h?.version||'?'}`:`v${h?.version||'?'} · se actualizará a v2.2.53`};}catch(e){out.mainWorker={ok:false,level:'warn',label:`No comprobado · ${e.message}`};}
  try{const g=await callIntegrationWorker({action:'github-auth-diagnostic'},{timeoutMs:20000});const authOk=g?.githubAuth===true;out.mainGithub={ok:authOk,level:authOk?'ok':updateDiagnosticAuthLevel('No validado',mainCurrent),label:authOk?'Token válido · repositorio accesible':(mainCurrent?'No validado':'Diagnóstico no disponible en Worker antiguo · se validará al subir el ZIP')};}catch(e){out.mainGithub={ok:false,level:updateDiagnosticAuthLevel(e.message,mainCurrent),label:mainCurrent?e.message:'Diagnóstico no disponible en Worker antiguo · se validará al subir el ZIP'};}
  try{const h=await fetchVuelingHealth();vuelingCurrent=h?.version==='1.0.23';out.vuelingWorker={ok:vuelingCurrent,level:vuelingCurrent?'ok':'warn',label:vuelingCurrent?`v${h?.version||'?'}`:`v${h?.version||'?'} · se actualizará a v1.0.23`};}catch(e){out.vuelingWorker={ok:false,level:'warn',label:`No comprobado · ${e.message}`};}
  try{const g=await callVuelingWorker({action:'github-vueling-diagnostic'},{authenticated:true,timeoutMs:20000});const authOk=g?.githubAuth===true;out.vuelingGithub={ok:authOk,level:authOk?'ok':updateDiagnosticAuthLevel('No validado',vuelingCurrent),label:authOk?'Token válido · repositorio accesible':(vuelingCurrent?'No validado':'Diagnóstico no disponible en Worker antiguo · se validará durante la actualización')};}catch(e){out.vuelingGithub={ok:false,level:updateDiagnosticAuthLevel(e.message,vuelingCurrent),label:vuelingCurrent?e.message:'Diagnóstico no disponible en Worker antiguo · se validará durante la actualización'};}
  state.updateDiagnostics=out;if(state.activeTab==='settings'&&state.settingsPanel==='updates')render();if(!silent){const rows=[out.mainWorker,out.mainGithub,out.vuelingWorker,out.vuelingGithub],errors=rows.filter(x=>updateDiagnosticLevel(x)==='error').length,warnings=rows.filter(x=>updateDiagnosticLevel(x)==='warn').length;toast(errors?'Diagnóstico terminado con incidencias. La subida intentará validar de nuevo al publicar.':warnings?'Diagnóstico con avisos. Puedes actualizar: los Workers antiguos se repararán con el ZIP.':'Diagnóstico de actualización correcto.',errors?'error':warnings?'success':'success');}return out;
}

async function fetchMobileDeployProgress({requestId='',silent=true}={}){
  const rid=String(requestId||mobileDeployRequestId()).trim();if(!rid)return null;
  try{const result=await callIntegrationWorker({action:'github-mobile-deploy-run-status',requestId:rid},{timeoutMs:20000});state.mobileDeployProgress={...result,requestId:rid};const label=mobileDeployRunLabel(state.mobileDeployProgress),failed=result.run?.status==='completed'&&result.run?.conclusion!=='success';state.integrationDiagnostics.mobileDeploy={ok:!failed,label,detail:result};if(result.run?.status==='completed'){clearInterval(state.mobileDeployTimer);state.mobileDeployTimer=null;if(result.run?.conclusion==='success')localStorage.removeItem(MOBILE_DEPLOY_REQUEST_KEY);if(!silent)toast(result.run?.conclusion==='success'?'MFE Viajes se ha actualizado correctamente.':'La actualización ha terminado con errores.',result.run?.conclusion==='success'?'success':'error');}if(state.activeTab==='settings'&&['integrations','updates'].includes(state.settingsPanel))render();return result;}catch(error){state.mobileDeployProgress={requestId:rid,error:error.message,runFound:false};if(!silent)toast(`No se pudo consultar el progreso: ${error.message}`,'error');return null;}
}
function startMobileDeployProgressPolling(requestId=''){const rid=String(requestId||mobileDeployRequestId()).trim();if(!rid)return;try{localStorage.setItem(MOBILE_DEPLOY_REQUEST_KEY,rid);}catch{}clearInterval(state.mobileDeployTimer);state.mobileDeployTimer=null;fetchMobileDeployProgress({requestId:rid,silent:true}).catch(()=>{});state.mobileDeployTimer=setInterval(()=>fetchMobileDeployProgress({requestId:rid,silent:true}).catch(()=>{}),6000);}
async function checkMobileDeployStatus({silent=false}={}){const result=await callIntegrationWorker({action:'github-mobile-deploy-status'},{timeoutMs:20000});state.integrationDiagnostics.mobileDeploy={ok:Boolean(result.current),label:result.current?'Preparado':'Pendiente de preparar',detail:result};const rid=mobileDeployRequestId();if(rid)await fetchMobileDeployProgress({requestId:rid,silent:true});await runUpdateDiagnostics({silent:true});if(!silent)toast(result.current?'Actualización móvil preparada en GitHub.':'Falta preparar el workflow móvil.');return result;}
async function prepareMobileDeploy(){if(!canEdit())throw new Error('Desbloquea la edición para preparar la actualización móvil.');toast('Preparando GitHub Actions para actualizar desde Android…');const result=await callIntegrationWorker({action:'github-mobile-deploy-install'},{timeoutMs:45000});state.integrationDiagnostics.mobileDeploy={ok:true,label:'Preparado',detail:result};toast(result.updated?'Workflow móvil instalado en GitHub.':'El workflow móvil ya estaba preparado.');if(state.activeTab==='settings'&&['integrations','updates'].includes(state.settingsPanel))render();return result;}
async function waitForMobileDeployRunConfirmation(requestId,{attempts=12,delayMs=2000}={}){
  const rid=String(requestId||'').trim();if(!rid)return null;
  for(let attempt=1;attempt<=attempts;attempt++){
    const progress=await fetchMobileDeployProgress({requestId:rid,silent:true});
    if(progress?.runFound&&progress?.run?.id)return progress;
    if(attempt<attempts)await new Promise(resolve=>setTimeout(resolve,delayMs));
  }
  return null;
}
function setMobileDeployClientPhase(label,percentage,detail=''){
  state.mobileDeployProgress={clientPhase:true,label,percentage,detail};
  if(state.activeTab==='settings'&&state.settingsPanel==='updates'){
    const host=$('[data-mobile-deploy-progress-host]');if(host)host.innerHTML=mobileDeployProgressMarkup(state.mobileDeployProgress);
  }
}
async function processMobileReleaseFile(file){
  if(!canEdit())throw new Error('Desbloquea la edición para actualizar la app.');
  if(!file)return;
  if(!/\.zip$/i.test(file.name))throw new Error('Selecciona el ZIP completo de MFE Viajes.');
  if(file.size>20*1024*1024)throw new Error('El ZIP supera 20 MB. Usa la release compacta de MFE Viajes.');
  if(!confirmAction(`¿Actualizar MFE Viajes con «${file.name}»?

El ZIP se subirá al repositorio privado de GitHub y se lanzará GitHub Actions.`))return;
  const uploadButton=$('[data-mobile-deploy-upload]'),originalLabel=uploadButton?.innerHTML||'';
  if(uploadButton){uploadButton.disabled=true;uploadButton.setAttribute('aria-busy','true');uploadButton.innerHTML='⏳ Actualizando…';}
  try{
    // v2.3.27: subida móvil por bloques para evitar que Android se quede detenido en el 48%.
    // El Worker 2.2.53 ya dispone de sesión temporal KV y ensamblado seguro.
    setMobileDeployClientPhase('1/4 · Leyendo ZIP',10,file.name);
    const releaseBase64=await fileToRawBase64(file);
    if(!releaseBase64||!/^UEsDB/.test(releaseBase64))throw new Error('El archivo seleccionado no parece un ZIP válido.');
    const chunkSize=320000;
    const chunks=[];for(let offset=0;offset<releaseBase64.length;offset+=chunkSize)chunks.push(releaseBase64.slice(offset,offset+chunkSize));
    setMobileDeployClientPhase('2/4 · Preparando subida segura',18,`${Math.round(file.size/1024)} KB · ${chunks.length} bloques`);
    const authToken=await currentFirebaseIdToken({timeoutMs:15000});
    const init=await callIntegrationWorker({action:'github-mobile-release-upload-init',releaseName:file.name,totalBytes:file.size,totalChunks:chunks.length},{timeoutMs:30000,token:authToken});
    const uploadId=String(init?.uploadId||'').trim();if(!uploadId)throw new Error('El Worker no pudo iniciar la sesión de subida.');
    for(let index=0;index<chunks.length;index++){
      const pct=22+Math.round(((index+1)/chunks.length)*34);
      setMobileDeployClientPhase(`2/4 · Subiendo ZIP · bloque ${index+1}/${chunks.length}`,pct,`${Math.round(file.size/1024)} KB · subida por bloques`);
      const part=await callIntegrationWorker({action:'github-mobile-release-upload-chunk',uploadId,index,totalChunks:chunks.length,chunkBase64:chunks[index]},{timeoutMs:45000,token:authToken});
      if(!part?.received)throw new Error(`No se confirmó el bloque ${index+1}/${chunks.length}.`);
    }
    setMobileDeployClientPhase('3/4 · Ensamblando y lanzando GitHub Actions',62,'El ZIP ya está completo en el Worker.');
    const result=await callIntegrationWorker({action:'github-mobile-release-upload-finalize',uploadId},{timeoutMs:150000,token:authToken});
    if(!result?.uploaded)throw new Error('GitHub no confirmó la sustitución de MFE_Viajes_RELEASE.zip.');
    if(!result?.workflowTriggered)throw new Error('GitHub recibió el ZIP, pero no confirmó el lanzamiento del workflow.');
    const requestId=String(result.requestId||'').trim();
    if(!requestId)throw new Error('El Worker no devolvió el identificador de seguimiento de la actualización.');
    try{localStorage.setItem(MOBILE_DEPLOY_REQUEST_KEY,requestId);}catch{}
    state.mobileDeployProgress={requestId,runFound:false,actionsUrl:result.actionsUrl,uploaded:true,workflowTriggered:true};
    state.integrationDiagnostics.mobileDeploy={ok:true,label:'Workflow lanzado · esperando GitHub',detail:result};
    setMobileDeployClientPhase('4/4 · Workflow lanzado',72,'El ZIP ya está en GitHub. La ejecución aparecerá en cuanto Actions la cree.');
    startMobileDeployProgressPolling(requestId);
    // Deja inmediatamente el panel en modo seguimiento, como el actualizador estable antiguo.
    state.mobileDeployProgress={requestId,runFound:false,actionsUrl:result.actionsUrl,uploaded:true,workflowTriggered:true};
    if(state.activeTab==='settings'&&state.settingsPanel==='updates'){
      const host=$('[data-mobile-deploy-progress-host]');if(host)host.innerHTML=mobileDeployProgressMarkup(state.mobileDeployProgress);
    }
    toast('ZIP subido y workflow lanzado. El progreso se actualizará automáticamente.','success');
  }catch(error){
    state.mobileDeployProgress={clientPhase:true,label:'Actualización no iniciada',percentage:100,detail:String(error?.message||error),error:true};
    if(state.activeTab==='settings'&&state.settingsPanel==='updates'){
      const host=$('[data-mobile-deploy-progress-host]');if(host)host.innerHTML=mobileDeployProgressMarkup(state.mobileDeployProgress);
    }
    throw error;
  }finally{
    if(uploadButton?.isConnected){uploadButton.disabled=false;uploadButton.removeAttribute('aria-busy');uploadButton.innerHTML=originalLabel||'📦 Seleccionar ZIP y actualizar';}
  }
}
async function retryMobileDeployWorkflow(){
  const previous=mobileDeployRequestId();
  if(!previous)throw new Error('No hay una actualización pendiente que relanzar. Selecciona primero un ZIP.');
  setMobileDeployClientPhase('Relanzando workflow…',55,'No se vuelve a subir el ZIP.');
  const result=await callIntegrationWorker({action:'github-mobile-deploy-trigger',requestId:previous},{timeoutMs:45000});
  if(!result?.workflowTriggered)throw new Error('GitHub no confirmó el relanzamiento del workflow.');
  const requestId=String(result.requestId||previous).trim();
  try{localStorage.setItem(MOBILE_DEPLOY_REQUEST_KEY,requestId);}catch{}
  state.mobileDeployProgress={requestId,runFound:false,actionsUrl:result.actionsUrl,workflowTriggered:true};
  startMobileDeployProgressPolling(requestId);
  toast('Workflow relanzado. Esperando a GitHub Actions.','success');
  if(state.activeTab==='settings'&&state.settingsPanel==='updates')render();
  return result;
}
function openMobileReleasePicker(){
  if(!canEdit())throw new Error('Desbloquea la edición para actualizar la app.');
  const input=$('[data-mobile-deploy-file]');
  if(!input)throw new Error('No se ha podido abrir el selector de archivos. Recarga GC 26 y vuelve a intentarlo.');
  input.value='';
  input.click();
}

async function testIntegration(name){
  try{
    const labels={firebase:'Firebase',drive:'Google Drive',github:'GitHub Actions',cloudflare:'Cloudflare Worker',mobiledeploy:'Actualización móvil',calendar:'Google Calendar',notifications:'Notificaciones',weather:'Open-Meteo'};
    toast(`Comprobando ${labels[name]||name}…`);
    if(name==='firebase'){
      if(!(state.provider instanceof FirebaseProvider))throw new Error('Firebase no está conectado.');
      await state.provider.profile(state.user);state.integrationDiagnostics.firebase={ok:true,label:'Conectado'};toast('Firebase conectado correctamente.');
    }else if(name==='drive'){
      const result=await testDriveIntegration();state.integrationDiagnostics.drive={ok:true,label:result.label};toast(`Google Drive conectado: ${result.label}.`);
    }else if(name==='cloudflare'||name==='github'){
      const health=await fetchIntegrationHealth();state.integrationDiagnostics.worker={ok:true,label:`Activo${health.version?` · v${health.version}`:''}`,detail:health};state.integrationDiagnostics.github={ok:Boolean(health.githubConfigured),label:health.githubConfigured?'Configurado':'Pendiente',detail:health};
      if(name==='github'&&!health.githubConfigured)throw new Error('El Worker funciona, pero faltan las variables GITHUB_TOKEN, GITHUB_OWNER o GITHUB_REPO.');
      toast(name==='github'?'GitHub está configurado en el Worker.':'Cloudflare Worker conectado.');
    }else if(name==='mobiledeploy'){await checkMobileDeployStatus();}
    else if(name==='calendar')toast('Google Calendar está disponible mediante enlaces de creación de eventos.');
    else if(name==='notifications'){await runNotificationDiagnostics();return;}
    else if(name==='weather'){await refreshWeather();return;}
    if(state.activeTab==='settings'&&['integrations','updates'].includes(state.settingsPanel))render();
  }catch(error){
    if(name==='drive')state.integrationDiagnostics.drive={ok:false,label:'Error',error:error.message};
    if(name==='github')state.integrationDiagnostics.github={ok:false,label:'Pendiente',error:error.message};
    if(name==='cloudflare')state.integrationDiagnostics.worker={ok:false,label:'Sin conexión',error:error.message};
    if(name==='mobiledeploy')state.integrationDiagnostics.mobileDeploy={ok:false,label:'Pendiente',error:error.message};
    toast(error.message||'No se ha podido comprobar la integración.','error');
    if(state.activeTab==='settings'&&['integrations','updates'].includes(state.settingsPanel))render();
  }
}
function usefulProductName(value) {
  const name=String(value||"").trim();
  if(!name)return false;
  return !/(resultados? de b[uú]squeda|resultados? para|buscar|alimentaci[oó]n y supermercado|hiperdino\s*[-–|])/i.test(name);
}
async function fetchProductUpdate(store,product,{requirePrice=false}={}) {
  const data=await callPriceWorker({url:product.url,postalCode:store.postalCode,productName:product.name});
  const priceValue=data.price===null||data.price===undefined||data.price===""?null:Number(data.price);
  const validPrice=Number.isFinite(priceValue)&&priceValue>0;
  const validName=usefulProductName(data.name);
  const validImage=isImageSource(data.image);
  if(requirePrice&&!validPrice)throw new Error(data.message||"HiperDino no ha devuelto un precio válido; se conserva el precio, la fecha y la imagen anteriores.");
  if(!validPrice&&!validName&&!validImage)throw new Error(data.message||"La tienda no ha devuelto datos válidos para este producto.");
  const now=new Date().toISOString();
  let updated={
    ...normalizeProductImageFields(product),
    name:validName?String(data.name).trim():product.name,
    unitPrice:validPrice?priceValue:product.unitPrice,
    priceUpdatedAt:validPrice?now:product.priceUpdatedAt,
    imageUpdatedAt:validImage?now:product.imageUpdatedAt
  };
  updated=mergeAutomaticProductImage(updated,validImage?data.image:"");
  return updated;
}
async function syncProduct(storeIndex,productIndex) {
  const store=state.data.shopping.stores[storeIndex],product=store?.products?.[productIndex];
  if(!store||!product)return;
  try {
    toast("Consultando la página del producto…");
    const beforePrices=shoppingCurrentPriceMap();
    store.products[productIndex]=await fetchProductUpdate(store,product,{requirePrice:true});
    const recorded=recordShoppingPriceSnapshot({source:"manual",beforePrices});
    await saveSection("shopping");
    state.shoppingSyncReport={completedAt:shoppingTracking().lastRunAt,total:1,refreshed:1,changed:recorded.changes.length,failed:0,failures:[],priceChanges:recorded.changes};
    render();
    toast(recorded.changes.length?`Producto actualizado · ${recorded.changes.length} cambio de precio.`:"Producto actualizado · sin cambios de precio.");
  } catch(error) {
    state.shoppingSyncReport={completedAt:new Date().toISOString(),total:1,refreshed:0,changed:0,failed:1,failures:[{storeIndex,productIndex,storeName:store.name,name:product.name,url:product.url,message:error?.message||"No se ha podido actualizar el producto."}]};
    render();
    toast(error.message || "No se ha podido actualizar el producto.","error");
  }
}
async function syncAllProducts({source="manual",silent=false}={}) {
  const queue=[];state.data.shopping.stores.forEach((store,s)=>store.products.forEach((product,p)=>{if(isValidUrl(product.url))queue.push({store,s,product,p});}));
  if(!queue.length){if(!silent)toast('No hay productos con enlace web para actualizar.','error');return {ok:false,reason:'empty'};}
  const beforePrices=shoppingCurrentPriceMap(),previousTotal=shoppingTotal();
  let refreshed=0,changed=0,failed=0,completed=0;
  const failures=[];
  state.shoppingSyncReport=null;
  setSaveState(`${source==="auto"?"Actualización automática":"Actualizando"} 0/${queue.length}…`,'saving');
  for(const entry of queue){
    try{
      const previousPrice=num(entry.product.unitPrice);
      const next=await fetchProductUpdate(entry.store,entry.product,{requirePrice:true});
      entry.store.products[entry.p]=next;
      refreshed++;
      if(Math.abs(num(next.unitPrice)-previousPrice)>=0.005)changed++;
    }catch(error){
      console.warn('Actualización de precio',entry.product?.name||entry.product?.url,error);
      failed++;
      failures.push({storeIndex:entry.s,productIndex:entry.p,storeName:entry.store?.name||'Supermercado',name:entry.product?.name||'Producto',url:entry.product?.url||'',message:error?.message||String(error)});
    }finally{
      completed++;
      setSaveState(`Revisando ${completed}/${queue.length} · ${refreshed} correctos · ${changed} cambios · ${failed} errores…`,'saving');
      if(completed<queue.length)await new Promise(resolve=>setTimeout(resolve,320));
    }
  }
  const completedAt=new Date().toISOString(),recorded=recordShoppingPriceSnapshot({source,beforePrices,at:completedAt}),currentTotal=shoppingTotal();
  await saveSection('shopping');
  state.shoppingSyncReport={completedAt,total:queue.length,refreshed,changed:recorded.changes.length,failed,failures,priceChanges:recorded.changes,previousTotal,currentTotal};
  render();
  setSaveState('Guardado');
  const detail=failures.length?` · Revisa el panel de errores para ver los ${failures.length} producto${failures.length===1?'':'s'} y sus enlaces.`:'';
  const totalDelta=currentTotal-previousTotal,totalText=Math.abs(totalDelta)>=.005?` · total ${totalDelta>0?'+':''}${formatMoney(totalDelta)}`:' · total sin cambios';
  const message=`Revisión ${source==='auto'?'automática ':''}terminada: ${refreshed}/${queue.length} correctos · ${recorded.changes.length} precios cambiados · ${failed} errores${totalText}${detail}`;
  if(!silent||recorded.changes.length||failed)toast(message,failed&&refreshed===0?'error':failed?'warning':'success');
  return {ok:refreshed>0,refreshed,failed,changes:recorded.changes,previousTotal,currentTotal};
}

function findStoreByName(name) {
  const target=String(name||"").trim().toLocaleLowerCase("es");
  if(!target)return null;
  const stores=state.data.shopping.stores||[];
  return stores.find(store=>String(store.name||"").trim().toLocaleLowerCase("es")===target)
    || stores.find(store=>target.includes(String(store.name||"").trim().toLocaleLowerCase("es")) || String(store.name||"").trim().toLocaleLowerCase("es").includes(target));
}
function purchaseStoreMarkup(name) {
  const store=findStoreByName(name);
  const visual=store ? (isImageSource(store.logoUrl)
    ? `<img class="purchase-store-logo" src="${esc(store.logoUrl)}" alt="${esc(store.name)}" data-image-popup="${esc(store.logoUrl)}">`
    : `<span class="purchase-store-icon">${esc(store.icon||"🛒")}</span>`) : `<span class="purchase-store-icon">🛒</span>`;
  return `<div class="purchase-store" style="--purchase-store-color:${esc(store?.color||"#4da3ff")}">${visual}<span>${esc(name||"—")}</span></div>`;
}

function budgetGroupById(groupId) {
  return state.data.budget.groups.find(group=>group.id===groupId) || null;
}
function otherExpenseMarkup(expense) {
  const group=budgetGroupById(expense.groupId);
  const iconUrl=expense.iconUrl||group?.iconUrl||"";
  const icon=expense.icon||group?.icon||"💳";
  const color=group?.color||"#4da3ff";
  return `<div class="purchase-store other-expense-category" style="--purchase-store-color:${esc(color)}">${isImageSource(iconUrl)?`<img class="purchase-store-logo" src="${esc(iconUrl)}" alt="" data-image-popup="${esc(iconUrl)}">`:`<span class="purchase-store-icon">${esc(icon)}</span>`}<span>${esc(expense.category||"Otros gastos")}</span></div>`;
}

function extraSiteMarkup(extra) {
  const group=budgetGroupById("g-extras");
  const iconUrl=extra.iconUrl||group?.iconUrl||"";
  const icon=extra.icon||group?.icon||"✨";
  const color=group?.color||"#f7c84b";
  return `<div class="purchase-store extra-site" style="--purchase-store-color:${esc(color)}">${isImageSource(iconUrl)?`<img class="purchase-store-logo" src="${esc(iconUrl)}" alt="" data-image-popup="${esc(iconUrl)}">`:`<span class="purchase-store-icon">${esc(icon)}</span>`}<span>${esc(extra.name||extra.category||"Extra")}</span></div>`;
}


const TICKET_ITEMS_VIEW_KEY=`mfe-ticket-items-view:${TRIP_ID}`;
function ticketItemsViewPrefs(){
  try{
    const parsed=JSON.parse(localStorage.getItem(TICKET_ITEMS_VIEW_KEY)||'{}');
    return {
      sort:['manual','date-desc','date-asc','amount-desc','amount-asc','name-asc','name-desc'].includes(parsed.sort)?parsed.sort:'date-desc',
      group:['none','ticket','store'].includes(parsed.group)?parsed.group:'none',
      store:String(parsed.store||'')
    };
  }catch{return {sort:'date-desc',group:'none',store:''};}
}
function saveTicketItemsViewPrefs(next={}){
  const current=ticketItemsViewPrefs();
  const merged={...current,...next};
  try{localStorage.setItem(TICKET_ITEMS_VIEW_KEY,JSON.stringify(merged));}catch{}
  return merged;
}
function ticketItemStoreKey(value){return normalizedKey(value||'');}
function ticketItemSortRows(rows,sort='date-desc'){
  const copy=[...(rows||[])];
  if(sort==='manual')return copy;
  const byText=(a,b)=>String(a.name||'').localeCompare(String(b.name||''),'es',{sensitivity:'base',numeric:true});
  copy.sort((a,b)=>{
    if(sort==='amount-desc')return num(b.price)-num(a.price)||byText(a,b);
    if(sort==='amount-asc')return num(a.price)-num(b.price)||byText(a,b);
    if(sort==='name-asc')return byText(a,b);
    if(sort==='name-desc')return -byText(a,b);
    if(sort==='date-asc')return String(a.date||'').localeCompare(String(b.date||''))||byText(a,b);
    return String(b.date||'').localeCompare(String(a.date||''))||byText(a,b);
  });
  return copy;
}
function ticketItemRowMarkup(x,indexOverride=null){
  const qty=Math.max(.01,num(x.quantity)||1),unit=num(x.unitPrice)||num(x.price)/qty;
  const sourceIndex=indexOverride??x._sourceIndex;
  return `<tr ${x._allowManualDrag&&canEdit()?`data-sort-item="ticket-item|${sourceIndex}"`:''}><td>${purchaseTableDate(x.date)}</td><td>${purchaseStoreMarkup(x.store)}</td><td>${esc(x.name)}${num(x.ticketCount)>1&&!x._ticketOccurrence?` <small class="muted">(${num(x.ticketCount)} tickets)</small>`:""}</td><td class="amount">${qty.toLocaleString('es-ES')}</td><td class="amount">${formatMoney(unit)}</td><td class="amount">${formatMoney(x.price)}</td>${canEdit()?`<td><div class="row-actions">${x._allowManualDrag?sortDragHandle(`ticket-item|${sourceIndex}`,'Arrastrar producto'):''}<button class="mini-btn" data-delete-ticket-item="${sourceIndex}" title="Eliminar producto OCR">×</button></div></td>`:""}</tr>`;
}
function ticketOccurrences(items=[]){
  const out=[];
  items.forEach((item,sourceIndex)=>{
    const breakdown=Array.isArray(item.ticketBreakdown)&&item.ticketBreakdown.length?item.ticketBreakdown:null;
    if(!breakdown){
      out.push({...item,_sourceIndex:sourceIndex,_ticketOccurrence:true,_ticketId:'',_ticketLabel:'Histórico OCR',_legacyTicketCount:Math.max(1,num(item.ticketCount)||1)});
      return;
    }
    breakdown.forEach((entry,occurrenceIndex)=>out.push({
      ...item,
      date:entry.date||item.date||'',store:entry.store||item.store||'',quantity:Math.max(.01,num(entry.quantity)||1),
      price:Number(num(entry.price).toFixed(2)),unitPrice:num(entry.unitPrice)||num(entry.price)/Math.max(.01,num(entry.quantity)||1),
      _sourceIndex:sourceIndex,_ticketOccurrence:true,_ticketId:String(entry.ticketId||''),_ticketLabel:String(entry.label||''),
      _ticketUrl:String(entry.ticketUrl||''),_legacy:Boolean(entry.legacy),_legacyTicketCount:Math.max(1,Math.round(num(entry.ticketCount)||1)),_occurrenceIndex:occurrenceIndex
    }));
  });
  return out;
}
function ticketStoreSelectorMarkup(selectedStore=''){
  const stores=(state.data.shopping.stores||[]).filter(store=>store.active!==false);
  const current=selectedStore?findStoreByName(selectedStore):null;
  const summary=current?purchaseStoreMarkup(current.name):`<div class="purchase-store ticket-store-all"><span class="purchase-store-icon">🛒</span><span>Todos los supermercados</span></div>`;
  return `<details class="ticket-store-filter"><summary>${summary}<span class="ticket-filter-chevron">⌄</span></summary><div class="ticket-store-filter-menu"><button type="button" class="ticket-store-option ${!selectedStore?'active':''}" data-ticket-store-filter=""><span class="purchase-store-icon">🛒</span><span>Todos los supermercados</span></button>${stores.map(store=>`<button type="button" class="ticket-store-option ${ticketItemStoreKey(selectedStore)===ticketItemStoreKey(store.name)?'active':''}" data-ticket-store-filter="${esc(store.name)}">${purchaseStoreMarkup(store.name)}</button>`).join('')}</div></details>`;
}
function ticketItemsToolbarMarkup(prefs){
  return `<div class="ticket-items-toolbar"><label class="ticket-toolbar-field"><span>Ordenar</span><select data-ticket-sort><option value="manual" ${prefs.sort==='manual'?'selected':''}>Manual · arrastrar</option><option value="date-desc" ${prefs.sort==='date-desc'?'selected':''}>Fecha · más recientes</option><option value="date-asc" ${prefs.sort==='date-asc'?'selected':''}>Fecha · más antiguos</option><option value="amount-desc" ${prefs.sort==='amount-desc'?'selected':''}>Importe · mayor a menor</option><option value="amount-asc" ${prefs.sort==='amount-asc'?'selected':''}>Importe · menor a mayor</option><option value="name-asc" ${prefs.sort==='name-asc'?'selected':''}>Producto · A → Z</option><option value="name-desc" ${prefs.sort==='name-desc'?'selected':''}>Producto · Z → A</option></select></label><label class="ticket-toolbar-field"><span>Agrupar</span><select data-ticket-group><option value="none" ${prefs.group==='none'?'selected':''}>Sin agrupar</option><option value="ticket" ${prefs.group==='ticket'?'selected':''}>Por ticket</option><option value="store" ${prefs.group==='store'?'selected':''}>Por supermercado</option></select></label><div class="ticket-toolbar-field ticket-store-field"><span>Supermercado</span>${ticketStoreSelectorMarkup(prefs.store)}</div></div>`;
}
function ticketItemsTableMarkup(rows=[]){
  return `<div class="table-wrap"><table class="ticket-products-table"><thead><tr><th>Última fecha</th><th>Comercio</th><th>Producto</th><th class="amount">Cantidad</th><th class="amount">Precio ud.</th><th class="amount">Total</th>${canEdit()?"<th></th>":""}</tr></thead><tbody>${rows.map(row=>ticketItemRowMarkup(row)).join('')||`<tr><td colspan="${canEdit()?7:6}" class="empty">No hay productos que coincidan con estos filtros.</td></tr>`}</tbody></table></div>`;
}
function renderTicketItemsSection(){
  const prefs=ticketItemsViewPrefs();
  const all=(state.data.purchases.ticketItems||[]).map((item,index)=>({...item,_sourceIndex:index}));
  const filtered=prefs.store?all.filter(item=>ticketItemStoreKey(item.store)===ticketItemStoreKey(prefs.store)):all;
  const actions=`<button class="mini-btn export-mini-btn icon-only-export pdf-action-btn" type="button" data-export-ticket-pdf title="Exportar a PDF" aria-label="Exportar a PDF">${pdfFileIconMarkup("pdf-action-icon")}</button><button class="mini-btn export-mini-btn icon-only-export excel-action-btn" type="button" data-export-ticket-xlsx title="Exportar a Excel" aria-label="Exportar a Excel">${excelFileIconMarkup("excel-action-icon")}</button>${editButtons(`<button class="mini-btn" data-edit-purchase-block="ticketItems" title="Editar icono y título">✎</button><button class="mini-btn" data-add-ticket-item>＋</button>`)}`;
  let content='';
  if(!filtered.length){
    content=ticketItemsTableMarkup([]);
  }else if(prefs.group==='store'){
    const groups=new Map();
    filtered.forEach(item=>{const key=ticketItemStoreKey(item.store)||'__other';if(!groups.has(key))groups.set(key,{store:item.store||'—',rows:[]});groups.get(key).rows.push(item);});
    content=`<div class="ticket-group-list">${[...groups.values()].sort((a,b)=>String(a.store).localeCompare(String(b.store),'es',{sensitivity:'base'})).map(group=>{const rows=ticketItemSortRows(group.rows,prefs.sort);const subtotal=sum(rows.map(r=>r.price));return `<section class="ticket-product-group"><div class="ticket-group-head"><div>${purchaseStoreMarkup(group.store)}</div><div class="ticket-group-meta"><span>${rows.length} producto${rows.length===1?'':'s'}</span><strong>${formatMoney(subtotal)}</strong></div></div>${ticketItemsTableMarkup(rows)}</section>`;}).join('')}</div>`;
  }else if(prefs.group==='ticket'){
    const occurrences=ticketOccurrences(filtered);
    const groups=new Map();
    occurrences.forEach(row=>{
      const legacyKey=`legacy:${ticketItemStoreKey(row.store)}:${row.date||'sin-fecha'}:${row._legacyTicketCount||1}`;
      const key=row._ticketId||legacyKey;
      if(!groups.has(key))groups.set(key,{key,ticketId:row._ticketId||'',store:row.store||'—',date:row.date||'',label:row._ticketLabel||'',ticketUrl:row._ticketUrl||'',legacy:!row._ticketId||row._legacy,legacyCount:row._legacyTicketCount||1,rows:[]});
      groups.get(key).rows.push(row);
    });
    const recordsById=new Map((state.data.purchases.records||[]).map(record=>[String(record.id||''),record]));
    const grouped=[...groups.values()].sort((a,b)=>String(b.date||'').localeCompare(String(a.date||'')));
    content=`<div class="ticket-group-list">${grouped.map(group=>{const record=recordsById.get(group.ticketId);const rows=ticketItemSortRows(group.rows,prefs.sort);const ocrSubtotal=sum(rows.map(r=>r.price));const label=group.legacy?(group.legacyCount>1?`Histórico OCR · ${group.legacyCount} tickets`:'Histórico OCR'):(group.label||record?.ticketDriveName||`Ticket ${formatDate(group.date)}`);const ticketUrl=record?.ticketStoredUrl||record?.ticketUrl||group.ticketUrl||'';return `<section class="ticket-product-group"><div class="ticket-group-head ticket-group-head-receipt"><div class="ticket-group-title">${purchaseStoreMarkup(group.store)}<div><strong>${esc(label)}</strong><small>${formatDate(group.date)}${group.legacy?' · Sin desglose individual disponible en datos antiguos':''}</small></div></div><div class="ticket-group-meta"><span>${rows.length} producto${rows.length===1?'':'s'} · OCR ${formatMoney(ocrSubtotal)}</span>${record&&num(record.amount)>0?`<strong>Ticket ${formatMoney(record.amount)}</strong>`:''}${ticketUrl?popupFileLink(ticketUrl,'Ver ticket','🧾'):''}</div></div>${ticketItemsTableMarkup(rows)}</section>`;}).join('')}</div>`;
  }else{
    content=ticketItemsTableMarkup(ticketItemSortRows(filtered,prefs.sort).map(row=>({...row,_allowManualDrag:prefs.sort==='manual'})));
  }
  return `<section class="card ticket-items" style="margin-top:18px"><div class="section-title" style="${purchaseBlockSectionStyle('ticketItems')}">${purchaseBlockTitleMarkup('ticketItems')}<div class="section-actions ticket-export-actions">${actions}</div></div><div class="ticket-items-controls">${ticketItemsToolbarMarkup(prefs)}<p class="help-text">Ordena por fecha, importe o producto, o usa Manual para colocar los productos arrastrando. El arrastre está disponible en vista «Sin agrupar». Puedes separar la lista por ticket o por supermercado.</p></div>${content}</section>`;
}
function bindTicketItemsControls(){
  $('[data-ticket-sort]')?.addEventListener('change',event=>{saveTicketItemsViewPrefs({sort:event.target.value});render();});
  $('[data-ticket-group]')?.addEventListener('change',event=>{saveTicketItemsViewPrefs({group:event.target.value});render();});
  $$('[data-ticket-store-filter]').forEach(button=>button.addEventListener('click',()=>{saveTicketItemsViewPrefs({store:button.dataset.ticketStoreFilter||''});render();}));
}

function currentPurchasesBlockOrder(){
  const defaults=['supermarkets','extras','otherExpenses','ticketItems'];
  const saved=Array.isArray(state.data.settings.purchasesBlockOrder)?state.data.settings.purchasesBlockOrder:[];
  return [...saved.filter(id=>defaults.includes(id)),...defaults.filter(id=>!saved.includes(id))];
}
function purchasesBlockDragHandle(id){return canEdit()?sortDragHandle(`purchase-block|${encodeURIComponent(id)}`,'Arrastrar bloque de Compra real'):'';}
function purchaseTableDate(value){
  return value?formatDate(value,{day:"2-digit",month:"short"}):"—";
}
function renderPurchases() {
  const records=state.data.purchases.records||[];
  const otherExpenses=state.data.purchases.otherExpenses||[];
  const extras=state.data.purchases.extras||[];
  const supermarketTotal=supermarketPurchaseTotal();
  const otherTotal=otherExpensesTotal();
  const extraTotal=extrasTotal(),extraPaid=paidExtrasTotal(),extraPending=unpaidExtrasTotal();
  const total=supermarketTotal+otherTotal+extraPaid;
  const actions=canEdit()?'<button class="btn primary canary-action-btn" data-add-purchase>＋ Compra supermercado</button><button class="btn secondary" data-add-extra>＋ Extra</button><button class="btn secondary" data-add-other-expense>＋ Otro gasto</button>':"";
  const blockHeaderActions=(id,addButton='')=>editButtons(`<div class="section-actions purchase-block-actions">${purchasesBlockDragHandle(id)}<button class="mini-btn" data-edit-purchase-block="${esc(id)}" title="Editar icono y título">✎</button>${addButton}</div>`);
  const blocks={
    supermarkets:`<section class="card purchase-reorder-block" data-sort-item="purchase-block|supermarkets"><div class="section-title" style="${purchaseBlockSectionStyle('supermarkets')}">${purchaseBlockTitleMarkup('supermarkets')}${blockHeaderActions('supermarkets','<button class="mini-btn" data-add-purchase title="Añadir compra">＋</button>')}</div><div class="table-wrap"><table class="purchases-table supermarket-purchases-table"><colgroup><col class="purchases-col-date"><col class="purchases-col-store"><col class="purchases-col-amount"><col class="purchases-col-notes"><col class="purchases-col-file">${canEdit()?'<col class="purchases-col-actions">':''}</colgroup><thead><tr><th>Fecha</th><th>Supermercado</th><th class="amount">Importe</th><th>Notas</th><th>Ticket</th>${canEdit()?"<th></th>":""}</tr></thead><tbody>${records.map((r,i)=>`<tr data-sort-item="purchase-record|${i}"><td>${purchaseTableDate(r.date)}</td><td>${purchaseStoreMarkup(r.store)}</td><td class="amount">${formatMoney(r.amount)}</td><td>${esc(r.notes||"")}</td><td>${(r.ticketStoredUrl||r.ticketUrl)?popupFileLink(r.ticketStoredUrl||r.ticketUrl,"Ver ticket","🧾"):"—"}</td>${canEdit()?`<td><div class="row-actions">${sortDragHandle(`purchase-record|${i}`,'Arrastrar compra')}<button class="mini-btn" data-upload-ticket="${i}" title="Subir ticket">⬆</button><button class="mini-btn" data-drive-ticket="${i}" title="Seleccionar de Drive">${driveIconMarkup()}</button>${(r.ticketStoragePath||r.ticketUrl)?`<button class="mini-btn" data-ocr-ticket="${i}" title="Procesar OCR">⌁</button>`:""}<button class="mini-btn" data-edit-purchase="${i}">✎</button><button class="mini-btn" data-delete-purchase="${i}">×</button></div></td>`:""}</tr>`).join("")||`<tr><td colspan="${canEdit()?6:5}" class="empty">Todavía no hay compras de supermercado.</td></tr>`}</tbody></table></div><div class="group-total"><span>Total supermercados</span><strong>${formatMoney(supermarketTotal)}</strong></div></section>`,
    extras:`<section class="card extras-purchases-card purchase-reorder-block" data-extras-section data-sort-item="purchase-block|extras"><div class="section-title" style="${purchaseBlockSectionStyle('extras')}">${purchaseBlockTitleMarkup('extras')}${blockHeaderActions('extras','<button class="mini-btn" data-add-extra title="Añadir extra">＋</button>')}</div><div class="card-body extras-help"><p class="muted">Puedes añadir un extra aunque todavía no lo hayas pagado. Aparecerá automáticamente en <strong>Presupuesto → Extras</strong>, donde podrás cambiar su estado entre Pagado y No pagado.</p></div><div class="table-wrap"><table class="purchases-table extras-purchases-table"><colgroup><col class="extra-col-date"><col class="extra-col-site"><col class="extra-col-category"><col class="extra-col-amount"><col class="extra-col-status"><col class="extra-col-notes"><col class="extra-col-file">${canEdit()?'<col class="purchases-col-actions">':''}</colgroup><thead><tr><th>Fecha</th><th>Sitio / concepto</th><th>Categoría</th><th class="amount">Importe</th><th>Estado</th><th>Notas</th><th>Archivo</th>${canEdit()?"<th></th>":""}</tr></thead><tbody>${extras.map((x,i)=>`<tr data-sort-item="purchase-extra|${i}"><td>${purchaseTableDate(x.date)}</td><td>${extraSiteMarkup(x)}</td><td>${esc(x.category||"Extra")}</td><td class="amount">${formatMoney(x.amount)}</td><td><span class="status-pill ${x.status==="paid"?"paid":"unpaid"}">${x.status==="paid"?"PAGADO":"NO PAGADO"}</span></td><td>${esc(x.notes||"")}</td><td>${x.fileUrl?popupFileLink(x.fileUrl,"Ver archivo","📄"):"—"}</td>${canEdit()?`<td><div class="row-actions">${sortDragHandle(`purchase-extra|${i}`,'Arrastrar extra')}<button class="mini-btn" data-edit-extra="${i}" title="Editar extra">✎</button><button class="mini-btn" data-delete-extra="${i}" title="Eliminar extra">×</button></div></td>`:""}</tr>`).join("")||`<tr><td colspan="${canEdit()?8:7}" class="empty">Añade restaurantes, entradas, lotería, regalos u otros extras, incluso antes de pagarlos.</td></tr>`}</tbody></table></div><div class="group-total"><span>Total extras · ${formatMoney(extraPaid)} pagados${extraPending?` · ${formatMoney(extraPending)} pendientes`:""}</span><strong>${formatMoney(extraTotal)}</strong></div></section>`,
    otherExpenses:`<section class="card other-expenses-card purchase-reorder-block" data-sort-item="purchase-block|otherExpenses"><div class="section-title" style="${purchaseBlockSectionStyle('otherExpenses')}">${purchaseBlockTitleMarkup('otherExpenses')}${blockHeaderActions('otherExpenses','<button class="mini-btn gradient-other-expense" data-add-other-expense title="Añadir otro gasto">＋</button>')}</div><div class="table-wrap"><table class="purchases-table other-purchases-table"><colgroup><col class="other-col-date"><col class="other-col-category"><col class="other-col-concept"><col class="other-col-amount"><col class="other-col-notes"><col class="other-col-file">${canEdit()?'<col class="purchases-col-actions">':''}</colgroup><thead><tr><th>Fecha</th><th>Categoría</th><th>Comercio / concepto</th><th class="amount">Importe</th><th>Notas</th><th>Archivo</th>${canEdit()?"<th></th>":""}</tr></thead><tbody>${otherExpenses.map((x,i)=>`<tr data-sort-item="purchase-other|${i}"><td>${purchaseTableDate(x.date)}</td><td>${otherExpenseMarkup(x)}</td><td>${esc(x.name||"—")}</td><td class="amount">${formatMoney(x.amount)}</td><td>${esc(x.notes||"")}</td><td>${x.fileUrl?popupFileLink(x.fileUrl,"Ver archivo","📄"):"—"}</td>${canEdit()?`<td><div class="row-actions">${sortDragHandle(`purchase-other|${i}`,'Arrastrar gasto')}<button class="mini-btn" data-edit-other-expense="${i}">✎</button><button class="mini-btn" data-delete-other-expense="${i}">×</button></div></td>`:""}</tr>`).join("")||`<tr><td colspan="${canEdit()?7:6}" class="empty">Añade gasolina, parking, peajes, farmacia u otros gastos. Elige el grupo de Presupuesto al que deben sumarse.</td></tr>`}</tbody></table></div><div class="group-total"><span>Total otros gastos</span><strong>${formatMoney(otherTotal)}</strong></div></section>`,
    ticketItems:renderTicketItemsSection().replace('<section class="card ticket-items"','<section class="card ticket-items purchase-reorder-block" data-sort-item="purchase-block|ticketItems"').replace('<div class="section-actions ticket-export-actions">','<div class="section-actions ticket-export-actions">'+purchasesBlockDragHandle('ticketItems'))
  };
  const orderedBlocks=currentPurchasesBlockOrder().map(id=>blocks[id]||'').join('');
  return `${lockedBanner()}${pageHead("Compra real","Registra supermercados, extras previstos o pagados y otros gastos; todo se sincroniza con Presupuesto",actions)}
  <section class="kpi-grid"><div class="kpi accent"><span>Total pagado real</span><strong>${formatMoney(total)}</strong></div><div class="kpi success"><span>Supermercados</span><strong>${formatMoney(supermarketTotal)}</strong></div><div class="kpi"><span>Extras</span><strong>${formatMoney(extraTotal)}</strong><small>${extraPending?`${formatMoney(extraPending)} pendientes`:"Todo pagado"}</small></div><div class="kpi"><span>Otros gastos</span><strong>${formatMoney(otherTotal)}</strong></div></section>
  <div class="purchases-block-list">${orderedBlocks}</div>`;
}
binders.purchases = () => {
  bindTicketItemsControls();
  $$('[data-add-purchase]').forEach(b=>b.addEventListener('click',()=>editPurchase()));
  $$('[data-edit-purchase]').forEach(b=>b.addEventListener('click',()=>editPurchase(num(b.dataset.editPurchase))));
  $$('[data-delete-purchase]').forEach(b=>b.addEventListener('click',async()=>{if(confirmAction("¿Eliminar esta compra?")){state.data.purchases.records.splice(num(b.dataset.deletePurchase),1);await saveSection("purchases");render();}}));
  $$('[data-add-extra]').forEach(b=>b.addEventListener('click',()=>editExtra()));
  $$('[data-edit-extra]').forEach(b=>b.addEventListener('click',()=>editExtra(num(b.dataset.editExtra))));
  $$('[data-delete-extra]').forEach(b=>b.addEventListener('click',async()=>{if(confirmAction("¿Eliminar este extra? También desaparecerá de Presupuesto → Extras.")){state.data.purchases.extras.splice(num(b.dataset.deleteExtra),1);await saveSection("purchases");render();}}));
  $$('[data-add-other-expense]').forEach(b=>b.addEventListener('click',()=>editOtherExpense()));
  $$('[data-edit-other-expense]').forEach(b=>b.addEventListener('click',()=>editOtherExpense(num(b.dataset.editOtherExpense))));
  $$('[data-delete-other-expense]').forEach(b=>b.addEventListener('click',async()=>{if(confirmAction("¿Eliminar este gasto?")){state.data.purchases.otherExpenses.splice(num(b.dataset.deleteOtherExpense),1);await saveSection("purchases");render();}}));
  $$('[data-upload-ticket]').forEach(b=>b.addEventListener('click',()=>uploadTicket(num(b.dataset.uploadTicket))));
  $$('[data-drive-ticket]').forEach(b=>b.addEventListener('click',()=>pickDriveForTicket(num(b.dataset.driveTicket))));
  $$('[data-ocr-ticket]').forEach(b=>b.addEventListener('click',()=>ocrTicket(num(b.dataset.ocrTicket))));
  $$('[data-export-ticket-pdf]').forEach(b=>b.addEventListener('click',exportTicketItemsPdf));
  $$('[data-export-ticket-xlsx]').forEach(b=>b.addEventListener('click',()=>exportTicketItemsExcel().catch(error=>toast(error.message||'No se pudo generar el Excel.','error'))));
  $$('[data-edit-purchase-block]').forEach(b=>b.addEventListener('click',()=>editPurchaseBlockHeader(String(b.dataset.editPurchaseBlock||''))));
  $$('[data-add-ticket-item]').forEach(b=>b.addEventListener('click',()=>editTicketItem()));
  $$('[data-delete-ticket-item]').forEach(b=>b.addEventListener('click',async()=>{if(!confirmAction('¿Eliminar este producto extraído del ticket?'))return;state.data.purchases.ticketItems.splice(num(b.dataset.deleteTicketItem),1);await saveSection("purchases");render();}));
};
function ticketItemsExportRows(){
  return (state.data.purchases.ticketItems||[]).map(x=>{
    const quantity=Math.max(.01,num(x.quantity)||1);
    const unitPrice=num(x.unitPrice)||num(x.price)/quantity;
    return {date:x.date||'',store:x.store||'',name:x.name||'',quantity,unitPrice:Number(unitPrice.toFixed(2)),total:Number(num(x.price).toFixed(2))};
  });
}
function exportTicketItemsPdf(){
  const rows=ticketItemsExportRows();
  if(!rows.length)return toast('No hay productos extraídos de tickets para exportar.','error');
  const total=sum(rows.map(r=>r.total));
  const body=`<section class="print-export-section"><table class="print-table"><thead><tr><th>Fecha</th><th>Comercio</th><th>Producto</th><th class="num">Cantidad</th><th class="num">Precio ud.</th><th class="num">Total</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${esc(formatDate(r.date))}</td><td>${esc(r.store)}</td><td>${esc(r.name)}</td><td class="num">${esc(r.quantity.toLocaleString('es-ES'))}</td><td class="num">${esc(formatMoney(r.unitPrice))}</td><td class="num">${esc(formatMoney(r.total))}</td></tr>`).join('')}<tr class="print-total-row"><td colspan="5">TOTAL</td><td class="num">${esc(formatMoney(total))}</td></tr></tbody></table></section>`;
  openPrintable('Productos extraídos de tickets',body);
}
async function exportTicketItemsExcel(){
  const rows=ticketItemsExportRows();
  if(!rows.length)throw new Error('No hay productos extraídos de tickets para exportar.');
  await loadScriptOnce('https://cdn.sheetjs.com/xlsx-0.20.3/package/dist/xlsx.full.min.js',()=>Boolean(window.XLSX));
  if(!window.XLSX)throw new Error('No se pudo cargar el generador de Excel. Comprueba la conexión a Internet.');
  const total=sum(rows.map(r=>r.total));
  const data=[['Última fecha','Comercio','Producto','Cantidad','Precio ud.','Total'],...rows.map(r=>[r.date,r.store,r.name,r.quantity,r.unitPrice,r.total]),['','','','', 'TOTAL',total]];
  const ws=window.XLSX.utils.aoa_to_sheet(data);
  ws['!cols']=[{wch:14},{wch:22},{wch:42},{wch:12},{wch:14},{wch:14}];
  const wb=window.XLSX.utils.book_new();window.XLSX.utils.book_append_sheet(wb,ws,'Productos tickets');
  window.XLSX.writeFile(wb,`MFE_Viajes_productos_tickets_${new Date().toISOString().slice(0,10)}.xlsx`);
}

function editPurchase(index=null) {
  const stores=state.data.shopping.stores.filter(s=>s.active!==false).map(s=>s.name);
  const current=index===null?{date:new Date().toISOString().slice(0,10),store:stores[0]||"",amount:0,notes:"",ticketUrl:""}:state.data.purchases.records[index];
  let selectedFile=null;
  let driveUploadFile=null;
  let driveUploadFolder=getRememberedDriveUploadFolder();
  let driveSelection=current.ticketDriveId?{id:current.ticketDriveId,label:current.ticketDriveName||'Ticket de Drive',url:current.ticketUrl,driveUrl:current.ticketUrl,mimeType:current.ticketMimeType||''}:null;
  const statusText=()=>selectedFile?`Archivo preparado: ${selectedFile.name}`:driveSelection?`Drive: ${driveSelection.label}`:(current.ticketUrl?'Enlace guardado':'Sin ticket seleccionado');
  openModal(`<div class="modal-head"><h3>${index===null?'Añadir compra de supermercado':'Editar compra'}</h3><button class="close-btn" data-close-modal>×</button></div><form id="purchase-form"><div class="modal-body"><div class="form-row">${fieldHtml({name:'date',label:'Fecha',type:'date',required:true},current.date)}${fieldHtml({name:'store',label:'Supermercado',type:'select',options:stores,required:true},current.store)}${fieldHtml({name:'amount',label:'Importe total (se completará con el OCR)',type:'number',step:'0.01'},current.amount)}${fieldHtml({name:'notes',label:'Notas',full:true},current.notes||'')}${fieldHtml({name:'ticketUrl',label:'Enlace al ticket',type:'url',full:true},current.ticketUrl||'')}</div><div class="ticket-source-panel"><strong>Ticket para OCR</strong><div class="page-actions"><button class="btn secondary" type="button" data-purchase-file>⬆ Subir archivo</button><button class="btn secondary" type="button" data-purchase-drive>${driveIconMarkup()} Seleccionar de Drive</button><button class="btn secondary drive-upload-ocr-btn" type="button" data-purchase-upload-drive>☁ Preparar subida a Drive</button></div><div class="drive-upload-options" data-drive-upload-options hidden><label class="field full">Nombre del archivo en Drive<input type="text" data-drive-upload-name autocomplete="off"></label><div class="drive-upload-destination"><div><small>Carpeta de destino</small><strong data-drive-upload-folder-label>${esc(driveUploadFolder.name)}</strong></div><div class="drive-upload-folder-actions"><button class="btn secondary" type="button" data-purchase-drive-folder>📁 Elegir carpeta</button><button class="btn ghost" type="button" data-purchase-drive-root>Mi unidad</button></div></div><button class="btn primary" type="button" data-purchase-drive-confirm>☁ Subir a Drive y hacer OCR</button></div><p class="help-text" data-purchase-source-status>${esc(statusText())}</p><p class="help-text">Puedes elegir la carpeta y cambiar el nombre antes de subir. La última carpeta utilizada queda recordada en este dispositivo. El ticket se guarda únicamente en Google Drive y después se ejecuta el OCR.</p></div></div><div class="modal-actions purchase-ocr-actions"><button class="btn ghost" type="button" data-close-modal>Cancelar</button><button class="btn secondary canary-save-btn" type="submit">Guardar sin OCR</button><button class="btn primary canary-action-btn" type="button" data-purchase-ocr>Hacer OCR</button></div></form>`,true);
  $$('[data-close-modal]',els.modal).forEach(b=>b.addEventListener('click',closeModal));
  const status=$('[data-purchase-source-status]',els.modal);
  const driveOptions=$('[data-drive-upload-options]',els.modal);
  const driveNameInput=$('[data-drive-upload-name]',els.modal);
  const driveFolderLabel=$('[data-drive-upload-folder-label]',els.modal);
  const hideDriveUploadOptions=()=>{if(driveOptions)driveOptions.hidden=true;driveUploadFile=null;};
  $('[data-purchase-file]',els.modal)?.addEventListener('click',()=>{const input=document.createElement('input');input.type='file';input.accept='image/*,application/pdf';input.onchange=()=>{selectedFile=input.files?.[0]||null;driveSelection=null;hideDriveUploadOptions();if(status)status.textContent=statusText();};input.click();});
  $('[data-purchase-drive]',els.modal)?.addEventListener('click',async()=>{try{const selected=(await selectFromDrive({multiple:false,includeToken:false,sharedDrives:false}))[0];if(!selected)return;driveSelection=selected;selectedFile=null;hideDriveUploadOptions();const urlInput=$('[name="ticketUrl"]',els.modal);if(urlInput)urlInput.value=selected.driveUrl||selected.url;if(status)status.textContent=statusText();}catch(error){toast(`No se pudo seleccionar desde Drive: ${error.message}`,'error');}});
  const buildDraft=()=>{
    const form=new FormData($('#purchase-form',els.modal));
    const value={id:current.id||uid('purchase'),...current,date:String(form.get('date')||''),store:String(form.get('store')||''),amount:num(form.get('amount')),notes:String(form.get('notes')||'').trim(),ticketUrl:String(form.get('ticketUrl')||'').trim()};
    if(driveSelection){value.ticketUrl=driveSelection.driveUrl||driveSelection.url;value.ticketStoredUrl='';value.ticketStoragePath='';value.ticketDriveId=driveSelection.id;value.ticketDriveName=driveSelection.label;value.ticketMimeType=driveSelection.mimeType||'';}
    return value;
  };
  $('[data-purchase-upload-drive]',els.modal)?.addEventListener('click',()=>{
    const input=document.createElement('input');input.type='file';input.accept='image/*,application/pdf';
    input.onchange=()=>{
      const file=input.files?.[0];if(!file)return;
      driveUploadFile=file;selectedFile=null;driveSelection=null;
      if(driveNameInput)driveNameInput.value=file.name||`ticket-${new Date().toISOString().slice(0,10)}`;
      if(driveFolderLabel)driveFolderLabel.textContent=driveUploadFolder.name;
      if(driveOptions)driveOptions.hidden=false;
      if(status)status.textContent=`Preparado para Drive: ${file.name}`;
    };
    input.click();
  });
  $('[data-purchase-drive-folder]',els.modal)?.addEventListener('click',async()=>{
    try{
      const folder=await selectDriveFolder();if(!folder)return;
      driveUploadFolder=folder;rememberDriveUploadFolder(folder);
      if(driveFolderLabel)driveFolderLabel.textContent=folder.name;
    }catch(error){toast(`No se pudo elegir la carpeta: ${error.message}`,'error');}
  });
  $('[data-purchase-drive-root]',els.modal)?.addEventListener('click',()=>{
    driveUploadFolder={id:'root',name:'Mi unidad'};rememberDriveUploadFolder(driveUploadFolder);
    if(driveFolderLabel)driveFolderLabel.textContent=driveUploadFolder.name;
  });
  $('[data-purchase-drive-confirm]',els.modal)?.addEventListener('click',async()=>{
    if(!driveUploadFile){toast('Selecciona primero el ticket que quieres subir.','error');return;}
    const button=$('[data-purchase-drive-confirm]',els.modal);
    try{
      if(button)button.disabled=true;
      const requestedName=String(driveNameInput?.value||driveUploadFile.name||'').trim();
      toast(`Subiendo a ${driveUploadFolder.name}…`);
      const uploaded=await uploadTicketFileToDrive(driveUploadFile,{name:requestedName,parentId:driveUploadFolder.id});
      driveSelection=uploaded;selectedFile=driveUploadFile;rememberDriveUploadFolder(driveUploadFolder);
      const urlInput=$('[name="ticketUrl"]',els.modal);if(urlInput)urlInput.value=uploaded.driveUrl||uploaded.url;
      if(status)status.textContent=`Drive · ${driveUploadFolder.name}: ${uploaded.label}`;
      toast('Ticket guardado en Google Drive. Iniciando OCR…');
      await ocrPurchaseDraft({record:buildDraft(),index,selectedFile:driveUploadFile});
    }catch(error){toast(error.message||'No se ha podido subir el ticket a Google Drive.','error');if(button)button.disabled=false;}
  });
  $('#purchase-form',els.modal).addEventListener('submit',async event=>{
    event.preventDefault();
    const value=buildDraft();
    if(selectedFile&&!driveSelection){toast('Subiendo ticket…');const uploaded=await state.provider.uploadFile(selectedFile,'tickets');value.ticketUrl=uploaded.url;value.ticketStoredUrl=uploaded.url;value.ticketStoragePath=uploaded.path;value.ticketDriveId='';value.ticketDriveName='';value.ticketMimeType=selectedFile.type||'';}
    if(index===null)state.data.purchases.records.push(value);else state.data.purchases.records[index]=value;
    await saveSection('purchases');closeModal();render();toast('Compra guardada.');
  });
  $('[data-purchase-ocr]',els.modal)?.addEventListener('click',async()=>{
    const value=buildDraft();
    if(!selectedFile&&!value.ticketDriveId&&!value.ticketStoredUrl&&!value.ticketUrl){toast('Selecciona primero un ticket para ejecutar el OCR.','error');return;}
    await ocrPurchaseDraft({record:value,index,selectedFile});
  });
}
function editExtra(index=null) {
  const current=index===null?{date:"",category:"Extra",name:"",amount:0,status:"unpaid",icon:"✨",iconUrl:"",notes:"",fileUrl:""}:state.data.purchases.extras[index];
  let iconMemoryBinding=null;
  openForm({title:index===null?"Añadir extra":"Editar extra",fields:[
    {name:"date",label:"Fecha prevista / real",type:"date",help:"Opcional: puedes dejarla vacía si todavía no sabes cuándo harás el gasto."},
    {name:"category",label:"Categoría",required:true,help:"Por ejemplo: Restaurante, Entrada, Lotería, Regalo o Actividad."},
    {name:"name",label:"Sitio / concepto",required:true,full:true},
    {name:"amount",label:"Importe",type:"number",step:"0.01",required:true},
    {name:"status",label:"Estado",type:"select",options:[{value:"unpaid",label:"No pagado"},{value:"paid",label:"Pagado"}],help:"También puedes cambiarlo después directamente desde Presupuesto → Extras."},
    {name:"icon",label:"Emoji alternativo"},
    {name:"iconUrl",label:"URL o imagen de Drive del icono del sitio",type:"url",full:true,driveImage:true},
    {name:"iconFile",label:"Subir imagen del icono / logo",type:"file",accept:"image/*",full:true,help:"Si este sitio ya apareció en otro viaje, la app recupera su último icono automáticamente."},
    {name:"notes",label:"Notas",full:true},
    {name:"fileUrl",label:"Ticket, reserva, web o archivo",type:"url",full:true,driveSelect:true}
  ],values:current,onSubmit:async v=>{
    if(v.iconFile)v.iconUrl=await fileToSquareDataUrl(v.iconFile);
    iconMemoryBinding?.applyTo(v);delete v.iconFile;
    const value={id:current.id||uid("purchase-extra"),...current,...v,status:v.status==="paid"?"paid":"unpaid"};
    const memoryChanged=rememberBudgetConceptIcon(value.name,value,{removeWhenBlank:index!==null&&iconMemoryBinding?.touched()===true});
    if(index===null)state.data.purchases.extras.push(value);else state.data.purchases.extras[index]=value;
    const saved=await saveSection("purchases");if(saved===false)throw new Error('No se ha podido guardar el extra.');
    if(memoryChanged){const memorySaved=await saveSection('budget');if(memorySaved===false)throw new Error('El extra se guardó, pero no se pudo guardar su icono reutilizable.');}
    render();
  }});
  iconMemoryBinding=bindBudgetConceptIconMemoryForm({defaultIcon:'✨'});
}
function editOtherExpense(index=null) {
  const fallbackGroup=state.data.budget.groups.find(g=>g.id==="g-shopping")||state.data.budget.groups[0];
  const current=index===null?{date:new Date().toISOString().slice(0,10),groupId:fallbackGroup?.id||"",category:"Gasolina",name:"",amount:0,icon:"⛽",iconUrl:"",fileUrl:""}:state.data.purchases.otherExpenses[index];
  const groupOptions=state.data.budget.groups.map(group=>({value:group.id,label:group.name}));
  let iconMemoryBinding=null;
  openForm({title:index===null?"Añadir otro gasto real":"Editar otro gasto",fields:[
    {name:"date",label:"Fecha",type:"date",required:true},
    {name:"groupId",label:"Grupo de Presupuesto",type:"select",options:groupOptions,required:true,help:"El total de esta categoría aparecerá automáticamente dentro de este grupo."},
    {name:"category",label:"Categoría",required:true,help:"Por ejemplo: Gasolina, Parking, Peajes o Farmacia."},
    {name:"name",label:"Comercio / concepto",required:true,full:true},
    {name:"amount",label:"Importe",type:"number",step:"0.01",required:true},
    {name:"icon",label:"Emoji alternativo"},
    {name:"iconUrl",label:"URL del icono",type:"url",full:true},
    {name:"iconFile",label:"Subir icono 128×128",type:"file",accept:"image/*",full:true,help:"Si el comercio ya se usó en otro viaje, la app reutiliza su último icono automáticamente."},
    {name:"notes",label:"Notas",full:true},
    {name:"fileUrl",label:"Enlace a recibo, web o archivo",type:"url",full:true,driveSelect:true}
  ],values:current,onSubmit:async v=>{
    if(v.iconFile)v.iconUrl=await fileToSquareDataUrl(v.iconFile);
    iconMemoryBinding?.applyTo(v);delete v.iconFile;
    const value={id:current.id||uid("other-expense"),...current,...v};
    const memoryChanged=rememberBudgetConceptIcon(value.name,value,{removeWhenBlank:index!==null&&iconMemoryBinding?.touched()===true});
    if(index===null)state.data.purchases.otherExpenses.push(value);else state.data.purchases.otherExpenses[index]=value;
    const saved=await saveSection("purchases");if(saved===false)throw new Error('No se ha podido guardar el gasto.');
    if(memoryChanged){const memorySaved=await saveSection('budget');if(memorySaved===false)throw new Error('El gasto se guardó, pero no se pudo guardar su icono reutilizable.');}
    render();
  }});
  iconMemoryBinding=bindBudgetConceptIconMemoryForm({defaultIcon:'⛽'});
}
function editTicketItem(prefill={}) {
  openForm({title:"Añadir producto de ticket",fields:[{name:"date",label:"Fecha",type:"date"},{name:"store",label:"Comercio"},{name:"name",label:"Producto",required:true,full:true},{name:"quantity",label:"Cantidad",type:"number",step:"0.01"},{name:"price",label:"Importe total",type:"number",step:"0.01"}],values:{quantity:1,...prefill},onSubmit:async v=>{state.data.purchases.ticketItems=normalizeStoredTicketItems([...state.data.purchases.ticketItems,{id:uid("ticket-item"),...v}]);await saveSection("purchases");pendingTicketItemMigration=false;render();}});
}
function uploadTicket(index) {
  const input=document.createElement("input"); input.type="file"; input.accept="image/*,application/pdf";
  input.addEventListener("change",async()=>{const file=input.files?.[0];if(!file)return;try{toast("Subiendo ticket…");const result=await state.provider.uploadFile(file,"tickets");const record=state.data.purchases.records[index];record.ticketUrl=result.url;record.ticketStoragePath=result.path;await saveSection("purchases");render();toast("Ticket guardado.");}catch(error){toast(error.message,"error");}}); input.click();
}
function loadScriptOnce(src,test){
  if(test())return Promise.resolve();
  return new Promise((resolve,reject)=>{
    const existing=[...document.scripts].find(s=>s.src===src);
    if(existing){existing.addEventListener('load',resolve,{once:true});existing.addEventListener('error',reject,{once:true});return;}
    const script=document.createElement('script');script.src=src;script.crossOrigin='anonymous';script.onload=resolve;script.onerror=()=>reject(new Error(`No se pudo cargar ${src}`));document.head.append(script);
  });
}
async function ensureLocalOcrLibraries(){
  await loadScriptOnce('https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js',()=>Boolean(window.Tesseract));
  await loadScriptOnce('https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js',()=>Boolean(window.pdfjsLib));
  window.pdfjsLib.GlobalWorkerOptions.workerSrc='https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
}
function driveFileIdFromUrl(url=''){
  try{const parsed=new URL(url);return parsed.pathname.match(/\/file\/d\/([^/]+)/)?.[1]||parsed.searchParams.get('id')||'';}catch{return '';}
}
function driveFileViewUrl(file={}){
  const id=file.driveFileId||driveFileIdFromUrl(file.driveUrl||file.url||'')||((file.source==='drive'&&file.id)?file.id:'');
  return id?`https://drive.google.com/file/d/${encodeURIComponent(id)}/view`:String(file.url||file.driveUrl||'');
}
function driveFilePreviewUrl(file={}){
  const id=file.driveFileId||driveFileIdFromUrl(file.driveUrl||file.url||'')||((file.source==='drive'&&file.id)?file.id:'');
  return id?`https://drive.google.com/file/d/${encodeURIComponent(id)}/preview`:drivePreviewUrl(file.url||file.driveUrl||'');
}
async function driveApiErrorDetail(response){
  if(!response)return '';
  try{
    const data=await response.clone().json();
    const reason=data?.error?.errors?.[0]?.reason||'';
    const message=data?.error?.message||data?.error_description||data?.error||'';
    return [reason,message].filter(Boolean).join(' · ');
  }catch{
    try{return String(await response.clone().text()||'').trim().slice(0,260);}catch{return '';}
  }
}
async function fetchDriveMediaObjectUrl(file={},interactive=false,force=false){
  const driveId=file.driveFileId||driveFileIdFromUrl(file.driveUrl||file.url||'')||((file.source==='drive'&&file.id)?file.id:'');
  if(!driveId)throw new Error('Este archivo no tiene identificador de Google Drive.');
  if(!force&&state.driveObjectUrls.has(driveId))return state.driveObjectUrls.get(driveId);
  let token;
  try{token=await getGoogleDriveAccessToken('',{interactive});}
  catch(error){
    if(!interactive)throw new Error(`Google Drive no ha podido obtener la sesión persistente: ${error.message||'autorización no disponible'}.`);
    // Solo se permite un flujo interactivo iniciado directamente por el usuario.
    token=await getGoogleDriveAccessToken('consent',{interactive:true});
  }
  const request=async accessToken=>fetch(`https://www.googleapis.com/drive/v3/files/${encodeURIComponent(driveId)}?alt=media&supportsAllDrives=true`,{headers:{Authorization:`Bearer ${accessToken}`},cache:'no-store'});
  let response=await request(token);
  // 401 = token caducado. 404 también puede significar que el token temporal pertenece
  // a otra cuenta. Antes de declarar el archivo perdido, reintenta con la sesión persistente.
  if((response.status===401||response.status===404)&&!(state.provider instanceof LocalProvider)){
    const firstToken=token;
    try{
      const persistentToken=await persistentDriveAccessToken();
      if(persistentToken&&persistentToken!==firstToken){token=persistentToken;response=await request(token);}
    }catch(error){
      if(response.status===401&&interactive)throw new Error(`La sesión persistente de Google Drive no ha podido renovarse: ${error.message||'error desconocido'}.`);
    }
  }
  if(!response.ok){
    const detail=await driveApiErrorDetail(response);
    throw new Error(`Google Drive no ha permitido abrir el archivo (HTTP ${response.status})${detail?`: ${detail}`:''}.`);
  }
  const blob=await response.blob();
  if(!blob.size)throw new Error('Google Drive ha devuelto un archivo vacío.');
  const previous=state.driveObjectUrls.get(driveId);if(previous&&String(previous).startsWith('blob:'))URL.revokeObjectURL(previous);
  const objectUrl=URL.createObjectURL(blob);state.driveObjectUrls.set(driveId,objectUrl);return objectUrl;
}
function driveLinkSelections(selected=[]){
  return (selected||[]).map(item=>{
    const driveId=item.driveFileId||item.id||driveFileIdFromUrl(item.driveUrl||item.url||'');
    const mimeType=String(item.mimeType||'').toLowerCase();
    const image=item.type==='image'||mimeType.startsWith('image/');
    return {id:uid('file'),driveFileId:driveId,label:item.label||'Archivo de Drive',url:`https://drive.google.com/file/d/${encodeURIComponent(driveId)}/view`,driveUrl:`https://drive.google.com/file/d/${encodeURIComponent(driveId)}/view`,type:image?'image':'file',mimeType:item.mimeType||'',source:'drive'};
  }).filter(item=>item.driveFileId);
}
async function downloadTicketBlob(record){
  const driveId=record.ticketDriveId||driveFileIdFromUrl(record.ticketUrl||'');
  if(driveId){
    let token;token=await getGoogleDriveAccessToken('',{interactive:true});
    const response=await fetch(`https://www.googleapis.com/drive/v3/files/${encodeURIComponent(driveId)}?alt=media`,{headers:{Authorization:`Bearer ${token}`}});
    if(!response.ok)throw new Error(`No se pudo descargar el archivo de Drive (HTTP ${response.status}).`);
    const blob=await response.blob();return {blob,mimeType:record.ticketMimeType||blob.type,name:record.ticketDriveName||'ticket'};
  }
  const url=record.ticketStoredUrl||record.ticketUrl;
  if(!isValidUrl(url))throw new Error('El ticket no tiene un enlace válido.');
  const response=await fetch(url);if(!response.ok)throw new Error(`No se pudo descargar el ticket (HTTP ${response.status}).`);
  const blob=await response.blob();return {blob,mimeType:blob.type,name:'ticket'};
}
function showOcrProgress(message='Preparando OCR local…',progress=0){
  openModal(`<div class="modal-head"><h3>Analizando ticket</h3></div><div class="modal-body"><p id="ocr-progress-message">${esc(message)}</p><div class="ocr-progress"><span id="ocr-progress-bar" style="width:${Math.max(2,Math.min(100,progress))}%"></span></div><p class="help-text">El análisis se realiza en este dispositivo. No se envía a Cloud Vision ni requiere facturación.</p><div class="page-actions"><button class="btn ghost" type="button" data-cancel-local-ocr>Cancelar</button></div></div>`,true);
  $('[data-cancel-local-ocr]',els.modal)?.addEventListener('click',async()=>{state.ocrCancelled=true;try{await state.ocrWorker?.terminate();}catch{}state.ocrWorker=null;closeModal();toast('OCR cancelado.','error');});
}
function updateOcrProgress(message,progress){const m=$('#ocr-progress-message',els.modal),b=$('#ocr-progress-bar',els.modal);if(m)m.textContent=message;if(b)b.style.width=`${Math.max(2,Math.min(100,progress||0))}%`;}
function parseOcrMoney(value=''){
  let s=String(value).replace(/[^0-9,.-]/g,'').trim();if(!s)return 0;
  if(s.includes(',')&&s.includes('.')){if(s.lastIndexOf(',')>s.lastIndexOf('.'))s=s.replace(/\./g,'').replace(',','.');else s=s.replace(/,/g,'');}
  else if(s.includes(','))s=s.replace(',','.');
  return num(s);
}
function receiptDateToIso(raw=''){
  const m=String(raw).match(/(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{2,4})/);if(!m)return '';
  const y=m[3].length===2?`20${m[3]}`:m[3];return `${y}-${m[2].padStart(2,'0')}-${m[1].padStart(2,'0')}`;
}
function receiptItemCanBeGrouped(item={}){return strictReceiptCanGroup(item);}
function receiptProductFingerprint(value=''){return strictReceiptFingerprint(value);}
function groupDuplicateReceiptItems(items=[]){return groupReceiptItemsStrict(items);}
function receiptTotalCandidates(lines=[],moneyRe){
  const candidates=[];
  const reject=/\b(SUBTOTAL|IVA|BASE|DESCUENTO|DTO\.?|PROMOCI[ÓO]N|PROMO|OFERTA|AHORRO|BONIF|CUP[ÓO]N|CAMBIO|ENTREGADO|EFECTIVO|TARJETA)\b/i;
  const rules=[
    {re:/\bTOTAL\s+A\s+PAGAR\b/i,priority:120},
    {re:/\bIMPORTE\s+TOTAL\b/i,priority:115},
    {re:/\bTOTAL\s+EUR\b/i,priority:110},
    {re:/\bA\s+PAGAR\b/i,priority:105},
    {re:/^\s*TOTAL\b/i,priority:100},
    {re:/\bTOTAL\b/i,priority:80}
  ];
  lines.forEach((line,index)=>{
    if(reject.test(line))return;
    for(const rule of rules){
      if(!rule.re.test(line))continue;
      const values=[...line.matchAll(moneyRe)].map(m=>parseOcrMoney(m[1])).filter(v=>v>0&&v<10000);
      for(const value of values)candidates.push({value,priority:rule.priority,index,line});
      break;
    }
  });
  return candidates.sort((a,b)=>b.priority-a.priority||b.index-a.index);
}
function chooseReceiptTotal(candidates=[],items=[],fallback=0){
  const itemSum=Number(sum((items||[]).map(item=>num(item.price))).toFixed(2));
  const maxItem=Math.max(0,...(items||[]).map(item=>num(item.price)));
  const plausible=candidates.find(candidate=>{
    if(candidate.value<=0)return false;
    if(itemSum<=0)return true;
    if(candidate.value+0.01<maxItem)return false;
    if(itemSum>=2&&candidate.value<itemSum*.5)return false;
    return true;
  });
  if(plausible)return {total:plausible.value,itemSum,ocrTotal:plausible.value,totalAdjusted:false,totalReason:''};
  if(itemSum>0){
    const rejected=candidates[0]?.value||0;
    return {total:itemSum,itemSum,ocrTotal:rejected,totalAdjusted:Boolean(rejected&&Math.abs(rejected-itemSum)>.01),totalReason:rejected?`El OCR leyó ${formatMoney(rejected)} como total, pero no era coherente con los productos. Se ha calculado ${formatMoney(itemSum)}.`:'El total se ha calculado sumando los productos detectados.'};
  }
  return {total:num(candidates[0]?.value)||num(fallback),itemSum:0,ocrTotal:num(candidates[0]?.value),totalAdjusted:false,totalReason:''};
}
function parseReceiptText(rawText,record){
  const text=String(rawText||'').replace(/\r/g,'');
  const lines=text.split('\n').map(x=>x.replace(/\s+/g,' ').trim()).filter(Boolean);
  const upper=text.toLocaleUpperCase('es');
  const knownStore=(state.data.shopping.stores||[]).find(s=>upper.includes(String(s.name||'').toLocaleUpperCase('es')))?.name||record.store||'';
  let date='';for(const line of lines){date=receiptDateToIso(line);if(date)break;}
  const moneyRe=/(-?\d{1,5}(?:[. ]\d{3})*[,.]\d{1,2})\s*(?:€|EUR)?/gi;
  const excluded=/\b(TOTAL|SUBTOTAL|IMPORTE|IVA|BASE|EFECTIVO|TARJETA|CAMBIO|PAGO|VISA|MASTERCARD|AHORRO|DESCUENTO|DTO\.?|REDONDEO|NIF|CIF|TEL[EÉ]FONO|GRACIAS|FECHA|HORA|PROMOCI[ÓO]N|PROMO|OFERTA|BONIFICACI[ÓO]N|CUP[ÓO]N)\b/i;
  const items=[];
  const isMercadona=normalizedKey(knownStore).includes('mercadona')||upper.includes('MERCADONA');
  for(const line of lines){
    if(excluded.test(line)||receiptDateToIso(line))continue;
    if(isMercadona){
      const mercadonaItem=parseMercadonaReceiptLine(line);
      if(mercadonaItem){items.push(mercadonaItem);if(items.length>=80)break;continue;}
    }
    const matches=[...line.matchAll(moneyRe)];if(!matches.length)continue;
    const last=matches.at(-1),lineTotal=parseOcrMoney(last[1]);if(lineTotal<=0||lineTotal>5000)continue;
    let name=line.slice(0,last.index).replace(/^\d{5,}\s*/,'').trim();
    if(!/[A-Za-zÁÉÍÓÚÜÑáéíóúüñ]{3}/.test(name))continue;
    let quantity=1,unitPrice=0;
    const leading=name.match(/^(\d+(?:[,.]\d+)?)\s*[xX*]\s*(?:(\d+[,.]\d{1,2})\s*)?/);
    if(leading){quantity=Math.max(.01,parseOcrMoney(leading[1]));unitPrice=parseOcrMoney(leading[2]);name=name.slice(leading[0].length).trim();}
    else{
      const trailing=name.match(/\s+(\d+(?:[,.]\d+)?)\s*[xX*]\s*(\d+[,.]\d{1,2})\s*$/);
      if(trailing){quantity=Math.max(.01,parseOcrMoney(trailing[1]));unitPrice=parseOcrMoney(trailing[2]);name=name.slice(0,trailing.index).trim();}
    }
    name=name.replace(/\s{2,}/g,' ').replace(/^[*·.\-]+|[*·.\-]+$/g,'').trim();
    if(name.length<3)continue;
    if(unitPrice<=0)unitPrice=Number((lineTotal/quantity).toFixed(2));
    items.push({name,quantity,unitPrice,price:Number(lineTotal.toFixed(2))});
    if(items.length>=80)break;
  }
  const groupedItems=groupDuplicateReceiptItems(items);
  const candidates=receiptTotalCandidates(lines,moneyRe);
  const totalInfo=chooseReceiptTotal(candidates,groupedItems,record.amount||0);
  return {store:knownStore,date:date||record.date||'',total:totalInfo.total,items:groupedItems,rawItems:items,rawText:text,...totalInfo};
}
async function renderPdfPagesForOcr(blob){
  const data=await blob.arrayBuffer(),pdf=await pdfjsLib.getDocument({data}).promise;
  const pages=[];const limit=Math.min(pdf.numPages,5);
  for(let n=1;n<=limit;n++){
    if(state.ocrCancelled)throw new Error('OCR cancelado.');
    updateOcrProgress(`Preparando página ${n} de ${limit}…`,5+(n-1)*8);
    const page=await pdf.getPage(n),viewport=page.getViewport({scale:2});
    const canvas=document.createElement('canvas');canvas.width=Math.ceil(viewport.width);canvas.height=Math.ceil(viewport.height);
    await page.render({canvasContext:canvas.getContext('2d',{alpha:false}),viewport}).promise;pages.push(canvas);
  }
  return pages;
}
async function runLocalOcr(blob,mimeType=''){
  await ensureLocalOcrLibraries();
  const isPdf=/pdf/i.test(mimeType||blob.type);const sources=isPdf?await renderPdfPagesForOcr(blob):[URL.createObjectURL(blob)];
  state.ocrWorker=await Tesseract.createWorker(['spa','eng'],1,{logger:m=>{if(m.status==='recognizing text')updateOcrProgress('Reconociendo texto…',15+Math.round((m.progress||0)*80));else if(m.status)updateOcrProgress(m.status,10);}});
  let combined='';
  try{for(let i=0;i<sources.length;i++){if(state.ocrCancelled)throw new Error('OCR cancelado.');updateOcrProgress(`Analizando ${isPdf?`página ${i+1}`:'imagen'}…`,15+Math.round(i/sources.length*65));const result=await state.ocrWorker.recognize(sources[i]);combined+=`${result.data.text||''}\n`;}}
  finally{try{await state.ocrWorker?.terminate();}catch{}state.ocrWorker=null;if(!isPdf)sources.forEach(x=>URL.revokeObjectURL(x));}
  return combined;
}
async function ocrPurchaseDraft({record,index=null,selectedFile=null}={}) {
  if(!record)return;
  if(!selectedFile&&!record.ticketDriveId&&!record.ticketStoredUrl&&!record.ticketUrl){toast('Añade primero un ticket desde Google Drive, un archivo o un enlace.','error');return;}
  state.ocrCancelled=false;
  try {
    showOcrProgress();
    const downloaded=selectedFile?{blob:selectedFile,mimeType:selectedFile.type||'',name:selectedFile.name||'ticket'}:await downloadTicketBlob(record);if(state.ocrCancelled)return;
    updateOcrProgress('Cargando motor OCR local…',6);
    const rawText=await runLocalOcr(downloaded.blob,downloaded.mimeType);if(state.ocrCancelled)return;
    const parsed=parseReceiptText(rawText,record);closeModal();openOcrReview(index,parsed,{record,selectedFile});
  } catch(error) { if(!state.ocrCancelled){closeModal();toast(`No se ha podido procesar: ${error.message}`,'error');} }
}
async function ocrTicket(index) {
  const record=state.data.purchases.records[index];
  await ocrPurchaseDraft({record,index});
}

function menuMealMarkup(label,value,visible=true){return visible?`<div class="meal"><small>${esc(label)}</small><div>${esc(value||"—")}</div></div>`:"";}
function renderMenu() {
  syncMenuDaysWithTripDates();const days=state.data.menu.days||[];
  return `${lockedBanner()}${pageHead("Menú","Los días se sincronizan automáticamente con las fechas del viaje",`<button class="btn secondary pdf-action-btn" data-export-menu-pdf>${pdfFileIconMarkup("pdf-action-icon")} Exportar PDF</button>`)}
  <div class="menu-calendar">${days.map((d,i)=>`<article class="card menu-day"><div class="menu-date"><div class="flight-top"><span>${formatDate(d.date,{weekday:"long",day:"2-digit",month:"short"})}</span>${editButtons(`<div class="mini-actions"><button class="mini-btn" data-edit-menu-day="${i}">✎</button></div>`)}</div></div>${menuMealMarkup("Desayuno",d.breakfast,d.showBreakfast!==false)}${menuMealMarkup("Comida",d.lunch,d.showLunch!==false)}${menuMealMarkup("Cena",d.dinner,d.showDinner!==false)}${d.notes?`<div class="meal"><small>Notas</small><div>${esc(d.notes)}</div></div>`:""}${d.showBreakfast===false&&d.showLunch===false&&d.showDinner===false&&!d.notes?'<div class="meal menu-all-hidden"><small>Sin comidas visibles</small></div>':''}</article>`).join("")}</div>`;
}
binders.menu = () => {
  $$('[data-export-menu-pdf]').forEach(b=>b.addEventListener('click',generateMenuPdf));
  $$('[data-edit-menu-day]').forEach(b=>b.addEventListener('click',()=>editMenuDay(num(b.dataset.editMenuDay))));
};
function editMenuDay(index){
  const current=state.data.menu.days[index];if(!current)return;
  openForm({title:`Editar menú · ${formatDate(current.date,{weekday:"long",day:"2-digit",month:"short"})}`,fields:[{name:"showBreakfast",label:"Mostrar desayuno en Menú y PDF",type:"checkbox",full:true},{name:"breakfast",label:"Desayuno"},{name:"showLunch",label:"Mostrar comida en Menú y PDF",type:"checkbox",full:true},{name:"lunch",label:"Comida"},{name:"showDinner",label:"Mostrar cena en Menú y PDF",type:"checkbox",full:true},{name:"dinner",label:"Cena"},{name:"notes",label:"Notas",type:"textarea",full:true}],values:{...current,showBreakfast:current.showBreakfast!==false,showLunch:current.showLunch!==false,showDinner:current.showDinner!==false},onSubmit:async v=>{state.data.menu.days[index]={...current,...v,date:current.date};await saveSection("menu");render();}});
}
function renderItinerary() {
  const it=state.data.itinerary||{}, activities=[...(it.activities||[])].sort((a,b)=>`${a.date}${a.start}`.localeCompare(`${b.date}${b.start}`));
  const currentView=it.view==='list'?'list':'calendar';
  const actions=`<button class="btn secondary" data-it-view="${currentView==="list"?"calendar":"list"}">${currentView==="list"?"🗓️ Ver calendario":"☷ Ver lista"}</button>${canEdit()?'<button class="btn primary canary-action-btn" data-add-activity>＋ Actividad</button>':""}`;
  let body="";
  if(currentView==="calendar") {
    const grouped=Object.groupBy?Object.groupBy(activities,a=>a.date):activities.reduce((acc,a)=>((acc[a.date]??=[]).push(a),acc),{});
    const tripDates=tripMenuDates(state.data.settings);
    const fallbackDates=activities.length?[...new Set(activities.map(a=>a.date).filter(Boolean))]:[];
    const dates=(tripDates.length?tripDates:fallbackDates).sort();
    const firstDate=dates[0]||activities[0]?.date||"";
    const lastDate=dates.at(-1)||activities.at(-1)?.date||"";
    const totalDays=dates.length||activities.length;
    const tripSummary=firstDate&&lastDate?`${formatDate(firstDate,{day:"2-digit",month:"short"})} → ${formatDate(lastDate,{day:"2-digit",month:"short",year:"numeric"})} · ${totalDays} ${totalDays===1?'día':'días'}`:'Actividades del viaje';
    body=`<div class="itinerary-calendar-wrap"><div class="itinerary-calendar-summary">${esc(tripSummary)}</div><div class="itinerary-trip-grid">${dates.map(date=>{const items=[...(grouped[date]||[])].sort((a,b)=>String(a.start||'').localeCompare(String(b.start||'')));return `<section class="itinerary-day-card"><div class="itinerary-day-head"><div class="itinerary-day-weekday">${esc(formatDate(date,{weekday:"short"}))}</div><div class="itinerary-day-date">${esc(formatDate(date,{day:"2-digit",month:"short"}))}</div></div><div class="itinerary-day-events">${items.length?items.map(a=>`<article class="itinerary-day-event" style="--item-color:${esc(a.color||"#4da3ff")}"><div class="itinerary-day-event-time">${esc(a.start||"")}${a.end?` · ${esc(a.end)}`:""}</div><div class="itinerary-day-event-title">${esc(a.title)}</div>${a.location?`<div class="itinerary-day-event-location">${esc(a.location)}</div>`:""}${a.notes?`<div class="itinerary-day-event-notes">${esc(a.notes)}</div>`:""}${a.mapsUrl?`<div class="itinerary-day-event-link">${safeLink(a.mapsUrl,"Abrir mapa","📍")}</div>`:""}</article>`).join(""):'<div class="itinerary-day-empty">Sin actividades</div>'}</div></section>`;}).join("")||'<div class="empty">Todavía no hay actividades.</div>'}</div></div>`;
  } else {
    body=`<div class="itinerary-list">${activities.map(a=>{const index=state.data.itinerary.activities.findIndex(x=>x.id===a.id);return `<article class="card itinerary-item" style="--item-color:${esc(a.color||"#4da3ff")}"><div class="itinerary-time">${formatDate(a.date,{day:"2-digit",month:"short"})}<br>${esc(a.start||"")}${a.end?`–${esc(a.end)}`:""}</div><div class="itinerary-line"></div><div><div class="itinerary-title">${esc(a.title)}</div><div class="itinerary-location">${esc(a.location||"")}</div>${a.notes?`<div class="itinerary-notes">${esc(a.notes)}</div>`:""}<div style="margin-top:8px">${safeLink(a.mapsUrl,"Abrir mapa","📍")}</div></div>${editButtons(`<div class="row-actions"><button class="mini-btn" data-edit-activity="${index}">✎</button><button class="mini-btn" data-delete-activity="${index}">×</button></div>`)}</article>`;}).join("")||'<div class="empty">Todavía no hay actividades.</div>'}</div>`;
  }
  return `${lockedBanner()}${pageHead("Itinerario","Actividades del viaje en vista calendario o lista",actions)}${body}`;
}
binders.itinerary = () => {
  $$('[data-it-view]').forEach(b=>b.addEventListener('click',async()=>{state.data.itinerary.view=b.dataset.itView;await saveSection("itinerary");render();}));
  $$('[data-add-activity]').forEach(b=>b.addEventListener('click',()=>editActivity()));
  $$('[data-edit-activity]').forEach(b=>b.addEventListener('click',()=>editActivity(num(b.dataset.editActivity))));
  $$('[data-delete-activity]').forEach(b=>b.addEventListener('click',async()=>{if(confirmAction("¿Eliminar esta actividad?")){state.data.itinerary.activities.splice(num(b.dataset.deleteActivity),1);await saveSection("itinerary");render();}}));
};
function editActivity(index=null) {
  const current=index===null?{date:"",start:"",end:"",title:"",location:"",mapsUrl:"",notes:"",color:"#4da3ff"}:state.data.itinerary.activities[index];
  openForm({title:index===null?"Añadir actividad":"Editar actividad",fields:[{name:"date",label:"Fecha",type:"date",required:true},{name:"color",label:"Color",type:"color"},{name:"start",label:"Hora inicio",type:"time"},{name:"end",label:"Hora fin",type:"time"},{name:"title",label:"Actividad",required:true,full:true},{name:"location",label:"Lugar",full:true},{name:"mapsUrl",label:"Google Maps",type:"url",full:true},{name:"notes",label:"Notas",type:"textarea",full:true}],values:current,onSubmit:async v=>{const value={id:current.id||uid("activity"),...current,...v};if(index===null)state.data.itinerary.activities.push(value);else state.data.itinerary.activities[index]=value;await saveSection("itinerary");render();}});
}

function archiveTripTitle(snapshot={}){
  const dest=String(snapshot.destination||state.data.settings.destination||'Viaje').trim();
  const clean=dest.split('·')[0].trim()||'Viaje';
  return `${clean}${snapshot.year?` ${snapshot.year}`:''}`.trim();
}
const ARCHIVE_DOC_IDS=['doc-flight','doc-car','doc-lodging'];
const ARCHIVE_TRACKER_FIELDS={
  autoreisen:['pickup','dropoff','pickupOfficeId','dropoffOfficeId','pickupAt','dropoffAt','group','model','carId','imageUrl','manualImageUrl','reservedPrice','currentPrice','lastUpdated','fleetLastCheckedAt','fleetPrices','fleetPriceHistory','history','availability','lastError','lastAttempt','source','monitorStatus'],
  cordial:['hotel','checkIn','checkOut','adults','children','targetRoom','targetRate','targetBoard','reservedPrice','currentPrice','lastUpdated','resultUrl','history','options','roomPriceHistory','availability','lastError','lastAttempt','source','monitorStatus'],
  vueling:['origin','destination','departureDate','returnDate','outboundFlight','returnFlight','outboundTime','returnTime','directOnly','adults','children','infants','fare','underseatBag','sameHandBaggageAllPassengers','checkedBags','checkedBagKg','checkedBagCount','checkedBagPassenger','sameBaggageRoundTrip','sameBaggageAllPassengers','reservedPrice','currentPrice','outboundPrice','returnPrice','baggagePrice','availability','lastUpdated','lastAttempt','lastError','monitorStatus','source','history']
};
function pickArchiveFields(source={},keys=[]){const out={};for(const key of keys)out[key]=clone(source?.[key]);return out;}
function archiveBudgetGroupsSnapshot(){
  return (state.data.budget.groups||[]).map(group=>({
    ...clone(group),
    items:effectiveBudgetEntries(group).map(entry=>({...clone(entry.item),status:'paid',archivedAutomatic:Boolean(entry.automatic)}))
  }));
}
function buildArchiveRestorePayload(){
  const s=state.data.settings||{},cover=state.data.cover||{},trackers=state.data.trackers||{};
  return {
    settings:pickArchiveFields(s,['destination','year','people','departureDateTime','returnDateTime','countdownEndDateTime']),
    budget:clone(state.data.budget||{}),
    purchases:clone(state.data.purchases||{}),
    cover:{
      flights:clone(cover.flights||[]),buses:clone(cover.buses||[]),lodging:clone(cover.lodging||{}),
      documents:clone((cover.documents||[]).filter(d=>ARCHIVE_DOC_IDS.includes(String(d?.id||''))))
    },
    trackers:{
      autoreisen:pickArchiveFields(trackers.autoreisen||{},ARCHIVE_TRACKER_FIELDS.autoreisen),
      cordial:pickArchiveFields(trackers.cordial||{},ARCHIVE_TRACKER_FIELDS.cordial),
      vueling:pickArchiveFields(trackers.vueling||{},ARCHIVE_TRACKER_FIELDS.vueling)
    }
  };
}
function buildTripArchiveSnapshot(){
  const s=state.data.settings||{},stats=budgetStats(),p=state.data.purchases||{},lodging=state.data.cover?.lodging||{};
  const departure=String(s.departureDateTime||''),ret=String(s.returnDateTime||'');
  const start=departure.slice(0,10),end=ret.slice(0,10);
  const snapshot={
    id:uid('trip-archive'),archivedAt:new Date().toISOString(),destination:s.destination||'',year:s.year||'',people:Math.max(1,num(s.people)||1),
    departureDateTime:departure,returnDateTime:ret,startDate:start,endDate:end,
    lodging:clone(lodging),flights:clone(state.data.cover?.flights||[]),buses:clone(state.data.cover?.buses||[]),
    rental:clone(state.data.trackers?.autoreisen||{}),cordial:clone(state.data.trackers?.cordial||{}),vueling:clone(state.data.trackers?.vueling||{}),
    budget:{groups:archiveBudgetGroupsSnapshot(),carKm:clone(state.data.budget?.carKm||{initial:'',final:''}),stats:{total:stats.total,paid:stats.total,unpaid:0,perPerson:stats.perPerson},allPaid:true},
    purchases:clone(p),purchaseTotals:{supermarket:supermarketPurchaseTotal(),other:otherExpensesTotal(),extras:extrasTotal(),real:purchaseTotal()},
    coverDocuments:clone((state.data.cover?.documents||[]).filter(d=>ARCHIVE_DOC_IDS.includes(String(d?.id||'')))),
    restorePayload:buildArchiveRestorePayload(),archiveVersion:3
  };
  snapshot.title=archiveTripTitle(snapshot);
  return snapshot;
}
function resetTripDocumentCard(doc={}){
  if(!ARCHIVE_DOC_IDS.includes(String(doc.id||'')))return doc;
  const keepPrimary=doc.keepLinkOnArchive===true;
  const persistentFiles=normalizeFileList(doc.files||[]).filter(file=>file.keepOnArchive===true);
  return {...doc,subtitle:'',url:keepPrimary?(doc.url||''):'',driveUrl:keepPrimary?(doc.driveUrl||''):'',imageUrl:'',files:persistentFiles};
}
function resetTrackerForNewTrip(id){
  const current=state.data.trackers?.[id];if(!current)return;
  if(id==='autoreisen')Object.assign(current,{pickup:'',dropoff:'',pickupOfficeId:'',dropoffOfficeId:'',pickupAt:'',dropoffAt:'',group:'',model:'',carId:'',imageUrl:'',manualImageUrl:'',reservedPrice:0,currentPrice:'',lastUpdated:'',fleetLastCheckedAt:'',fleetPrices:[],fleetPriceHistory:[],history:[],availability:'',lastError:'',lastAttempt:'',source:'',monitorStatus:'pending'});
  if(id==='cordial')Object.assign(current,{hotel:'',checkIn:'',checkOut:'',adults:Math.max(1,num(state.data.settings?.people)||1),children:0,targetRoom:'',targetRate:'',targetBoard:'',reservedPrice:0,currentPrice:'',lastUpdated:'',resultUrl:'',history:[],options:[],roomPriceHistory:[],availability:'',lastError:'',lastAttempt:'',source:'',monitorStatus:'pending'});
  if(id==='vueling')Object.assign(current,{origin:'',destination:'',departureDate:'',returnDate:'',outboundFlight:'',returnFlight:'',outboundTime:'',returnTime:'',fare:'',reservedPrice:0,currentPrice:'',outboundPrice:'',returnPrice:'',baggagePrice:'',lastUpdated:'',history:[],availability:'',lastError:'',lastAttempt:'',source:'',monitorStatus:'pending'});
}
function reusableFlightTemplate(flight={}){
  const next=clone(flight);
  // Conservamos aerolínea, ruta, número, logos, colores y enlaces de servicio.
  // Solo se eliminan datos que pertenecen al viaje ya terminado.
  Object.assign(next,{date:'',departure:'',arrival:'',leaveAirportReminder:'',checkInNotifyAt:0,leaveNotifyAt:0,walletMikelUrl:'',walletNereaUrl:'',boardingPasses:{mikel:[],nerea:[]}});
  delete next.status;delete next.terminal;delete next.gate;delete next.checkInCounters;delete next.source;delete next.lastUpdated;delete next.flightAwareUrl;delete next.arrivalMapsUrl;delete next.operationalHints;
  return next;
}
function reusableBusTemplate(bus={}){
  const next=clone(bus);
  // Ruta, compañía, icono y estilo permanecen como plantilla; billetes/fechas son del viaje anterior.
  Object.assign(next,{date:'',departureTime:'',arrivalTime:'',departure:'',arrival:'',files:[]});
  if(Object.prototype.hasOwnProperty.call(next,'reservationCode'))next.reservationCode='';
  return next;
}
function reusableLodgingTemplate(lodging={}){
  return {...clone(lodging),checkIn:'',checkOut:''};
}
function reusableTrackerTemplate(id,tracker={}){
  const next=clone(tracker||{});
  if(id==='autoreisen')Object.assign(next,{pickupAt:'',dropoffAt:'',reservedPrice:0,currentPrice:'',lastUpdated:'',fleetLastCheckedAt:'',fleetPrices:[],fleetPriceHistory:[],history:[],availability:'',lastError:'',lastAttempt:'',source:'',monitorStatus:'pending'});
  if(id==='cordial')Object.assign(next,{checkIn:'',checkOut:'',reservedPrice:0,currentPrice:'',lastUpdated:'',resultUrl:'',history:[],options:[],roomPriceHistory:[],availability:'',lastError:'',lastAttempt:'',source:'',monitorStatus:'pending'});
  if(id==='vueling')Object.assign(next,{departureDate:'',returnDate:'',reservedPrice:0,currentPrice:'',outboundPrice:'',returnPrice:'',baggagePrice:'',availability:'',lastUpdated:'',lastAttempt:'',lastError:'',monitorStatus:'pending',source:'',history:[]});
  return next;
}
function applyReusableTripTemplate(snapshot={}){
  const s=state.data.settings||{};
  // Destino y número de viajeros suelen repetirse. Año y fechas se dejan listos para el próximo viaje.
  if(String(snapshot.destination||'').trim())s.destination=snapshot.destination;
  if(num(snapshot.people)>0)s.people=Math.max(1,num(snapshot.people));
  Object.assign(s,{year:'',departureDateTime:'',returnDateTime:'',countdownEndDateTime:''});
  state.data.cover.flights=(snapshot.flights||[]).map(reusableFlightTemplate);
  state.data.cover.buses=(snapshot.buses||[]).map(reusableBusTemplate);
  state.data.cover.lodging=reusableLodgingTemplate(snapshot.lodging||{});
  if(state.data.trackers?.autoreisen)Object.assign(state.data.trackers.autoreisen,reusableTrackerTemplate('autoreisen',snapshot.rental||{}));
  if(state.data.trackers?.cordial)Object.assign(state.data.trackers.cordial,reusableTrackerTemplate('cordial',snapshot.cordial||{}));
  if(state.data.trackers?.vueling)Object.assign(state.data.trackers.vueling,reusableTrackerTemplate('vueling',snapshot.vueling||{}));
}
function resetCurrentTripAfterArchive(){
  // El Histórico conserva el viaje completo. Para el siguiente viaje solo vaciamos
  // los datos económicos/documentales que no deben reutilizarse. Hotel, vuelos,
  // coche, seguimientos y también el plan de comidas quedan como plantilla editable.
  // IMPORTANTE: toda la personalización de interfaz/menú se conserva literalmente.
  const settingsBefore=clone(state.data.settings||{});
  const menuBefore=clone(state.data.menu||{days:[]});
  const archivedTemplate=buildTripArchiveSnapshot();
  state.data.budget.groups=(state.data.budget.groups||[]).map(group=>({...group,items:[]}));
  state.data.budget.carKm={initial:'',final:''};
  state.data.purchases={...(state.data.purchases||{}),records:[],ticketItems:[],otherExpenses:[],extras:[]};
  state.data.cover.documents=(state.data.cover.documents||[]).map(resetTripDocumentCard);
  applyReusableTripTemplate(archivedTemplate);
  const nextTripSettings={
    destination:state.data.settings.destination,
    people:state.data.settings.people,
    year:state.data.settings.year,
    departureDateTime:state.data.settings.departureDateTime,
    returnDateTime:state.data.settings.returnDateTime,
    countdownEndDateTime:state.data.settings.countdownEndDateTime
  };
  state.data.settings={...settingsBefore,...nextTripSettings};
  state.data.menu=menuBefore;
}
function archiveMoneyRow(label,value,meta=''){return `<div class="history-money-row"><span><b>${esc(label)}</b>${meta?`<small>${esc(meta)}</small>`:''}</span><strong>${formatMoney(num(value))}</strong></div>`;}
function archivedBudgetMarkup(snapshot={}){
  const groups=snapshot.budget?.groups||[];
  return `<div class="history-budget-groups">${groups.map(group=>{const items=group.items||[],total=sum(items.map(item=>num(item.amount)));return `<details class="history-budget-group"><summary><span>${esc(group.icon||'•')} ${esc(group.name||'Grupo')}</span><strong>${formatMoney(total)}</strong></summary><div class="history-budget-items">${items.length?items.map(item=>`<div><span><b>${esc(item.name||'Concepto')}</b>${item.detail?`<small>${esc(item.detail)}</small>`:''}</span><strong>${formatMoney(num(item.amount))}</strong></div>`).join(''):'<p class="muted history-empty-inline">Sin gastos.</p>'}</div></details>`;}).join('')}</div>`;
}
function archivedPurchasesMarkup(snapshot={}){
  const p=snapshot.purchases||{},rows=[];
  for(const r of p.records||[])rows.push({label:`${r.store||'Compra'}${r.date?` · ${formatDate(r.date,{day:'2-digit',month:'short'})}`:''}`,amount:r.amount});
  for(const r of p.otherExpenses||[])rows.push({label:r.category||r.name||'Otro gasto',amount:r.amount});
  for(const r of p.extras||[])rows.push({label:r.name||r.category||'Extra',amount:r.amount});
  return rows.length?`<div class="history-purchase-list">${rows.map(r=>archiveMoneyRow(r.label,r.amount)).join('')}</div>`:'<p class="muted">No había compras ni otros gastos registrados.</p>';
}
function archivedPurchaseDetailMarkup(snapshot={}){
  const p=snapshot.purchases||{},parts=[];
  const records=p.records||[],items=p.ticketItems||[],other=p.otherExpenses||[],extras=p.extras||[];
  if(records.length)parts.push(`<section class="history-detail-block"><div class="history-detail-block-head"><h4>🛒 Compras registradas</h4><strong>${formatMoney(sum(records.map(x=>num(x.amount))))}</strong></div><div class="history-purchase-list">${records.map(r=>archiveMoneyRow(r.store||'Compra',r.amount,[r.date?formatDate(r.date,{day:'2-digit',month:'short',year:'numeric'}):'',r.notes||''].filter(Boolean).join(' · '))).join('')}</div></section>`);
  if(items.length)parts.push(`<section class="history-detail-block"><div class="history-detail-block-head"><h4>🧾 Productos de tickets</h4><strong>${items.length}</strong></div><div class="history-archive-table">${items.map(i=>`<div><span><b>${esc(i.name||'Producto')}</b><small>${esc([i.store||'',i.date?formatDate(i.date,{day:'2-digit',month:'short'}):'',num(i.quantity)>1?`${i.quantity} uds.`:''].filter(Boolean).join(' · '))}</small></span><strong>${formatMoney(num(i.price))}</strong></div>`).join('')}</div></section>`);
  if(other.length)parts.push(`<section class="history-detail-block"><div class="history-detail-block-head"><h4>🚗 Otros gastos</h4><strong>${formatMoney(sum(other.map(x=>num(x.amount))))}</strong></div><div class="history-purchase-list">${other.map(r=>archiveMoneyRow(r.name||r.category||'Gasto',r.amount,[r.category||'',r.date?formatDate(r.date,{day:'2-digit',month:'short'}):'',r.notes||''].filter(Boolean).join(' · '))).join('')}</div></section>`);
  if(extras.length)parts.push(`<section class="history-detail-block"><div class="history-detail-block-head"><h4>✨ Extras</h4><strong>${formatMoney(sum(extras.map(x=>num(x.amount))))}</strong></div><div class="history-purchase-list">${extras.map(r=>archiveMoneyRow(r.name||r.category||'Extra',r.amount,[r.category||'',r.date?formatDate(r.date,{day:'2-digit',month:'short'}):'',r.status==='paid'?'Pagado':'Pendiente'].filter(Boolean).join(' · '))).join('')}</div></section>`);
  return parts.join('')||'<p class="muted">No había compras ni otros gastos registrados.</p>';
}
function archivedFlightsMarkup(snapshot={}){
  const flights=snapshot.flights||[];
  return flights.length?`<div class="history-archive-logistic-grid">${flights.map(f=>`<article><span class="history-archive-icon">✈️</span><div><small>${esc(f.type||f.airline||'Vuelo')}</small><strong>${esc(f.number||'Sin número')}</strong><p>${esc(f.from||'')} → ${esc(f.to||'')}</p><p>${esc([f.date?formatDate(f.date,{day:'2-digit',month:'short',year:'numeric'}):'',f.departureTime||f.time||'',f.arrivalTime||''].filter(Boolean).join(' · '))}</p></div></article>`).join('')}</div>`:'<p class="muted">No había vuelos archivados.</p>';
}
function archivedBusesMarkup(snapshot={}){
  const buses=snapshot.buses||[];
  return buses.length?`<div class="history-archive-logistic-grid">${buses.map(b=>`<article><span class="history-archive-icon">🚌</span><div><small>${esc(b.company||b.type||'Autobús')}</small><strong>${esc(`${b.from||''} → ${b.to||''}`)}</strong><p>${esc([b.date?formatDate(b.date,{day:'2-digit',month:'short',year:'numeric'}):'',b.departureTime||b.time||'',b.arrivalTime||''].filter(Boolean).join(' · '))}</p></div></article>`).join('')}</div>`:'<p class="muted">No había autobuses archivados.</p>';
}
function archivedLodgingMarkup(snapshot={}){
  const l=snapshot.lodging||{};return `<div class="history-archive-logistic-grid"><article><span class="history-archive-icon">🏨</span><div><small>Alojamiento</small><strong>${esc(l.name||snapshot.cordial?.hotel||'—')}</strong><p>${esc([l.checkIn?formatDate(l.checkIn,{day:'2-digit',month:'short',year:'numeric'}):'',l.checkOut?formatDate(l.checkOut,{day:'2-digit',month:'short',year:'numeric'}):''].filter(Boolean).join(' → '))}</p>${l.address?`<p>${esc(l.address)}</p>`:''}</div></article></div>`;}
function archivedRentalMarkup(snapshot={}){
  const r=snapshot.rental||{},km=snapshot.budget?.carKm||snapshot.carKm||{};
  const hasInitial=km.initial!==''&&km.initial!==null&&km.initial!==undefined,hasFinal=km.final!==''&&km.final!==null&&km.final!==undefined;
  const driven=hasInitial&&hasFinal?num(km.final)-num(km.initial):null;
  const kmText=hasInitial||hasFinal?`<p class="history-rental-km"><b>Kilómetros:</b> ${hasInitial?`${num(km.initial).toLocaleString('es-ES')} km`:'—'} → ${hasFinal?`${num(km.final).toLocaleString('es-ES')} km`:'—'}${driven!==null?` · <strong>${driven.toLocaleString('es-ES')} km recorridos</strong>`:''}</p>`:'';
  return `<div class="history-archive-logistic-grid"><article><span class="history-archive-icon">🚗</span><div><small>${esc(r.pickup||'Coche de alquiler')}</small><strong>${esc([r.group?`Grupo ${r.group}`:'',r.model||''].filter(Boolean).join(' · ')||'—')}</strong><p>${esc([r.pickupAt?formatDate(r.pickupAt,{day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'}):'',r.dropoffAt?formatDate(r.dropoffAt,{day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'}):''].filter(Boolean).join(' → '))}</p><p>Reservado ${formatMoney(num(r.reservedPrice))}${num(r.currentPrice)>0?` · Último precio ${formatMoney(num(r.currentPrice))}`:''}</p>${kmText}</div></article></div>`;}
function historyArchiveAppearance(snapshot={}){
  const appearance=snapshot.appearance||{};
  return {
    gradient1:normalizeHexColor(appearance.headerGradient1,'#114067'),
    gradient2:normalizeHexColor(appearance.headerGradient2,'#051421')
  };
}
function historyArchiveCard(snapshot,index){
  const summary=snapshot.summary||{},stats=snapshot.budget?.stats||summary.budgetStats||{},flights=snapshot.flights||[],rental=snapshot.rental||summary.rental||{},lodging=snapshot.lodging||summary.lodging||{};
  const flightCount=flights.length||num(summary.flightCount),firstAirline=flights[0]?.airline||summary.firstAirline||snapshot.vueling?.title||'';
  const dates=snapshot.startDate&&snapshot.endDate?`${formatDate(snapshot.startDate,{day:'2-digit',month:'short'})} – ${formatDate(snapshot.endDate,{day:'2-digit',month:'short',year:'numeric'})}`:'Fechas no indicadas';
  const driveBadge=snapshot.driveArchive?.fileId?'<span class="history-drive-badge">☁ Drive</span>':'';
  const colors=historyArchiveAppearance(snapshot),hasCustomColors=Boolean(snapshot.appearance?.headerGradient1||snapshot.appearance?.headerGradient2),style=hasCustomColors?`--history-g1:${colors.gradient1};--history-g2:${colors.gradient2}`:'';
  const colorButton=canEdit()?`<button type="button" class="mini-btn history-header-color-button" data-history-header-colors="${esc(snapshot.id||String(index))}" title="Cambiar degradado de la cabecera" aria-label="Cambiar degradado de la cabecera">🎨</button>`:'';
  return `<article class="card history-trip-card" style="${esc(style)}"><button type="button" class="history-trip-open" data-open-history-archive="${esc(snapshot.id||String(index))}" aria-label="Abrir ${esc(snapshot.title||'viaje archivado')}"><div class="history-trip-head"><div><span class="header-kicker">VIAJE ARCHIVADO ${driveBadge}</span><h3>${esc(snapshot.title||'Viaje')}</h3><p>${esc(dates)} · ${snapshot.people||1} viajero${snapshot.people===1?'':'s'}</p></div><div class="history-final-cost"><small>Gasto real final</small><strong>${formatMoney(stats.total||0)}</strong><span>Todo pagado</span></div></div><div class="history-trip-kpis"><div><small>🏨 Alojamiento</small><strong>${esc(lodging.name||snapshot.cordial?.hotel||summary.cordialHotel||'—')}</strong></div><div><small>✈️ Vuelos</small><strong>${flightCount?`${flightCount} trayecto${flightCount===1?'':'s'}${firstAirline?` · ${esc(firstAirline)}`:''}`:'—'}</strong></div><div><small>🚗 Coche</small><strong>${esc(rental.model||'—')}</strong></div><div><small>🧾 Compra real</small><strong>${formatMoney(snapshot.purchaseTotals?.real??summary.purchaseReal??0)}</strong></div></div><div class="history-trip-open-footer"><span>Ver presupuesto, compras y todos los detalles</span><b>›</b></div></button>${colorButton}</article>`;
}
async function editHistoryArchiveAppearance(id){
  const reference=historyArchiveById(id);if(!reference)return toast('No se ha encontrado el viaje archivado.','error');
  const current=historyArchiveAppearance(reference);
  openForm({title:`Degradado · ${reference.title||'Viaje archivado'}`,fields:[{name:'headerGradient1',label:'Color inicial',type:'color'},{name:'headerGradient2',label:'Color final',type:'color'}],values:{headerGradient1:current.gradient1,headerGradient2:current.gradient2},onSubmit:async value=>{reference.appearance={...(reference.appearance||{}),headerGradient1:normalizeHexColor(value.headerGradient1,current.gradient1),headerGradient2:normalizeHexColor(value.headerGradient2,current.gradient2)};await state.provider.saveSection('history',state.data.history);render();toast('Degradado del viaje actualizado.');}});
}
function historyCurrentTripPreview(){
  const snap=buildTripArchiveSnapshot(),stats=snap.budget.stats,l=snap.lodging||{};
  const hasCurrent=stats.total>0||snap.flights.length>0||snap.buses.length>0||Boolean(String(l.name||'').trim())||num(snap.rental?.reservedPrice)>0||num(snap.rental?.currentPrice)>0||Boolean(String(snap.destination||'').trim());
  if(!hasCurrent)return `<section class="card history-current-trip history-current-empty"><div class="history-current-banner"><div><span class="header-kicker">VIAJE ACTUAL</span><h3>Listo para un nuevo viaje</h3><p>El último viaje ya está archivado. Configura las nuevas fechas, reservas y presupuesto cuando quieras.</p></div><div class="history-current-total"><small>Gasto actual</small><strong>${formatMoney(0)}</strong></div></div></section>`;
  const dates=snap.startDate&&snap.endDate?`${formatDate(snap.startDate,{day:'2-digit',month:'short'})} – ${formatDate(snap.endDate,{day:'2-digit',month:'short',year:'numeric'})}`:'Configura las fechas del viaje';
  return `<section class="card history-current-trip"><div class="history-current-banner"><div><span class="header-kicker">VIAJE ACTUAL</span><h3>${esc(snap.title)}</h3><p>${esc(dates)}</p></div><div class="history-current-total"><small>Gasto que se archivará</small><strong>${formatMoney(stats.total)}</strong></div></div><div class="history-current-grid"><div><span>📅</span><small>Fechas</small><strong>${esc(dates)}</strong></div><div><span>🏨</span><small>Alojamiento</small><strong>${esc(l.name||'—')}</strong></div><div><span>✈️</span><small>Vuelos</small><strong>${snap.flights.length} trayecto${snap.flights.length===1?'':'s'}</strong></div><div><span>🚗</span><small>Coche alquiler</small><strong>${esc(snap.rental?.model||'—')}</strong></div><div><span>💶</span><small>Gasto final</small><strong>${formatMoney(stats.total)}</strong></div><div><span>🧾</span><small>Compra real</small><strong>${formatMoney(snap.purchaseTotals.real)}</strong></div></div></section>`;
}
function historyArchiveById(id=''){return (state.data.history?.archives||[]).find((item,index)=>String(item?.id||index)===String(id));}
function historyArchiveSortTime(item={}){
  for(const value of [item.endDate,item.returnDateTime,item.startDate,item.departureDateTime,item.archivedAt]){
    const t=Date.parse(String(value||''));if(Number.isFinite(t))return t;
  }
  const year=num(item.year);return year>0?Date.UTC(year,11,31):0;
}
function sortedHistoryArchives(){
  return [...(state.data.history?.archives||[])].sort((a,b)=>historyArchiveSortTime(b)-historyArchiveSortTime(a)||String(b.archivedAt||'').localeCompare(String(a.archivedAt||'')));
}
function latestHistoryArchiveReference(){return sortedHistoryArchives()[0]||null;}
function archiveDriveFolder(){
  const folder=state.data.settings?.historyDriveFolder||{};
  return folder?.id?{id:String(folder.id),name:String(folder.name||'Carpeta Histórico'),sharedDriveId:String(folder.sharedDriveId||''),sourceMode:String(folder.sourceMode||'my')}:{id:'',name:'',sharedDriveId:'',sourceMode:'my'};
}
function archiveJsonFileName(snapshot={}){
  const raw=`${snapshot.title||snapshot.destination||'Viaje'} ${snapshot.startDate||''} ${snapshot.endDate||''}`.normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-zA-Z0-9._ -]+/g,'').trim().replace(/\s+/g,'_').slice(0,90)||'Viaje';
  return `${raw}_${snapshot.id||Date.now()}.json`;
}
function archiveReferenceFromSnapshot(snapshot={},uploaded={},folder={}){
  const flights=snapshot.flights||[],stats=snapshot.budget?.stats||{},rental=snapshot.rental||{},lodging=snapshot.lodging||{};
  return {
    id:snapshot.id,title:snapshot.title,archivedAt:snapshot.archivedAt,destination:snapshot.destination||'',year:snapshot.year||'',people:snapshot.people||1,
    departureDateTime:snapshot.departureDateTime||'',returnDateTime:snapshot.returnDateTime||'',startDate:snapshot.startDate||'',endDate:snapshot.endDate||'',
    budget:{stats:clone(stats)},purchaseTotals:clone(snapshot.purchaseTotals||{}),
    summary:{budgetStats:clone(stats),purchaseReal:num(snapshot.purchaseTotals?.real),lodging:{name:lodging.name||''},flightCount:flights.length,firstAirline:flights[0]?.airline||'',rental:{model:rental.model||''},cordialHotel:snapshot.cordial?.hotel||''},
    driveArchive:{fileId:String(uploaded.driveFileId||uploaded.id||''),fileName:String(uploaded.label||''),folderId:String(folder.id||uploaded.parentId||''),folderName:String(folder.name||''),mimeType:'application/json',size:num(uploaded.size),url:String(uploaded.driveUrl||uploaded.url||''),formatVersion:1},
    archiveVersion:4
  };
}
async function uploadHistorySnapshotToDrive(snapshot={},folder={}){
  if(!folder?.id)throw new Error('Elige primero la carpeta de Google Drive para el Histórico.');
  const payload={format:'mfe-viajes-history',formatVersion:1,createdAt:new Date().toISOString(),snapshot};
  const fileName=archiveJsonFileName(snapshot);
  const file=new File([JSON.stringify(payload)],fileName,{type:'application/json'});
  return uploadBlobToDrive(file,{name:fileName,parentId:folder.id,originalName:fileName,errorLabel:'archivo histórico'});
}
async function loadHistorySnapshotFromDrive(reference={}, {force=false}={}){
  if(!reference?.driveArchive?.fileId)return reference;
  const id=String(reference.id||reference.driveArchive.fileId),cached=state.historyArchiveCache.get(id);
  if(cached&&!force)return cached;
  const fileId=String(reference.driveArchive.fileId);
  const response=await authorizedDriveFetch(`https://www.googleapis.com/drive/v3/files/${encodeURIComponent(fileId)}?alt=media&supportsAllDrives=true`,{cache:'no-store'});
  if(!response.ok){let detail='';try{detail=(await response.json())?.error?.message||'';}catch{}throw new Error(`No se pudo leer el Histórico desde Drive (HTTP ${response.status})${detail?`: ${detail}`:''}.`);}
  const text=await response.text();let parsed;try{parsed=JSON.parse(text);}catch{throw new Error('El archivo histórico de Drive no contiene un JSON válido.');}
  const snapshot=parsed?.format==='mfe-viajes-history'?parsed.snapshot:parsed?.snapshot||parsed;
  if(!snapshot||typeof snapshot!=='object')throw new Error('El archivo histórico de Drive no contiene un viaje válido.');
  if(reference.id&&snapshot.id&&String(reference.id)!==String(snapshot.id))throw new Error('El archivo de Drive no corresponde con esta ficha del Histórico.');
  state.historyArchiveCache.set(id,snapshot);
  return snapshot;
}
async function readHistorySnapshotSelection(selected={}){
  const fileId=String(selected.driveFileId||selected.id||'').trim();if(!fileId)throw new Error('Google Drive no ha devuelto el identificador del JSON.');
  const [contentResponse,metaResponse]=await Promise.all([
    authorizedDriveFetch(`https://www.googleapis.com/drive/v3/files/${encodeURIComponent(fileId)}?alt=media&supportsAllDrives=true`,{cache:'no-store'}),
    authorizedDriveFetch(`https://www.googleapis.com/drive/v3/files/${encodeURIComponent(fileId)}?fields=id,name,mimeType,parents,size,webViewLink&supportsAllDrives=true`,{cache:'no-store'})
  ]);
  if(!contentResponse.ok)throw new Error(`No se pudo leer el JSON de Drive (HTTP ${contentResponse.status}).`);
  const text=await contentResponse.text();let parsed;try{parsed=JSON.parse(text);}catch{throw new Error('El archivo seleccionado no contiene un JSON válido.');}
  const snapshot=parsed?.format==='mfe-viajes-history'?parsed.snapshot:parsed?.snapshot||parsed;
  if(!snapshot||typeof snapshot!=='object')throw new Error('El JSON no contiene un snapshot de MFE Viajes.');
  if(!snapshot.id)snapshot.id=uid('trip-archive-import');
  if(!snapshot.title)snapshot.title=archiveTripTitle(snapshot);
  if(!snapshot.startDate&&snapshot.departureDateTime)snapshot.startDate=String(snapshot.departureDateTime).slice(0,10);
  if(!snapshot.endDate&&snapshot.returnDateTime)snapshot.endDate=String(snapshot.returnDateTime).slice(0,10);
  const stats=snapshot.budget?.stats||{};if(!Object.prototype.hasOwnProperty.call(stats,'total')||!Number.isFinite(Number(stats.total)))throw new Error('El JSON no contiene un total de presupuesto válido.');
  let meta={};if(metaResponse.ok){try{meta=await metaResponse.json();}catch{}}
  return {snapshot,meta:{id:fileId,name:meta.name||selected.label||'Histórico.json',mimeType:meta.mimeType||selected.mimeType||'application/json',parents:Array.isArray(meta.parents)?meta.parents:[],size:num(meta.size),webViewLink:meta.webViewLink||selected.driveUrl||selected.url||`https://drive.google.com/file/d/${fileId}/view`}};
}
async function importHistoryArchiveFromDrive(){
  if(!canEdit())return toast('Desbloquea la edición para importar un viaje al Histórico.','error');
  try{
    const selected=(await selectFromDrive({multiple:false,mimeTypes:'application/json',includeToken:false,sharedDrives:false,title:'Importar viaje histórico · JSON de Google Drive'}))[0];if(!selected)return;
    toast('Leyendo viaje histórico desde Google Drive…');
    const {snapshot,meta}=await readHistorySnapshotSelection(selected);
    state.data.history=state.data.history||{archives:[]};state.data.history.archives=Array.isArray(state.data.history.archives)?state.data.history.archives:[];
    if(state.data.history.archives.some(item=>String(item.id)===String(snapshot.id)))return toast('Ese viaje ya está añadido al Histórico.','error');
    const configured=archiveDriveFolder(),parentId=String(meta.parents?.[0]||'');
    const folder={id:parentId,name:configured.id===parentId?configured.name:'Google Drive'};
    const uploaded={driveFileId:meta.id,id:meta.id,label:meta.name,driveUrl:meta.webViewLink,url:meta.webViewLink,size:meta.size,parentId};
    const reference=archiveReferenceFromSnapshot(snapshot,uploaded,folder);
    if(snapshot.appearance)reference.appearance=clone(snapshot.appearance);
    state.data.history.archives.unshift(reference);
    await state.provider.saveSection('history',state.data.history);
    state.historyArchiveCache.set(String(snapshot.id),snapshot);render();toast(`${snapshot.title||'Viaje'} añadido al Histórico.`);
  }catch(error){toast(`No se pudo importar el Histórico: ${error.message}`,'error');}
}
function renderHistoryArchiveDetailModal(snapshot={}){
  const stats=snapshot.budget?.stats||{},dates=snapshot.startDate&&snapshot.endDate?`${formatDate(snapshot.startDate,{day:'2-digit',month:'short',year:'numeric'})} – ${formatDate(snapshot.endDate,{day:'2-digit',month:'short',year:'numeric'})}`:'Fechas no indicadas';
  openModal(`<div class="modal-head history-archive-modal-head"><div><span class="header-kicker">VIAJE ARCHIVADO</span><h3>${esc(snapshot.title||'Viaje')}</h3><small>${esc(dates)} · Archivado ${esc(formatDate(snapshot.archivedAt,{day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'}))}</small></div><button class="close-btn" data-close-modal>×</button></div><div class="history-archive-detail"><section class="history-archive-hero"><div><small>Gasto real final</small><strong>${formatMoney(stats.total||0)}</strong><span>Todo pagado</span></div><div><small>Compra real</small><strong>${formatMoney(snapshot.purchaseTotals?.real||0)}</strong><span>${snapshot.people||1} viajero${snapshot.people===1?'':'s'}</span></div></section><section class="history-detail-block"><div class="history-detail-block-head"><h4>💶 Presupuesto convertido a gasto real</h4><strong>${formatMoney(stats.total||0)}</strong></div>${archivedBudgetMarkup(snapshot)}</section><section class="history-detail-block"><div class="history-detail-block-head"><h4>🧾 Compras y gastos reales</h4><strong>${formatMoney(snapshot.purchaseTotals?.real||0)}</strong></div>${archivedPurchaseDetailMarkup(snapshot)}</section><section class="history-detail-block"><div class="history-detail-block-head"><h4>🏨 Alojamiento</h4></div>${archivedLodgingMarkup(snapshot)}</section><section class="history-detail-block"><div class="history-detail-block-head"><h4>✈️ Vuelos</h4></div>${archivedFlightsMarkup(snapshot)}</section>${(snapshot.buses||[]).length?`<section class="history-detail-block"><div class="history-detail-block-head"><h4>🚌 Autobuses</h4></div>${archivedBusesMarkup(snapshot)}</section>`:''}<section class="history-detail-block"><div class="history-detail-block-head"><h4>🚗 Coche de alquiler</h4></div>${archivedRentalMarkup(snapshot)}</section><section class="history-detail-block history-tracker-snapshot"><div class="history-detail-block-head"><h4>📡 Seguimientos archivados</h4></div><div class="history-archive-summary-grid"><div><small>AutoReisen</small><strong>${formatMoney(num(snapshot.rental?.currentPrice||snapshot.rental?.reservedPrice))}</strong></div><div><small>Cordial</small><strong>${formatMoney(num(snapshot.cordial?.currentPrice||snapshot.cordial?.reservedPrice))}</strong></div><div><small>Vueling</small><strong>${formatMoney(num(snapshot.vueling?.currentPrice||snapshot.vueling?.reservedPrice))}</strong></div></div></section><div class="history-archive-actions">${snapshot.readOnlyArchive===true?'':`<button type="button" class="btn secondary history-undo-button" data-undo-history-archive="${esc(snapshot.id)}">🔐 Deshacer archivo</button>`}<button type="button" class="btn secondary" data-close-modal>Cerrar</button></div><p class="help-text history-undo-help">${snapshot.readOnlyArchive===true?'Histórico importado en modo solo lectura. El detalle se lee del archivo guardado en Google Drive.':'El detalle se lee del archivo guardado en Google Drive. Deshacer requiere la biometría/verificación segura de este dispositivo y solo se permite si no hay datos de otro viaje activo.'}</p></div>`,true);
  $('[data-undo-history-archive]',els.modal)?.addEventListener('click',()=>openUndoArchiveConfirm(snapshot.id));
}
async function openHistoryArchiveDetail(id){
  const reference=historyArchiveById(id);if(!reference)return toast('No se ha encontrado el viaje archivado.','error');
  if(reference.driveArchive?.fileId)openModal(`<div class="modal-head"><h3>${esc(reference.title||'Viaje archivado')}</h3><button class="close-btn" data-close-modal>×</button></div><div class="modal-body"><div class="archive-drive-loading">☁ Cargando el Histórico desde Google Drive…</div></div>`,true);
  try{const snapshot=await loadHistorySnapshotFromDrive(reference);renderHistoryArchiveDetailModal(snapshot);}
  catch(error){openModal(`<div class="modal-head"><h3>Histórico no disponible</h3><button class="close-btn" data-close-modal>×</button></div><div class="modal-body"><p>No se ha podido abrir el archivo guardado en Google Drive.</p><p class="help-text">${esc(error.message)}</p>${reference.driveArchive?.url?`<div class="page-actions"><a class="btn secondary" href="${esc(reference.driveArchive.url)}" target="_blank" rel="noopener">↗ Abrir archivo en Drive</a></div>`:''}</div>`,true);}
}
function currentTripHasRestorableData(){
  const s=state.data.settings||{},p=state.data.purchases||{},groups=state.data.budget?.groups||[],km=state.data.budget?.carKm||{};
  const hasCarKm=(km.initial!==''&&km.initial!==null&&km.initial!==undefined)||(km.final!==''&&km.final!==null&&km.final!==undefined);
  // Vuelos/alojamiento/coche pueden permanecer como plantilla tras archivar. Solo consideramos
  // que hay un nuevo viaje activo cuando ya existen fechas/año o datos económicos nuevos.
  return Boolean(String(s.year||'').trim()||String(s.departureDateTime||'').trim()||String(s.returnDateTime||'').trim()||groups.some(g=>(g.items||[]).length)||hasCarKm||(p.records||[]).length||(p.ticketItems||[]).length||(p.otherExpenses||[]).length||(p.extras||[]).length);
}
function archiveFallbackRestorePayload(snapshot={}){
  return {settings:{destination:snapshot.destination||'',year:snapshot.year||'',people:snapshot.people||1,departureDateTime:snapshot.departureDateTime||'',returnDateTime:snapshot.returnDateTime||'',countdownEndDateTime:''},budget:{...(state.data.budget||{}),groups:clone(snapshot.budget?.groups||[]),carKm:clone(snapshot.budget?.carKm||snapshot.carKm||{initial:'',final:''})},purchases:clone(snapshot.purchases||{}),cover:{flights:clone(snapshot.flights||[]),buses:clone(snapshot.buses||[]),lodging:clone(snapshot.lodging||{}),documents:clone(snapshot.coverDocuments||[])},trackers:{autoreisen:pickArchiveFields(snapshot.rental||{},ARCHIVE_TRACKER_FIELDS.autoreisen),cordial:pickArchiveFields(snapshot.cordial||{},ARCHIVE_TRACKER_FIELDS.cordial),vueling:pickArchiveFields(snapshot.vueling||{},ARCHIVE_TRACKER_FIELDS.vueling)}};
}
function mergeArchivedDocumentsIntoCover(documents=[]){
  const archived=new Map((documents||[]).map(d=>[String(d?.id||''),clone(d)]));
  const current=state.data.cover?.documents||[];const seen=new Set();
  state.data.cover.documents=current.map(doc=>{const id=String(doc?.id||'');if(archived.has(id)){seen.add(id);return archived.get(id);}return doc;});
  for(const [id,doc] of archived.entries())if(!seen.has(id))state.data.cover.documents.push(doc);
}
function applyTrackerRestoreFields(id,values={}){const target=state.data.trackers?.[id];if(!target)return;for(const key of ARCHIVE_TRACKER_FIELDS[id]||[])if(Object.prototype.hasOwnProperty.call(values,key))target[key]=clone(values[key]);}
function applyArchiveRestorePayload(snapshot={}){
  const payload=snapshot.restorePayload||archiveFallbackRestorePayload(snapshot),sp=payload.settings||{};
  for(const key of ['destination','year','people','departureDateTime','returnDateTime','countdownEndDateTime'])if(Object.prototype.hasOwnProperty.call(sp,key))state.data.settings[key]=clone(sp[key]);
  if(payload.budget)state.data.budget=clone(payload.budget);
  if(payload.purchases)state.data.purchases=clone(payload.purchases);
  if(payload.cover){state.data.cover.flights=clone(payload.cover.flights||[]);state.data.cover.buses=clone(payload.cover.buses||[]);state.data.cover.lodging=clone(payload.cover.lodging||{});mergeArchivedDocumentsIntoCover(payload.cover.documents||[]);}
  for(const id of ['autoreisen','cordial','vueling'])applyTrackerRestoreFields(id,payload.trackers?.[id]||{});
}
async function openUndoArchiveConfirm(id){
  const reference=historyArchiveById(id);if(!reference)return;
  if(currentTripHasRestorableData())return openModal(`<div class="modal-head"><h3>No se puede deshacer todavía</h3><button class="close-btn" data-close-modal>×</button></div><div class="modal-body"><p>Hay datos de otro viaje en la zona activa. Para evitar sobrescribirlos, primero archiva ese viaje o deja vacíos los campos que forman parte del Histórico.</p><div class="page-actions"><button class="btn secondary" data-close-modal>Cerrar</button></div></div>`,true);
  let snapshot;try{snapshot=await loadHistorySnapshotFromDrive(reference);}catch(error){return toast(`No se puede deshacer sin leer el archivo de Drive: ${error.message}`,'error');}
  openModal(`<div class="modal-head"><h3>Deshacer archivo</h3><button class="close-btn" data-close-modal>×</button></div><div class="modal-body"><div class="archive-confirm-summary"><strong>${esc(snapshot.title||'Viaje')}</strong><span>Se restaurará como viaje activo y desaparecerá de Histórico.</span></div><div class="archive-check-list"><div>🔐 Requiere biometría/verificación del dispositivo</div><div>✓ Restaurará presupuesto, compras, vuelos, alojamiento y coche</div><div>✓ Solo modifica los mismos campos que fueron archivados</div><div>✓ No sobrescribe otro viaje activo</div></div><p class="help-text">El JSON original de Google Drive se conserva como copia de seguridad aunque deshagas el archivo.</p><div class="page-actions"><button class="btn secondary" data-close-modal>Cancelar</button><button class="btn primary" data-confirm-undo-history="${esc(snapshot.id)}">🔐 Deshacer archivo</button></div></div>`,true);
  $('[data-confirm-undo-history]',els.modal)?.addEventListener('click',()=>undoHistoryArchive(snapshot.id));
}
async function undoHistoryArchive(id){
  const reference=historyArchiveById(id);if(!reference)return toast('No se ha encontrado el archivo.','error');
  if(currentTripHasRestorableData())return toast('Hay datos de otro viaje activo. No se sobrescribirá.','error');
  if(!deviceAuthConfigured())return toast('Activa primero la biometría/verificación del dispositivo en Configuración → Seguridad.','error');
  const button=$('[data-confirm-undo-history]',els.modal);if(button){button.disabled=true;button.textContent='Verificando…';}
  let snapshot;try{snapshot=await loadHistorySnapshotFromDrive(reference);}catch(error){if(button){button.disabled=false;button.textContent='🔐 Deshacer archivo';}return toast(`No se pudo leer el archivo histórico de Drive: ${error.message}`,'error');}
  try{const ok=await authenticateWithDevice();if(!ok)throw new Error('No se pudo verificar el dispositivo.');}
  catch(error){if(button){button.disabled=false;button.textContent='🔐 Deshacer archivo';}return toast(deviceAuthErrorMessage(error),'error');}
  const memoryBackup=clone({settings:state.data.settings,budget:state.data.budget,purchases:state.data.purchases,cover:state.data.cover,trackers:state.data.trackers,history:state.data.history});
  try{
    applyArchiveRestorePayload(snapshot);
    await Promise.all(['settings','budget','purchases','cover','trackers'].map(section=>state.provider.saveSection(section,state.data[section])));
    state.data.history.archives=(state.data.history.archives||[]).filter(item=>String(item.id)!==String(snapshot.id));
    await state.provider.saveSection('history',state.data.history);
    state.historyArchiveCache.delete(String(snapshot.id));
    closeModal();render();toast('Archivo deshecho. El viaje vuelve a estar activo; la copia JSON permanece en Drive.');
  }catch(error){Object.assign(state.data,{settings:memoryBackup.settings,budget:memoryBackup.budget,purchases:memoryBackup.purchases,cover:memoryBackup.cover,trackers:memoryBackup.trackers,history:memoryBackup.history});render();toast(`No se pudo deshacer el archivo: ${error.message}`,'error');}
}
async function recoverReusableTripTemplateFromLatestArchive(){
  if(!canEdit())return toast('Desbloquea la edición para recuperar la plantilla.','error');
  const reference=latestHistoryArchiveReference();if(!reference)return toast('No hay ningún viaje archivado del que recuperar la configuración.','error');
  try{
    toast(`Recuperando configuración de ${reference.title||'último viaje'}…`);
    const snapshot=await loadHistorySnapshotFromDrive(reference);
    applyReusableTripTemplate(snapshot);
    await Promise.all(['settings','cover','trackers'].map(section=>state.provider.saveSection(section,state.data[section])));
    render();toast(`Plantilla recuperada de ${snapshot.title||reference.title||'último viaje'}. Solo tienes que cambiar fechas, precios o lo que necesites.`);
  }catch(error){toast(`No se pudo recuperar la plantilla: ${error.message}`,'error');}
}
function fullResetFlights(){
  state.data.cover.flights=[];
  resetTrackerForNewTrip('vueling');
}
function fullResetLodging(){
  state.data.cover.lodging={...(state.data.cover.lodging||{}),name:'',checkIn:'',checkOut:'',website:'',mapsUrl:'',imageUrl:'',address:'',googleReviewsUrl:'',tripadvisorReviewsUrl:'',bookingReviewsUrl:'',guestGuideUrl:''};
  resetTrackerForNewTrip('cordial');
}
function promptProtectedTripDataReset(kind){
  const isFlights=kind==='flights',label=isFlights?'vuelos y seguimiento Vueling':'alojamiento y seguimiento Cordial';
  openForm({title:isFlights?'Resetear vuelos':'Resetear alojamiento',submitText:'Resetear',submitClass:'danger',fields:[{name:'pin',label:'PIN de edición',type:'password',required:true,full:true,help:`Acción protegida: se vaciarán los datos de ${label}. El Histórico no se modifica.`,warning:true}],onSubmit:async({pin})=>{
    await verifyEditPin(pin);
    if(isFlights)fullResetFlights();else fullResetLodging();
    await Promise.all([state.provider.saveSection('cover',state.data.cover),state.provider.saveSection('trackers',state.data.trackers)]);
    render();toast(isFlights?'Vuelos y seguimiento Vueling reseteados.':'Alojamiento y seguimiento Cordial reseteados.');
  }});
}

function openArchiveTripConfirm(){
  const snap=buildTripArchiveSnapshot(),folder=archiveDriveFolder();
  openModal(`<div class="modal-head"><h3>Archivar viaje</h3><button class="icon-btn" data-close-modal>×</button></div><div class="archive-confirm-body"><p class="archive-confirm-lead">Se guardará una copia completa en Google Drive. Después se vaciarán los gastos del viaje y se conservarán hotel, vuelos, coche y seguimientos como plantilla para el siguiente.</p><div class="archive-confirm-summary"><strong>${esc(snap.title)}</strong><span>${formatMoney(snap.budget.stats.total)} · todo se consolidará como gasto real pagado</span></div><div class="archive-drive-target"><div><small>Carpeta del Histórico en Google Drive</small><strong data-history-drive-folder-label>${esc(folder.name||'Sin seleccionar')}</strong><span>${folder.id?'Se recordará y sincronizará entre dispositivos.':'Créala en Drive y selecciónala una sola vez.'}</span></div><button type="button" class="btn secondary" data-history-drive-folder>📁 ${folder.id?'Cambiar':'Elegir carpeta'}</button></div><div class="archive-check-list"><div>☁ El snapshot completo se guardará como un único JSON en Drive</div><div>✓ Fechas, alojamiento, vuelos, coche y kilómetros registrados</div><div>✓ Presupuesto completo convertido a gasto real</div><div>✓ Compra real, otros gastos y productos de tickets</div><div>✓ Datos principales de AutoReisen, Cordial y Vueling</div><div>↻ Firebase solo conservará una ficha ligera y el ID del archivo</div><div>♻ Hotel, vuelos, coche y configuración de seguimientos permanecerán preparados para reutilizarse</div></div><p class="help-text">Los gastos, kilómetros y documentos del viaje se limpian solo después de que Drive y la ficha de Histórico hayan confirmado el guardado. La configuración reutilizable no se borra.</p><div class="page-actions"><button type="button" class="btn secondary" data-close-modal>Cancelar</button><button type="button" class="btn primary archive-trip-action" data-confirm-archive-trip ${folder.id?'':'disabled'}>🗂️ Archivar viaje</button></div></div>`,true);
  const updateFolderUi=()=>{const f=archiveDriveFolder(),label=$('[data-history-drive-folder-label]',els.modal),confirm=$('[data-confirm-archive-trip]',els.modal),pick=$('[data-history-drive-folder]',els.modal);if(label)label.textContent=f.name||'Sin seleccionar';if(confirm)confirm.disabled=!f.id;if(pick)pick.textContent=`📁 ${f.id?'Cambiar':'Elegir carpeta'}`;};
  $('[data-history-drive-folder]',els.modal)?.addEventListener('click',async()=>{try{const chosen=await selectDriveFolder();if(!chosen)return;state.data.settings.historyDriveFolder={id:chosen.id,name:chosen.name,sharedDriveId:chosen.sharedDriveId||'',sourceMode:chosen.sourceMode||'my'};await state.provider.saveSection('settings',state.data.settings);updateFolderUi();toast(`Carpeta del Histórico: ${chosen.name}`);}catch(error){toast(`No se pudo seleccionar la carpeta: ${error.message}`,'error');}});
  $('[data-confirm-archive-trip]',els.modal)?.addEventListener('click',archiveCurrentTrip);
}
async function archiveCurrentTrip(){
  if(!canEdit()){toast('Desbloquea la edición para archivar el viaje.','error');return;}
  const folder=archiveDriveFolder();if(!folder.id)return toast('Elige primero la carpeta de Google Drive para guardar el Histórico.','error');
  const button=$('[data-confirm-archive-trip]',els.modal);if(button){button.disabled=true;button.textContent='Subiendo a Drive…';}
  state.data.budget.conceptIconMemory=mergedBudgetConceptIconMemory(state.data);
  const snapshot=buildTripArchiveSnapshot();state.data.history=state.data.history||{archives:[]};state.data.history.archives=Array.isArray(state.data.history.archives)?state.data.history.archives:[];
  let uploaded=null,reference=null;
  try{
    uploaded=await uploadHistorySnapshotToDrive(snapshot,folder);
    if(button)button.textContent='Guardando ficha…';
    reference=archiveReferenceFromSnapshot(snapshot,uploaded,folder);
    state.data.history.archives.unshift(reference);
    await state.provider.saveSection('history',state.data.history);
    state.historyArchiveCache.set(String(snapshot.id),snapshot);
  }catch(error){
    if(reference)state.data.history.archives=state.data.history.archives.filter(x=>x.id!==snapshot.id);
    if(uploaded?.driveFileId){try{await deleteDriveFileById(uploaded.driveFileId);}catch{}}
    if(button){button.disabled=false;button.textContent='🗂️ Archivar viaje';}
    toast(`No se ha archivado: ${error.message}`,'error');return;
  }
  resetCurrentTripAfterArchive();
  try{
    await Promise.all(['settings','budget','purchases','cover','trackers'].map(section=>state.provider.saveSection(section,state.data[section])));
    closeModal();render();toast(`Viaje archivado en Drive · ${folder.name}. Configuración reutilizable conservada para el próximo viaje.`);
  }catch(error){closeModal();render();toast('El viaje está archivado en Drive, pero algún campo activo no pudo reiniciarse. El histórico está a salvo.','error');console.error(error);}
}
function renderHistory(){
  const archives=sortedHistoryArchives();
  const actions=canEdit()?'<div class="page-actions history-page-actions"><button type="button" class="btn secondary" data-import-history-drive>☁ Importar JSON</button><button type="button" class="btn primary history-archive-button" data-archive-trip>🗂️ Archivar viaje</button></div>':'';
  return `${lockedBanner()}${pageHead('Histórico','Viajes finalizados y gastos reales',actions)}${historyCurrentTripPreview()}<section class="history-archive-list"><div class="history-list-head"><div><span class="header-kicker">VIAJES ARCHIVADOS</span><h3>Tu histórico</h3></div><strong>${archives.length} viaje${archives.length===1?'':'s'}</strong></div>${archives.length?archives.map(historyArchiveCard).join(''):'<div class="empty card history-empty">Todavía no has archivado ningún viaje.</div>'}</section>`;
}
binders.history=()=>{
  $$('[data-archive-trip]').forEach(b=>b.addEventListener('click',openArchiveTripConfirm));
  $$('[data-import-history-drive]').forEach(b=>b.addEventListener('click',importHistoryArchiveFromDrive));
  $$('[data-open-history-archive]').forEach(b=>b.addEventListener('click',()=>openHistoryArchiveDetail(b.dataset.openHistoryArchive)));
  $$('[data-history-header-colors]').forEach(b=>b.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();editHistoryArchiveAppearance(b.dataset.historyHeaderColors);}));
};

function renderNotes() {
  const blocks=state.data.notes.blocks||[];
  return `${lockedBanner()}${pageHead("Otros","Preguntas, teléfonos, notas y textos libres",canEdit()?'<button class="btn primary canary-action-btn" data-add-note>＋ Añadir bloque</button>':"")}
  <div class="notes-grid">${blocks.map((n,i)=>`<article class="card note-card" style="--note-color:${esc(n.color||"#4da3ff")}"><div class="card-body"><div class="flight-top"><h3 class="card-title">${esc(n.title)}</h3>${editButtons(`<div class="mini-actions"><button class="mini-btn" data-edit-note="${i}">✎</button><button class="mini-btn" data-delete-note="${i}">×</button></div>`)}</div><div class="note-content" style="margin-top:14px">${esc(n.content||"")}</div></div></article>`).join("")}</div>`;
}
binders.notes = () => {
  $$('[data-add-note]').forEach(b=>b.addEventListener('click',()=>editNote()));
  $$('[data-edit-note]').forEach(b=>b.addEventListener('click',()=>editNote(num(b.dataset.editNote))));
  $$('[data-delete-note]').forEach(b=>b.addEventListener('click',async()=>{if(confirmAction("¿Eliminar este bloque?")){state.data.notes.blocks.splice(num(b.dataset.deleteNote),1);await saveSection("notes");render();}}));
};
function editNote(index=null) {
  const current=index===null?{title:"",content:"",color:"#4da3ff"}:state.data.notes.blocks[index];
  openForm({title:index===null?"Añadir bloque":"Editar bloque",fields:[{name:"title",label:"Título",required:true},{name:"color",label:"Color",type:"color"},{name:"content",label:"Contenido",type:"textarea",required:true,full:true}],values:current,onSubmit:async v=>{const value={id:current.id||uid("note"),...current,...v};if(index===null)state.data.notes.blocks.push(value);else state.data.notes.blocks[index]=value;await saveSection("notes");render();}});
}

function disabledAttr() { return canEdit()?"":"disabled"; }
function setSettingsDirty(dirty=true) {
  state.settingsDirty=Boolean(dirty);
  const floating=$('[data-settings-floating-save]');
  if(floating){
    // El botón flotante debe permanecer siempre visible, pero con un estado visual discreto
    // hasta que haya cambios pendientes o el usuario pase el ratón / enfoque por encima.
    floating.classList.add('is-visible');
    floating.classList.toggle('is-dirty',state.settingsDirty);
    floating.setAttribute('aria-hidden','false');
    const note=floating.querySelector('[data-settings-save-note]');
    const button=floating.querySelector('[data-save-settings]');
    const message=state.settingsDirty?'Cambios sin guardar':'Listo para guardar';
    if(note)note.textContent=message;
    if(button){
      button.title=state.settingsDirty?'Hay cambios sin guardar':'Guardar cambios';
      button.setAttribute('aria-label',state.settingsDirty?'Guardar cambios pendientes':'Guardar cambios');
    }
  }
}
function bindSettingsDirtyTracking(){
  if(!canEdit())return;
  const markDirty=event=>{
    const control=event.target;
    if(!(control instanceof HTMLInputElement||control instanceof HTMLSelectElement||control instanceof HTMLTextAreaElement))return;
    if(!control.closest('.settings-panel form')||control.disabled||control.dataset.settingsDirtyIgnore==='true')return;
    setSettingsDirty(true);
  };
  // Delegación: también cubre controles que se inyectan dinámicamente en Configuración.
  els.content.oninput=markDirty;
  els.content.onchange=markDirty;
}
function settingsInput(name,label,value,type="text",extra="",full=false) {
  const val=type==="datetime-local"?toLocalInput(value):value??"";
  if(type==="color")return `<label class="field ${full?"full":""}"><span>${esc(label)}</span>${colorControlHtml(name,val,disabledAttr(),`settings-${name}`)}</label>`;
  return `<label class="field ${full?"full":""}">${esc(label)}<input name="${esc(name)}" type="${esc(type)}" value="${esc(val)}" ${extra} ${disabledAttr()}></label>`;
}
function settingsImageInput(name,label,value,previewTarget="") {
  const driveLabel=String(value||'').trim()?'Sustituir desde Drive':'Seleccionar desde Drive';
  return `<label class="field full">${esc(label)}<div class="drive-url-field"><input name="${esc(name)}" type="url" value="${esc(value||'')}" ${disabledAttr()}><button class="btn secondary small drive-url-pick" type="button" data-settings-drive-image="${esc(name)}" data-preview-target="${esc(previewTarget)}" title="${esc(driveLabel)}" ${disabledAttr()}>${driveIconMarkup()}<span>${esc(driveLabel)}</span></button></div></label>`;
}
function renderSettingsLegacy() {
  const s=state.data.settings,t=s.theme;
  const tabs=[["general","General"],["tripdata","Datos viaje"],["manage","Contenido"],["design","Diseño"],["weather","Servicios y mapas"],["integrations","Integraciones"],["updates","Actualización app"],["notifications","Notificaciones"],["security","Acceso"],["data","Datos"]];
  const mobileSettingsNav=`<label class="settings-mobile-nav"><span>Apartado de configuración</span><select data-settings-mobile-panel aria-label="Apartado de configuración">${tabs.map(([id,label])=>`<option value="${esc(id)}" ${state.settingsPanel===id?'selected':''}>${esc(label)}</option>`).join('')}</select></label>`;
  const tabChecks=TABS.filter(([id])=>id!=="settings").map(([id,icon,label])=>`<label class="switch-row"><span>${isImageSource(s.tabIconUrls?.[id])?`<img class="settings-tab-icon" src="${esc(s.tabIconUrls[id])}" alt="">`:esc(icon)} ${esc(label)}</span><input type="checkbox" name="tab-${id}" ${s.enabledTabs.includes(id)?"checked":""} ${disabledAttr()}></label>`).join("");
  const tabIconUploads=TABS.map(([id,icon,label])=>`<label class="icon-upload-card"><span class="icon-upload-preview" data-icon-preview="tab-${esc(id)}">${isImageSource(s.tabIconUrls?.[id])?`<img src="${esc(s.tabIconUrls[id])}" alt="${esc(label)}">`:esc(icon)}</span><strong>${esc(label)}</strong><input type="file" name="tabIconFile-${id}" accept="image/png,image/jpeg,image/webp,image/svg+xml" ${disabledAttr()}><small>128×128 recomendado</small></label>`).join('');
  const colorFields=Object.entries(t).filter(([,v])=>String(v).startsWith("#")).map(([key,value])=>`<div class="color-field"><span>${esc(key)}</span>${colorControlHtml(`theme-${key}`,value,disabledAttr(),`theme-${key}`)}</div>`).join("");
  const sectionColors=Object.entries(s.sectionColors||{}).map(([key,v])=>`<div class="card-body" style="padding:12px;border:1px solid var(--line);border-radius:12px"><strong style="text-transform:capitalize">${esc(key)}</strong><div class="form-grid" style="margin-top:9px"><label class="field"><span>Color</span>${colorControlHtml(`section-${key}-color`,v.color,disabledAttr(),`section-${key}-color`)}</label><label class="field"><span>Degradado 1</span>${colorControlHtml(`section-${key}-gradient1`,v.gradient1,disabledAttr(),`section-${key}-gradient1`)}</label><label class="field"><span>Degradado 2</span>${colorControlHtml(`section-${key}-gradient2`,v.gradient2,disabledAttr(),`section-${key}-gradient2`)}</label><label class="field"><span>Color del texto</span>${colorControlHtml(`section-${key}-textColor`,v.textColor||'#ffffff',disabledAttr(),`section-${key}-textColor`)}</label></div></div>`).join("");
  const officialHeaders=s.officialDocumentHeaders||{};
  const officialHeaderColorFields=['mikel','nerea'].map(person=>{const cfg=officialHeaders[person]||{};const label=person==='mikel'?'Mikel':'Nerea';const g1=cfg.gradient1||(person==='mikel'?'#184f68':'#4e2768'),g2=cfg.gradient2||(person==='mikel'?'#257b91':'#754198'),text=cfg.textColor||'#ffffff';return `<div class="card-body official-header-color-card"><div class="official-header-preview" data-official-header-preview="${person}" style="--preview-g1:${esc(g1)};--preview-g2:${esc(g2)};--preview-text:${esc(text)}">🪪 DOCUMENTOS OFICIALES ${label.toUpperCase()}</div><div class="form-grid three" style="margin-top:12px"><label class="field"><span>Inicio de la barra</span>${colorControlHtml(`official-${person}-gradient1`,g1,disabledAttr(),`official-${person}-gradient1`)}</label><label class="field"><span>Final de la barra</span>${colorControlHtml(`official-${person}-gradient2`,g2,disabledAttr(),`official-${person}-gradient2`)}</label><label class="field"><span>Color del título</span>${colorControlHtml(`official-${person}-textColor`,text,disabledAttr(),`official-${person}-textColor`)}</label></div></div>`;}).join('');
  const counts={flights:state.data.cover.flights.length,documents:state.data.cover.documents.length,budget:state.data.budget.groups.length,stores:state.data.shopping.stores.length,purchases:(state.data.purchases.records||[]).length+(state.data.purchases.otherExpenses||[]).length+(state.data.purchases.extras||[]).length,activities:state.data.itinerary.activities.length,tasks:(state.data.tasks.items||[]).length,menu:(state.data.menu.days||[]).length,notes:(state.data.notes.blocks||[]).length,emergency:(state.data.emergency.contacts||[]).length,common:(state.data.suitcases.common||[]).length,mikel:(state.data.suitcases.mikel||[]).length,nerea:(state.data.suitcases.nerea||[]).length};
  return `${lockedBanner()}${pageHead("Configuración","Personaliza la app completa y administra la estructura del viaje",canEdit()?'<button class="btn primary" data-save-settings>'+saveButtonContent("Guardar cambios")+'</button>':"")}
  ${mobileSettingsNav}<div class="settings-layout"><aside class="card settings-nav">${tabs.map(([id,label])=>`<button data-settings-panel="${id}" class="${state.settingsPanel===id?"active":""}">${esc(label)}</button>`).join("")}</aside><div>
  <section class="settings-panel ${state.settingsPanel==="general"?"active":""}" data-panel="general"><form id="settings-general"><article class="card settings-section"><h3>Identidad del viaje</h3><div class="form-grid">${settingsInput("appName","Nombre de la app",s.appName)}${settingsInput("appIcon","Emoji alternativo",s.appIcon)}${settingsImageInput("appIconUrl","URL de icono personalizado",s.appIconUrl,"app")}<div class="app-icon-upload full"><span class="icon-upload-preview app-icon-preview" data-icon-preview="app">${isImageSource(s.appIconUrl)?`<img src="${esc(s.appIconUrl)}" alt="Icono actual">`:esc(s.appIcon||"✈️")}</span><label class="field">Subir icono de la app (PNG recomendado)<input name="appIconFile" type="file" accept="image/png,image/jpeg,image/webp,image/svg+xml" ${disabledAttr()}><span class="help-text">Se guarda con transparencia y se utiliza también al instalar la web app. Si cambias el icono, Android generará automáticamente PNG reales de instalación con el mismo encuadre limpio y un fondo azul navy oscuro, sin añadir borde.</span></label></div>${settingsInput("destination","Destino",s.destination)}${settingsInput("year","Año",s.year,"number")}${settingsInput("people","Número de personas",s.people,"number",'min="1"')}${settingsInput("departureDateTime","Inicio del viaje · fecha maestra",s.departureDateTime,"datetime-local")}${settingsInput("returnDateTime","Fin del viaje · fecha maestra",s.returnDateTime,"datetime-local")}<label class="switch-row full"><span><strong>Usar estas fechas en vuelos, alojamiento y coche</strong><small>Al guardarlas se actualizan automáticamente ida/vuelta, entrada/salida, Cordial, Vueling y AutoReisen. Se conservan las horas ya configuradas en cada servicio.</small></span><input type="checkbox" name="syncTripDatesToTravelDetails" ${s.syncTripDatesToTravelDetails!==false?"checked":""} ${disabledAttr()}></label>${settingsImageInput("coverImageUrl","Imagen de portada (URL o Google Drive)",s.coverImageUrl,"cover")}${settingsInput("currency","Moneda ISO",s.currency)}${settingsInput("locale","Formato regional",s.locale)}</div><label class="switch-row smart-app-setting"><span>📱 Abrir apps instaladas cuando sea posible</span><input type="checkbox" name="preferNativeApps" ${s.preferNativeApps!==false?"checked":""} ${disabledAttr()}></label><p class="help-text">En móvil se usan enlaces seguros que respetan lo que cada servicio admite. Vueling utiliza sus enlaces universales oficiales. AENA e HiperDino reciben la URL HTTPS exacta para que el sistema abra la app solo si esa app la tiene registrada; si no, se conserva la página exacta (salidas o producto) y nunca se fuerza Google Play. El resto mantiene su apertura inteligente con fallback web.</p></article></form></section>
  <section class="settings-panel ${state.settingsPanel==="tripdata"?"active":""}" data-panel="tripdata"><form id="settings-tripdata"></form></section>
  <section class="settings-panel ${state.settingsPanel==="design"?"active":""}" data-panel="design"><form id="settings-design"><article class="card settings-section"><h3>Estilo visual</h3><p class="muted">Puedes probar el rediseño premium y volver al aspecto clásico en cualquier momento sin modificar ningún dato.</p><label class="field">Diseño<select name="visualStyle" ${disabledAttr()}><option value="premium" ${s.visualStyle!=='classic'?'selected':''}>Premium · v2.4.23</option><option value="classic" ${s.visualStyle==='classic'?'selected':''}>Clásico · anterior</option></select></label></article><article class="card settings-section"><h3>Paleta general</h3><p class="muted">La app permanece siempre en modo oscuro. Los colores controlan acentos, tarjetas, estados y degradados.</p><div class="color-grid">${colorFields}</div></article><article class="card settings-section"><h3>Colores por tipo</h3><div class="grid">${sectionColors}</div></article><article class="card settings-section"><h3>Color de las barras «Documentos oficiales»</h3><p class="muted">Cambia aquí el color de la barra superior y del título de Mikel y Nerea. La vista previa se actualiza al elegir los colores.</p><div class="grid">${officialHeaderColorFields}</div></article></form></section>
  <section class="settings-panel ${state.settingsPanel==="weather"?"active":""}" data-panel="weather"><form id="settings-weather"><article class="card settings-section"><h3>Open-Meteo</h3><div class="form-grid">${settingsInput("weatherPlace","Localidad que se muestra",s.weatherPlace)}${settingsInput("weatherLatitude","Latitud opcional",s.weatherLatitude,"number",'step="any"')}${settingsInput("weatherLongitude","Longitud opcional",s.weatherLongitude,"number",'step="any"')}</div><p class="help-text">No necesita clave ni Cloud Functions. Si dejas las coordenadas vacías, la app localizará automáticamente la localidad.</p><div class="page-actions" style="margin-top:13px"><button class="btn secondary" type="button" data-refresh-weather>↻ Probar tiempo</button></div></article><article class="card settings-section"><h3>Actualización de precios</h3><div class="form-grid">${settingsInput("priceWorkerUrl","URL del Cloudflare Worker",s.priceWorkerUrl||DEFAULT_PRICE_WORKER_URL,"url","",true)}</div><p class="help-text">Se utiliza para leer nombre, imagen y precio desde las páginas de producto sin activar el plan Blaze.</p><div class="page-actions" style="margin-top:13px"><button class="btn secondary" type="button" data-test-price-worker>✓ Probar conexión</button></div></article><article class="card settings-section"><h3>Worker Vueling</h3><div class="form-grid">${settingsInput("vuelingWorkerUrl","URL del Worker Vueling",s.vuelingWorkerUrl||DEFAULT_VUELING_WORKER_URL,"url","",true)}</div><p class="help-text">Worker independiente para el seguimiento del precio final de Vueling. El navegador real se ejecuta en GitHub Actions.</p><div class="page-actions" style="margin-top:13px"><button class="btn secondary" type="button" data-test-vueling-worker>✓ Probar Vueling</button></div></article><article class="card settings-section"><h3>Google Maps</h3><div class="form-grid">${settingsInput("mapQuery","Lugar o dirección",s.mapQuery,"text","",true)}${settingsInput("mapEmbedUrl","URL de iframe personalizada",s.mapEmbedUrl,"url","",true)}</div></article></form></section>
  <section class="settings-panel ${state.settingsPanel==="integrations"?"active":""}" data-panel="integrations"><form id="settings-integrations"></form></section>
  <section class="settings-panel ${state.settingsPanel==="updates"?"active":""}" data-panel="updates"><form id="settings-updates"></form></section>
  <section class="settings-panel ${state.settingsPanel==="notifications"?"active":""}" data-panel="notifications"><form id="settings-notifications"></form></section>
  <section class="settings-panel ${state.settingsPanel==="manage"?"active":""}" data-panel="manage"><form id="settings-manage"><article class="card settings-section"><h3>Resto del contenido del viaje</h3><p class="muted">Desde aquí puedes abrir y personalizar el resto de áreas del viaje. Vuelos, alojamiento, alquiler de coche y supermercados se gestionan en «Datos viaje».</p><div class="manager-grid">
    ${managerCard("📎","Reservas y documentos",`${counts.documents} bloques`,"cover")}${managerCard("💶","Presupuesto",`${counts.budget} grupos`,"budget")}${managerCard("🧳","Maleta común",`${counts.common} elementos`,"suitcase-common")}${managerCard("🎒","Maleta Mikel",`${counts.mikel} elementos`,"suitcase-mikel")}${managerCard("👜","Maleta Nerea",`${counts.nerea} elementos`,"suitcase-nerea")}${managerCard("🛒","Lista de la compra",`${counts.stores} supermercados`,"shopping")}${managerCard("🧾","Compra real",`${counts.purchases} registros`,"purchases")}${managerCard("✅","Tareas",`${counts.tasks} tareas`,"tasks")}${managerCard("🍽️","Menú",`${counts.menu} días`,"menu")}${managerCard("📍","Itinerario",`${counts.activities} actividades`,"itinerary")}${managerCard("🆘","Emergencia",`${counts.emergency} contactos`,"emergency")}${managerCard("📡","Seguimientos","AutoReisen, Cordial, Vueling y gasolineras","trackers")}${managerCard("📝","Otros",`${counts.notes} bloques`,"notes")}
  </div></article></form></section>
  <section class="settings-panel ${state.settingsPanel==="security"?"active":""}" data-panel="security"><article class="card settings-section"><h3>Usuario actual</h3><div class="manager-grid"><div class="manager-card"><strong>${esc(state.profile?.displayName||state.user?.email||"Usuario")}</strong><span>Rol: ${esc(state.profile?.role||"viewer")}</span><br><span>Acceso a Viajes: ${state.profile?.apps?.travel!==false?"Sí":"No"}</span></div></div></article><article class="card settings-section"><h3>PIN de edición</h3><p class="muted">Además del login y del rol, el PIN evita cambios accidentales. El PIN inicial de la demo es <strong>2026</strong>; cámbialo al publicar.</p><button class="btn secondary" type="button" data-change-pin ${canEdit()?"":"disabled"}>Cambiar PIN</button></article><article class="card settings-section device-auth-settings"><div class="settings-section-head"><div><h3>Huella / bloqueo del dispositivo</h3><p class="muted">Desbloqueo rápido mediante el autenticador local del dispositivo. Se solicita modo plataforma, credencial no residente y transporte interno para reducir al máximo la intervención de gestores de passkeys externos.</p></div><span class="device-auth-status ${deviceAuthConfigured()?'is-active':''}">${esc(deviceAuthStatusText())}</span></div><div class="integration-security-info"><p>La activación se guarda solo en este navegador y dispositivo para el usuario actual. Mikel puede activarlo en su móvil, Nerea en el suyo y también puede configurarse independientemente en una tablet.</p><p class="help-text">Tras instalar esta versión tendrás que activarlo de nuevo si lo habías registrado con la v2.2.154. El PIN de MFE siempre permanece como respaldo.</p></div><div class="page-actions">${deviceAuthConfigured()?`<button class="btn secondary" type="button" data-device-auth-test>👆 Probar desbloqueo</button><button class="btn danger" type="button" data-device-auth-disable>Desactivar en este dispositivo</button>`:`<button class="btn primary" type="button" data-device-auth-enable ${canEdit()?"":"disabled"}>👆 Activar en este dispositivo</button>`}</div></article><article class="card settings-section"><h3>Permisos MFE Apps</h3><p class="muted">Los usuarios se controlan en <code>mfeUsers/{uid}</code>. El usuario exclusivo de esta app debe tener <code>apps.travel: true</code> y el resto de permisos de apps en <code>false</code>.</p></article></section>
  <section class="settings-panel ${state.settingsPanel==="data"?"active":""}" data-panel="data"><article class="card settings-section"><h3>Copias y migraciones</h3><div class="page-actions"><button class="btn secondary" data-export-json>⬇ Exportar JSON</button><button class="btn secondary" data-import-json ${canEdit()?"":"disabled"}>⬆ Importar JSON</button></div><p class="help-text">La exportación incluye toda la configuración, listas, presupuesto, menú, itinerario y notas; no incluye los archivos binarios de Firebase Storage.</p></article><article class="card settings-section danger-zone"><h3>Restaurar datos iniciales</h3><p class="muted">Sustituye el viaje actual por los datos importados del Excel VIAJE VERANO 26.</p><button class="btn danger" data-reset-seed ${canEdit()?"":"disabled"}>Restaurar plantilla inicial</button></article></section>
  </div></div>`;
}
function managerCard(icon,title,subtitle,tab) { return `<div class="manager-card"><strong>${icon} ${esc(title)}</strong><span>${esc(subtitle)}</span><button class="btn secondary small" data-go-tab="${esc(tab)}">Abrir pestaña</button></div>`; }

binders.settings = () => {
  const activateSettingsPanel=id=>{if(!id)return;state.settingsPanel=id;render();requestAnimationFrame(()=>{const active=$('.settings-nav button.active');if(active)active.scrollIntoView({behavior:'smooth',block:'nearest',inline:'center'});});if(state.settingsPanel==='notifications')runNotificationDiagnostics({silent:true}).catch(console.warn);if(state.settingsPanel==='integrations'||state.settingsPanel==='updates')runIntegrationDiagnostics({silent:true}).catch(console.warn);if(state.settingsPanel==='updates')checkMobileDeployStatus({silent:true}).catch(console.warn);};
  $$('[data-settings-panel]').forEach(b=>b.addEventListener('click',()=>activateSettingsPanel(b.dataset.settingsPanel)));
  $('[data-settings-mobile-panel]')?.addEventListener('change',e=>activateSettingsPanel(e.target.value));
  $$('[data-go-tab]').forEach(b=>b.addEventListener('click',()=>navigateToTab(b.dataset.goTab)));
  $$('[data-save-settings]').forEach(b=>b.addEventListener('click',saveSettingsForms));
  $$('[data-refresh-weather]').forEach(b=>b.addEventListener('click',refreshWeather));
  $$('[data-test-price-worker]').forEach(b=>b.addEventListener('click',async()=>{try{toast('Comprobando Worker principal…');await testPriceWorker();}catch(e){toast(e?.message||'No se pudo comprobar el Worker principal.','error');}}));
  $$('[data-test-vueling-worker]').forEach(b=>b.addEventListener('click',async()=>{try{toast('Comprobando Worker Vueling…');const h=await fetchVuelingHealth();toast(`Worker Vueling conectado · v${h.version||'?'}`);}catch(e){toast(`Vueling: ${e.message}`,'error');}}));
  $$('[data-change-pin]').forEach(b=>b.addEventListener('click',changePin));
  $$('[data-device-auth-enable]').forEach(b=>b.addEventListener('click',activateDeviceAuth));
  $$('[data-device-auth-test]').forEach(b=>b.addEventListener('click',testDeviceAuth));
  $$('[data-device-auth-disable]').forEach(b=>b.addEventListener('click',()=>{if(confirmAction('¿Desactivar el desbloqueo del dispositivo en este navegador? El PIN seguirá funcionando.'))disableDeviceAuth();}));
  $$('[data-export-json]').forEach(b=>b.addEventListener('click',exportJson));
  $$('[data-import-json]').forEach(b=>b.addEventListener('click',importJson));
  $$('[data-reset-seed]').forEach(b=>b.addEventListener('click',resetSeed));
  $$('input[type="file"][name="appIconFile"], input[type="file"][name^="tabIconFile-"]').forEach(input=>input.addEventListener('change',()=>{
    const file=input.files?.[0];if(!file)return;
    const key=input.name==="appIconFile"?"app":`tab-${input.name.replace("tabIconFile-","")}`;
    const preview=document.querySelector(`[data-icon-preview="${CSS.escape(key)}"]`);
    if(!preview)return;
    const url=URL.createObjectURL(file);
    preview.innerHTML=`<img src="${esc(url)}" alt="Vista previa">`;
    preview.classList.add("has-selection");
  }));
};
function applySectionColorPresets() {
  const presets=state.data.settings.sectionColors||{};
  const applyVisual=(target,preset)=>{if(!target||!preset)return;target.color=preset.color||target.color;target.gradient1=preset.gradient1||target.gradient1;target.gradient2=preset.gradient2||target.gradient2;target.textColor=preset.textColor||target.textColor||'#ffffff';};
  const applyGroup=(id,key)=>applyVisual(state.data.budget.groups.find(x=>x.id===id),presets[key]);
  applyGroup("g-bus","bus");applyGroup("g-flights","flights");applyGroup("g-car","car");applyGroup("g-lodging","lodging");applyGroup("g-shopping","shopping");applyGroup("g-extras","extras");
  state.data.cover.flights.forEach(f=>applyVisual(f,presets.flights));
  (state.data.cover.buses||[]).forEach(bus=>{if(bus?.styleCustomized!==true)applyVisual(bus,presets.bus);});
  if(state.data.cover.lodging&&presets.lodging){state.data.cover.lodging.gradient1=presets.lodging.gradient1||state.data.cover.lodging.gradient1;state.data.cover.lodging.gradient2=presets.lodging.gradient2||state.data.cover.lodging.gradient2;state.data.cover.lodging.textColor=presets.lodging.textColor||state.data.cover.lodging.textColor||'#ffffff';}
  const docMap={"doc-flight":"flights","doc-car":"car","doc-lodging":"lodging","doc-parking":"parking"};
  state.data.cover.documents.forEach(d=>applyVisual(d,presets[docMap[d.id]]));
}

async function saveSettingsForms() {
  if(!canEdit())return;
  if(!validateHexColorControls(els.content)){toast("Revisa los códigos hexadecimales de color.","error");return;}
  let tripDatesChanged=false;
  const general=$("#settings-general"),manage=$("#settings-manage"),design=$("#settings-design"),weather=$("#settings-weather"),integrations=$("#settings-integrations"),notifications=$("#settings-notifications");
  if(general) {
    const f=new FormData(general); const s=state.data.settings;
    ["appName","appIcon","appIconUrl","destination","coverImageUrl","currency","locale"].forEach(k=>s[k]=String(f.get(k)||"").trim());
    const appIconFile=general.elements.appIconFile?.files?.[0];if(appIconFile)s.appIconUrl=await fileToSquareDataUrl(appIconFile,512);
    s.year=num(f.get("year"));s.people=Math.max(1,num(f.get("people")));const previousDeparture=s.departureDateTime,previousReturn=s.returnDateTime;s.departureDateTime=fromLocalInput(f.get("departureDateTime"));s.returnDateTime=fromLocalInput(f.get("returnDateTime"));tripDatesChanged=previousDeparture!==s.departureDateTime||previousReturn!==s.returnDateTime;
    s.syncTripDatesToTravelDetails=Boolean(general.elements.syncTripDatesToTravelDetails?.checked);
    s.preferNativeApps=Boolean(general.elements.preferNativeApps?.checked);
  }
  if(manage) {
    const f=new FormData(manage),s=state.data.settings;
    s.tabIconUrls=s.tabIconUrls||{};
    for(const [id] of TABS){const file=manage.elements[`tabIconFile-${id}`]?.files?.[0];if(file)s.tabIconUrls[id]=await fileToSquareDataUrl(file);}
    // La visibilidad se gestiona directamente desde la lista unificada de navegación.
    s.enabledTabs=[...new Set([...(s.enabledTabs||[]),"settings"])];
    for(const id of ["autoreisen","cordial","vueling","fuel"]){const input=manage.elements[`tracker-visible-${id}`];if(input)state.data.trackers.visible[id]=Boolean(input.checked);const titleInput=manage.elements[`tracker-title-${id}`];if(titleInput&&state.data.trackers[id])state.data.trackers[id].title=String(titleInput.value||'').trim()||state.data.trackers[id].title;}
    s.navigationPosition=String(f.get("navigationPosition")||s.navigationPosition||"top");
    s.countdownTitle=String(f.get("countdownTitle")??s.countdownTitle??"").trim();s.countdownSubtitle=String(f.get("countdownSubtitle")??s.countdownSubtitle??"").trim();s.countdownImageUrl=String(f.get("countdownImageUrl")??s.countdownImageUrl??"").trim();s.countdownGradient1=String(f.get("countdownGradient1")||s.countdownGradient1||s.theme.gradientStart);s.countdownGradient2=String(f.get("countdownGradient2")||s.countdownGradient2||s.theme.gradientEnd);s.countdownTextColor=String(f.get("countdownTextColor")||s.countdownTextColor||"#ffffff");s.countdownEndDateTime=fromLocalInput(f.get("countdownEndDateTime"));s.countdownShowSeconds=Boolean(manage.elements.countdownShowSeconds?.checked);s.countdownOverlayOpacity=Math.min(.95,Math.max(0,num(f.get("countdownOverlayOpacity"))));s.countdownImageCrop={x:Math.min(100,Math.max(0,num(f.get("countdownCropX")))),y:Math.min(100,Math.max(0,num(f.get("countdownCropY")))),zoom:Math.min(3,Math.max(1,num(f.get("countdownZoom"))||1))};
  }
  if(design) {
    state.data.settings.visualStyle=String(design.elements.visualStyle?.value||state.data.settings.visualStyle||"premium")==="classic"?"classic":"premium";
    Object.keys(state.data.settings.theme).forEach(k=>{const input=design.elements[`theme-${k}`];if(input)state.data.settings.theme[k]=input.value;});
    Object.entries(state.data.settings.sectionColors||{}).forEach(([key,v])=>["color","gradient1","gradient2","textColor"].forEach(prop=>{const input=design.elements[`section-${key}-${prop}`];if(input)v[prop]=input.value;}));
    state.data.settings.officialDocumentHeaders=state.data.settings.officialDocumentHeaders||{};
    for(const person of ['mikel','nerea']){
      const current=state.data.settings.officialDocumentHeaders[person]||{};
      state.data.settings.officialDocumentHeaders[person]={
        ...current,
        gradient1:design.elements[`official-${person}-gradient1`]?.value||current.gradient1,
        gradient2:design.elements[`official-${person}-gradient2`]?.value||current.gradient2,
        textColor:design.elements[`official-${person}-textColor`]?.value||current.textColor||'#ffffff'
      };
    }
  }
  if(weather) {
    const f=new FormData(weather);
    ["weatherPlace","weatherLatitude","weatherLongitude","priceWorkerUrl","vuelingWorkerUrl","mapQuery","mapEmbedUrl","googleDriveApiKey","googleDriveClientId","googleDriveAppId","mapType"].forEach(k=>{const value=f.get(k);if(value!==null)state.data.settings[k]=String(value||"").trim();});
  }
  if(integrations){
    const f=new FormData(integrations),settings=state.data.settings;
    ["firebaseConsoleUrl","firebaseMessagingUrl","googleDriveUrl","googleCalendarUrl","githubRepoUrl","githubActionsUrl","cloudflareDashboardUrl"].forEach(key=>{const value=f.get(key);if(value!==null)settings[key]=String(value||"").trim();});
    settings.autoreisenSyncWithTripDates=Boolean(integrations.elements.autoreisenSyncWithTripDates?.checked);
    settings.githubRunWorkflowAfterSync=Boolean(integrations.elements.githubRunWorkflowAfterSync?.checked);
  }
  if(notifications){const f=new FormData(notifications);const value=f.get('pushVapidKey');if(value!==null)state.data.settings.pushVapidKey=String(value||'').trim();}
  applySectionColorPresets();
  if(tripDatesChanged&&state.data.settings.syncTripDatesToTravelDetails!==false)synchronizeTravelDatesFromMasterLocally();
  if(tripDatesChanged)syncMenuDaysWithTripDates();
  const results=await Promise.all([saveSection("settings"),saveSection("cover"),saveSection("budget"),saveSection("trackers"),...(tripDatesChanged?[saveSection("menu")]:[])]);
  if(results.some(ok=>ok===false)){toast("Algún cambio no se ha podido guardar. Revisa el aviso de error.","error");return;}
  let syncWarning="";
  if(tripDatesChanged&&state.data.settings.autoreisenSyncWithTripDates!==false){
    try{await synchronizeAutoreisenWithTrip({runWorkflow:Boolean(state.data.settings.githubRunWorkflowAfterSync),silent:true});}
    catch(error){syncWarning=error.message||"No se pudo sincronizar GitHub.";}
  }
  state.settingsDirty=false;
  await persistAppIdentity(state.data.settings);
  applyTheme();render();
  if(syncWarning)toast(`Configuración guardada. AutoReisen se actualizó en la app, pero GitHub queda pendiente: ${syncWarning}`,"error");
  else toast(tripDatesChanged&&state.data.settings.syncTripDatesToTravelDetails!==false?"Configuración guardada y fechas maestras aplicadas a vuelos, alojamiento y coche.":(tripDatesChanged&&state.data.settings.autoreisenSyncWithTripDates!==false?"Configuración guardada y fechas de AutoReisen sincronizadas.":"Configuración e iconos guardados."));
}
function changePin() {
  openForm({title:"Cambiar PIN de edición",fields:[{name:"pin",label:"Nuevo PIN",type:"password",required:true},{name:"repeat",label:"Repetir PIN",type:"password",required:true}],onSubmit:async({pin,repeat})=>{if(pin.length<4)throw new Error("Utiliza al menos 4 caracteres.");if(pin!==repeat)throw new Error("Los PIN no coinciden.");state.data.settings.editPinHash=await hashText(pin);await saveSection("settings");toast("PIN actualizado.");}});
}
function exportJson() {
  const blob=new Blob([JSON.stringify(state.data,null,2)],{type:"application/json"});const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=`${TRIP_ID}-copia-${new Date().toISOString().slice(0,10)}.json`;a.click();URL.revokeObjectURL(a.href);
}
function importJson() {
  const input=document.createElement("input");input.type="file";input.accept="application/json";input.addEventListener("change",async()=>{const file=input.files?.[0];if(!file)return;try{const parsed=JSON.parse(await file.text());for(const key of Object.keys(SEED_DATA))if(key!=="history"&&!(key in parsed))throw new Error(`Falta la sección ${key}`);state.data=normalizeData(parsed);await state.provider.saveAll(state.data);render();toast("Copia importada.");}catch(error){toast(`Archivo no válido: ${error.message}`,"error");}});input.click();
}
async function resetSeed() { if(!confirmAction("¿Restaurar todos los datos iniciales? Se perderán los cambios actuales."))return;state.data=clone(SEED_DATA);await state.provider.saveAll(state.data);render();toast("Plantilla inicial restaurada."); }


function mapsDirectionsUrl(destination, fallback="") {
  if(isValidUrl(fallback)&&/google\.[^/]+\/maps/i.test(fallback))return fallback;
  const target=String(destination||"").trim();
  return target?`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(target)}&travelmode=driving`:fallback;
}
function moveArrayItem(array,index,delta){const target=index+delta;if(!Array.isArray(array)||target<0||target>=array.length)return false;const[item]=array.splice(index,1);array.splice(target,0,item);return true;}
function moveArrayItemTo(array,from,to,after=false){
  if(!Array.isArray(array)||from<0||from>=array.length)return false;
  const original=from,[item]=array.splice(from,1);
  let insert=Math.max(0,Math.min(array.length,to+(after?1:0)-(from<to+(after?1:0)?1:0)));
  array.splice(insert,0,item);
  return insert!==original;
}
function sortDragHandle(value,title='Arrastrar para mover'){
  return `<button type="button" class="mini-btn free-drag-handle" data-sort-handle="${esc(value)}" title="${esc(title)}" aria-label="${esc(title)}">⋮⋮</button>`;
}
function parseSortKey(value=''){return String(value||'').split('|').map(decodeURIComponent);}
function sortDropAllowed(sourceKey,targetKey){
  const s=parseSortKey(sourceKey),t=parseSortKey(targetKey);if(!s[0]||s[0]!==t[0])return false;
  if(s[0]==='suitcase')return s[1]===t[1];
  if(s[0]==='shopping-product')return s[1]===t[1];
  if(s[0]==='official')return s[1]===t[1];
  return true;
}
async function applySortDrop(sourceKey,targetKey,after=false,isContainer=false){
  if(!sortDropAllowed(sourceKey,targetKey))return false;
  const s=parseSortKey(sourceKey),t=parseSortKey(targetKey),kind=s[0];
  if(kind==='cover-doc'){
    if(!moveArrayItemTo(state.data.cover.documents,num(s[1]),num(t[1]),after))return false;await saveSection('cover');render();return true;
  }
  if(kind==='budget-group'){
    if(!moveArrayItemTo(state.data.budget.groups,num(s[1]),num(t[1]),after))return false;state.data.settings.budgetGroupOrderCustomized=true;await Promise.all([saveSection('budget'),saveSection('settings')]);render();return true;
  }
  if(kind==='suitcase'){
    const key=s[1],sg=num(s[2]),si=num(s[3]),tg=num(t[2]);if(!state.data.suitcases[key]?.[sg]||!state.data.suitcases[key]?.[tg])return false;
    const source=state.data.suitcases[key][sg].items,target=state.data.suitcases[key][tg].items;
    let targetSubgroupId='';
    if(isContainer&&String(t[3]||'').startsWith('sg='))targetSubgroupId=String(t[3]).slice(3);
    else if(!isContainer&&target[num(t[3])])targetSubgroupId=String(target[num(t[3])].subgroupId||'');
    const [item]=source.splice(si,1);if(!item)return false;item.subgroupId=targetSubgroupId;
    let ti=isContainer?target.length:num(t[3]);if(!isContainer&&sg===tg&&si<ti)ti--;if(!isContainer&&after)ti++;ti=Math.max(0,Math.min(target.length,ti));target.splice(ti,0,item);await saveSection('suitcases');render();return true;
  }
  if(kind==='shopping-product'){
    const store=num(s[1]),arr=state.data.shopping.stores?.[store]?.products;if(!arr)return false;if(!moveArrayItemTo(arr,num(s[2]),num(t[2]),after))return false;await saveSection('shopping');render();return true;
  }
  if(kind==='task'){
    if(!moveArrayItemTo(state.data.tasks.items,num(s[1]),num(t[1]),after))return false;await saveSection('tasks');render();return true;
  }
  if(kind==='official'){
    const person=s[1],arr=state.data.emergency.documents?.[person];if(!arr)return false;if(!moveArrayItemTo(arr,num(s[2]),num(t[2]),after))return false;await saveSection('emergency');render();return true;
  }
  if(kind==='pool-section'){
    const order=state.data.settings.poolPanel?.sectionOrder||[],from=order.indexOf(s[1]),to=order.indexOf(t[1]);if(from<0||to<0||!moveArrayItemTo(order,from,to,after))return false;await saveSection('settings');render();return true;
  }
  if(kind==='pool-card'){
    const detected=orderedPoolList(state.poolMeasurements?.pools||[]).map(p=>poolConfigKey(p.name)),order=[...new Set([...(state.data.settings.poolPanel?.poolOrder||[]),...detected])],from=order.indexOf(s[1]),to=order.indexOf(t[1]);if(from<0||to<0||!moveArrayItemTo(order,from,to,after))return false;state.data.settings.poolPanel.poolOrder=order;await saveSection('settings');render();return true;
  }
  if(kind==='tracker'){
    const order=state.data.trackers.order||[],from=order.indexOf(s[1]),to=order.indexOf(t[1]);if(from<0||to<0||!moveArrayItemTo(order,from,to,after))return false;await saveSection('trackers');render();return true;
  }
  if(kind==='tab'){
    const order=state.data.settings.tabOrder||[],from=order.indexOf(s[1]),to=order.indexOf(t[1]);if(from<0||to<0||!moveArrayItemTo(order,from,to,after))return false;await saveSection('settings');render();return true;
  }
  if(kind==='cover-order'){
    const order=state.data.settings.coverOrder||[],from=order.indexOf(s[1]),to=order.indexOf(t[1]);if(from<0||to<0||!moveArrayItemTo(order,from,to,after))return false;await saveSection('settings');render();return true;
  }
  if(kind==='carousel'){
    if(!moveArrayItemTo(state.data.cover.mediaCarousels,num(s[1]),num(t[1]),after))return false;state.data.settings.desktopCoverOrder=desktopCoverOrder();await Promise.all([saveSection('cover'),saveSection('settings')]);render();return true;
  }
  if(kind==='trip-transport'){
    const order=currentTripTransportOrder(),from=order.indexOf(s[1]),to=order.indexOf(t[1]);if(from<0||to<0||!moveArrayItemTo(order,from,to,after))return false;state.data.settings.tripTransportOrder=order;await saveSection('settings');render();return true;
  }
  if(kind==='store'){
    if(!moveArrayItemTo(state.data.shopping.stores,num(s[1]),num(t[1]),after))return false;await saveSection('shopping');render();return true;
  }
  if(kind==='tripdata'){
    const order=currentTripDataSectionOrder(),from=order.indexOf(s[1]),to=order.indexOf(t[1]);if(from<0||to<0||!moveArrayItemTo(order,from,to,after))return false;state.data.settings.tripDataSectionOrder=order;await saveSection('settings');render();return true;
  }
  if(kind==='cover-layout'){
    const order=desktopCoverOrder(),from=order.indexOf(s[1]),to=order.indexOf(t[1]);if(from<0||to<0||!moveArrayItemTo(order,from,to,after))return false;state.data.settings.desktopCoverOrder=order;await saveSection('settings');render();return true;
  }
  if(kind==='purchase-block'){
    const order=currentPurchasesBlockOrder(),from=order.indexOf(s[1]),to=order.indexOf(t[1]);if(from<0||to<0||!moveArrayItemTo(order,from,to,after))return false;state.data.settings.purchasesBlockOrder=order;await saveSection('settings');render();return true;
  }
  if(kind==='purchase-record'){
    if(!moveArrayItemTo(state.data.purchases.records,num(s[1]),num(t[1]),after))return false;await saveSection('purchases');render();return true;
  }
  if(kind==='purchase-extra'){
    if(!moveArrayItemTo(state.data.purchases.extras,num(s[1]),num(t[1]),after))return false;await saveSection('purchases');render();return true;
  }
  if(kind==='purchase-other'){
    if(!moveArrayItemTo(state.data.purchases.otherExpenses,num(s[1]),num(t[1]),after))return false;await saveSection('purchases');render();return true;
  }
  if(kind==='ticket-item'){
    if(!moveArrayItemTo(state.data.purchases.ticketItems,num(s[1]),num(t[1]),after))return false;saveTicketItemsViewPrefs({sort:'manual',group:'none'});await saveSection('purchases');render();return true;
  }
  return false;
}
function bindDragReorderSurface({root=document,handleSelector='[data-sort-handle]',itemSelector='[data-sort-item]',containerSelector='[data-sort-container]',keyOfHandle=el=>el.dataset.sortHandle,keyOfItem=el=>el.dataset.sortItem,keyOfContainer=el=>el.dataset.sortContainer,onDrop=applySortDrop,canDrop=sortDropAllowed}={}){
  const handles=$$(handleSelector,root),items=$$(itemSelector,root),containers=$$(containerSelector,root);if(!handles.length)return;
  let sourceKey='',sourceItem=null,targetEl=null,targetKey='',targetAfter=false,targetContainer=false,activePointer=null,dragStarted=false,startX=0,startY=0;
  const clearTarget=()=>{if(targetEl)targetEl.classList.remove('sort-target-before','sort-target-after','sort-target-container');targetEl=null;targetKey='';targetAfter=false;targetContainer=false;};
  const clearAll=()=>{clearTarget();sourceItem?.classList.remove('sort-dragging');sourceItem=null;sourceKey='';activePointer=null;dragStarted=false;document.body.classList.remove('is-free-sorting');};
  const beginDrag=()=>{if(dragStarted||!sourceKey)return;dragStarted=true;sourceItem?.classList.add('sort-dragging');document.body.classList.add('is-free-sorting');};
  const setTarget=(el,clientY)=>{if(!sourceKey||!el)return;let key='',container=false;if(el.matches(itemSelector))key=keyOfItem(el);else if(el.matches(containerSelector)){key=keyOfContainer(el);container=true;}if(!key||!canDrop(sourceKey,key)){clearTarget();return;}if(targetEl!==el)clearTarget();targetEl=el;targetKey=key;targetContainer=container;targetAfter=false;if(container){el.classList.add('sort-target-container');return;}const r=el.getBoundingClientRect();targetAfter=clientY>r.top+r.height/2;el.classList.toggle('sort-target-before',!targetAfter);el.classList.toggle('sort-target-after',targetAfter);};
  const updateTarget=(event)=>{if(!dragStarted)return;if(event.clientY<72)window.scrollBy({top:-24,behavior:'auto'});else if(event.clientY>window.innerHeight-72)window.scrollBy({top:24,behavior:'auto'});const hit=document.elementFromPoint(event.clientX,event.clientY);let el=hit;while(el&&el!==document.documentElement){if(el.matches?.(itemSelector)){const key=keyOfItem(el);if(key&&canDrop(sourceKey,key))break;}if(el.matches?.(containerSelector)){const key=keyOfContainer(el);if(key&&canDrop(sourceKey,key))break;}el=el.parentElement;}if(el&&el!==document.documentElement)setTarget(el,event.clientY);else clearTarget();};
  const commit=async()=>{if(!dragStarted||!sourceKey||!targetKey){clearAll();return;}const s=sourceKey,t=targetKey,a=targetAfter,c=targetContainer;clearAll();await onDrop(s,t,a,c);};
  handles.forEach(handle=>{
    const item=handle.closest(itemSelector);
    handle.removeAttribute('draggable');
    handle.addEventListener('pointerdown',event=>{
      if(event.button!==undefined&&event.button!==0)return;
      sourceKey=keyOfHandle(handle)||'';sourceItem=item;activePointer=event.pointerId;startX=event.clientX;startY=event.clientY;dragStarted=false;
      handle.setPointerCapture?.(event.pointerId);event.preventDefault();event.stopPropagation();
    });
    handle.addEventListener('pointermove',event=>{
      if(activePointer!==event.pointerId||!sourceKey)return;
      if(!dragStarted&&Math.hypot(event.clientX-startX,event.clientY-startY)>=3)beginDrag();
      if(dragStarted)updateTarget(event);
      event.preventDefault();event.stopPropagation();
    });
    handle.addEventListener('pointerup',event=>{if(activePointer!==event.pointerId)return;commit();event.preventDefault();event.stopPropagation();});
    handle.addEventListener('pointercancel',clearAll);
    handle.addEventListener('lostpointercapture',()=>{if(activePointer!==null)clearAll();});
  });
}
function bindFreeSortInteractions(){bindDragReorderSurface();}
function tripTransportRefs(){return [...(state.data.cover.buses||[]).map(bus=>`bus:${bus.id}`),...(state.data.cover.flights||[]).map((flight,i)=>`flight:${flight.id||`flight-${i+1}`}`),'lodging'];}
function currentTripTransportOrder(){const refs=tripTransportRefs(),saved=Array.isArray(state.data.settings.tripTransportOrder)?state.data.settings.tripTransportOrder:[];return [...saved.filter(ref=>refs.includes(ref)),...refs.filter(ref=>!saved.includes(ref))];}
function currentTripDataSectionOrder(){const defaults=['travel','rental','stores'],saved=Array.isArray(state.data.settings.tripDataSectionOrder)?state.data.settings.tripDataSectionOrder:[];return [...saved.filter(id=>defaults.includes(id)),...defaults.filter(id=>!saved.includes(id))];}
function visibleFiles(value=[]){return normalizeFileList(value).filter(file=>file.hidden!==true);}
function renderFileButton(file,title="Archivo"){
  if(file?.hidden===true)return "";
  if(!isValidUrl(file?.url))return "";
  const label=file.label||"Ver archivo",type=file.type||"auto";
  if(type==="image")return `<button class="link-btn" data-image-popup="${esc(file.url)}" data-image-title="${esc(title)}">🖼️ ${esc(label)}</button>`;
  if(type==="web")return safeLink(file.url,label,"🌐");
  return popupFileLink(file.url,label,"📄");
}
function enhanceResponsiveTables(){
  $$('table').forEach(table=>{const heads=$$('thead th',table).map(th=>th.textContent.trim());$$('tbody tr',table).forEach(row=>$$('td',row).forEach((td,i)=>{if(!td.dataset.label)td.dataset.label=heads[i]||"";}));});
}
function workerImageProxyUrl(url){
  const worker=String(state.data.settings.priceWorkerUrl||DEFAULT_PRICE_WORKER_URL).trim();
  if(!isValidUrl(worker)||!isValidUrl(url))return "";
  const proxy=new URL(worker);proxy.searchParams.set("action","image");proxy.searchParams.set("url",url);return proxy.href;
}
function appendCacheBust(url){
  if(!isValidUrl(url))return url||"";
  try{const parsed=new URL(url);parsed.searchParams.set("mfev",String(Date.now()));return parsed.href;}catch{return url;}
}
function officialFileDriveId(file={}){
  return file.driveFileId||driveFileIdFromUrl(file.driveUrl||file.url||'')||((file.source==='drive'&&file.id)?file.id:'');
}
function officialImageSource(file={}){
  return officialFileDriveId(file)?TRANSPARENT_IMAGE:String(file.url||'');
}
function officialFileOpenUrl(file={}){
  return officialFileDriveId(file)?driveFileViewUrl(file):String(file.url||file.driveUrl||'');
}
function findOfficialDocument(person,docId){
  return (state.data.emergency?.documents?.[person]||[]).find(doc=>String(doc.id)===String(docId));
}
function findOfficialFile(person,docId,fileId){
  const doc=findOfficialDocument(person,docId);return {doc,file:(doc?.files||[]).find(item=>String(item.id)===String(fileId))};
}
async function repairOfficialImage(person,docId,fileId,{interactive=false,img=null}={}){
  const {file}=findOfficialFile(person,docId,fileId);
  if(!file)throw new Error('No se ha encontrado la imagen en esta ficha.');
  let repaired='';
  if(officialFileDriveId(file))repaired=await fetchDriveMediaObjectUrl(file,interactive,true);
  else if(isValidUrl(file.url))repaired=appendCacheBust(file.url);
  if(!repaired)throw new Error('No se ha podido abrir la imagen. Vuelve a seleccionarla desde Google Drive.');
  if(img){const frame=img.closest('.official-image-frame');img.dataset.repairTried='1';img.src=repaired;img.dataset.imagePopup=repaired;frame?.classList.remove('has-error','is-loading');}
  else render();
  return repaired;
}
async function hydrateOfficialImage(img){
  if(!img?.dataset?.officialImage||img.dataset.officialHydrated)return;
  img.dataset.officialHydrated='1';
  const {file}=findOfficialFile(img.dataset.officialPerson,img.dataset.officialDocId,img.dataset.officialFileId);
  if(!file)return;
  const frame=img.closest('.official-image-frame');frame?.classList.add('is-loading');
  try{
    const resolved=officialFileDriveId(file)?await fetchDriveMediaObjectUrl(file,false,false):officialImageSource(file);
    if(!resolved)throw new Error('El archivo no tiene una URL válida.');
    img.src=resolved;img.dataset.imagePopup=resolved;frame?.classList.remove('has-error','is-loading');
  }catch(error){console.warn('No se pudo preparar la imagen oficial desde Google Drive',error);frame?.classList.remove('is-loading');frame?.classList.add('has-error');}
}
function bindOfficialImageRecovery(img){
  if(!img.dataset.officialImage||img.dataset.officialRecoveryBound)return;
  img.dataset.officialRecoveryBound='1';
  img.addEventListener('error',()=>{const frame=img.closest('.official-image-frame');frame?.classList.remove('is-loading');frame?.classList.add('has-error');});
  img.addEventListener('load',()=>{if(img.src!==TRANSPARENT_IMAGE){img.closest('.official-image-frame')?.classList.remove('has-error','is-loading');const card=img.closest('.official-card');const key=card?.dataset.officialViewKey;if(card&&key){const saved=officialDocumentZoom(key);if(saved===null)fitOfficialCardImage(card,key);else applyOfficialCardZoom(card,key,saved,{remember:false});}}});
  hydrateOfficialImage(img);
}

async function hydrateResilientIcon(img){
  if(!img?.dataset?.resilientIcon||img.dataset.resilientBound)return;
  img.dataset.resilientBound='1';
  const shell=img.closest('[data-resilient-icon-shell]');
  const fail=()=>{shell?.classList.add('is-fallback');img.style.visibility='hidden';};
  const show=()=>{shell?.classList.remove('is-fallback');img.style.visibility='visible';};
  img.addEventListener('error',fail);
  img.addEventListener('load',()=>{if(img.src!==TRANSPARENT_IMAGE)show();});
  const driveId=String(img.dataset.driveBackedImageId||'').trim();
  if(!driveId)return;
  shell?.classList.add('is-fallback');
  try{
    const resolved=await fetchDriveMediaObjectUrl({driveFileId:driveId},false,false);
    img.src=resolved;if(img.dataset.resilientNoPopup!=='1')img.dataset.imagePopup=resolved;show();
  }catch(error){console.warn('No se pudo cargar un icono desde Google Drive',error);fail();}
}
function bindImageResilience(){
  $$('img').forEach(img=>{
    bindOfficialImageRecovery(img);
    bindCoverCarouselImage(img);
    if(img.dataset.resilientIcon){hydrateResilientIcon(img);return;}
    if(img.dataset.imageBound)return;img.dataset.imageBound='1';
    img.addEventListener('error',async()=>{
      if(img.dataset.officialImage||img.dataset.coverCarouselImage){img.alt='Imagen temporalmente no disponible';return;}
      img.classList.add('image-load-error');img.alt='Imagen temporalmente no disponible';
      if(!img.dataset.productImage)return;
      const[sIndex,pIndex]=img.dataset.productImage.split(':').map(num);
      const store=state.data.shopping.stores[sIndex],product=store?.products?.[pIndex];
      if(!product)return;
      const imageMode=normalizeProductImageFields(product).imageSource;
      if(!img.dataset.proxyTried&&isValidUrl(product.imageUrl)){
        const proxy=workerImageProxyUrl(product.imageUrl);
        if(proxy){img.dataset.proxyTried='1';img.src=proxy;img.dataset.imagePopup=proxy;return;}
      }
      if(imageMode==='manual'&&!img.dataset.autoFallbackTried&&isValidUrl(product.url)){
        const automatic=workerProductImageUrl(product.url,product.imageUpdatedAt||'',product.name||'');
        if(automatic){img.dataset.autoFallbackTried='1';img.src=automatic;img.dataset.imagePopup=automatic;return;}
      }
      if(!img.dataset.retryDone&&product.url){
        img.dataset.retryDone='1';
        try{
          const updated=await fetchProductUpdate(store,product);
          store.products[pIndex]=updated;await saveSection('shopping');
          const next=productImageDisplayUrl(updated);
          if(next){img.src=next;img.dataset.imagePopup=next;img.classList.remove('image-load-error');return;}
        }catch{}
      }
      img.style.display='none';
    });
    img.addEventListener('load',()=>{img.style.display='';img.classList.remove('image-load-error');if(img.dataset.productImage)img.dataset.imagePopup=img.currentSrc||img.src;if(img.dataset.officialImage)img.alt=img.dataset.originalAlt||img.alt;});
  });
}
function imagePreviewBox(url,label="Vista previa"){return isImageSource(url)?`<img class="url-preview" src="${esc(url)}" alt="${esc(label)}">`:`<div class="image-placeholder">Sin imagen</div>`;}

const DRIVE_FILE_SCOPE="https://www.googleapis.com/auth/drive.file";
const DRIVE_READONLY_SCOPE="https://www.googleapis.com/auth/drive.readonly";
const DRIVE_BROWSER_SCOPES=`${DRIVE_FILE_SCOPE} ${DRIVE_READONLY_SCOPE}`;

async function loadGooglePicker(){
  const s=state.data.settings;if(!s.googleDriveApiKey||!s.googleDriveClientId||!s.googleDriveAppId)throw new Error('Configura la API key, Client ID y número de proyecto de Google Drive Picker.');
  if(!window.google?.accounts){await new Promise((resolve,reject)=>{const sc=document.createElement('script');sc.src='https://accounts.google.com/gsi/client';sc.onload=resolve;sc.onerror=()=>reject(new Error('No se pudo cargar Google Identity Services.'));document.head.append(sc);});}
  if(!window.gapi){await new Promise((resolve,reject)=>{const sc=document.createElement('script');sc.src='https://apis.google.com/js/api.js';sc.onload=resolve;sc.onerror=()=>reject(new Error('No se pudo cargar Google Picker.'));document.head.append(sc);});}
  await new Promise(resolve=>gapi.load('picker',resolve));
}
function clearDriveAccessToken(){
  state.driveAccessToken="";state.driveAccessTokenExpiresAt=0;
  try{sessionStorage.removeItem(DRIVE_SESSION_TOKEN_KEY);}catch{}
}
function restoreDriveAccessToken(){
  if(state.driveAccessToken&&Date.now()<state.driveAccessTokenExpiresAt-60000)return state.driveAccessToken;
  try{
    const saved=JSON.parse(sessionStorage.getItem(DRIVE_SESSION_TOKEN_KEY)||"null");
    const token=String(saved?.token||"");const expiresAt=Number(saved?.expiresAt||0);
    if(token&&expiresAt>Date.now()+60000){state.driveAccessToken=token;state.driveAccessTokenExpiresAt=expiresAt;return token;}
    sessionStorage.removeItem(DRIVE_SESSION_TOKEN_KEY);
  }catch{}
  return "";
}
function cacheDriveAccessToken(token="",expiresIn=3300){
  state.driveAccessToken=String(token||"");
  state.driveAccessTokenExpiresAt=Date.now()+(Math.max(300,num(expiresIn)||3300)*1000);
  if(state.driveAccessToken){
    try{sessionStorage.setItem(DRIVE_SESSION_TOKEN_KEY,JSON.stringify({token:state.driveAccessToken,expiresAt:state.driveAccessTokenExpiresAt}));}catch{}
    setTimeout(()=>stabilizeLegacyBusDriveVisuals(state.driveAccessToken).catch(error=>console.warn('No se pudieron estabilizar los iconos del autobús',error)),0);
  }
  return state.driveAccessToken;
}
const DRIVE_AUTH_WORKER_TIMEOUT_MS=12000;
async function callDriveAuthWorker(payload,{retries=2}={}){
  let lastError=null;
  for(let attempt=0;attempt<Math.max(1,retries);attempt++){
    try{return await callIntegrationWorker(payload,{timeoutMs:DRIVE_AUTH_WORKER_TIMEOUT_MS});}
    catch(error){lastError=error;if(attempt+1<retries)await new Promise(resolve=>setTimeout(resolve,450));}
  }
  throw lastError||new Error('No se pudo contactar con el servicio persistente de Google Drive.');
}
function drivePersistentConnected(status=state.drivePersistentStatus){return Boolean(status?.persistentConnected||(status?.configured&&status?.connected&&!status?.temporary));}
function driveTemporaryConnected(status=state.drivePersistentStatus){return Boolean(status?.temporary||(!drivePersistentConnected(status)&&restoreDriveAccessToken()));}
function driveConnectionLabel(status=state.drivePersistentStatus){
  if(drivePersistentConnected(status))return `Persistente${status?.email?` · ${status.email}`:""}`;
  if(driveTemporaryConnected(status))return `Temporal${status?.email?` · ${status.email}`:""}`;
  if(status?.configured)return "Listo para conexión persistente";
  return "Persistencia pendiente · Drive disponible al autorizar";
}
async function refreshDrivePersistentStatus({silent=true,force=false}={}){
  if(!force&&state.drivePersistentStatus?.checked&&drivePersistentStatusCheckedAt&&Date.now()-drivePersistentStatusCheckedAt<DRIVE_PERSISTENT_STATUS_CACHE_MS){
    return state.drivePersistentStatus;
  }
  const previous={...(state.drivePersistentStatus||{})};
  try{
    const data=await callDriveAuthWorker({action:"drive-auth-status"},{retries:2});
    const temporary=Boolean(restoreDriveAccessToken());
    state.drivePersistentStatus={checked:true,connected:Boolean(data.connected||temporary),persistentConnected:Boolean(data.connected),configured:Boolean(data.configured),temporary:temporary&&!data.connected,email:String(data.email||previous.email||""),name:String(data.name||previous.name||""),lastMessage:data.connected?"Google Drive conectado de forma persistente.":temporary?"Google Drive conectado con sesión temporal del navegador.":(data.configured?"Drive preparado para activar la conexión persistente.":"La sesión permanente de Drive necesita volver a autorizarse.")};
    drivePersistentStatusCheckedAt=Date.now();
    return state.drivePersistentStatus;
  }catch(error){
    const temporary=Boolean(restoreDriveAccessToken());
    // Un timeout del Worker no debe borrar un estado persistente que ya conocíamos.
    state.drivePersistentStatus={...previous,checked:true,connected:Boolean(previous.connected||temporary),persistentConnected:Boolean(previous.persistentConnected),configured:previous.configured??null,temporary:previous.persistentConnected?false:temporary,email:String(previous.email||""),name:String(previous.name||""),lastMessage:error.message||previous.lastMessage||"No se pudo comprobar Drive."};
    drivePersistentStatusCheckedAt=Date.now();
    if(!silent)toast(`Google Drive: ${state.drivePersistentStatus.lastMessage}`,"error");
    return state.drivePersistentStatus;
  }
}
async function persistentDriveAccessToken(){
  const data=await callDriveAuthWorker({action:"drive-auth-token"},{retries:2});
  if(!data?.accessToken)throw new Error(data?.error||"Google Drive no está conectado de forma persistente.");
  state.drivePersistentStatus={checked:true,connected:true,persistentConnected:true,configured:true,temporary:false,email:String(data.email||state.drivePersistentStatus.email||""),name:String(data.name||state.drivePersistentStatus.name||""),lastMessage:"Google Drive conectado de forma persistente."};
  return cacheDriveAccessToken(data.accessToken,data.expiresIn||3300);
}
async function connectPersistentDrive({browserAccess=true,selectAccount=false}={}){
  await loadGooglePicker();
  const settings=state.data.settings;
  const status=await refreshDrivePersistentStatus({silent:true,force:true});
  // La sesión persistente es preferida, pero Drive no debe quedar inutilizable si
  // Cloudflare pierde temporalmente el Client Secret. En ese caso usamos OAuth
  // directo del navegador y conservamos el token en memoria para esta sesión.
  if(status.configured===false){
    const token=await legacyDriveAccessToken(selectAccount?'select_account':'consent',{browserAccess,selectAccount});
    state.drivePersistentStatus={checked:true,connected:true,persistentConnected:false,configured:false,temporary:true,email:String(state.drivePersistentStatus?.email||''),name:String(state.drivePersistentStatus?.name||''),lastMessage:'Google Drive conectado con sesión temporal del navegador.'};
    return token;
  }
  const requestedScopes=browserAccess?DRIVE_BROWSER_SCOPES:DRIVE_FILE_SCOPE;
  return new Promise((resolve,reject)=>{
    const client=google.accounts.oauth2.initCodeClient({
      client_id:settings.googleDriveClientId,
      scope:requestedScopes,
      include_granted_scopes:true,
      ux_mode:"popup",
      select_account:Boolean(selectAccount),
      callback:async response=>{
        if(response?.error){reject(new Error(response.error_description||response.error));return;}
        try{
          const data=await callDriveAuthWorker({action:"drive-auth-exchange",code:String(response?.code||""),clientId:settings.googleDriveClientId,redirectUri:location.origin},{retries:1});
          state.drivePersistentStatus={checked:true,connected:true,persistentConnected:true,configured:true,temporary:false,email:String(data.email||""),name:String(data.name||""),lastMessage:"Google Drive conectado de forma persistente."};
          resolve(cacheDriveAccessToken(data.accessToken,data.expiresIn||3300));
        }catch(error){
          // Si el Worker cambia entre la comprobación y el intercambio (por ejemplo,
          // secret ausente), degradamos a token directo en lugar de bloquear Drive.
          try{
            const token=await legacyDriveAccessToken(selectAccount?'select_account':'consent',{browserAccess,selectAccount});
            state.drivePersistentStatus={checked:true,connected:true,persistentConnected:false,configured:false,temporary:true,email:'',name:'',lastMessage:'Google Drive conectado con sesión temporal del navegador.'};
            resolve(token);
          }catch{reject(error);}
        }
      },
      error_callback:error=>reject(new Error(error?.message||error?.type||"No se pudo abrir la autorización de Google Drive."))
    });
    client.requestCode();
  });
}
async function disconnectPersistentDrive(){
  await callDriveAuthWorker({action:"drive-auth-disconnect"},{retries:1});
  clearDriveAccessToken();
  state.drivePersistentStatus={checked:true,connected:false,persistentConnected:false,configured:true,temporary:false,email:"",name:"",lastMessage:"Google Drive desconectado."};
}
async function legacyDriveAccessToken(prompt='',{browserAccess=false,selectAccount=false}={}){
  await loadGooglePicker();const settings=state.data.settings;
  return new Promise((resolve,reject)=>{
    const client=google.accounts.oauth2.initTokenClient({
      client_id:settings.googleDriveClientId,
      scope:browserAccess?DRIVE_BROWSER_SCOPES:DRIVE_FILE_SCOPE,
      include_granted_scopes:true,
      callback:response=>{
        if(response.error){reject(new Error(response.error_description||response.error));return;}
        resolve(cacheDriveAccessToken(response.access_token||'',response.expires_in||3300));
      }
    });
    client.requestAccessToken({prompt:selectAccount?'select_account':prompt});
  });
}
async function getGoogleDriveAccessToken(prompt='',options={}){
  const interactive=options.interactive!==false;
  const browserAccess=Boolean(options.browserAccess);
  const restoredToken=!prompt?restoreDriveAccessToken():"";
  // Rendimiento: mientras el token actual siga vigente, úsalo directamente. Antes se
  // consultaba Cloudflare en CADA lectura de carpeta/archivo, aunque el navegador ya
  // tuviera un token válido, y eso añadía varios segundos a Drive y a la app.
  if(restoredToken)return restoredToken;
  if(!(state.provider instanceof LocalProvider)){
    try{return await persistentDriveAccessToken();}
    catch(persistentError){
      if(!interactive)throw persistentError;
      const status=await refreshDrivePersistentStatus({silent:true});
      try{return await connectPersistentDrive({browserAccess,selectAccount:Boolean(options.selectAccount)});}
      catch(error){
        if(status.configured===false||status.configured==null)return legacyDriveAccessToken(prompt||'consent',{browserAccess,selectAccount:Boolean(options.selectAccount)});
        throw error;
      }
    }
  }
  if(!interactive)throw new Error("Google Drive necesita autorización.");
  return legacyDriveAccessToken(prompt||'consent',{browserAccess,selectAccount:Boolean(options.selectAccount)});
}
async function authorizedDriveFetch(url,options={}){
  let token=await getGoogleDriveAccessToken('',{interactive:true});
  const request=accessToken=>fetch(url,{...options,headers:{...(options.headers||{}),Authorization:`Bearer ${accessToken}`}});
  let response=await request(token);
  if(response.status===401&&!(state.provider instanceof LocalProvider)){
    clearDriveAccessToken();
    try{token=await persistentDriveAccessToken();response=await request(token);}catch{}
  }
  return response;
}
const DRIVE_UPLOAD_FOLDER_KEY=`mfe-viajes-drive-upload-folder:${TRIP_ID}`;
function getRememberedDriveUploadFolder(){
  try{const saved=JSON.parse(localStorage.getItem(DRIVE_UPLOAD_FOLDER_KEY)||'null');if(saved?.id&&saved?.name)return saved;}catch{}
  return {id:'root',name:'Mi unidad'};
}
function rememberDriveUploadFolder(folder){
  if(!folder?.id||!folder?.name)return;
  try{localStorage.setItem(DRIVE_UPLOAD_FOLDER_KEY,JSON.stringify({id:folder.id,name:folder.name}));}catch{}
}
async function selectDriveFolder(){
  return selectFromDriveTouch({folderPicker:true,title:'Elegir carpeta de destino en Google Drive'});
}
async function uploadBlobToDrive(blob,{name='',parentId='root',originalName='',errorLabel='archivo'}={}){
  if(!blob)throw new Error('No hay ningún archivo preparado para subir a Google Drive.');
  const mimeType=blob.type||'application/octet-stream';
  const metadata=buildDriveUploadMetadata({originalName:originalName||blob.name||name||'archivo',requestedName:name,mimeType,parentId});
  const fields='id,name,mimeType,webViewLink,parents,size,createdTime,modifiedTime';
  let response;
  // Multipart es ideal para archivos pequeños. Para snapshots grandes usamos una
  // sesión resumible de Drive, de modo que el Histórico no vuelva a depender de
  // límites cercanos a unos pocos MB.
  if(num(blob.size)>4*1024*1024){
    const init=await authorizedDriveFetch(`https://www.googleapis.com/upload/drive/v3/files?uploadType=resumable&supportsAllDrives=true&fields=${fields}`,{method:'POST',headers:{'Content-Type':'application/json; charset=UTF-8','X-Upload-Content-Type':mimeType,'X-Upload-Content-Length':String(blob.size)},body:JSON.stringify(metadata)});
    if(!init.ok){let detail='';try{detail=(await init.json())?.error?.message||'';}catch{}throw new Error(`Google Drive no ha podido preparar el ${errorLabel} (HTTP ${init.status})${detail?`: ${detail}`:''}.`);}
    const sessionUrl=init.headers.get('Location');if(!sessionUrl)throw new Error('Google Drive no devolvió la sesión de subida del archivo histórico.');
    response=await authorizedDriveFetch(sessionUrl,{method:'PUT',headers:{'Content-Type':mimeType},body:blob});
  }else{
    const boundary=`mfe-viajes-${Date.now()}-${Math.random().toString(36).slice(2)}`;
    const body=new Blob([
      `--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n`,
      JSON.stringify(metadata),
      `\r\n--${boundary}\r\nContent-Type: ${mimeType}\r\n\r\n`,
      blob,
      `\r\n--${boundary}--`
    ],{type:`multipart/related; boundary=${boundary}`});
    response=await authorizedDriveFetch(`https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&supportsAllDrives=true&fields=${fields}`,{method:'POST',headers:{'Content-Type':`multipart/related; boundary=${boundary}`},body});
  }
  if(!response.ok){let detail='';try{detail=(await response.json())?.error?.message||'';}catch{}throw new Error(`Google Drive no ha podido guardar el ${errorLabel} (HTTP ${response.status})${detail?`: ${detail}`:''}.`);}
  const saved=await response.json();
  if(!saved.id)throw new Error('Google Drive no devolvió el identificador del archivo subido.');
  const driveUrl=saved.webViewLink||`https://drive.google.com/file/d/${encodeURIComponent(saved.id)}/view`;
  return {id:saved.id,driveFileId:saved.id,label:saved.name||metadata.name,url:driveUrl,driveUrl,mimeType:saved.mimeType||mimeType,parentId:(saved.parents||[])[0]||parentId,size:num(saved.size)||num(blob.size),createdTime:saved.createdTime||'',modifiedTime:saved.modifiedTime||'',type:String(saved.mimeType||mimeType).startsWith('image/')?'image':'file',source:'drive'};
}
async function uploadTicketFileToDrive(file,{name='',parentId='root'}={}){
  if(!file)throw new Error('Selecciona un archivo para subirlo a Google Drive.');
  return uploadBlobToDrive(file,{name,parentId,originalName:file.name,errorLabel:'ticket'});
}
async function deleteDriveFileById(fileId=''){
  const id=String(fileId||'').trim();if(!id)return false;
  const response=await authorizedDriveFetch(`https://www.googleapis.com/drive/v3/files/${encodeURIComponent(id)}?supportsAllDrives=true`,{method:'DELETE'});
  return response.ok||response.status===404;
}
function drivePickerDocuments(data={}){
  const responseKey=window.google?.picker?.Response?.DOCUMENTS;
  const raw=(responseKey&&data?.[responseKey])||data?.docs||[];
  return Array.isArray(raw)?raw:[];
}
function normalizeDrivePickerSelection(data,token='',includeToken=false){
  const seen=new Set(),items=[];
  for(const d of drivePickerDocuments(data)){
    const id=String(d?.id||'').trim();
    const mimeType=String(d?.mimeType||'');
    if(!id||mimeType==='application/vnd.google-apps.folder'||seen.has(id))continue;
    seen.add(id);
    items.push({
      id,driveFileId:id,label:d?.name||'Archivo de Drive',
      url:mimeType.startsWith('image/')?`https://drive.google.com/thumbnail?id=${encodeURIComponent(id)}&sz=w2000`:`https://drive.google.com/file/d/${id}/view`,
      driveUrl:`https://drive.google.com/file/d/${id}/view`,
      type:mimeType.startsWith('image/')?'image':'file',mimeType,source:'drive',
      ...(includeToken?{accessToken:token}:{})
    });
  }
  return items;
}
function driveApiErrorText(data,status=0){
  const message=String(data?.error?.message||data?.error_description||data?.error||'').trim();
  return message||`Google Drive respondió HTTP ${status}.`;
}
function driveScopeInsufficient(data,status=0){
  const text=JSON.stringify(data||{});
  return status===403&&/insufficientPermissions|insufficient authentication scopes|ACCESS_TOKEN_SCOPE_INSUFFICIENT|insufficient_scope/i.test(text);
}
async function driveBrowserFetch(url,options={}){
  const request=async token=>{
    const controller=new AbortController();
    const timer=setTimeout(()=>controller.abort(),15000);
    try{return await fetch(url,{...options,headers:{...(options.headers||{}),Authorization:`Bearer ${token}`},signal:controller.signal});}
    catch(error){if(error?.name==='AbortError')throw new Error('Google Drive ha tardado demasiado en responder. Pulsa «Actualizar» o «Cambiar cuenta / acceso».');throw error;}
    finally{clearTimeout(timer);}
  };
  // La carga automática del navegador NO debe abrir popups. Usa únicamente un token
  // ya disponible (caché o sesión persistente). Si no existe, el propio selector
  // mostrará el botón explícito «Cambiar cuenta / acceso».
  let token;
  try{token=await getGoogleDriveAccessToken('',{interactive:false,browserAccess:true});}
  catch{throw new Error('Google Drive necesita autorización. Pulsa «Cambiar cuenta / acceso» para continuar.');}
  let response=await request(token);
  if(response.status===401){
    clearDriveAccessToken();
    throw new Error('La sesión de Google Drive ha caducado. Pulsa «Cambiar cuenta / acceso» para renovarla.');
  }
  if(response.status===403){
    let detail=null;try{detail=await response.clone().json();}catch{}
    if(driveScopeInsufficient(detail,response.status)){
      throw new Error('Google Drive necesita renovar el permiso para navegar por carpetas. Pulsa «Cambiar cuenta / acceso» y autoriza Drive de nuevo.');
    }
  }
  return response;
}
function driveAllowedMime(mimeType='',mimeTypes=''){
  const type=String(mimeType||'').toLowerCase();
  if(type==='application/vnd.google-apps.folder')return true;
  const allowed=String(mimeTypes||'').split(',').map(x=>x.trim().toLowerCase()).filter(Boolean);
  if(!allowed.length)return true;
  return allowed.some(rule=>rule.endsWith('/*')?type.startsWith(rule.slice(0,-1)):type===rule);
}
function driveQueryEscape(value=''){return String(value).replace(/\\/g,'\\\\').replace(/'/g,"\\'");}
function driveFileDisplayType(mimeType=''){
  const type=String(mimeType||'').toLowerCase();
  if(type==='application/vnd.google-apps.folder')return 'Carpeta';
  if(type==='application/pdf')return 'PDF';
  if(type.startsWith('image/'))return 'Imagen';
  return 'Archivo';
}
function driveFileIcon(mimeType=''){
  const type=String(mimeType||'').toLowerCase();
  if(type==='application/vnd.google-apps.folder')return '📁';
  if(type==='application/pdf')return pdfFileIconMarkup('drive-browser-pdf-icon');
  if(type.startsWith('image/'))return '🖼️';
  return '📎';
}
function formatDriveSize(value){
  const bytes=Number(value)||0;if(!bytes)return '';
  if(bytes<1024)return `${bytes} B`;
  if(bytes<1048576)return `${(bytes/1024).toFixed(bytes<10240?1:0)} KB`;
  return `${(bytes/1048576).toFixed(bytes<10485760?1:0)} MB`;
}
const DRIVE_BROWSER_LOCATION_PREFIX=`mfe-viajes-drive-browser-location:${TRIP_ID}:`;
const DRIVE_BROWSER_SORT_KEY=`mfe-viajes-drive-browser-sort:${TRIP_ID}`;
function driveBrowserAccountKey(){
  return String(state.drivePersistentStatus?.email||state.drivePersistentStatus?.name||'default').trim().toLowerCase()||'default';
}
function driveBrowserLocationKey(source='my'){
  return `${DRIVE_BROWSER_LOCATION_PREFIX}${encodeURIComponent(driveBrowserAccountKey())}:${source==='shared'?'shared':'my'}`;
}
function readDriveBrowserLocation(source='my'){
  try{
    const saved=JSON.parse(localStorage.getItem(driveBrowserLocationKey(source))||'null');
    if(!saved||saved.sourceMode!==source)return null;
    if(source==='my'&&(!saved.folderId||!Array.isArray(saved.path)||!saved.path.length))return null;
    if(source==='shared'&&!saved.showingDriveList&&(!saved.folderId||!saved.sharedDriveId||!Array.isArray(saved.path)||!saved.path.length))return null;
    return saved;
  }catch{return null;}
}
function rememberDriveBrowserLocation({sourceMode='my',folderId='',sharedDriveId='',path=[],showingDriveList=false}={}){
  try{
    const safePath=Array.isArray(path)?path.filter(x=>x?.id&&x?.name).map(x=>({id:String(x.id),name:String(x.name)})):[];
    localStorage.setItem(driveBrowserLocationKey(sourceMode),JSON.stringify({sourceMode,folderId:String(folderId||''),sharedDriveId:String(sharedDriveId||''),path:safePath,showingDriveList:Boolean(showingDriveList)}));
  }catch{}
}
function getDriveBrowserSort(){
  try{
    const value=localStorage.getItem(DRIVE_BROWSER_SORT_KEY)||'name-asc';
    return ['name-asc','name-desc','date-desc','date-asc'].includes(value)?value:'name-asc';
  }catch{return 'name-asc';}
}
function rememberDriveBrowserSort(value){
  if(!['name-asc','name-desc','date-desc','date-asc'].includes(value))return;
  try{localStorage.setItem(DRIVE_BROWSER_SORT_KEY,value);}catch{}
}
function driveBrowserOrderBy(sort='name-asc'){
  if(sort==='name-desc')return 'name_natural desc';
  if(sort==='date-desc')return 'modifiedTime desc';
  if(sort==='date-asc')return 'modifiedTime';
  return 'name_natural';
}
function driveBrowserSortItems(files=[],sort='name-asc'){
  const compareName=(a,b)=>String(a?.name||'').localeCompare(String(b?.name||''),'es',{numeric:true,sensitivity:'base'});
  const compareDate=(a,b)=>{
    const av=Date.parse(a?.modifiedTime||0)||0,bv=Date.parse(b?.modifiedTime||0)||0;
    return av-bv||compareName(a,b);
  };
  const dir=sort==='name-desc'||sort==='date-desc'?-1:1;
  const dateSort=sort.startsWith('date-');
  return [...files].sort((a,b)=>{
    const af=a?.mimeType==='application/vnd.google-apps.folder'||a?._sharedDriveRoot;
    const bf=b?.mimeType==='application/vnd.google-apps.folder'||b?._sharedDriveRoot;
    if(af!==bf)return af?-1:1;
    return (dateSort?compareDate(a,b):compareName(a,b))*dir;
  });
}
function formatDriveModified(value=''){
  const date=new Date(value);if(Number.isNaN(date.getTime()))return '';
  try{return new Intl.DateTimeFormat('es-ES',{day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'}).format(date).replace(',', ' ·');}
  catch{return date.toLocaleString();}
}
async function driveListFolder({folderId='root',sharedDriveId='',pageToken='',search='',sort='name-asc'}={}){
  // Drive pagina los resultados. Antes el selector enseñaba solo 100 elementos y
  // obligaba a pulsar «Cargar más», por lo que archivos recientes podían quedar
  // escondidos en páginas posteriores según el orden elegido. Pedimos el máximo
  // práctico por página y seguimos automáticamente hasta completar la carpeta.
  const allFiles=[];
  let token=String(pageToken||''),pages=0;
  do{
    const params=new URLSearchParams({pageSize:'1000',spaces:'drive',fields:'nextPageToken,files(id,name,mimeType,modifiedTime,size,thumbnailLink,iconLink,webViewLink,parents,driveId)',orderBy:driveBrowserOrderBy(sort),includeItemsFromAllDrives:'true',supportsAllDrives:'true'});
    const terms=[`'${driveQueryEscape(folderId)}' in parents`,'trashed = false'];
    if(String(search||'').trim())terms.push(`name contains '${driveQueryEscape(String(search).trim())}'`);
    params.set('q',terms.join(' and '));
    if(token)params.set('pageToken',token);
    if(sharedDriveId){params.set('corpora','drive');params.set('driveId',sharedDriveId);}
    else params.set('corpora','user');
    const response=await driveBrowserFetch(`https://www.googleapis.com/drive/v3/files?${params}`);
    let data=null;try{data=await response.json();}catch{}
    if(!response.ok)throw new Error(driveApiErrorText(data,response.status));
    if(Array.isArray(data?.files))allFiles.push(...data.files);
    token=String(data?.nextPageToken||'');
    pages+=1;
    // Salvaguarda extrema: 20.000 elementos por apertura es más que suficiente
    // para uso normal. Si existieran más, se mantiene el token y aparece Cargar más.
  }while(token&&pages<20);
  return {files:allFiles,nextPageToken:token};
}
async function driveListSharedDrives(pageToken=''){
  const params=new URLSearchParams({pageSize:'100',fields:'nextPageToken,drives(id,name)'});if(pageToken)params.set('pageToken',pageToken);
  const response=await driveBrowserFetch(`https://www.googleapis.com/drive/v3/drives?${params}`);
  let data=null;try{data=await response.json();}catch{}
  if(!response.ok)throw new Error(driveApiErrorText(data,response.status));
  return {drives:Array.isArray(data?.drives)?data.drives:[],nextPageToken:String(data?.nextPageToken||'')};
}
function driveSelectionObject(file,token='',includeToken=false){
  const id=String(file?.id||'').trim(),mimeType=String(file?.mimeType||'');
  return {id,driveFileId:id,label:String(file?.name||'Archivo de Drive'),url:mimeType.startsWith('image/')?`https://drive.google.com/thumbnail?id=${encodeURIComponent(id)}&sz=w2000`:`https://drive.google.com/file/d/${id}/view`,driveUrl:`https://drive.google.com/file/d/${id}/view`,type:mimeType.startsWith('image/')?'image':'file',mimeType,source:'drive',...(includeToken?{accessToken:token}:{})};
}
function requestDriveBrowserAccountTokenFromClick(){
  // IMPORTANTE: esta función debe ejecutarse directamente dentro del handler de click.
  // No hace ningún await antes de requestAccessToken(), para que Firefox/Chrome no
  // consideren el selector de cuentas un popup tardío y lo bloqueen.
  const settings=state.data.settings;
  if(!window.google?.accounts?.oauth2)throw new Error('Google Identity todavía se está preparando. Espera un instante y vuelve a pulsar.');
  return new Promise((resolve,reject)=>{
    const client=google.accounts.oauth2.initTokenClient({
      client_id:settings.googleDriveClientId,
      scope:DRIVE_BROWSER_SCOPES,
      include_granted_scopes:true,
      callback:response=>{
        if(response?.error){reject(new Error(response.error_description||response.error));return;}
        const token=cacheDriveAccessToken(response?.access_token||'',response?.expires_in||3300);
        if(!token){reject(new Error('Google no ha devuelto un token de acceso a Drive.'));return;}
        resolve(token);
      },
      error_callback:error=>reject(new Error(error?.message||error?.type||'No se pudo abrir el selector de cuentas de Google.'))
    });
    client.requestAccessToken({prompt:'select_account'});
  });
}
async function updateDriveBrowserAccountIdentity(token){
  try{
    const controller=new AbortController();
    const timer=setTimeout(()=>controller.abort(),10000);
    const response=await fetch('https://www.googleapis.com/drive/v3/about?fields=user(displayName,emailAddress)',{headers:{Authorization:`Bearer ${token}`},signal:controller.signal});
    clearTimeout(timer);
    if(response.ok){
      const data=await response.json();
      state.drivePersistentStatus={
        ...state.drivePersistentStatus,
        checked:true,connected:true,temporary:true,
        email:String(data?.user?.emailAddress||''),name:String(data?.user?.displayName||''),
        lastMessage:'Cuenta de Google Drive seleccionada para esta sesión.'
      };
    }
  }catch{}
}
async function selectFromDriveTouch({multiple=false,mimeTypes='application/pdf,image/png,image/jpeg,image/webp',includeToken=false,sharedDrives=false,title='',folderPicker=false}={}){
  const selected=new Map();
  // No bloquear nunca la apertura del selector esperando al Worker. La comprobación
  // de la sesión persistente se hace en paralelo para que TODOS los botones de Drive
  // respondan inmediatamente incluso si Cloudflare/Google tarda o falla.
  const statusRefreshPromise=state.provider instanceof LocalProvider
    ? Promise.resolve(state.drivePersistentStatus)
    : refreshDrivePersistentStatus({silent:true});
  // Precargamos Google Identity mientras el usuario navega. El botón de cambiar cuenta
  // solo se habilita cuando está listo, de modo que el click pueda abrir OAuth de forma
  // síncrona y no quede atrapado en «Abriendo…».
  let accountOauthReady=Boolean(window.google?.accounts?.oauth2),accountOauthError='';
  const accountOauthReadyPromise=accountOauthReady?Promise.resolve():loadGooglePicker().then(()=>{accountOauthReady=true;accountOauthError='';}).catch(error=>{accountOauthError=error?.message||'No se pudo preparar Google Identity.';});
  const initialSource=sharedDrives?'shared':'my';
  const initialSaved=readDriveBrowserLocation(initialSource);
  let sourceMode=initialSource,
      folderId=initialSaved?.folderId||(sharedDrives?'':'root'),
      sharedDriveId=initialSaved?.sharedDriveId||'',
      path=initialSaved?.path||(sharedDrives?[]:[{id:'root',name:'Mi unidad'}]),
      showingDriveList=initialSaved?Boolean(initialSaved.showingDriveList):sharedDrives,
      items=[],nextPageToken='',loading=false,search='',accountBusy=false,sort=getDriveBrowserSort(),restoredLocation=Boolean(initialSaved),browserError='';

  const hadParentModal=!els.modalBackdrop.classList.contains('hidden')&&els.modal.childNodes.length>0;
  const parentWide=els.modal.classList.contains('modal-wide');
  const parentFragment=hadParentModal?document.createDocumentFragment():null;
  if(hadParentModal){while(els.modal.firstChild)parentFragment.appendChild(els.modal.firstChild);}
  const restoreParent=()=>{
    state.driveBrowserCancel=null;
    if(hadParentModal){
      els.modal.innerHTML='';els.modal.appendChild(parentFragment);els.modal.classList.toggle('modal-wide',parentWide);
      els.modalBackdrop.classList.remove('hidden');els.modalBackdrop.setAttribute('aria-hidden','false');
    }else closeModal();
  };

  const applySavedLocation=source=>{
    const saved=readDriveBrowserLocation(source);
    sourceMode=source;search='';nextPageToken='';items=[];restoredLocation=Boolean(saved);
    if(source==='shared'){
      showingDriveList=saved?Boolean(saved.showingDriveList):true;
      sharedDriveId=saved?.sharedDriveId||'';folderId=saved?.folderId||'';path=saved?.path||[];
    }else{
      showingDriveList=false;sharedDriveId='';folderId=saved?.folderId||'root';path=saved?.path||[{id:'root',name:'Mi unidad'}];
    }
  };
  const rememberLocation=()=>rememberDriveBrowserLocation({sourceMode,folderId,sharedDriveId,path,showingDriveList});
  return new Promise((resolve,reject)=>{
    let settled=false;
    const finish=async accept=>{
      if(settled)return;settled=true;
      try{
        if(!accept){restoreParent();resolve(folderPicker?null:[]);return;}
        if(folderPicker){
          if(showingDriveList||!folderId){settled=false;toast('Entra primero en una unidad o carpeta de Google Drive.','error');return;}
          const currentName=path[path.length-1]?.name||(sourceMode==='my'?'Mi unidad':'Carpeta de Drive');
          const result={id:String(folderId),name:String(currentName),sharedDriveId:String(sharedDriveId||''),sourceMode};
          rememberLocation();restoreParent();resolve(result);return;
        }
        if(!selected.size){settled=false;return;}
        let token='';
        if(includeToken){
          // El selector ya ha navegado por Drive con un access token válido. Reutilizarlo
          // aquí evita una segunda renovación OAuth al pulsar «Seleccionar», que puede
          // quedar bloqueada por el navegador o fallar si la sesión persistente necesita
          // mantenimiento. Si el token ya no está disponible, mantenemos el selector
          // abierto y pedimos al usuario renovar explícitamente desde «Cambiar cuenta / acceso».
          const cachedToken=String(state.driveAccessToken||'');
          const cachedTokenValid=Boolean(cachedToken)&&Date.now()<Number(state.driveAccessTokenExpiresAt||0)-15000;
          if(cachedTokenValid)token=cachedToken;
          else{
            try{token=await getGoogleDriveAccessToken('',{interactive:false});}catch{}
          }
          if(!token){
            settled=false;
            toast('La sesión de Drive necesita renovarse. Pulsa «Cambiar cuenta / acceso» y vuelve a seleccionar el archivo.','error');
            render();
            return;
          }
        }
        const result=[...selected.values()].map(file=>driveSelectionObject(file,token,includeToken));
        restoreParent();resolve(result);
      }catch(error){restoreParent();reject(error);}
    };
    state.driveBrowserCancel=()=>finish(false);
    const accountLabel=()=>String(state.drivePersistentStatus?.email||state.drivePersistentStatus?.name||'Cuenta de Google Drive');
    const resetToMyDrive=()=>{sourceMode='my';showingDriveList=false;sharedDriveId='';folderId='root';path=[{id:'root',name:'Mi unidad'}];search='';nextPageToken='';items=[];restoredLocation=false;rememberLocation();};
    const resetToShared=()=>{sourceMode='shared';showingDriveList=true;sharedDriveId='';folderId='';path=[];search='';nextPageToken='';items=[];restoredLocation=false;rememberLocation();};
    const changeAccount=()=>{
      if(accountBusy)return;
      if(!accountOauthReady){
        toast(accountOauthError||'Google Drive todavía está preparando el acceso. Espera un instante y vuelve a pulsar.','error');
        return;
      }
      // La llamada que abre Google es la PRIMERA operación del click: sin fetch, await ni
      // refrescos de estado delante. Así preservamos la activación de usuario del navegador.
      let request;
      try{request=requestDriveBrowserAccountTokenFromClick();}
      catch(error){accountBusy=false;toast(`No se pudo abrir el selector de cuenta: ${error.message}`,'error');render();return;}
      accountBusy=true;render();toast('Elige la cuenta de Google Drive que contiene tus archivos…');
      request.then(async token=>{
        await updateDriveBrowserAccountIdentity(token);
        selected.clear();browserError='';resetToMyDrive();
        accountBusy=false;await load(false);
        toast(`Drive conectado: ${accountLabel()}`);
      }).catch(error=>{
        accountBusy=false;loading=false;toast(`No se pudo cambiar la cuenta de Drive: ${error.message}`,'error');render();
      });
    };
    const render=()=>{
      const defaultHeading=folderPicker?'Elegir carpeta de Google Drive':(multiple?'Seleccionar varios archivos de Google Drive':'Seleccionar archivo de Google Drive');
      const heading=title||defaultHeading;
      const breadcrumb=showingDriveList?'<span class="drive-browser-crumb current">Unidades compartidas</span>':`${sourceMode==='shared'?'<button type="button" class="drive-browser-crumb" data-drive-shared-root>Unidades compartidas</button><span class="drive-browser-sep">›</span>':''}${path.map((entry,index)=>`<button type="button" class="drive-browser-crumb${index===path.length-1?' current':''}" data-drive-breadcrumb="${index}" ${index===path.length-1?'disabled':''}>${esc(entry.name)}</button>`).join('<span class="drive-browser-sep">›</span>')}`;
      const selectable=folderPicker?[]:items.filter(item=>item.mimeType!=='application/vnd.google-apps.folder'&&driveAllowedMime(item.mimeType,mimeTypes));
      const allVisibleSelected=multiple&&selectable.length&&selectable.every(item=>selected.has(String(item.id)));
      const isEmpty=!loading&&!items.length;
      const emptyMessage=browserError|| (search?'No hay resultados en esta carpeta.':(sourceMode==='my'&&folderId==='root'?'No se ven carpetas ni archivos en esta cuenta con la autorización actual. Si tus archivos están en otra cuenta, o conectaste Drive antes de activar la navegación por carpetas, pulsa «Cambiar cuenta / acceso».':(folderPicker?'Esta carpeta no contiene subcarpetas. Puedes elegir la carpeta actual con el botón inferior.':'Esta carpeta no contiene archivos compatibles.')));
      const rows=items.map(item=>{
        const id=String(item.id||''),folder=item.mimeType==='application/vnd.google-apps.folder'||item._sharedDriveRoot;
        if(folder){
          return `<div class="drive-browser-row is-folder" data-drive-row="${esc(id)}"><button type="button" class="drive-browser-open" data-drive-open="${esc(id)}" aria-label="Abrir ${esc(item.name||'carpeta')}"><span class="drive-browser-icon">📁</span><span class="drive-browser-name"><strong>${esc(item.name||'Carpeta')}</strong><small>${esc(item._sharedDriveRoot?'Unidad compartida':'Carpeta')}</small></span><span class="drive-browser-chevron">›</span></button></div>`;
        }
        if(folderPicker||!driveAllowedMime(item.mimeType,mimeTypes))return '';
        const checked=selected.has(id),meta=[driveFileDisplayType(item.mimeType),formatDriveSize(item.size),formatDriveModified(item.modifiedTime)].filter(Boolean).join(' · ');
        const inputType=multiple?'checkbox':'radio';
        return `<div class="drive-browser-row is-file ${checked?'is-selected':''}" data-drive-row="${esc(id)}"><label class="drive-browser-select"><input type="${inputType}" name="drive-browser-choice" data-drive-check="${esc(id)}" ${checked?'checked':''}><span class="drive-browser-checkmark" aria-hidden="true">✓</span><span class="drive-browser-icon">${driveFileIcon(item.mimeType)}</span><span class="drive-browser-name"><strong>${esc(item.name||'Archivo')}</strong><small>${esc(meta)}</small></span></label></div>`;
      }).join('')||`<div class="drive-browser-empty"><div><span class="drive-browser-empty-icon">${loading?'⏳':'📂'}</span><p>${loading?'Cargando Google Drive…':esc(emptyMessage)}</p>${isEmpty&&(browserError||(sourceMode==='my'&&folderId==='root'&&!search))?'<button class="btn primary small" type="button" data-drive-account>👤 Cambiar cuenta / acceso</button>':''}</div></div>`;
      const connected=Boolean(state.drivePersistentStatus?.connected||state.driveAccessToken);
      const selectionActions=folderPicker
        ?'<div class="drive-browser-selection-actions"><button class="btn ghost small" type="button" data-drive-refresh>↻ Actualizar</button></div>'
        :multiple
          ?`<div class="drive-browser-selection-actions"><button class="btn ghost small" type="button" data-drive-refresh>↻ Actualizar</button><button class="btn ghost small" type="button" data-drive-select-all ${!selectable.length?'disabled':''}>${allVisibleSelected?'Quitar visibles':'Seleccionar visibles'}</button><button class="btn ghost small" type="button" data-drive-clear ${!selected.size?'disabled':''}>Limpiar selección</button></div>`
          :`<div class="drive-browser-selection-actions"><button class="btn ghost small" type="button" data-drive-refresh>↻ Actualizar</button><button class="btn ghost small" type="button" data-drive-clear ${!selected.size?'disabled':''}>Limpiar selección</button></div>`;
      const currentFolderReady=folderPicker&&!showingDriveList&&Boolean(folderId);
      const footerCounter=folderPicker?(currentFolderReady?`Carpeta: ${esc(path[path.length-1]?.name||(sourceMode==='my'?'Mi unidad':'Drive'))}`:'Entra en una unidad'):`${selected.size} archivo${selected.size===1?'':'s'}`;
      const acceptLabel=folderPicker?'Usar esta carpeta':(multiple?`Añadir ${selected.size||''}${selected.size?' archivo'+(selected.size===1?'':'s'):' archivos'}`:'Seleccionar');
      const acceptDisabled=folderPicker?!currentFolderReady:!selected.size;
      const selectionHint=folderPicker?'Navega hasta la carpeta de destino. Se recuerda la última ubicación y el orden para la próxima vez.':multiple?'Entra en las carpetas tocando 📁 y marca tantos archivos como quieras. La selección se conserva mientras navegas.':'Entra en las carpetas tocando 📁 y marca el archivo que quieras usar.';
      openModal(`<div class="modal-head drive-browser-head"><div><h3>${esc(heading)}</h3><small>${folderPicker?'Navegador de carpetas':`${selected.size} seleccionado${selected.size===1?'':'s'}`}</small></div><button class="close-btn" type="button" data-drive-browser-cancel>×</button></div><div class="modal-body drive-browser-body"><div class="drive-browser-account"><div class="drive-browser-account-main"><span class="drive-browser-account-icon">${driveIconMarkup()}</span><span><small>Cuenta de Google Drive</small><strong>${esc(accountLabel())}</strong><em>${connected?'Conectada para navegar por carpetas':'Selecciona la cuenta donde están tus archivos'}</em></span></div><button class="btn secondary small" type="button" data-drive-account ${(accountBusy||!accountOauthReady)?'disabled':''} title="${esc(accountOauthError||'Cambiar la cuenta utilizada por Google Drive')}">👤 ${accountBusy?'Abriendo…':(!accountOauthReady?'Preparando acceso…':'Cambiar cuenta / acceso')}</button></div><div class="drive-browser-source-tabs"><button class="drive-browser-source-tab ${sourceMode==='my'?'active':''}" type="button" data-drive-source="my">☁ Mi unidad</button><button class="drive-browser-source-tab ${sourceMode==='shared'?'active':''}" type="button" data-drive-source="shared">▦ Unidades compartidas</button></div><div class="drive-browser-toolbar"><div class="drive-browser-search"><input type="search" value="${esc(search)}" placeholder="Buscar en esta carpeta" aria-label="Buscar en esta carpeta" data-drive-browser-search><button class="btn secondary small" type="button" data-drive-browser-search-btn>🔎 Buscar</button></div><div class="drive-browser-sort-row"><label>Ordenar<select data-drive-sort><option value="name-asc" ${sort==='name-asc'?'selected':''}>Nombre · A → Z</option><option value="name-desc" ${sort==='name-desc'?'selected':''}>Nombre · Z → A</option><option value="date-desc" ${sort==='date-desc'?'selected':''}>Fecha · más recientes</option><option value="date-asc" ${sort==='date-asc'?'selected':''}>Fecha · más antiguos</option></select></label><small>Se recuerda para la próxima vez</small></div>${selectionActions}</div><div class="drive-browser-breadcrumb">${breadcrumb}</div><div class="drive-browser-list ${loading?'is-loading':''}">${rows}</div>${nextPageToken?'<div class="drive-browser-more"><button class="btn secondary" type="button" data-drive-more>Cargar más</button></div>':''}<p class="help-text drive-browser-help">${selectionHint} El navegador carga automáticamente todas las páginas de la carpeta, recuerda la última ubicación y permite ordenar por nombre o fecha. «Cambiar cuenta / acceso» abre el selector de cuentas de Google.</p></div><div class="modal-actions drive-browser-actions"><span class="drive-browser-counter">${footerCounter}</span><button class="btn ghost" type="button" data-drive-browser-cancel>Cancelar</button><button class="btn primary" type="button" data-drive-browser-accept ${acceptDisabled?'disabled':''}>${acceptLabel}</button></div>`,true);
      const cancel=()=>finish(false);
      $$('[data-drive-browser-cancel]',els.modal).forEach(button=>button.addEventListener('click',cancel));
      $('[data-drive-browser-accept]',els.modal)?.addEventListener('click',()=>finish(true));
      $$('[data-drive-account]',els.modal).forEach(button=>button.addEventListener('click',changeAccount));
      $$('[data-drive-source]',els.modal).forEach(button=>button.addEventListener('click',async()=>{const target=button.dataset.driveSource;if(target===sourceMode)return;selected.clear();applySavedLocation(target==='shared'?'shared':'my');await load(false);}));
      $$('[data-drive-check]',els.modal).forEach(input=>input.addEventListener('change',()=>{const id=String(input.dataset.driveCheck||''),file=items.find(x=>String(x.id)===id);if(!file)return;if(input.checked){if(!multiple)selected.clear();selected.set(id,file);}else selected.delete(id);render();}));
      $$('[data-drive-open]',els.modal).forEach(button=>button.addEventListener('click',async()=>{const id=String(button.dataset.driveOpen||''),file=items.find(x=>String(x.id)===id);if(!file)return;search='';nextPageToken='';restoredLocation=false;if(file._sharedDriveRoot){sourceMode='shared';sharedDriveId=id;folderId=id;path=[{id,name:file.name||'Unidad compartida'}];showingDriveList=false;}else{folderId=id;path.push({id,name:file.name||'Carpeta'});}rememberLocation();await load(false);}));
      $$('[data-drive-breadcrumb]',els.modal).forEach(button=>button.addEventListener('click',async()=>{const index=Number(button.dataset.driveBreadcrumb);if(!Number.isFinite(index)||index<0||index>=path.length)return;path=path.slice(0,index+1);folderId=path[index].id;search='';nextPageToken='';restoredLocation=false;rememberLocation();await load(false);}));
      $('[data-drive-shared-root]',els.modal)?.addEventListener('click',async()=>{resetToShared();await load(false);});
      $('[data-drive-refresh]',els.modal)?.addEventListener('click',()=>{nextPageToken='';load(false);});
      $('[data-drive-clear]',els.modal)?.addEventListener('click',()=>{selected.clear();render();});
      $('[data-drive-select-all]',els.modal)?.addEventListener('click',()=>{if(allVisibleSelected)selectable.forEach(file=>selected.delete(String(file.id)));else selectable.forEach(file=>selected.set(String(file.id),file));render();});
      $('[data-drive-sort]',els.modal)?.addEventListener('change',async event=>{sort=String(event.currentTarget.value||'name-asc');rememberDriveBrowserSort(sort);nextPageToken='';await load(false);});
      const runSearch=async()=>{search=String($('[data-drive-browser-search]',els.modal)?.value||'').trim();nextPageToken='';await load(false);};
      $('[data-drive-browser-search-btn]',els.modal)?.addEventListener('click',runSearch);
      $('[data-drive-browser-search]',els.modal)?.addEventListener('keydown',event=>{if(event.key==='Enter'){event.preventDefault();runSearch();}});
      $('[data-drive-more]',els.modal)?.addEventListener('click',()=>load(true));
    };
    const load=async append=>{
      if(!append)browserError='';
      loading=true;render();
      try{
        if(showingDriveList){
          const result=await driveListSharedDrives(append?nextPageToken:'');
          const mapped=driveBrowserSortItems(result.drives.map(d=>({id:d.id,name:d.name,mimeType:'application/vnd.google-apps.folder',_sharedDriveRoot:true})),sort);
          items=append?driveBrowserSortItems([...items,...mapped],sort):mapped;nextPageToken=result.nextPageToken;
        }else{
          const result=await driveListFolder({folderId,sharedDriveId,pageToken:append?nextPageToken:'',search,sort});
          const sorted=driveBrowserSortItems(result.files,sort);
          items=append?driveBrowserSortItems([...items,...sorted],sort):sorted;nextPageToken=result.nextPageToken;
          rememberLocation();restoredLocation=false;
        }
        loading=false;render();
      }catch(error){
        if(restoredLocation&&!append){
          restoredLocation=false;
          if(sourceMode==='shared')resetToShared();else resetToMyDrive();
          toast('La última carpeta ya no está disponible. He vuelto al inicio de Drive.');
          await load(false);return;
        }
        loading=false;items=[];nextPageToken='';browserError=error.message||'No se pudo leer Google Drive.';toast(browserError,'error');render();
      }
    };
    // Abrimos el navegador ya; estado persistente y Google Identity se preparan en segundo plano.
    statusRefreshPromise.then(()=>{if(!settled)render();}).catch(()=>{});
    accountOauthReadyPromise.finally(()=>{if(!settled)render();});
    load(false);
  });
}
async function selectFromDrive({multiple=false,mimeTypes='application/pdf,image/png,image/jpeg,image/webp',includeToken=false,sharedDrives=false,title=''}={}){
  return selectFromDriveTouch({multiple,mimeTypes,includeToken,sharedDrives,title});
}
function extensionForMime(mimeType=''){
  const type=String(mimeType).toLowerCase();
  if(type==='image/png')return '.png';
  if(type==='image/webp')return '.webp';
  if(type==='image/gif')return '.gif';
  if(type==='image/svg+xml')return '.svg';
  if(type==='image/jpeg')return '.jpg';
  if(type==='application/pdf')return '.pdf';
  return '';
}
async function importDriveFile(selected,folder='drive-files'){
  if(!selected?.id)return selected;
  let token=selected.accessToken;
  if(!token){token=await getGoogleDriveAccessToken('',{interactive:true});}
  const driveId=selected.driveFileId||selected.id;
  const response=await fetch(`https://www.googleapis.com/drive/v3/files/${encodeURIComponent(driveId)}?alt=media&supportsAllDrives=true`,{headers:{Authorization:`Bearer ${token}`},cache:'no-store'});
  if(!response.ok)throw new Error(`No se pudo importar el archivo de Drive (HTTP ${response.status}). Comprueba que el archivo pertenece a la cuenta seleccionada y vuelve a intentarlo.`);
  const blob=await response.blob();
  const mimeType=selected.mimeType||blob.type||(selected.type==='image'?'image/jpeg':'application/pdf');
  let safeName=String(selected.label||`drive-${driveId}`).replace(/[\/:*?"<>|]+/g,'-').trim()||`drive-${driveId}`;
  const extension=extensionForMime(mimeType);
  if(extension&&!/\.[a-z0-9]{2,5}$/i.test(safeName))safeName+=extension;
  const file=new File([blob],safeName,{type:mimeType});
  const uploaded=await state.provider.uploadFile(file,folder);
  return {
    id:uid('file'),driveFileId:driveId,label:selected.label||file.name,
    url:uploaded.url,driveUrl:selected.driveUrl||selected.url,
    type:String(mimeType).startsWith('image/')?'image':'file',mimeType,
    storagePath:uploaded.path,source:'drive'
  };
}
async function importDriveImage(selected,folder='drive-images'){
  const imported=await importDriveFile(selected,folder);
  if(imported&&imported.type!=='image')throw new Error('El archivo seleccionado no es una imagen compatible.');
  return imported;
}
async function prepareDriveSelections(selected,folder='documents'){
  const ready=[];
  for(const item of selected||[])ready.push(await importDriveFile(item,folder));
  return ready;
}
function openFilesManager(initial,onSave,title='Archivos',options={}){
  let files=normalizeFileList(clone(initial||[]));
  // v2.4.12 · Los gestores exclusivos de Drive guardan la referencia del archivo
  // directamente. Evita una segunda descarga/subida y el bloqueo observado en carruseles.
  const autoSave=Boolean(options.autoSave),driveOnly=Boolean(options.driveOnly),storeDriveLinks=driveOnly?true:Boolean(options.storeDriveLinks),archivePersistence=Boolean(options.archivePersistence);
  const allowedMimeTypes=String(options.mimeTypes||'application/pdf,image/png,image/jpeg,image/webp');
  const storageFolder=String(options.storageFolder||'documents').replace(/^\/+|\/+$/g,'');
  const persist=async()=>{if(autoSave){const result=await onSave(normalizeFileList(files),{keepOpen:true});if(result===false)throw new Error('No se han podido guardar los archivos en la ficha seleccionada.');}};
  // v2.2.149 · Drive móvil robusto: el gestor intentaba copiar primero el archivo de
  // Drive a Firebase Storage. En Android esa copia puede fallar después de haber hecho
  // la selección correctamente, dejando al usuario de vuelta en el gestor sin el archivo.
  // Si la importación no es posible, conservamos el archivo como referencia segura a
  // Google Drive (driveFileId + URL) en vez de descartarlo.
  // v2.2.149 · Drive móvil: incorporar inmediatamente la referencia de Google Drive.
  // No descargamos ni re-subimos el archivo a Firebase al pulsar «Añadir archivos».
  const prepareSelected=async selected=>{
    if(storeDriveLinks)return driveLinkSelections(selected);
    const ready=[];
    for(const item of selected||[]){
      try{ready.push(await importDriveFile(item,storageFolder));}
      catch(error){console.warn('No se pudo crear copia estable del archivo de Drive; se conserva el enlace.',error);ready.push(...driveLinkSelections([item]));}
    }
    return ready;
  };
  const draw=()=>{
    const count=files.length;
    const addButtons=driveOnly?`<button class="btn secondary" type="button" data-file-add-drive>${driveIconMarkup()} Seleccionar varios · Mi unidad</button><button class="btn secondary" type="button" data-file-add-shared>▦ Seleccionar varios · Compartidas</button>`:`<button class="btn secondary" type="button" data-file-add-url>🔗 Añadir enlace</button><button class="btn secondary" type="button" data-file-add-drive>${driveIconMarkup()} Seleccionar varios · Mi unidad</button><button class="btn secondary" type="button" data-file-add-shared>▦ Seleccionar varios · Compartidas</button><button class="btn secondary" type="button" data-file-upload>⬆ Subir archivos</button>`;
    const archiveHelp=archivePersistence?' El pin 📌 permite conservar individualmente webs, guías o archivos al archivar el viaje; los elementos sin pin se limpiarán como hasta ahora.':'';
    const help=(driveOnly?'Puedes marcar varios archivos en una sola apertura del selector de Google Drive. Se mantienen en Drive: la app guarda únicamente su identificador y los abre con tu autorización; no utiliza Firebase Storage.':(autoSave?'Puedes seleccionar varios archivos de Drive de una vez; los seleccionados o subidos se guardan inmediatamente en esta ficha. El botón final conserva también cambios de orden, nombre, visibilidad o eliminación.':'Puedes seleccionar varios archivos de Drive de una vez. No se aplicarán a la ficha hasta pulsar «Guardar archivos». El ojo permite ocultar cada elemento sin borrarlo.'))+archiveHelp;
    openModal(`<div class="modal-head"><h3>${esc(title)} <span class="file-count-badge">${count}</span></h3><button class="close-btn" data-close-modal>×</button></div><div class="modal-body"><div class="file-manager-list">${files.map((f,i)=>`<div class="file-manager-row ${f.hidden===true?'is-hidden':''}" data-file-sort-item="${i}"><span><strong>${esc(f.label||'Archivo')}</strong><small class="file-manager-url">${esc(officialFileDriveId(f)?driveFileViewUrl(f):(f.url||'Sin URL'))}</small>${f.keepOnArchive===true?'<small class="file-manager-persistent-label">📌 Se conserva al archivar</small>':''}${f.hidden===true?'<small class="file-manager-hidden-label">Oculto en la app · sigue guardado</small>':''}</span><small>${officialFileDriveId(f)?'Google Drive':esc(f.type||'auto')}</small><div class="row-actions"><button type="button" class="mini-btn free-drag-handle" data-file-sort-handle="${i}" title="Arrastrar archivo" aria-label="Arrastrar archivo">⋮⋮</button>${archivePersistence?`<button class="mini-btn file-archive-pin ${f.keepOnArchive===true?'is-pinned':''}" type="button" data-file-archive-persist="${i}" title="${f.keepOnArchive===true?'Dejar de conservar al archivar':'Conservar al archivar'}" aria-label="${f.keepOnArchive===true?'Dejar de conservar al archivar':'Conservar al archivar'}">📌</button>`:''}<button class="mini-btn file-visibility-toggle ${f.hidden===true?'is-hidden':''}" type="button" data-file-visibility="${i}" title="${f.hidden===true?'Mostrar':'Ocultar'} este elemento" aria-label="${f.hidden===true?'Mostrar':'Ocultar'} este elemento">${coverEyeIconMarkup('file-eye-icon')}</button><button class="mini-btn" type="button" data-file-edit="${i}">✎</button><button class="mini-btn" type="button" data-file-delete="${i}">×</button></div></div>`).join('')||'<div class="empty">No hay archivos.</div>'}</div><div class="page-actions" style="margin-top:16px">${addButtons}</div><p class="help-text">${help}</p></div><div class="modal-actions"><button class="btn ghost" type="button" data-close-modal>Cancelar</button><button class="btn primary" type="button" data-files-save>Guardar archivos (${count})</button></div>`,true);
    $$('[data-close-modal]',els.modal).forEach(button=>button.addEventListener('click',closeModal));
    bindDragReorderSurface({root:els.modal,handleSelector:'[data-file-sort-handle]',itemSelector:'[data-file-sort-item]',containerSelector:'[data-no-file-sort-container]',keyOfHandle:el=>el.dataset.fileSortHandle,keyOfItem:el=>el.dataset.fileSortItem,onDrop:async(source,target,after)=>{if(moveArrayItemTo(files,num(source),num(target),after))draw();},canDrop:()=>true});
    $$('[data-file-delete]',els.modal).forEach(button=>button.addEventListener('click',()=>{if(!confirmAction('¿Eliminar este archivo o enlace de la ficha?'))return;files.splice(num(button.dataset.fileDelete),1);draw();}));
    $$('[data-file-archive-persist]',els.modal).forEach(button=>button.addEventListener('click',async()=>{const index=num(button.dataset.fileArchivePersist);if(!files[index])return;const previous=files[index].keepOnArchive===true;files[index]={...files[index],keepOnArchive:!previous};draw();try{await persist();toast(files[index]?.keepOnArchive===true?'📌 Este elemento se conservará al archivar.':'Este elemento volverá a limpiarse al archivar.');}catch(error){files[index]={...files[index],keepOnArchive:previous};draw();toast(error.message||'No se ha podido guardar la opción de archivo.','error');}}));
    $$('[data-file-visibility]',els.modal).forEach(button=>button.addEventListener('click',async()=>{const index=num(button.dataset.fileVisibility);if(!files[index])return;const previous=files[index].hidden===true;files[index]={...files[index],hidden:!previous};draw();try{await persist();toast(files[index]?.hidden===true?'Elemento ocultado. Sigue guardado y puedes recuperarlo con el ojo.':'Elemento visible de nuevo.');}catch(error){files[index]={...files[index],hidden:previous};draw();toast(error.message||'No se ha podido guardar la visibilidad del elemento.','error');}}));
    $$('[data-file-edit]',els.modal).forEach(button=>button.addEventListener('click',()=>{const index=num(button.dataset.fileEdit),current=files[index];const fields=driveOnly?[{name:'label',label:'Etiqueta (Anverso, Reverso, Página 1…)',required:true,full:true},...(archivePersistence?[{name:'keepOnArchive',label:'📌 Conservar al archivar',type:'checkbox',full:true}]:[])]:[{name:'label',label:'Etiqueta (Anverso, Reverso, Página 1…)',required:true,full:true},{name:'url',label:'URL',type:'url',required:true,full:true,driveSelect:true,driveLabelTarget:'label',driveTypeTarget:'type'},{name:'type',label:'Tipo',type:'select',options:[{value:'file',label:'PDF / Drive / archivo'},{value:'image',label:'Imagen'},{value:'web',label:'Página web'}]},...(archivePersistence?[{name:'keepOnArchive',label:'📌 Conservar al archivar',type:'checkbox',full:true}]:[])];openForm({title:'Editar archivo o cara',fields,values:current,onSubmit:async value=>{files[index]={...current,...value};draw();return false;}});}));
    $('[data-file-add-url]',els.modal)?.addEventListener('click',()=>openForm({title:'Añadir enlace',fields:[{name:'label',label:'Texto del botón',required:true},{name:'url',label:'URL',type:'url',required:true,full:true,driveSelect:true,driveLabelTarget:'label',driveTypeTarget:'type'},{name:'type',label:'Tipo',type:'select',options:[{value:'file',label:'PDF / Drive / archivo'},{value:'image',label:'Imagen'},{value:'web',label:'Página web'}]},...(archivePersistence?[{name:'keepOnArchive',label:'📌 Conservar al archivar',type:'checkbox',full:true,help:'Ideal para webs o guías que quieres reutilizar en todos los viajes.'}]:[])],onSubmit:async value=>{files.push(normalizeFileList([{id:uid('file'),...value}])[0]);draw();return false;}}));
    const addFromDrive=async sharedDrives=>{
      let previousFiles=null;
      try{
        const selected=await selectFromDrive({multiple:true,mimeTypes:allowedMimeTypes,includeToken:false,sharedDrives,title:sharedDrives?'Seleccionar varios archivos · Unidades compartidas':'Seleccionar varios archivos · Mi unidad'});
        if(!selected.length){draw();return;}
        toast('Añadiendo archivos de Google Drive…');
        const ready=await prepareSelected(selected);
        if(!ready.length)throw new Error('Google Drive no ha devuelto archivos compatibles para guardar.');
        previousFiles=clone(files);
        files=normalizeFileList([...files,...ready]);
        // Mostrar inmediatamente la selección en el gestor antes de persistirla.
        // Así el usuario nunca vuelve a una ventana vacía mientras se guarda en Firebase.
        draw();
        await persist();
        toast(autoSave?`${ready.length} archivo${ready.length===1?'':'s'} añadido${ready.length===1?'':'s'} y guardado.`:`${ready.length} archivo${ready.length===1?'':'s'} añadido${ready.length===1?'':'s'}. Pulsa «Guardar archivos» para confirmar.`);
      }catch(error){
        if(previousFiles){files=previousFiles;draw();}
        toast(error.message||'No se han podido guardar los archivos de Drive.','error');
      }
    };
    $('[data-file-add-drive]',els.modal)?.addEventListener('click',()=>addFromDrive(false));
    $('[data-file-add-shared]',els.modal)?.addEventListener('click',()=>addFromDrive(true));
    $('[data-file-upload]',els.modal)?.addEventListener('click',()=>{const input=document.createElement('input');input.type='file';input.multiple=true;input.accept='application/pdf,image/*';input.onchange=async()=>{const selected=[...(input.files||[])];if(!selected.length)return;try{for(const file of selected){const result=await state.provider.uploadFile(file,storageFolder);const mimeType=result.mimeType||file.type||'';files.push({id:uid('file'),label:file.name,url:result.url,type:mimeType.startsWith('image/')?'image':'file',storagePath:result.path,mimeType});}await persist();toast(`${selected.length} archivo${selected.length===1?'':'s'} subido${selected.length===1?'':'s'} a esta ficha.`);draw();}catch(error){toast(error.message||'No se han podido subir los archivos.','error');}};input.click();});
    $('[data-files-save]',els.modal)?.addEventListener('click',async()=>{const cleanFiles=normalizeFileList(files);await onSave(cleanFiles);closeModal();toast(`${cleanFiles.length} archivo${cleanFiles.length===1?'':'s'} guardado${cleanFiles.length===1?'':'s'}.`);});
  };draw();
}

function openOcrReview(index,result,options={}){
  const record={...(options.record||state.data.purchases.records[index]||{})};
  const selectedFile=options.selectedFile||null;
  let items=groupDuplicateReceiptItems((result.items||[]).map(x=>{
    const rawQuantity=num(x.quantity);
    const quantity=rawQuantity>0?rawQuantity:1;
    const unitPrice=num(x.unitPrice)||num(x.price)/quantity;
    return {name:x.name||'',quantity,unitPrice:Number(unitPrice.toFixed(2)),price:Number((quantity*unitPrice).toFixed(2)),groupedLines:num(x.groupedLines)||1};
  }));
  const rows=items.map((x,i)=>`<div class="ocr-item-row" data-ocr-row="${i}"><label class="ocr-item-field ocr-product-field"><span>Producto</span><input name="name-${i}" aria-label="Producto" value="${esc(x.name)}"></label><label class="ocr-item-field"><span>Unidades</span><input name="qty-${i}" aria-label="Unidades" type="number" min="0" step="0.01" value="${esc(x.quantity)}"></label><label class="ocr-item-field"><span>Precio/ud.</span><input name="unit-${i}" aria-label="Precio por unidad" type="number" min="0" step="0.01" value="${esc(x.unitPrice)}"></label><label class="ocr-item-field"><span>Total</span><input name="line-total-${i}" aria-label="Total del producto" type="number" step="0.01" value="${esc(x.price)}" readonly></label><button class="mini-btn ocr-delete-row" type="button" data-ocr-delete-row title="Eliminar esta línea" aria-label="Eliminar esta línea">×</button>${x.groupedLines>1?`<small class="ocr-grouped-note">${x.groupedLines} líneas agrupadas</small>`:''}</div>`).join('');
  openModal(`<div class="modal-head"><h3>Revisar ticket</h3><button class="close-btn" data-close-modal>×</button></div><form id="ocr-review-form"><div class="modal-body"><div class="form-grid"><label class="field">Supermercado<select name="store">${state.data.shopping.stores.map(s=>`<option value="${esc(s.name)}" ${normalizedKey(s.name)===normalizedKey(result.store||record.store)?'selected':''}>${esc(s.name)}</option>`).join('')}</select></label><label class="field">Fecha<input name="date" type="date" value="${esc(result.date||record.date||'')}"></label><label class="field full">Importe total<input name="total" type="number" step="0.01" value="${esc(result.total??record.amount??0)}"></label></div>${result.totalReason?`<div class="ocr-total-warning">⚠ ${esc(result.totalReason)}</div>`:''}<h4>Productos detectados</h4>${items.length?`<div class="ocr-items-head"><span>Producto</span><span>Unidades</span><span>Precio/ud.</span><span>Total</span><span></span></div><div id="ocr-items">${rows}</div>`:'<p class="muted">No se han detectado líneas; puedes guardar solo el total.</p>'}<p class="help-text">Revisa y corrige antes de guardar. Al cambiar unidades o precio unitario, el total de esa línea se recalcula automáticamente. Una línea con 0 unidades no se guardará.</p>${result.rawText?`<details class="ocr-raw"><summary>Ver texto reconocido</summary><pre>${esc(result.rawText)}</pre></details>`:''}</div><div class="modal-actions ocr-review-actions"><button class="btn ghost" type="button" data-close-modal>Cancelar</button><button class="btn primary canary-save-btn" type="submit">Guardar compra</button></div></form>`,true);
  $$('[data-close-modal]',els.modal).forEach(b=>b.addEventListener('click',closeModal));
  const recalcRow=row=>{
    const i=row.dataset.ocrRow;
    const qty=Math.max(0,num($(`[name="qty-${i}"]`,row)?.value));
    const unit=Math.max(0,num($(`[name="unit-${i}"]`,row)?.value));
    const total=$(`[name="line-total-${i}"]`,row);if(total)total.value=receiptLineTotal(qty,unit).toFixed(2);
  };
  $$('[data-ocr-row]',els.modal).forEach(row=>{
    recalcRow(row);
    $(`[name="qty-${row.dataset.ocrRow}"]`,row)?.addEventListener('input',()=>recalcRow(row));
    $(`[name="unit-${row.dataset.ocrRow}"]`,row)?.addEventListener('input',()=>recalcRow(row));
    $('[data-ocr-delete-row]',row)?.addEventListener('click',()=>{
      if(!confirmAction('¿Eliminar esta línea detectada por el OCR?'))return;
      row.remove();
      const container=$('#ocr-items',els.modal);
      if(container&&!$('[data-ocr-row]',container))container.innerHTML='<p class="muted ocr-empty-lines">No quedan productos. Puedes guardar únicamente el importe total.</p>';
    });
  });
  $('#ocr-review-form',els.modal).addEventListener('submit',async e=>{
    e.preventDefault();
    const fd=new FormData(e.currentTarget);
    record.store=String(fd.get('store')||record.store);
    record.date=String(fd.get('date')||record.date);
    record.amount=num(fd.get('total'));
    if(selectedFile&&!record.ticketDriveId){
      toast('Guardando ticket…');
      const uploaded=await state.provider.uploadFile(selectedFile,'tickets');
      record.ticketUrl=uploaded.url;record.ticketStoredUrl=uploaded.url;record.ticketStoragePath=uploaded.path;record.ticketDriveId='';record.ticketDriveName='';record.ticketMimeType=selectedFile.type||'';
    }
    const reviewed=[];
    for(const row of $$('[data-ocr-row]',e.currentTarget)){
      const i=row.dataset.ocrRow;
      const name=String(fd.get(`name-${i}`)||'').trim();if(!name)continue;
      const quantity=Math.max(0,num(fd.get(`qty-${i}`)));
      const unitPrice=Math.max(0,num(fd.get(`unit-${i}`)));
      if(quantity<=0)continue;
      reviewed.push({name,quantity,unitPrice,price:receiptLineTotal(quantity,unitPrice),groupedLines:num(items[i]?.groupedLines)||1});
    }
    const finalItems=groupDuplicateReceiptItems(reviewed);
    record.id=record.id||uid('purchase');
    if(index===null||index===undefined){state.data.purchases.records.push(record);index=state.data.purchases.records.length-1;}else state.data.purchases.records[index]=record;
    const ticketLabel=record.ticketDriveName||`Ticket ${record.store||''} · ${record.date||''}`;
    const ticketUrl=record.ticketStoredUrl||record.ticketUrl||'';
    const additions=finalItems.map(item=>{
      const quantity=Math.max(.01,num(item.quantity)||1);
      const unitPrice=receiptUnitPriceCents(item)/100;
      const price=Number(num(item.price).toFixed(2));
      return {id:uid('ocr'),date:record.date,store:record.store,name:item.name,quantity,price,unitPrice,groupedLines:item.groupedLines,ticketCount:1,ticketId:record.id,sourcePurchaseId:record.id,ticketLabel,ticketUrl,ticketBreakdown:[{ticketId:record.id,date:record.date,store:record.store,quantity,price,unitPrice,label:ticketLabel,ticketUrl,legacy:false,ticketCount:1}]};
    });
    state.data.purchases.ticketItems=normalizeStoredTicketItems([...state.data.purchases.ticketItems,...additions]);
    // Los productos extraídos del ticket pertenecen exclusivamente a Compra real.
    // Nunca se copian ni se fusionan con Lista de la compra.
    await saveSection('purchases');
    pendingTicketItemMigration=false;
    closeModal();render();toast(`Compra guardada con ${finalItems.length} producto${finalItems.length===1?'':'s'} revisado${finalItems.length===1?'':'s'}.`);
  });
}
function normalizedProductKey(v){return receiptProductFingerprint(v);}
async function pickDriveForTicket(index){
  try{
    const files=await selectFromDrive({multiple:false,includeToken:false,sharedDrives:false});
    const selected=files[0];if(!selected)return;
    const record=state.data.purchases.records[index];
    record.ticketUrl=selected.url;
    record.ticketDriveId=selected.id;
    record.ticketDriveName=selected.label;
    record.ticketMimeType=selected.mimeType||'';
    record.ticketStoragePath='';
    record.ticketStoredUrl='';
    await saveSection('purchases');render();toast('Ticket de Drive enlazado y listo para OCR local.');
  }catch(e){toast(`No se pudo seleccionar desde Drive: ${e.message}`,'error');}
}

function printableShell(title,body){const cfg=state.data.settings;const pdfLogoUrl=new URL("./icons/pdf-logo-white.png",location.href).href;const brandMark=`<img class="brand-logo" src="${esc(pdfLogoUrl)}" alt="Logo Gran Canaria 2026">`;return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)}</title><link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Livvic:ital,wght@0,400;0,500;0,600;0,700;0,800;0,900;1,400;1,600&display=swap" rel="stylesheet"><style>
@page{size:A4;margin:13mm 13mm 16mm}html,body{margin:0!important;padding:0!important;background:#fff!important;width:auto;height:auto;overflow:visible!important}*{box-sizing:border-box}body{font-family:"Livvic",Arial,sans-serif;color:#172033;-webkit-print-color-adjust:exact;print-color-adjust:exact}.print-root{margin:0;padding:0}.head{display:flex;align-items:center;justify-content:space-between;background:linear-gradient(90deg,#d6a83d 0%,#efcf68 100%);border-bottom:4px solid ${cfg.theme.accent};padding:16px 18px 14px;margin:0 0 18px;break-after:avoid}.brand{display:flex;align-items:center;gap:14px}.brand-logo{width:58px;height:58px;object-fit:contain;display:block;flex:0 0 auto}.head h1{margin:0;color:#172033;font-size:24px;line-height:1.15}.destination{color:#34425f;margin-top:4px;font-size:14px}.group{break-inside:auto;page-break-inside:auto;margin:0 0 16px;border:1px solid #dbe1ea;border-radius:14px;overflow:visible;background:#fff}.group h2{margin:0;padding:10px 14px;background:linear-gradient(90deg,var(--group-header-start,#eef4ff),var(--group-header-end,#fff8df));color:#fff;font-size:18px;break-after:avoid;page-break-after:avoid}.row{display:grid;grid-template-columns:24px minmax(0,1fr) auto;gap:10px;padding:9px 14px;border-top:1px solid #edf0f5;align-items:center;break-inside:avoid;page-break-inside:avoid}.box{width:16px;height:16px;border:1.8px solid #64748b;border-radius:4px;display:grid;place-items:center;font-size:11px}.done{text-decoration:line-through;color:#728096}.meta{font-size:12px;color:#687386}.print-export-section{margin-top:4px}.print-table{width:100%;border-collapse:collapse;font-size:11px}.print-table th,.print-table td{padding:7px 8px;border:1px solid #d9e0ea;vertical-align:top}.print-table th{background:#eef3fa;text-align:left;font-weight:800}.print-table .num{text-align:right;white-space:nowrap}.shopping-print-table .check{width:28px;text-align:center}.shopping-print-table th:nth-child(3){width:88px}.shopping-print-table th:nth-child(4),.shopping-print-table th:nth-child(5){width:92px}.store-print-head{display:flex;align-items:center;gap:10px;min-height:46px}.store-print-logo{width:94px;max-width:34%;height:34px;object-fit:contain;object-position:left center;background:transparent;display:block}.store-print-icon{font-size:22px;line-height:1}.print-total-row td{font-weight:900;background:#f7f1dc}.footer{margin-top:16px;padding-top:8px;border-top:1px solid #e6eaf0;text-align:center;color:#8993a3;font-size:10px}.group:first-of-type{page-break-before:auto!important;break-before:auto!important}@media print{.print-root,.head,.group{page-break-before:auto!important}body{min-height:0!important}.group{overflow:visible!important}}
</style></head><body><main class="print-root"><div class="head"><div class="brand">${brandMark}<div><h1>${esc(title)}</h1><div class="destination">${esc(cfg.destination)} · ${formatDate(cfg.departureDateTime.slice(0,10))} – ${formatDate(cfg.returnDateTime.slice(0,10))}</div></div></div></div>${body}<div class="footer">Generado ${new Date().toLocaleString('es-ES')} · ${esc(cfg.appName)}</div></main></body></html>`;}
function openPrintable(title,body){const w=window.open('about:blank','_blank');if(!w){toast('Permite ventanas emergentes para generar el PDF.','error');return;}w.document.open();w.document.write(printableShell(title,body));w.document.close();const launch=async()=>{try{await w.document.fonts?.ready;const images=[...w.document.images];await Promise.all(images.map(img=>img.complete?Promise.resolve():new Promise(r=>{img.onload=img.onerror=r;})));setTimeout(()=>{w.focus();w.print();},120);}catch{setTimeout(()=>{try{w.focus();w.print();}catch{}},200);}};if(w.document.readyState==='complete')launch();else w.addEventListener('load',launch,{once:true});}

function budgetPrintableShell(title,body){
  const cfg=state.data.settings;
  const pdfLogoUrl=new URL("./icons/pdf-logo-white.png",location.href).href;
  return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)}</title><link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Livvic:ital,wght@0,400;0,500;0,600;0,700;0,800;0,900;1,400;1,600&display=swap" rel="stylesheet"><style>
@page{size:A4 portrait;margin:7mm 8mm 8mm}html,body{margin:0!important;padding:0!important;background:#fff!important}*{box-sizing:border-box}body{font-family:"Livvic",Arial,sans-serif;color:#172033;-webkit-print-color-adjust:exact;print-color-adjust:exact}.budget-pdf{width:100%}.budget-pdf-head{position:relative;overflow:hidden;display:flex;align-items:center;justify-content:space-between;gap:7mm;padding:5.5mm 6mm 5mm;margin-bottom:3mm;border-radius:4.5mm;background:linear-gradient(118deg,#0b1424 0%,#142844 58%,#203c62 100%);color:#fff}.budget-pdf-head:after{content:"";position:absolute;right:-22mm;top:-28mm;width:72mm;height:72mm;border:8mm solid rgba(244,197,66,.13);border-radius:50%}.budget-pdf-brand{display:flex;align-items:center;gap:4mm;position:relative;z-index:1}.budget-pdf-logo{width:15mm;height:15mm;object-fit:contain;flex:0 0 auto}.budget-pdf-kicker{display:none}.budget-pdf-head h1{margin:0;font-size:20pt;line-height:1.02}.budget-pdf-sub{margin-top:1.1mm;font-size:7.8pt;color:#c9d5e7}.budget-pdf-stamp{position:relative;z-index:1;text-align:right;font-size:7pt;color:#c9d5e7;white-space:nowrap}.budget-pdf-stamp strong{display:block;color:#fff;font-size:9pt;margin-bottom:.7mm}.budget-pdf-summary{display:grid;grid-template-columns:1.45fr repeat(3,1fr);gap:2.2mm;margin-bottom:2.5mm}.budget-pdf-kpi{min-height:17mm;padding:3mm;border:1px solid #e1e7ef;border-radius:3.3mm;background:linear-gradient(145deg,#fff,#f7f9fc)}.budget-pdf-kpi span{display:block;color:#728096;font-size:6.5pt;text-transform:uppercase;letter-spacing:.07em;font-weight:700}.budget-pdf-kpi strong{display:block;margin-top:1mm;font-size:13pt;line-height:1;color:#172033}.budget-pdf-kpi.hero{background:linear-gradient(135deg,#fff8d9,#fff);border-color:#ecd36c;box-shadow:inset 0 0 0 .35mm rgba(216,170,42,.12)}.budget-pdf-kpi.hero strong{font-size:17pt;color:#8a6500}.budget-pdf-kpi.paid strong{color:#138a5a}.budget-pdf-kpi.pending strong{color:#cf4055}.budget-pdf-flight{margin:0 0 4mm;border:1px solid #e1e7ef;border-radius:4mm;overflow:hidden;break-inside:avoid}.budget-pdf-flight-head,.budget-pdf-distribution-head{display:flex;align-items:center;justify-content:space-between;padding:1.8mm 2.7mm;background:#f4f7fb;font-size:6.8pt;font-weight:900;text-transform:uppercase;letter-spacing:.06em;color:#4d5a70}.budget-pdf-flight table{width:100%;border-collapse:collapse;font-size:7.4pt}.budget-pdf-flight th,.budget-pdf-flight td{padding:2.1mm 2.4mm;border-top:1px solid #edf0f5;text-align:left}.budget-pdf-flight th{color:#748094;font-size:6.8pt;text-transform:uppercase;letter-spacing:.04em}.budget-pdf-distribution{margin-bottom:2.5mm;border:1px solid #e1e7ef;border-radius:3.3mm;overflow:hidden;break-inside:avoid}.budget-pdf-dist-body{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:1.4mm 4mm;padding:2mm 2.6mm}.budget-pdf-dist-row{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:1mm 2mm;align-items:center}.budget-pdf-dist-label{font-size:6.6pt;font-weight:800;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.budget-pdf-dist-value{font-size:6.6pt;font-weight:900}.budget-pdf-dist-track{grid-column:1/-1;height:1.6mm;border-radius:99px;background:#edf1f6;overflow:hidden}.budget-pdf-dist-fill{height:100%;border-radius:99px;background:var(--dist-color)}.budget-pdf-groups{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:2.4mm;align-items:start}.budget-pdf-group:last-child:nth-child(odd){grid-column:1/-1}.budget-pdf-group{border:1px solid #dfe5ed;border-radius:3.2mm;overflow:hidden;background:#fff;break-inside:avoid;page-break-inside:avoid}.budget-pdf-group-head{display:flex;align-items:center;justify-content:space-between;gap:3mm;padding:2mm 2.5mm;background:linear-gradient(100deg,var(--g1),var(--g2));color:var(--title-text,#fff);break-after:avoid;page-break-after:avoid}.budget-pdf-group-title{display:flex;align-items:center;gap:1.5mm;font-weight:900;font-size:8pt}.budget-pdf-group-icon{display:grid;place-items:center;width:5.7mm;height:5.7mm;border-radius:1.6mm;background:rgba(255,255,255,.16);font-size:8.5pt;overflow:hidden}.budget-pdf-group-icon-image{width:4.7mm;height:4.7mm;object-fit:contain}.budget-pdf-group-icon-image.emoji{width:auto;height:auto;font-size:8.5pt;line-height:1}.budget-pdf-group-total{text-align:right}.budget-pdf-group-total small{display:block;font-size:5.4pt;opacity:.8;text-transform:uppercase;letter-spacing:.08em}.budget-pdf-group-total strong{font-size:8.5pt}.budget-pdf-table{width:100%;border-collapse:collapse;table-layout:fixed}.budget-pdf-table thead{display:table-header-group}.budget-pdf-table th{padding:1.4mm 1.7mm;background:#f5f7fa;color:#758095;font-size:5.3pt;text-transform:uppercase;letter-spacing:.045em;text-align:left;border-bottom:1px solid #e5e9ef}.budget-pdf-table td{padding:1.5mm 1.7mm;border-top:1px solid #edf0f4;font-size:6.2pt;vertical-align:middle;break-inside:avoid;page-break-inside:avoid}.budget-pdf-table .concept{width:32%;font-weight:800}.budget-pdf-table .detail{width:32%;color:#667287}.budget-pdf-table .money{width:19%;text-align:right;font-weight:900;white-space:nowrap}.budget-pdf-table .status{width:17%;text-align:right}.budget-pdf-status{display:inline-block;padding:.7mm 1.2mm;border-radius:99px;font-size:5.2pt;font-weight:900;letter-spacing:.03em}.budget-pdf-status.paid{background:#dcf8eb;color:#08734a}.budget-pdf-status.unpaid{background:#ffe6ea;color:#b52d43}.budget-pdf-group-foot{display:flex;justify-content:flex-end;gap:3mm;padding:1.2mm 1.8mm;background:#fbfcfd;border-top:1px solid #edf0f4;font-size:5.7pt;color:#657085}.budget-pdf-group-foot strong{color:#172033}.budget-pdf-footer{display:flex;justify-content:space-between;gap:8mm;margin-top:2.5mm;padding-top:1.5mm;border-top:1px solid #e1e6ed;color:#8490a2;font-size:5.8pt}.budget-pdf-footer strong{color:#39465b}@media print{.budget-pdf-head,.budget-pdf-kpi,.budget-pdf-flight,.budget-pdf-distribution,.budget-pdf-group-head{-webkit-print-color-adjust:exact;print-color-adjust:exact}.budget-pdf-table tr{break-inside:avoid;page-break-inside:avoid}}
</style></head><body><main class="budget-pdf">${body}</main></body></html>`;
}
function openBudgetPrintable(title,body){
  const w=window.open('about:blank','_blank');if(!w){toast('Permite ventanas emergentes para generar el PDF.','error');return;}
  w.document.open();w.document.write(budgetPrintableShell(title,body));w.document.close();
  const launch=async()=>{try{await w.document.fonts?.ready;await Promise.all([...w.document.images].map(img=>img.complete?Promise.resolve():new Promise(r=>{img.onload=img.onerror=r;})));setTimeout(()=>{w.focus();w.print();},150);}catch{setTimeout(()=>{try{w.focus();w.print();}catch{}},250);}};
  if(w.document.readyState==='complete')launch();else w.addEventListener('load',launch,{once:true});
}
function generateBudgetPdf(){
  const cfg=state.data.settings,stats=budgetStats(),chart=donutData(),people=Math.max(1,num(cfg.people));
  const pdfLogoUrl=new URL("./icons/pdf-logo-white.png",location.href).href;
  const period=`${formatDate(cfg.departureDateTime.slice(0,10))} - ${formatDate(cfg.returnDateTime.slice(0,10))}`;
  const distribution=chart.groups.map(g=>`<div class="budget-pdf-dist-row"><span class="budget-pdf-dist-label">${esc(g.name)}</span><strong class="budget-pdf-dist-value">${formatMoney(g.value)} · ${g.percentage.toFixed(1)}%</strong><div class="budget-pdf-dist-track"><div class="budget-pdf-dist-fill" style="--dist-color:${esc(g.color||'#4da3ff')};width:${Math.max(2,g.percentage).toFixed(1)}%"></div></div></div>`).join('');
  const groups=(state.data.budget.groups||[]).map(group=>{
    const entries=effectiveBudgetEntries(group),total=sum(entries.map(e=>itemAmount(e.item))),paid=sum(entries.filter(e=>e.item.status==='paid'||(e.automatic&&e.item.autoType!=='extra')).map(e=>itemAmount(e.item))),pending=Math.max(0,total-paid);
    const rows=entries.map(({item,automatic})=>`<tr><td class="concept">${esc(item.name||'Concepto')}${automatic?'<br><small style="color:#8993a3;font-weight:600">Sincronizado automáticamente</small>':''}</td><td class="detail">${esc(item.detail||'—')}</td><td class="money">${formatMoney(itemAmount(item))}</td><td class="status"><span class="budget-pdf-status ${item.status==='paid'||(automatic&&item.autoType!=='extra')?'paid':'unpaid'}">${item.status==='paid'||(automatic&&item.autoType!=='extra')?'PAGADO':'PENDIENTE'}</span></td></tr>`).join('')||'<tr><td colspan="4" style="color:#8993a3">Sin conceptos</td></tr>';
    return `<section class="budget-pdf-group" style="--g1:${esc(group.gradient1||group.color||'#173b61')};--g2:${esc(group.gradient2||group.color||'#285f91')};--title-text:${esc(group.textColor||'#ffffff')}"><header class="budget-pdf-group-head"><div class="budget-pdf-group-title"><span class="budget-pdf-group-icon">${printableIconMarkup(group.icon||'•',group.iconUrl,'budget-pdf-group-icon-image')}</span><span>${esc(group.name||'Grupo')}</span></div><div class="budget-pdf-group-total"><small>Total grupo</small><strong>${formatMoney(total)}</strong></div></header><table class="budget-pdf-table"><thead><tr><th>Concepto</th><th>Detalle</th><th style="text-align:right">Importe</th><th style="text-align:right">Estado</th></tr></thead><tbody>${rows}</tbody></table><footer class="budget-pdf-group-foot"><span>Pagado <strong>${formatMoney(paid)}</strong></span><span>Pendiente <strong>${formatMoney(pending)}</strong></span></footer></section>`;
  }).join('');
  const body=`<header class="budget-pdf-head"><div class="budget-pdf-brand"><img class="budget-pdf-logo" src="${esc(pdfLogoUrl)}" alt=""><div><h1>Presupuesto del viaje</h1><div class="budget-pdf-sub">${esc(cfg.destination)} · ${esc(period)} · ${people} viajero${people===1?'':'s'}</div></div></div><div class="budget-pdf-stamp"><strong>${esc(cfg.appName)}</strong>Generado ${new Date().toLocaleString('es-ES')}</div></header><section class="budget-pdf-summary"><div class="budget-pdf-kpi hero"><span>Total previsto</span><strong>${formatMoney(stats.total)}</strong></div><div class="budget-pdf-kpi paid"><span>Pagado</span><strong>${formatMoney(stats.paid)}</strong></div><div class="budget-pdf-kpi pending"><span>Por pagar</span><strong>${formatMoney(stats.unpaid)}</strong></div><div class="budget-pdf-kpi"><span>Por persona</span><strong>${formatMoney(stats.total/people)}</strong></div></section>${distribution?`<section class="budget-pdf-distribution"><div class="budget-pdf-distribution-head"><span>Distribución del presupuesto</span><span>${chart.groups.length} categorías</span></div><div class="budget-pdf-dist-body">${distribution}</div></section>`:''}<div class="budget-pdf-groups">${groups}</div><footer class="budget-pdf-footer"><span>Documento generado desde los datos actuales de MFE Viajes.</span><strong>${esc(cfg.destination)} · ${esc(cfg.year||'')}</strong></footer>`;
  openBudgetPrintable('Presupuesto del viaje',body);
}

function menuPrintableShell(title,body,columns){
  const cfg=state.data.settings,pdfLogoUrl=new URL("./icons/pdf-logo-white.png",location.href).href,cols=Math.max(1,Math.min(5,Number(columns)||4));
  return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)}</title><link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Livvic:ital,wght@0,400;0,500;0,600;0,700;0,800;0,900;1,400;1,600&display=swap" rel="stylesheet"><style>
@page{size:A4 landscape;margin:6mm}html,body{margin:0!important;padding:0!important;background:#f4f2ea!important}*{box-sizing:border-box}body{font-family:"Livvic",Arial,sans-serif;color:#172033;-webkit-print-color-adjust:exact;print-color-adjust:exact}.menu-pdf-frame{width:285mm;height:198mm;overflow:hidden;background:linear-gradient(135deg,#f7f5ef 0%,#eef3f8 100%);position:relative}.menu-pdf-content{width:100%;height:auto;transform-origin:top left;padding:0}.menu-pdf-head{height:27mm;display:flex;align-items:center;justify-content:space-between;gap:7mm;padding:4.5mm 5mm;border-radius:4.5mm;background:linear-gradient(110deg,#0a1424,#1d3758);color:#fff;overflow:hidden;position:relative}.menu-pdf-head:after{content:"";position:absolute;right:-12mm;top:-30mm;width:72mm;height:72mm;border-radius:50%;border:10mm solid rgba(244,197,66,.13)}.menu-pdf-brand{display:flex;align-items:center;gap:3.5mm;position:relative;z-index:1}.menu-pdf-logo{width:17mm;height:17mm;object-fit:contain}.menu-pdf-kicker{font-size:6.8pt;text-transform:uppercase;letter-spacing:.16em;color:#f2cc5d;font-weight:900}.menu-pdf-head h1{margin:0;font-size:19pt;line-height:1}.menu-pdf-sub{font-size:7.8pt;color:#c9d6e9;margin-top:1.3mm}.menu-pdf-meta{position:relative;z-index:1;text-align:right;color:#d4deec;font-size:7.2pt}.menu-pdf-meta strong{display:block;color:#fff;font-size:9.5pt;margin-bottom:.7mm}.menu-pdf-grid{display:grid;grid-template-columns:repeat(var(--menu-cols),minmax(0,1fr));grid-auto-rows:minmax(0,1fr);gap:3mm;margin-top:3mm;height:159mm}.menu-pdf-day{min-width:0;overflow:hidden;border:1px solid #dce3ec;border-radius:4mm;background:#fff;box-shadow:0 1.2mm 4mm rgba(22,40,64,.07);display:flex;flex-direction:column}.menu-pdf-day-head{display:grid;grid-template-columns:13mm minmax(0,1fr);gap:2.2mm;align-items:center;padding:2.5mm 2.8mm;background:linear-gradient(110deg,color-mix(in srgb,var(--day-accent) 88%,#fff),color-mix(in srgb,var(--day-accent) 48%,#fff));color:#fff}.menu-pdf-date-badge{width:11mm;height:11mm;border-radius:3mm;background:rgba(255,255,255,.18);display:grid;place-items:center;font-weight:900;font-size:13pt;line-height:1}.menu-pdf-weekday{font-size:9.2pt;font-weight:900;text-transform:capitalize;line-height:1.05}.menu-pdf-date{font-size:6.6pt;opacity:.92;margin-top:.7mm}.menu-pdf-meals{display:grid;grid-template-rows:repeat(3,minmax(0,1fr));flex:1}.menu-pdf-meal{padding:2.2mm 2.8mm;border-top:1px solid #edf0f4;display:flex;flex-direction:column;justify-content:center;min-height:0}.menu-pdf-meal-label{display:flex;align-items:center;gap:1.3mm;color:#7e8999;font-size:5.8pt;font-weight:900;text-transform:uppercase;letter-spacing:.08em}.menu-pdf-meal-label i{width:2.2mm;height:2.2mm;border-radius:50%;background:var(--meal-color)}.menu-pdf-meal-value{margin-top:1.2mm;font-size:8pt;font-weight:800;line-height:1.16;color:#263348;overflow-wrap:anywhere}.menu-pdf-meal-value.empty{font-weight:500;color:#a0a9b7;font-style:italic}.menu-pdf-notes{padding:1.7mm 2.8mm;border-top:1px dashed #dfe4eb;background:#fbfcfd;color:#6d7889;font-size:6.1pt;line-height:1.2}.menu-pdf-foot{height:6mm;display:flex;align-items:end;justify-content:space-between;padding:1.4mm .5mm 0;color:#7c8798;font-size:6.4pt}.menu-pdf-foot strong{color:#354159}@media print{.menu-pdf-frame{width:285mm!important;height:198mm!important;overflow:hidden!important}.menu-pdf-content{transform-origin:top left!important}.menu-pdf-head,.menu-pdf-day{-webkit-print-color-adjust:exact;print-color-adjust:exact}}
</style></head><body><div class="menu-pdf-frame"><main class="menu-pdf-content"><header class="menu-pdf-head"><div class="menu-pdf-brand"><img class="menu-pdf-logo" src="${esc(pdfLogoUrl)}" alt=""><div><h1>${esc(title)}</h1><div class="menu-pdf-sub">${formatDate(cfg.departureDateTime.slice(0,10))} - ${formatDate(cfg.returnDateTime.slice(0,10))}</div></div></div><div class="menu-pdf-meta"><strong>${esc(cfg.appName)}</strong>${esc(String((state.data.menu?.days||[]).length))} días · ${esc(String(cfg.people||1))} viajeros</div></header><div class="menu-pdf-grid" style="--menu-cols:${cols}">${body}</div><footer class="menu-pdf-foot"><span>Generado ${new Date().toLocaleString('es-ES')}</span><strong>Menú del viaje · ${esc(cfg.destination)}</strong></footer></main></div></body></html>`;
}
function fitMenuPrint(doc){
  const frame=doc.querySelector('.menu-pdf-frame'),content=doc.querySelector('.menu-pdf-content');if(!frame||!content)return 1;
  content.style.transform='none';const fw=frame.clientWidth||1,fh=frame.clientHeight||1,cw=content.scrollWidth||1,ch=content.scrollHeight||1,scale=Math.min(1,fw/cw,fh/ch);content.style.transform=`scale(${scale})`;return scale;
}
function openMenuPrintable(title,body,columns){
  const w=window.open('about:blank','_blank');if(!w){toast('Permite ventanas emergentes para generar el PDF.','error');return;}
  w.document.open();w.document.write(menuPrintableShell(title,body,columns));w.document.close();
  const launch=async()=>{try{await w.document.fonts?.ready;await Promise.all([...w.document.images].map(img=>img.complete?Promise.resolve():new Promise(r=>{img.onload=img.onerror=r;})));fitMenuPrint(w.document);setTimeout(()=>{w.focus();w.print();},150);}catch{setTimeout(()=>{try{fitMenuPrint(w.document);w.focus();w.print();}catch{}},250);}};
  if(w.document.readyState==='complete')launch();else w.addEventListener('load',launch,{once:true});
}
function generateMenuPdf(){
  const days=[...(state.data.menu?.days||[])].sort((a,b)=>String(a.date).localeCompare(String(b.date)));if(!days.length){toast('Añade al menos un día al menú antes de exportar.','error');return;}
  const accents=['#c99a1b','#2474a8','#1f9278','#d05f52','#7459a8','#488756','#c47731','#516b8d','#8f5f7d','#2f8791'];
  const body=days.map((d,i)=>{const date=new Date(`${d.date}T12:00:00`),dayNum=Number.isNaN(date.getTime())?'':String(date.getDate()).padStart(2,'0'),weekday=Number.isNaN(date.getTime())?'Día':date.toLocaleDateString('es-ES',{weekday:'long'}),dateLabel=Number.isNaN(date.getTime())?d.date:date.toLocaleDateString('es-ES',{day:'2-digit',month:'long'}),meal=(label,value,color)=>`<div class="menu-pdf-meal"><div class="menu-pdf-meal-label"><i style="--meal-color:${color}"></i>${label}</div><div class="menu-pdf-meal-value ${String(value||'').trim()?'':'empty'}">${esc(String(value||'').trim()||'Por decidir')}</div></div>`,meals=[d.showBreakfast!==false?meal('Desayuno',d.breakfast,'#e4a44c'):'',d.showLunch!==false?meal('Comida',d.lunch,'#36a37c'):'',d.showDinner!==false?meal('Cena',d.dinner,'#5477c7'):''].filter(Boolean);return `<article class="menu-pdf-day" style="--day-accent:${accents[i%accents.length]}"><header class="menu-pdf-day-head"><div class="menu-pdf-date-badge">${esc(dayNum)}</div><div><div class="menu-pdf-weekday">${esc(weekday)}</div><div class="menu-pdf-date">${esc(dateLabel)}</div></div></header><div class="menu-pdf-meals" style="grid-template-rows:repeat(${Math.max(1,meals.length)},minmax(0,1fr))">${meals.join('')}</div>${String(d.notes||'').trim()?`<div class="menu-pdf-notes"><strong>Nota:</strong> ${esc(d.notes)}</div>`:''}</article>`;}).join('');
  const columns=days.length<=4?days.length:Math.min(5,Math.ceil(days.length/2));openMenuPrintable('Menú del viaje',body,columns);
}

function shoppingA6HeaderMarkup(title,total=shoppingTotal()){
  const cfg=state.data.settings,pdfLogoUrl=new URL("./icons/pdf-logo-white.png",location.href).href;
  return `<header class="a6-head"><div class="a6-brand"><img class="a6-brand-logo" src="${esc(pdfLogoUrl)}" alt=""><div><div class="a6-title">${esc(title)}</div><div class="a6-sub">${esc(cfg.destination)} · ${formatDate(cfg.departureDateTime.slice(0,10))} - ${formatDate(cfg.returnDateTime.slice(0,10))}</div></div></div><div class="a6-total">${formatMoney(total)}</div></header>`;
}
function shoppingA6Shell(title,body){
  const cfg=state.data.settings;
  return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)}</title><link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Livvic:ital,wght@0,400;0,500;0,600;0,700;0,800;0,900;1,400;1,600&display=swap" rel="stylesheet"><style>
@page{size:A6 portrait;margin:2mm}html,body{margin:0!important;padding:0!important;background:#fff!important}*{box-sizing:border-box}body{font-family:"Livvic",Arial,sans-serif;color:#172033;-webkit-print-color-adjust:exact;print-color-adjust:exact}.a6-fit-frame{width:100%;overflow:hidden;position:relative}.a6-fit-content{width:100%;height:auto;transform:none!important}.a6-head{height:10vw;display:flex;align-items:center;justify-content:space-between;gap:2vw;padding:1.2vw 1.7vw;background:linear-gradient(110deg,#0a1424,#1d3758);border-bottom:.65mm solid #efc947;margin-bottom:1vw;border-radius:1.8vw;overflow:hidden;position:relative;color:#fff}.a6-head:after{content:"";position:absolute;right:-7vw;top:-14vw;width:30vw;height:30vw;border-radius:50%;border:4vw solid rgba(244,197,66,.15)}.a6-brand{display:flex;align-items:center;gap:1.5vw;min-width:0;position:relative;z-index:1}.a6-brand-logo{width:6.4vw;height:6.4vw;object-fit:contain}.a6-title{font-weight:900;font-size:3.15vw;line-height:1;color:#fff}.a6-sub{font-size:1.45vw;color:#cbd7e7;margin-top:.55vw;white-space:nowrap}.a6-total{font-weight:900;font-size:2.9vw;white-space:nowrap;color:#f2ca52;position:relative;z-index:1}.shopping-a6-grid{display:block;width:100%}.shopping-a6-page{width:100%}.shopping-a6-page .a6-store{width:100%;margin:0 0 .7vw 0}.a6-store{border:.24mm solid #cfd7e4;border-radius:1.5vw;overflow:hidden;background:#fff;min-width:0}.a6-store-head{height:5vw;display:flex;align-items:center;gap:1.1vw;padding:.5vw .8vw;background:linear-gradient(90deg,var(--g1),var(--g2));color:var(--title-text,#fff);font-size:2.2vw;font-weight:900;white-space:nowrap}.a6-store-logo{width:15vw;max-width:42%;height:3.8vw;object-fit:contain;object-position:left center;filter:none}.a6-store-icon{font-size:3vw}.a6-table{width:100%;border-collapse:collapse;table-layout:fixed;font-size:1.9vw;line-height:1}.a6-table th,.a6-table td{border-top:.16mm solid #e3e7ee;padding:.22vw .38vw;vertical-align:middle}.a6-table th{background:#eef3fa;font-size:1.65vw;font-weight:800;white-space:nowrap}.a6-table .check{width:4vw;text-align:center}.a6-table .qty{width:9vw;text-align:right;white-space:nowrap}.a6-table .money{width:15vw;text-align:right;white-space:nowrap}.a6-product{font-weight:500;overflow-wrap:anywhere}.a6-table tr.done .a6-product{text-decoration:line-through;color:#737d8f}.a6-box{display:inline-grid;place-items:center;width:2.1vw;height:2.1vw;border:.25mm solid #64748b;border-radius:.5vw;font-size:1.25vw}.a6-total-row td{font-weight:900;background:#f8f2dc;padding:.22vw .38vw}.a6-foot{height:2vw;display:flex;align-items:end;justify-content:space-between;font-size:1.3vw;color:#7c8799;padding:.5vw .38vw 0}.a6-foot strong{color:#354056}.a6-empty{padding:2vw;font-size:2vw;color:#657085}
/* Todo usa unidades relativas al ancho de la hoja. Si el visor ignora A6 y abre A4, el contenido crece con la página en vez de quedarse como un A6 diminuto en la esquina. */
@media print{.a6-fit-frame,.a6-fit-content{width:100%!important;transform:none!important}.shopping-a6-page{break-inside:auto;page-break-inside:auto}.shopping-a6-page:not(:first-child){break-before:page;page-break-before:always}.a6-store{break-inside:auto;page-break-inside:auto}.a6-table thead{display:table-header-group}.a6-table tr{break-inside:avoid;page-break-inside:avoid}}
</style></head><body><div class="a6-fit-frame"><div class="a6-fit-content">${body}<footer class="a6-foot"><span>Generado ${new Date().toLocaleString('es-ES')}</span><strong>${esc(cfg.appName)}</strong></footer></div></div></body></html>`;
}
function fitShoppingA6(doc){
  // v2.1.66: ya no se aplica transform:scale(). El diseño es responsivo al
  // ancho real de la hoja y por eso ocupa toda la página tanto si el visor
  // respeta A6 como si abre por defecto un tamaño A mayor.
  const content=doc.querySelector('.a6-fit-content');if(content)content.style.transform='none';return 1;
}
function openShoppingA6(title,body){
  const w=window.open('about:blank','_blank');if(!w){toast('Permite ventanas emergentes para generar el PDF.','error');return;}
  w.document.open();w.document.write(shoppingA6Shell(title,body));w.document.close();
  const launch=async()=>{try{await w.document.fonts?.ready;await Promise.all([...w.document.images].map(img=>img.complete?Promise.resolve():new Promise(r=>{img.onload=img.onerror=r;})));fitShoppingA6(w.document);setTimeout(()=>{w.focus();w.print();},150);}catch{setTimeout(()=>{try{fitShoppingA6(w.document);w.focus();w.print();}catch{}},250);}};
  if(w.document.readyState==='complete')launch();else w.addEventListener('load',launch,{once:true});
}

function printableIconMarkup(icon='',iconUrl='',className='printable-title-icon'){
  const src=String(iconUrl||'').trim();
  if(src&&isImageSource(src))return `<img class="${esc(className)}" src="${esc(src)}" alt="">`;
  const fallback=String(icon||'').trim();
  return fallback?`<span class="${esc(className)} emoji">${esc(fallback)}</span>`:'';
}
function printableGroupStyle(start,end,textColor='#ffffff'){return ` style="--group-header-start:${esc(start||'#4da3ff')};--group-header-end:${esc(end||start||'#285f91')};--group-title-text:${esc(textColor||'#ffffff')}"`;}

function suitcasePrintableShell(title,body,columns=1){
  const cfg=state.data.settings;
  const pdfLogoUrl=new URL("./icons/pdf-logo-white.png",location.href).href;
  const cols=Math.max(1,Number(columns)||1);
  return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)}</title><link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Livvic:ital,wght@0,400;0,500;0,600;0,700;0,800;0,900;1,400;1,600&display=swap" rel="stylesheet"><style>
@page{size:A4 portrait;margin:6mm}html,body{margin:0!important;padding:0!important;background:#fff!important;width:198mm!important;height:285mm!important;overflow:hidden!important}*{box-sizing:border-box}body{font-family:"Livvic",Arial,sans-serif;color:#172033;-webkit-print-color-adjust:exact;print-color-adjust:exact}.suitcase-frame{width:198mm;height:285mm;overflow:hidden;position:relative;background:#fff}.suitcase-content{width:198mm;transform-origin:top left}.suitcase-head{display:flex;align-items:center;justify-content:space-between;gap:5mm;background:linear-gradient(110deg,#efbf28 0%,#ffdd67 100%);border-bottom:1mm solid #102b4c;padding:3mm 4mm 2.8mm;margin:0 0 2.6mm;border-radius:3.5mm;overflow:hidden;position:relative;color:#10213a}.suitcase-head:after{content:"";position:absolute;right:-11mm;top:-24mm;width:58mm;height:58mm;border-radius:50%;border:8mm solid rgba(15,42,75,.16)}.suitcase-brand{display:flex;align-items:center;gap:2.6mm;min-width:0;position:relative;z-index:1}.suitcase-brand-logo{width:12.5mm;height:12.5mm;object-fit:contain;display:block;flex:0 0 auto;background:#102b4c;border-radius:2.7mm;padding:1.3mm;box-shadow:inset 0 0 0 .3mm rgba(255,255,255,.12)}.suitcase-head h1{margin:0;color:#10213a;font-size:14pt;line-height:1.05}.suitcase-destination{color:#28425f;margin-top:.8mm;font-size:7.2pt;font-weight:600}.suitcase-summary{font-size:7.4pt;font-weight:800;color:#102b4c;white-space:nowrap;position:relative;z-index:1}.suitcase-grid{display:grid;grid-template-columns:repeat(var(--suitcase-cols),minmax(0,1fr));gap:2.4mm;align-items:start;width:100%}.suitcase-group{min-width:0;border:.25mm solid #dbe1ea;border-radius:2.2mm;overflow:hidden;background:#fff;break-inside:avoid;page-break-inside:avoid}.suitcase-group h2{margin:0;padding:1.8mm 2.1mm;background:linear-gradient(90deg,var(--group-header-start,#4da3ff),var(--group-header-end,#285f91));color:var(--group-title-text,#fff);font-size:9pt;line-height:1.05;display:flex;align-items:center;gap:1.4mm}.suitcase-group-title-icon{width:4.8mm;height:4.8mm;object-fit:contain;flex:0 0 4.8mm}.suitcase-group-title-icon.emoji{width:auto;height:auto;font-size:9pt;line-height:1}.suitcase-group h3{margin:0;padding:1.2mm 1.8mm;background:var(--subgroup-header,#f5f7fa);color:var(--subgroup-title-text,#354056);border-top:.18mm solid color-mix(in srgb,var(--subgroup-header,#e5e9f0) 72%,#aab4c2);font-size:7pt;line-height:1.05;display:flex;align-items:center;gap:1.2mm}.suitcase-subgroup-title-icon{width:3.7mm;height:3.7mm;object-fit:contain;flex:0 0 3.7mm}.suitcase-subgroup-title-icon.emoji{width:auto;height:auto;font-size:7pt;line-height:1}.suitcase-row{display:grid;grid-template-columns:3.7mm minmax(0,1fr);gap:1.2mm;padding:.85mm 1.8mm;border-top:.18mm solid #edf0f5;align-items:start;font-size:6.6pt;line-height:1.1;break-inside:avoid;page-break-inside:avoid}.suitcase-box{width:2.8mm;height:2.8mm;border:.36mm solid #64748b;border-radius:.65mm;display:grid;place-items:center;font-size:5.8pt;line-height:1}.suitcase-row.done .suitcase-name{text-decoration:line-through;color:#728096}.suitcase-foot{display:flex;justify-content:space-between;gap:4mm;margin-top:2mm;padding-top:1.2mm;border-top:.22mm solid #e6eaf0;color:#7c8799;font-size:6.1pt}.suitcase-foot strong{color:#354056}@media print{html,body{width:198mm!important;height:285mm!important;overflow:hidden!important}.suitcase-frame{width:198mm!important;height:285mm!important;overflow:hidden!important}.suitcase-content{width:198mm!important;transform-origin:top left!important}.suitcase-grid{width:100%!important}.suitcase-group{break-inside:avoid!important;page-break-inside:avoid!important}}
</style></head><body><div class="suitcase-frame"><main class="suitcase-content"><header class="suitcase-head"><div class="suitcase-brand"><img class="suitcase-brand-logo" src="${esc(pdfLogoUrl)}" alt=""><div><h1>${esc(title)}</h1><div class="suitcase-destination">${esc(cfg.destination)} · ${formatDate(cfg.departureDateTime.slice(0,10))} - ${formatDate(cfg.returnDateTime.slice(0,10))}</div></div></div><div class="suitcase-summary">${cols} categor${cols===1?'ía':'ías'} · ${esc(String(cfg.people||1))} viajeros</div></header><div class="suitcase-grid" style="--suitcase-cols:${cols}">${body}</div><footer class="suitcase-foot"><span>Generado ${new Date().toLocaleString('es-ES')}</span><strong>${esc(cfg.appName)}</strong></footer></main></div></body></html>`;
}
function fitSuitcasePrint(doc){
  // v2.3.16: el PDF de maletas se compone sobre una única hoja A4 vertical real.
  // Se mide el contenido dentro de esa hoja física y solo se reduce si su altura
  // supera el área imprimible. Así Android no desplaza la fila de categorías a
  // una segunda página ni escala todo contra el viewport de la previsualización.
  const frame=doc.querySelector('.suitcase-frame'),content=doc.querySelector('.suitcase-content');
  if(!frame||!content)return 1;
  content.style.transform='none';
  content.style.width='198mm';
  const fw=frame.clientWidth||1,fh=frame.clientHeight||1,cw=content.scrollWidth||1,ch=content.scrollHeight||1;
  const scale=Math.min(1,fw/cw,fh/ch);
  content.style.transform=`scale(${scale})`;
  return scale;
}
function openSuitcasePrintable(title,body,columns){
  const w=window.open('about:blank','_blank');if(!w){toast('Permite ventanas emergentes para generar el PDF.','error');return;}
  w.document.open();w.document.write(suitcasePrintableShell(title,body,columns));w.document.close();
  const launch=async()=>{try{await w.document.fonts?.ready;await Promise.all([...w.document.images].map(img=>img.complete?Promise.resolve():new Promise(r=>{img.onload=img.onerror=r;})));fitSuitcasePrint(w.document);setTimeout(()=>{w.focus();w.print();},150);}catch{setTimeout(()=>{try{fitSuitcasePrint(w.document);w.focus();w.print();}catch{}},250);}};
  if(w.document.readyState==='complete')launch();else w.addEventListener('load',launch,{once:true});
}
function generateSuitcasePdf(key){
  const labels={common:'Maleta común',mikel:'Maleta de Mikel',nerea:'Maleta de Nerea'};
  const groups=state.data.suitcases[key]||[];
  const body=groups.map(g=>{
    const buckets=suitcaseGroupBuckets(g);
    const gColor=g.color||'#4da3ff',gText=g.textColor||'#ffffff',gEnd=`color-mix(in srgb, ${gColor} 45%, #111)`;
    const groupIcon=printableIconMarkup(g.icon||'🧳',g.iconUrl,'suitcase-group-title-icon');
    const subgroupHtml=buckets.map(bucket=>{
      const showSubgroups=(g.subgroups||[]).length>0;
      const subgroupIcon=printableIconMarkup(bucket.icon||'',bucket.iconUrl||'','suitcase-subgroup-title-icon');
      const header=showSubgroups?`<h3 style="--subgroup-header:${esc(bucket.color||gColor)};--subgroup-title-text:${esc(bucket.textColor||gText)}">${subgroupIcon}<span>${esc(bucket.name||'General')}</span></h3>`:'';
      const rows=bucket.items.map(entry=>{const i=entry.item;return `<div class="suitcase-row ${i.checked?'done':''}"><span class="suitcase-box">${i.checked?'✓':''}</span><span class="suitcase-name">${esc(i.name)}</span></div>`;}).join('');
      return `${header}${rows}`;
    }).join('');
    return `<section class="suitcase-group"${printableGroupStyle(gColor,gEnd,gText)}><h2>${groupIcon}<span>${esc(g.name)}</span></h2>${subgroupHtml}</section>`;
  }).join('');
  openSuitcasePrintable(labels[key]||'Maleta',body,Math.max(1,groups.length));
}
function generateShoppingPdf(){
  const stores=state.data.shopping.stores.filter(s=>s.active!==false);
  const body=`<div class="shopping-a6-grid">${stores.map(store=>{
    const logo=isImageSource(store.logoUrl)?`<img class="a6-store-logo" src="${esc(store.logoUrl)}" alt="Logo ${esc(store.name)}">`:`<span class="a6-store-icon">${esc(store.icon||'🛒')}</span>`;
    const rows=(store.products||[]).map(p=>`<tr class="${p.checked?'done':''}"><td class="check"><span class="a6-box">${p.checked?'✓':''}</span></td><td class="a6-product">${esc(p.name)}</td><td class="qty">${num(p.quantity).toLocaleString('es-ES')}</td><td class="money">${formatMoney(p.unitPrice)}</td><td class="money"><strong>${formatMoney(num(p.quantity)*num(p.unitPrice))}</strong></td></tr>`).join('');
    return `<section class="shopping-a6-page">${shoppingA6HeaderMarkup('Lista de la compra',storeTotal(store))}<section class="a6-store" style="--g1:${esc(store.gradient1||store.color||'#173b61')};--g2:${esc(store.gradient2||store.color||store.gradient1||'#285f91')};--title-text:${esc(store.textColor||'#ffffff')}"><div class="a6-store-head">${logo}<span>${esc(store.name)}</span></div><table class="a6-table"><thead><tr><th class="check">✓</th><th>Producto</th><th class="qty">Uds.</th><th class="money">Precio/u</th><th class="money">Total</th></tr></thead><tbody>${rows||'<tr><td colspan="5" class="a6-empty">Sin productos</td></tr>'}</tbody><tfoot><tr class="a6-total-row"><td colspan="4">Total ${esc(store.name)}</td><td class="money">${formatMoney(storeTotal(store))}</td></tr></tfoot></table></section></section>`;
  }).join('')}</div>`;
  openShoppingA6('Lista de la compra',body);
}


function googleCalendarUrl(task){
  if(!task?.dueAt)return "";
  const start=new Date(task.dueAt);if(Number.isNaN(start.getTime()))return "";
  const end=new Date(start.getTime()+Math.max(15,num(task.durationMinutes)||30)*60000);
  const stamp=d=>d.toISOString().replace(/[-:]/g,"").replace(/\.\d{3}Z$/,"Z");
  const details=[task.description||"",task.responsible?`Responsable: ${task.responsible}`:"",task.url?`Documento: ${task.url}`:""].filter(Boolean).join("\n\n");
  const url=new URL("https://calendar.google.com/calendar/render");
  url.searchParams.set("action","TEMPLATE");url.searchParams.set("text",task.title||"Tarea del viaje");url.searchParams.set("dates",`${stamp(start)}/${stamp(end)}`);url.searchParams.set("details",details);
  if(task.location)url.searchParams.set("location",task.location);
  return url.href;
}
function renderTasks(){const items=state.data.tasks.items||[];return `${lockedBanner()}${pageHead('Tareas','Preparación del viaje con responsables, fechas y recordatorios',`<button class="btn secondary" data-enable-notifications>🔔 Activar avisos</button>${canEdit()?'<button class="btn primary canary-action-btn" data-add-task>＋ Tarea</button>':''}`)}<div class="task-list">${items.map((t,i)=>`<article class="card task-card ${t.completed?'task-complete':''}" data-sort-item="task|${i}"><div class="card-body"><div class="task-main"><input type="checkbox" data-task-toggle="${i}" ${t.completed?'checked':''} ${roleCanEdit()?'':'disabled'}><div><h3>${esc(t.title)}</h3><p>${esc(t.description||'')}</p><div class="task-meta"><span>👤 ${esc(t.responsible||'Ambos')}</span><span>📅 ${t.dueAt?formatDate(t.dueAt,{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'}):'Sin fecha'}</span><span>🔔 ${num(t.reminderMinutes)||0} min antes</span>${t.location?`<span>📍 ${esc(t.location)}</span>`:''}</div><div class="page-actions">${isValidUrl(t.url)?safeLink(t.url,'Abrir documento','📎'):''}${t.dueAt?`<button class="link-btn" data-task-calendar="${i}">📅 ${t.calendarAddedAt?'Abrir de nuevo en Calendar':'Añadir a Google Calendar'}</button>`:''}</div></div>${canEdit()?`<div class="row-actions">${sortDragHandle(`task|${i}`,'Arrastrar tarea')}<button class="mini-btn" data-task-edit="${i}">✎</button><button class="mini-btn" data-task-delete="${i}">×</button></div>`:''}</div></div></article>`).join('')||'<div class="empty">No hay tareas.</div>'}</div>`;}
binders.tasks=()=>{
  $$('[data-add-task]').forEach(b=>b.onclick=()=>editTask());
  $$('[data-task-edit]').forEach(b=>b.onclick=()=>editTask(num(b.dataset.taskEdit)));
  $$('[data-task-delete]').forEach(b=>b.onclick=async()=>{if(!confirmAction('¿Eliminar esta tarea?'))return;state.data.tasks.items.splice(num(b.dataset.taskDelete),1);await saveSection('tasks');render();});
  $$('[data-task-move]').forEach(b=>b.onclick=async()=>{const[i,d]=b.dataset.taskMove.split(':').map(num);moveArrayItem(state.data.tasks.items,i,d);await saveSection('tasks');render();});
  $$('[data-task-toggle]').forEach(b=>b.onchange=async()=>{if(!roleCanEdit())return;state.data.tasks.items[num(b.dataset.taskToggle)].completed=b.checked;await saveSection('tasks');render();});
  $$('[data-task-calendar]').forEach(b=>b.onclick=async()=>{const task=state.data.tasks.items[num(b.dataset.taskCalendar)],url=googleCalendarUrl(task);if(!url){toast('Añade primero una fecha y hora a la tarea.','error');return;}window.open(url,'_blank','noopener');task.calendarAddedAt=new Date().toISOString();await saveSection('tasks');render();});
  $$('[data-enable-notifications]').forEach(b=>b.onclick=enableNotifications);
};
function editTask(index=null){const current=index===null?{title:'',description:'',responsible:'Ambos',dueAt:'',durationMinutes:30,location:'',completed:false,reminderMinutes:60,url:''}:state.data.tasks.items[index];openForm({title:index===null?'Añadir tarea':'Editar tarea',fields:[{name:'title',label:'Tarea',required:true,full:true},{name:'description',label:'Descripción',type:'textarea',full:true},{name:'responsible',label:'Responsable',type:'select',options:['Mikel','Nerea','Ambos']},{name:'dueAt',label:'Fecha y hora',type:'datetime-local'},{name:'durationMinutes',label:'Duración (minutos)',type:'number',step:'5'},{name:'location',label:'Ubicación',full:true},{name:'reminderMinutes',label:'Avisar minutos antes',type:'number',step:'1'},{name:'url',label:'Documento o enlace',type:'url',full:true,driveSelect:true},{name:'completed',label:'Completada',type:'checkbox',full:true}],values:current,onSubmit:async v=>{const dueMs=v.dueAt?new Date(v.dueAt).getTime():0;const value={id:current.id||uid('task'),...current,...v,notifyAt:dueMs?dueMs-(num(v.reminderMinutes)||0)*60000:0,notifiedAt:v.completed?(current.notifiedAt||new Date().toISOString()):''};if(index===null)state.data.tasks.items.push(value);else state.data.tasks.items[index]=value;await saveSection('tasks');scheduleTaskNotifications();render();}});}
function notificationPermissionInfo(){
  if(!('Notification' in window))return {key:'unsupported',label:'No compatible',tone:'bad'};
  if(Notification.permission==='granted')return {key:'granted',label:'Permitido',tone:'good'};
  if(Notification.permission==='denied')return {key:'denied',label:'Bloqueado',tone:'bad'};
  return {key:'default',label:'No solicitado',tone:'warn'};
}
function notificationStatusBadge(label,tone='neutral'){return `<span class="notification-status ${esc(tone)}">${esc(label)}</span>`;}
function currentVapidKey(){return String(document.querySelector('#settings-notifications [name="pushVapidKey"]')?.value||state.data.settings.pushVapidKey||'').trim();}
async function copyToClipboard(value){
  if(!value)throw new Error('No hay ningún token para copiar.');
  if(navigator.clipboard?.writeText){await navigator.clipboard.writeText(value);return;}
  const area=document.createElement('textarea');area.value=value;area.style.position='fixed';area.style.opacity='0';document.body.append(area);area.select();const ok=document.execCommand('copy');area.remove();if(!ok)throw new Error('No se pudo copiar automáticamente.');
}
async function runNotificationDiagnostics({silent=false}={}){
  const d=state.notificationDiagnostics;d.checked=true;d.secure=window.isSecureContext===true;d.notifications='Notification' in window;d.permission=d.notifications?Notification.permission:'unsupported';d.serviceWorker='serviceWorker' in navigator;d.swStatus=d.serviceWorker?'Comprobando…':'No compatible';
  if(d.serviceWorker){try{const reg=await navigator.serviceWorker.ready;d.swStatus=reg.active?'Activo y listo':'Registrado, pendiente';}catch(error){d.swStatus=`Error: ${error.message}`;}}
  d.vapid=Boolean(currentVapidKey());d.firebase=state.provider instanceof FirebaseProvider;
  if(d.firebase){try{d.fcmSupported=await state.provider.messagingSupported();}catch(error){d.fcmSupported=false;d.lastMessage=error.message;}}
  else d.fcmSupported=false;
  if(state.activeTab==='settings'&&state.settingsPanel==='notifications')render();
  if(!silent)toast('Diagnóstico de notificaciones actualizado.');
  return d;
}
async function requestNotificationPermission(){
  if(!('Notification' in window)){toast('Este navegador no admite notificaciones.','error');return;}
  try{
    const permission=await Notification.requestPermission();
    state.data.settings.pushEnabled=permission==='granted';await saveSection('settings');
    state.notificationDiagnostics.lastMessage=permission==='granted'?'Permiso concedido.':'El permiso no fue concedido.';
    scheduleTaskNotifications();await runNotificationDiagnostics({silent:true});
    toast(permission==='granted'?'Permiso de notificaciones concedido.':'No se concedió el permiso. Revisa los permisos del sitio.',permission==='granted'?'success':'error');
  }catch(error){state.notificationDiagnostics.lastMessage=error.message;toast(error.message,'error');}
}
async function testLocalNotification(){
  try{
    if(!window.isSecureContext)throw new Error('Las notificaciones requieren HTTPS o localhost.');
    if(!('Notification' in window))throw new Error('Este navegador no admite notificaciones.');
    if(Notification.permission!=='granted')throw new Error('Primero pulsa «Solicitar permiso».');
    if(!('serviceWorker' in navigator))throw new Error('El navegador no admite service workers.');
    const registration=await navigator.serviceWorker.ready;
    await registration.showNotification('MFE Viajes · prueba local',{body:'La notificación local funciona correctamente en este dispositivo.',icon:state.data.settings.appIconUrl||'./icons/app-icon.svg',badge:'./icons/notification-badge.svg',tag:`mfe-local-test-${Date.now()}`,data:{url:'./#tasks'},renotify:true});
    state.notificationDiagnostics.lastMessage='Notificación local enviada correctamente.';await runNotificationDiagnostics({silent:true});toast('Notificación local enviada.');
  }catch(error){state.notificationDiagnostics.lastMessage=error.message;toast(error.message,'error');if(state.activeTab==='settings')render();}
}
async function generateAndCopyFcmToken(){
  try{
    if(!(state.provider instanceof FirebaseProvider))throw new Error('FCM solo está disponible cuando la app está conectada a Firebase.');
    if(Notification.permission!=='granted')throw new Error('Primero concede el permiso de notificaciones.');
    const vapidKey=currentVapidKey();if(!vapidKey)throw new Error('Introduce y guarda la clave pública VAPID.');
    if(canEdit()&&vapidKey!==state.data.settings.pushVapidKey){state.data.settings.pushVapidKey=vapidKey;await saveSection('settings');}
    const token=await state.provider.enablePush(vapidKey);state.notificationDiagnostics.token=token;state.notificationDiagnostics.lastMessage='Token FCM generado, registrado y copiado.';
    state.data.settings.pushEnabled=true;await saveSection('settings');await copyToClipboard(token);scheduleTaskNotifications();await runNotificationDiagnostics({silent:true});toast('Token FCM generado y copiado.');
  }catch(error){state.notificationDiagnostics.lastMessage=error.message;toast(error.message,'error');if(state.activeTab==='settings')render();}
}
async function copyCurrentFcmToken(){try{await copyToClipboard(state.notificationDiagnostics.token);toast('Token copiado.');}catch(error){toast(error.message,'error');}}
async function enableNotifications(){
  await requestNotificationPermission();
  if(!('Notification' in window)||Notification.permission!=='granted')return;
  const vapidKey=state.data.settings.pushVapidKey;
  if(state.provider instanceof FirebaseProvider&&vapidKey){await generateAndCopyFcmToken();}
  else toast('Avisos locales activados. Configura VAPID para recibir push con la app cerrada.');
}
function scheduleTaskNotifications(){state.notificationTimers.forEach(clearTimeout);state.notificationTimers=[];if(!('Notification' in window)||!state.data.settings.pushEnabled||Notification.permission!=='granted')return;for(const t of state.data.tasks.items||[]){if(t.completed||!t.dueAt)continue;const when=new Date(t.dueAt).getTime()-(num(t.reminderMinutes)||0)*60000;const delay=when-Date.now();if(delay>0&&delay<2147483647)state.notificationTimers.push(setTimeout(async()=>{try{const registration=await navigator.serviceWorker.ready;await registration.showNotification(t.title,{body:t.description||`Tarea prevista para ${formatDate(t.dueAt)}`,icon:state.data.settings.appIconUrl||'./icons/app-icon.svg',badge:'./icons/notification-badge.svg',data:{url:'./#tasks'},tag:`task-${t.id||t.title}`});}catch(error){console.warn('No se pudo mostrar el recordatorio local',error);}},delay));}}

function renderEmergency(){const e=state.data.emergency;return `${lockedBanner()}${pageHead('Información de emergencia','Contactos rápidos y documentos oficiales',canEdit()?'<button class="btn primary canary-action-btn" data-add-emergency-contact>＋ Contacto</button>':'')}<div class="emergency-grid">${(e.contacts||[]).map((c,i)=>`<article class="card emergency-card" style="--em-color:${esc(c.color||'#4da3ff')};--em-g1:${esc(c.gradient1||c.color||'#173b61')};--em-g2:${esc(c.gradient2||c.color||'#285f91')};--em-title-text:${esc(c.textColor||'#ffffff')}"><div class="emergency-card-accent"></div><div class="card-body"><div class="flight-top"><span class="emergency-icon">${iconMarkup(c.icon||'☎️',c.iconUrl,'emergency-icon-image')}</span>${canEdit()?`<div class="row-actions"><button class="mini-btn" data-edit-emergency="${i}">✎</button><button class="mini-btn" data-delete-emergency="${i}">×</button></div>`:''}</div><h3>${esc(c.title)}</h3><p>${esc(c.subtitle||'')}</p><div class="page-actions">${c.phone?safeLink(`tel:${c.phone}`,'Llamar','☎'):''}${safeLink(mapsDirectionsUrl(c.address,c.mapsUrl),'Cómo llegar',googleMapsIconMarkup(),'maps-route-link')}${safeLink(c.url,'Abrir','↗')}</div></div></article>`).join('')}</div>${renderOfficialDocuments('mikel','Documentos oficiales Mikel')}${renderOfficialDocuments('nerea','Documentos oficiales Nerea')}`;}
function renderOfficialDocuments(person,title){
  const docs=state.data.emergency.documents[person]||[];
  const defaults=person==='mikel'?{gradient1:'#184f68',gradient2:'#257b91',textColor:'#ffffff'}:{gradient1:'#4e2768',gradient2:'#754198',textColor:'#ffffff'};
  const header={...defaults,...(state.data.settings.officialDocumentHeaders?.[person]||{})};
  return `<section class="official-section card"><div class="section-title official-section-title" style="--g1:${esc(header.gradient1)};--g2:${esc(header.gradient2)};--official-title-text:${esc(header.textColor)};background:linear-gradient(110deg,${esc(header.gradient1)},${esc(header.gradient2)});color:${esc(header.textColor)}"><span>🪪 ${esc(title)}</span>${canEdit()?`<button class="mini-btn" data-add-official="${person}">＋</button>`:''}</div><div class="official-grid">${docs.map((doc,i)=>{
    const files=visibleFiles(doc.files||[]),slide=Math.min(state.documentSlides[doc.id]||0,Math.max(0,files.length-1)),file=files[slide];
    const imageSrc=file?.type==='image'?officialImageSource(file):'';
    const driveImage=Boolean(file&&officialFileDriveId(file));
    const fileUrl=file?officialFileOpenUrl(file):'';
    return `<article class="official-card" data-sort-item="official|${encodeURIComponent(person)}|${i}" style="--doc-color:${esc(doc.color||'#4da3ff')}"><div class="official-head"><span>${esc(doc.icon||'📄')} ${esc(doc.title)}</span>${canEdit()?`<div class="row-actions">${sortDragHandle(`official|${encodeURIComponent(person)}|${i}`,'Arrastrar documento')}<button class="mini-btn action-clip" data-manage-official-files data-official-person="${esc(person)}" data-official-doc-id="${esc(doc.id)}" title="Archivos de Google Drive" aria-label="Archivos de Google Drive">📎</button><button class="mini-btn" data-edit-official="${person}:${i}">✎</button><button class="mini-btn" data-delete-official="${person}:${i}">×</button></div>`:''}</div><div class="official-preview">${file?(file.type==='image'?`<div class="official-image-frame ${driveImage?'is-loading':''}"><img src="${esc(imageSrc||TRANSPARENT_IMAGE)}" data-image-popup="${esc(imageSrc||TRANSPARENT_IMAGE)}" data-original-alt="${esc(file.label)}" data-official-image="1" data-official-person="${esc(person)}" data-official-doc-id="${esc(doc.id)}" data-official-file-id="${esc(file.id)}" alt="${esc(file.label)}"><div class="official-drive-loading">Cargando desde Google Drive…</div><div class="official-image-error"><span>La imagen necesita autorización de Google Drive.</span><button class="btn small secondary" type="button" data-repair-official-image data-official-person="${esc(person)}" data-official-doc-id="${esc(doc.id)}" data-official-file-id="${esc(file.id)}">${driveIconMarkup()} Cargar desde Drive</button></div></div>`:`<div class="pdf-preview" data-file-popup="${esc(fileUrl)}" data-file-title="${esc(doc.title)}">${pdfFileIconMarkup('pdf-preview-icon')}<span>${esc(file.label)}</span><small>Abrir desde Google Drive</small></div>`):'<div class="image-placeholder">Sin archivos</div>'}</div><div class="official-controls"><button class="mini-btn" data-official-slide="${doc.id}:-1" ${slide===0?'disabled':''}>‹</button><span>${files.length?`${slide+1}/${files.length} · ${esc(file?.label||'')}`:'0/0'}</span><button class="mini-btn" data-official-slide="${doc.id}:1" ${slide>=files.length-1?'disabled':''}>›</button></div></article>`;
  }).join('')}</div></section>`;
}
function openOfficialFilesManager(person,docId){
  const current=findOfficialDocument(person,docId);if(!current){toast('No se ha encontrado la ficha seleccionada.','error');return;}
  const stablePerson=String(person),stableDocId=String(current.id);
  openFilesManager(current.files||[],async(files,meta={})=>{
    const target=findOfficialDocument(stablePerson,stableDocId);
    if(!target)throw new Error('La ficha seleccionada ya no existe o no tiene identificador.');
    target.files=normalizeFileList(files);
    const saved=await saveSection('emergency');
    if(!saved)throw new Error('No se han podido guardar los archivos de esta ficha.');
    if(!meta.keepOpen)render();
    return true;
  },`${current.title} · ${person==='mikel'?'Mikel':'Nerea'} · Google Drive`,{
    autoSave:true,
    driveOnly:true,
    storeDriveLinks:true
  });
}
binders.emergency=()=>{$$('[data-add-emergency-contact]').forEach(b=>b.onclick=()=>editEmergencyContact());$$('[data-edit-emergency]').forEach(b=>b.onclick=()=>editEmergencyContact(num(b.dataset.editEmergency)));$$('[data-delete-emergency]').forEach(b=>b.onclick=async()=>{if(!confirmAction('¿Eliminar este contacto de emergencia?'))return;state.data.emergency.contacts.splice(num(b.dataset.deleteEmergency),1);await saveSection('emergency');render();});$$('[data-add-official]').forEach(b=>b.onclick=()=>editOfficialDocument(b.dataset.addOfficial));$$('[data-edit-official]').forEach(b=>b.onclick=()=>{const[p,i]=b.dataset.editOfficial.split(':');editOfficialDocument(p,num(i));});$$('[data-delete-official]').forEach(b=>b.onclick=async()=>{const[p,i]=b.dataset.deleteOfficial.split(':');if(!confirmAction('¿Eliminar este documento oficial y sus enlaces asociados?'))return;state.data.emergency.documents[p].splice(num(i),1);await saveSection('emergency');render();});$$('[data-official-move]').forEach(b=>b.onclick=async()=>{const[p,i,d]=b.dataset.officialMove.split(':');moveArrayItem(state.data.emergency.documents[p],num(i),num(d));await saveSection('emergency');render();});$$('[data-official-slide]').forEach(b=>b.onclick=()=>{const[id,d]=b.dataset.officialSlide.split(':');state.documentSlides[id]=Math.max(0,(state.documentSlides[id]||0)+num(d));render();});$$('[data-manage-official-files]').forEach(b=>b.onclick=()=>openOfficialFilesManager(b.dataset.officialPerson,b.dataset.officialDocId));$$('[data-repair-official-image]').forEach(b=>b.onclick=async()=>{try{b.disabled=true;await repairOfficialImage(b.dataset.officialPerson,b.dataset.officialDocId,b.dataset.officialFileId,{interactive:true});toast('Imagen cargada desde Google Drive.');}catch(error){toast(error.message,'error');b.disabled=false;}});};
function editEmergencyContact(index=null){const current=index===null?{title:'',subtitle:'',phone:'',address:'',mapsUrl:'',url:'',icon:'☎️',iconUrl:'',color:'#4da3ff',gradient1:'#173b61',gradient2:'#285f91',textColor:'#ffffff'}:state.data.emergency.contacts[index];openForm({title:index===null?'Añadir contacto':'Editar contacto',fields:[{name:'title',label:'Nombre',required:true},{name:'icon',label:'Emoji alternativo'},{name:'iconUrl',label:'URL del icono',type:'url',full:true},{name:'iconFile',label:'Subir imagen para el icono',type:'file',accept:'image/*',full:true},{name:'subtitle',label:'Descripción',full:true},{name:'phone',label:'Teléfono'},{name:'address',label:'Dirección',full:true},{name:'mapsUrl',label:'Enlace Google Maps',type:'url',full:true},{name:'url',label:'Web o documento',type:'url',full:true,driveSelect:true},{name:'color',label:'Color de acento',type:'color'},{name:'gradient1',label:'Degradado inicio',type:'color'},{name:'gradient2',label:'Degradado fin',type:'color'},{name:'textColor',label:'Color del texto del título',type:'color'}],values:{textColor:'#ffffff',...current},onSubmit:async v=>{if(v.iconFile)v.iconUrl=await fileToSquareDataUrl(v.iconFile);delete v.iconFile;const value={id:current.id||uid('emergency'),...current,...v};if(index===null)state.data.emergency.contacts.push(value);else state.data.emergency.contacts[index]=value;await saveSection('emergency');render();}});}
function editOfficialDocument(person,index=null){const current=index===null?{title:'',icon:'📄',color:'#4da3ff',files:[]}:state.data.emergency.documents[person][index];openForm({title:index===null?'Añadir documento oficial':'Editar documento oficial',fields:[{name:'title',label:'Documento',required:true},{name:'icon',label:'Icono'},{name:'color',label:'Color',type:'color'}],values:current,onSubmit:async v=>{const value={id:current.id||uid('official'),files:current.files||[],...current,...v};if(index===null)state.data.emergency.documents[person].push(value);else state.data.emergency.documents[person][index]=value;await saveSection('emergency');render();}});}

function trackerIconEditorFields(){
  return [
    {name:'titleIcon',label:'Icono del seguimiento · emoji alternativo'},
    {name:'titleIconUrl',label:'Icono del seguimiento · PNG / Google Drive',type:'url',full:true,driveImage:true,driveImageSize:128,help:'Selecciona un PNG desde Google Drive o una imagen compatible. La app la convierte a PNG 128×128 y la guarda dentro de la configuración, conservando la transparencia.'},
    {name:'titleIconFile',label:'Icono del seguimiento · subir archivo local',type:'file',accept:'image/png,image/jpeg,image/webp,image/svg+xml',full:true,help:'PNG recomendado. También se aceptan JPG, WebP y SVG y se convierten automáticamente a PNG.'}
  ];
}
async function applyTrackerIconEditorValues(target,values={},fallback='📡'){
  if(!target)return;
  let iconUrl=String(values.titleIconUrl??target.titleIconUrl??'').trim();
  if(values.titleIconFile)iconUrl=await fileToSquareDataUrl(values.titleIconFile,128);
  else if(iconUrl)iconUrl=await stabilizeDriveIconUrl(iconUrl,128);
  target.titleIcon=String(values.titleIcon??target.titleIcon??fallback).trim()||fallback;
  target.titleIconUrl=iconUrl;
}
function trackerTitleIconMarkup(id,fallback='📡'){
  const cfg=state.data.trackers?.[id]||{},url=String(cfg.titleIconUrl||'');
  if(isImageSource(url))return `<img class="tracker-title-icon-image" src="${esc(url)}" alt="" loading="lazy">`;
  return `<span class="tracker-title-icon-emoji">${esc(cfg.titleIcon||TRACKER_DEFAULT_ICONS[id]||fallback)}</span>`;
}
function editTrackerTitleIcon(id){
  const tracker=state.data.trackers?.[id];if(!tracker)return;const fallback=TRACKER_DEFAULT_ICONS[id]||'📡';
  openForm({title:`Icono de ${tracker.title||id}`,fields:trackerIconEditorFields(),values:{titleIcon:tracker.titleIcon||fallback,titleIconUrl:tracker.titleIconUrl||''},onSubmit:async v=>{await applyTrackerIconEditorValues(tracker,v,fallback);delete v.titleIconFile;await saveSection('trackers');render();toast('Icono del seguimiento actualizado como PNG.');}});
  addModalResetButton('↺ Restaurar icono',()=>{setModalFormValue('titleIcon',fallback);setModalFormValue('titleIconUrl','');setModalFormValue('titleIconFile','');});
}

async function resetTrackerTitleIcon(id){const tracker=state.data.trackers?.[id];if(!tracker)return;tracker.titleIcon=TRACKER_DEFAULT_ICONS[id]||'📡';tracker.titleIconUrl='';await saveSection('trackers');render();toast('Icono predeterminado restaurado.');}
function trackerSummaryData(id){
  const tracker=state.data.trackers?.[id]||{};
  let current=0,reserved=0;
  if(id==='autoreisen'){
    const liveRow=autoreisenCurrentFleetRow(tracker);
    current=num(liveRow?.total||tracker.currentPrice);
    reserved=num(trackerBudgetReference('autoreisen',tracker).total||tracker.reservedPrice);
  }else if(id==='cordial'){
    const clubTarget=cordialPreferredClubTarget(tracker);
    current=num(clubTarget?.price||tracker.currentPrice);
    reserved=num(trackerBudgetReference('cordial',tracker).total||tracker.reservedPrice);
  }else if(id==='vueling'){
    current=num(tracker.currentPrice);
    reserved=num(vuelingBudgetReference(tracker).total||tracker.reservedPrice);
  }
  const difference=current>0&&reserved>0?current-reserved:null;
  return {current,reserved,difference};
}
function trackerSummaryUpdatedLabel(id){
  const tracker=state.data.trackers?.[id]||{};
  const stamps=id==='autoreisen'?[tracker.fleetLastCheckedAt,tracker.lastUpdated].filter(Boolean):[tracker.lastUpdated].filter(Boolean);const stamp=stamps.sort((a,b)=>(Date.parse(b)||0)-(Date.parse(a)||0))[0]||'';
  if(!stamp)return '—';
  return formatDate(stamp,{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'});
}
function autoreisenFleetRowsFromState(a={}){
  const catalog=new Map();
  for(const row of (Array.isArray(a.fleetCatalog)?a.fleetCatalog:[])){
    const key=autoreisenFleetKey(row);if(key)catalog.set(key,{...row});
  }
  let source=(Array.isArray(a.fleetPrices)?a.fleetPrices:[]).filter(row=>num(row?.total)>0);
  if(!source.length){
    const history=[...(Array.isArray(a.fleetPriceHistory)?a.fleetPriceHistory:[])].filter(snap=>Array.isArray(snap?.fleet)&&snap.fleet.some(row=>num(row?.total)>0)).sort((x,y)=>Date.parse(y?.date||0)-Date.parse(x?.date||0));
    if(history[0])source=history[0].fleet;
  }
  if(!source.length)source=[...catalog.values()].filter(row=>num(row?.total)>0);
  const rows=[];
  for(const raw of source){
    const key=autoreisenFleetKey(raw),meta=catalog.get(key)||{};
    const row={...meta,...raw,imageUrl:String(raw?.imageUrl||meta?.imageUrl||'').trim(),carId:String(raw?.carId||meta?.carId||'').trim(),availability:String(raw?.availability||meta?.availability||'Disponible')};
    if(row.group&&row.model&&num(row.total)>0&&!rows.some(x=>autoreisenFleetKey(x)===key))rows.push(row);
  }
  // Nunca reutilizamos una misma foto para modelos distintos: si el parser anterior
  // dejó una imagen duplicada (p. ej. el Arona en toda la flota), se conserva solo
  // en el modelo configurado o, en su defecto, en la primera coincidencia.
  const byImage=new Map();
  for(const row of rows){const url=String(row.imageUrl||'').trim();if(!url)continue;if(!byImage.has(url))byImage.set(url,[]);byImage.get(url).push(row);}
  for(const group of byImage.values()){if(group.length<2)continue;const keep=group.find(row=>autoreisenFleetKey(row)===autoreisenFleetKey({group:a.group,model:a.model}))||group[0];for(const row of group)if(row!==keep)row.imageUrl='';}
  return rows.sort((x,y)=>num(x.total)-num(y.total));
}
function autoreisenSummaryFleetMiniMarkup(a={}){
  const allRows=autoreisenFleetRowsFromState(a),rows=autoreisenVisibleFleetRows(a,allRows);
  if(!rows.length)return '';
  return `<div class="tracker-summary-fleet"><div class="tracker-summary-fleet-head"><span>${esc(autoreisenFleetSelectionLabel(a))}</span><strong>${rows.length} coche${rows.length===1?'':'s'}</strong></div><div class="tracker-summary-fleet-grid">${rows.map(row=>`<span class="tracker-summary-fleet-row"><small>Grupo ${esc(row.group||'—')}</small><b>${esc(row.model||'Vehículo')}</b><strong>${formatMoney(num(row.total))}</strong></span>`).join('')}</div></div>`;
}
function cordialIsClubRate(row={}){
  const rate=cordialNorm(row?.rateName||''),room=cordialNorm(row?.roomType||'');
  return rate.includes('club cordial')||room.includes('club cordial');
}
function cordialIsOnlyAccommodation(row={}){return cordialNorm(row?.board||'').includes('solo alojamiento');}
function cordialIsReservationOnline(row={}){
  const rate=cordialNorm(row?.rateName||''),room=cordialNorm(row?.roomType||'');
  return (rate.includes('reserva online')||room.includes('reserva online'))&&!rate.includes('prepago')&&!room.includes('prepago');
}
function cordialHasAdvanceCancellation(row={}){
  // En BeCordial la tarifa «Club Cordial - Reserva Online» es la opción flexible
  // sin gastos que queremos usar en todos los resúmenes. Algunas lecturas antiguas
  // arrastraron por error el texto «Cancelación con gastos» de la tarifa anterior.
  if(cordialIsReservationOnline(row))return true;
  const cancellation=cordialNorm(row?.cancellation||'');
  if(/no reembolsable|con gastos/.test(cancellation))return false;
  return /cancelacion anticipada|cancelacion gratuita|reembolsable|sin gastos|cancelacion/.test(cancellation);
}
function cordialHasCancellationFees(row={}){
  if(cordialIsReservationOnline(row))return false;
  const cancellation=cordialNorm(row?.cancellation||''),rate=cordialNorm(row?.rateName||'');
  return /cancelacion con gastos|con gastos|gastos de cancelacion/.test(cancellation)||/cancelacion con gastos|con gastos/.test(rate);
}
function cordialCancellationLabel(row={}){
  if(cordialIsReservationOnline(row))return 'Cancelación sin gastos';
  return String(row?.cancellation||'').trim();
}
function cordialClubOptions(a={}){return (Array.isArray(a?.options)?a.options:[]).filter(cordialIsClubRate);}
function cordialClubSummaryOptions(a={}){
  const base=cordialClubOptions(a).filter(cordialIsOnlyAccommodation);
  // Siempre que exista, el resumen usa «Reserva Online · Solo alojamiento»
  // (la tercera tarifa de cada bloque en el motor actual), no la Prepago.
  const flexible=base.filter(cordialIsReservationOnline);
  if(flexible.length)return flexible;
  const withoutFees=base.filter(cordialHasAdvanceCancellation);
  return withoutFees.length?withoutFees:base;
}
function cordialPreferredClubTarget(a={}){
  const options=cordialClubSummaryOptions(a);if(!options.length)return null;
  const targetRoom=cordialNorm(a?.targetRoom||'Classic Duplex');
  const ranked=options.map(row=>{const room=cordialNorm(row?.roomType||'');let score=0;if(targetRoom&&room.includes(targetRoom))score+=200;if(cordialIsReservationOnline(row))score+=160;if(cordialHasAdvanceCancellation(row))score+=60;return {row,score,price:num(row?.price)||Number.POSITIVE_INFINITY};});
  ranked.sort((x,y)=>y.score-x.score||x.price-y.price);return ranked[0]?.row||null;
}
function cordialSummaryRoomRows(a={}){
  const options=cordialClubSummaryOptions(a),groups=new Map();
  for(const row of options){
    let room=String(row?.roomType||'Alojamiento').trim()||'Alojamiento';
    if(/^(club cordial\s*-|tarifa club cordial|oferta .*online|reserva online)/i.test(room))room='Alojamiento sin clasificar';
    if(!groups.has(room))groups.set(room,[]);groups.get(room).push(row);
  }
  return [...groups.entries()].map(([room,rows])=>{const prices=rows.map(x=>num(x?.price)).filter(x=>x>0);return {room,rows,price:prices.length?Math.min(...prices):0};}).sort((x,y)=>(x.price||999999)-(y.price||999999)||x.room.localeCompare(y.room,'es'));
}
function cordialSummaryRoomsMiniMarkup(a={}){
  const rooms=cordialSummaryRoomRows(a);if(!rooms.length)return '';
  return `<div class="tracker-summary-rooms"><div class="tracker-summary-fleet-head"><span>Club Cordial · cancelación sin gastos</span><strong>${rooms.length} tipo${rooms.length===1?'':'s'}</strong></div><div class="tracker-summary-room-grid">${rooms.map(item=>`<span class="tracker-summary-room-row"><b>${esc(item.room)}</b><small>${item.rows.length} tarifa${item.rows.length===1?'':'s'} · cancelación sin gastos</small><strong>${item.price>0?formatMoney(item.price):'—'}</strong></span>`).join('')}</div></div>`;
}
function trackerSearchStamp(id,tracker={}){
  const stamps=id==='autoreisen'?[tracker.fleetLastCheckedAt,tracker.lastUpdated].filter(Boolean):[tracker.lastUpdated].filter(Boolean);
  return stamps.sort((a,b)=>(Date.parse(b)||0)-(Date.parse(a)||0))[0]||'';
}
function trackerSearchDateMarkup(id,tracker={}){
  const stamp=trackerSearchStamp(id,tracker);if(!stamp)return '<div class="tracker-search-date"><span>🔎 Búsqueda</span><strong>—</strong></div>';
  return `<div class="tracker-search-date"><span>🔎 Búsqueda</span><strong>${esc(formatDate(stamp,{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'}))}</strong></div>`;
}
function cordialRoomTypesCompactMarkup(a={}){
  const rooms=cordialSummaryRoomRows(a);if(!rooms.length)return '<p class="help-text">Todavía no hay tarifas Club Cordial leídas.</p>';
  return `<div class="cordial-room-types-grid">${rooms.map(item=>`<div class="cordial-room-type-card"><div><strong>${esc(item.room)}</strong><small>${item.rows.length} tarifa${item.rows.length===1?'':'s'} · Club Cordial · sin gastos</small></div><b>${item.price>0?formatMoney(item.price):'—'}</b></div>`).join('')}</div>`;
}
function trackerSummarySearchRange(id,tracker={}){
  let start='',end='';
  if(id==='autoreisen'){start=tracker.pickupAt||'';end=tracker.dropoffAt||'';}
  else if(id==='cordial'){start=tracker.checkIn||'';end=tracker.checkOut||'';}
  else if(id==='vueling'){start=tracker.departureDate||'';end=tracker.returnDate||'';}
  const startDate=String(start||'').slice(0,10),endDate=String(end||'').slice(0,10);
  if(!startDate&&!endDate)return 'Fechas pendientes';
  const startYear=startDate.slice(0,4),endYear=endDate.slice(0,4),showYear=Boolean(startYear&&endYear&&startYear!==endYear);
  const opts=showYear?{day:'2-digit',month:'short',year:'numeric'}:{day:'2-digit',month:'short'};
  const from=startDate?formatDate(startDate,opts):'—',to=endDate?formatDate(endDate,opts):'—';
  return `${from} → ${to}`;
}
function trackerSummaryPill(id,context='trackers'){
  const cfg=state.data.trackers?.[id]||{},data=trackerSummaryData(id),title=cfg.title||(id==='autoreisen'?'AutoReisen':id==='cordial'?'Cordial':id==='vueling'?'Vueling':id);
  const diffClass=data.difference===null?'':data.difference<0?'is-better':data.difference>0?'is-worse':'is-same';
  const updatedLabel=trackerSummaryUpdatedLabel(id);
  const updatedTitle=updatedLabel==='—'?`Sin búsqueda automática guardada para ${title}`:`Última búsqueda de ${title}: ${updatedLabel}`;
  const searchRange=trackerSummarySearchRange(id,cfg);
  const rangeTitle=`Periodo que utiliza ${title}: ${searchRange}`;
  const refresh=roleCanEdit()?`<button type="button" class="tracker-summary-refresh" data-tracker-summary-refresh="${esc(id)}" title="Actualizar ${esc(title)} ahora" aria-label="Actualizar ${esc(title)} ahora">↻</button>`:'';
  const tools=`<div class="tracker-summary-tools"><span class="tracker-summary-meta tracker-summary-updated" title="${esc(updatedTitle)}" aria-label="${esc(updatedTitle)}"><small>Última búsqueda</small><span class="tracker-summary-meta-value">${esc(updatedLabel)}</span></span><span class="tracker-summary-meta tracker-summary-range" title="${esc(rangeTitle)}" aria-label="${esc(rangeTitle)}"><small>Periodo</small><span class="tracker-summary-meta-value">${esc(searchRange)}</span></span>${refresh}</div>`;
  const mainAttr=context==='cover'?`data-cover-tracker-open="${esc(id)}"`:`data-tracker-summary-target="${esc(id)}"`;
  const fleetExtra=id==='autoreisen'?autoreisenSummaryFleetMiniMarkup(cfg):'';
  const roomExtra=id==='cordial'?cordialSummaryRoomsMiniMarkup(cfg):'';
  const wideClass=id==='autoreisen'?'tracker-summary-pill-autoreisen':id==='cordial'&&roomExtra?'tracker-summary-pill-cordial':'';
  return `<article class="tracker-summary-pill ${wideClass}" style="--tracker-color:${esc(cfg.color||'#4da3ff')};--tracker-g1:${esc(cfg.gradient1||cfg.color||'#173b61')};--tracker-g2:${esc(cfg.gradient2||cfg.color||'#285f91')};--tracker-title-text:${esc(cfg.textColor||'#ffffff')}" ><div class="tracker-summary-main" ${mainAttr} role="button" tabindex="0" title="Ir a ${esc(title)}"><div class="tracker-summary-topbar"><div class="tracker-summary-pill-head"><span class="tracker-summary-pill-icon">${trackerTitleIconMarkup(id,TRACKER_DEFAULT_ICONS[id]||'📡')}</span><strong>${esc(title)}</strong></div>${tools}</div><div class="tracker-summary-pill-values"><span><small>Actual</small><b>${data.current>0?formatMoney(data.current):'—'}</b></span><span><small>Reservado</small><b>${data.reserved>0?formatMoney(data.reserved):'—'}</b></span><span class="tracker-summary-diff ${diffClass}"><small>Diferencia</small><b>${data.difference===null?'—':signedMoney(data.difference)}</b></span></div>${fleetExtra}${roomExtra}</div></article>`;
}
function trackerSummaryStrip(context='trackers'){
  const ids=['autoreisen','cordial','vueling'].filter(id=>state.data.trackers?.visible?.[id]!==false);
  return ids.length?`<div class="tracker-summary-strip ${context==='cover'?'is-cover':''}">${ids.map(id=>trackerSummaryPill(id,context)).join('')}</div>`:'';
}
function trackerCard(id,title,icon,content,actions=''){const cfg=state.data.trackers[id]||{};return `<article class="card tracker-card" data-tracker-card="${id}" data-sort-item="tracker|${encodeURIComponent(id)}" style="--tracker-color:${esc(cfg.color||'#4da3ff')};--tracker-g1:${esc(cfg.gradient1||cfg.color||'#173b61')};--tracker-g2:${esc(cfg.gradient2||cfg.color||'#285f91')};--tracker-title-text:${esc(cfg.textColor||'#ffffff')}"><div class="section-title" style="--g1:var(--tracker-g1);--g2:var(--tracker-g2);--title-text:var(--tracker-title-text)"><span class="tracker-title-label"><span class="tracker-title-icon">${trackerTitleIconMarkup(id,icon)}</span>${esc(title)}</span>${canEdit()?`<div class="row-actions">${sortDragHandle(`tracker|${encodeURIComponent(id)}`,'Arrastrar bloque')}<button class="mini-btn" data-tracker-toggle="${id}" title="Ocultar bloque" aria-label="Ocultar bloque">◉</button></div>`:''}</div><div class="card-body">${content}<div class="page-actions" style="margin-top:14px">${actions}</div></div></article>`;}
function haversineKm(lat1,lon1,lat2,lon2){
  const rad=v=>v*Math.PI/180,R=6371;const dLat=rad(lat2-lat1),dLon=rad(lon2-lon1);
  const a=Math.sin(dLat/2)**2+Math.cos(rad(lat1))*Math.cos(rad(lat2))*Math.sin(dLon/2)**2;
  return 2*R*Math.asin(Math.sqrt(a));
}
function fuelStationKey(x){return normalizedKey(`${x.name}|${x.address}|${x.municipality}`);}
function fuelOrigin(){
  if(state.currentLocation)return state.currentLocation;
  const lat=Number.parseFloat(String(state.data.settings.weatherLatitude||'').replace(',','.'));
  const lon=Number.parseFloat(String(state.data.settings.weatherLongitude||'').replace(',','.'));
  return Number.isFinite(lat)&&Number.isFinite(lon)?{latitude:lat,longitude:lon,label:'alojamiento'}:null;
}
function fuelRowsCalculated(){
  const f=state.data.trackers.fuel,origin=fuelOrigin(),litres=Math.max(0,num(state.data.settings.fuelExpectedLitres)),consumption=Math.max(0,num(state.data.settings.carConsumption));
  const rows=(f.stations||[]).map(x=>{
    const lat=num(x.latitude),lon=num(x.longitude),distance=origin&&lat&&lon?haversineKm(origin.latitude,origin.longitude,lat,lon):null;
    const travelFuel=distance==null?0:(distance*2*consumption/100);
    return {...x,distance,realCost:litres*num(x.price)+travelFuel*num(x.price),favorite:(f.favorites||[]).includes(fuelStationKey(x))};
  });
  const sort=state.fuelSort||'price';
  rows.sort((a,b)=>sort==='distance'?(a.distance??9999)-(b.distance??9999):sort==='realCost'?a.realCost-b.realCost:a.price-b.price);
  const radius=Math.max(0,num(state.data.settings.fuelRadiusKm));
  return origin&&radius?rows.filter(x=>x.distance==null||x.distance<=radius):rows;
}
function renderFuelTrackerCard(){
  const f=state.data.trackers.fuel,rows=fuelRowsCalculated(),prices=rows.map(x=>num(x.price)).filter(Boolean),min=prices.length?Math.min(...prices):0,avg=prices.length?sum(prices)/prices.length:0;
  const best=rows.slice().sort((a,b)=>a.realCost-b.realCost)[0];
  const controls=`<select class="compact-select" data-fuel-sort><option value="price" ${state.fuelSort==='price'?'selected':''}>Ordenar por precio</option><option value="distance" ${state.fuelSort==='distance'?'selected':''}>Ordenar por distancia</option><option value="realCost" ${state.fuelSort==='realCost'?'selected':''}>Mejor opción real</option></select><button class="btn secondary" data-fuel-location>⌖ Usar ubicación actual</button>`;
  const tableRows=rows.map(x=>`<tr><td><button class="mini-btn ${x.favorite?'favorite-active':''}" data-fuel-favorite="${esc(fuelStationKey(x))}">${x.favorite?'★':'☆'}</button></td><td><strong>${esc(x.name)}</strong><small class="price-updated">${esc(x.address||'')}</small></td><td>${esc(x.municipality)}</td><td class="amount fuel-price">${formatNumberEs(x.price,3)} €/l</td><td>${x.distance==null?'—':`${formatNumberEs(x.distance,1)} km`}</td><td class="amount fuel-price">${formatMoney(x.realCost)}</td><td>${esc(x.hours||'')}</td><td>${safeLink(mapsDirectionsUrl(`${x.latitude},${x.longitude}`),'Cómo llegar',googleMapsIconMarkup(),'maps-route-link')}</td></tr>`).join('');
  const content=`<div class="tracker-kpis"><div><span>Más barata</span><strong class="fuel-price">${min?`${formatNumberEs(min,3)} €/l`:'—'}</strong></div><div><span>Precio medio</span><strong class="fuel-price">${avg?`${formatNumberEs(avg,3)} €/l`:'—'}</strong></div><div><span>Mejor coste real</span><strong>${best?formatMoney(best.realCost):'—'}</strong></div><div><span>Estaciones</span><strong>${rows.length}</strong></div></div><div class="page-actions fuel-controls">${controls}</div><div class="tracker-run-progress-wrap" data-tracker-run-progress="fuel">${trackerRunProgressMarkup('fuel')}</div><div id="fuel-map" class="fuel-map"></div><p class="help-text fuel-list-help">Se muestran unas 10 estaciones a la vez. Desliza la lista para consultar el resto.</p><div class="fuel-table-scroll"><div class="table-wrap"><table class="fuel-table"><thead><tr><th>★</th><th>Estación</th><th>Municipio</th><th>Precio</th><th>Distancia</th><th>Coste real</th><th>Horario</th><th></th></tr></thead><tbody>${tableRows||'<tr><td colspan="8" class="empty">Pulsa Actualizar para cargar precios oficiales.</td></tr>'}</tbody></table></div></div>`;
  return trackerCard('fuel',f.title||'Gasolineras · Gran Canaria','⛽',content,`<button class="btn secondary" data-refresh-tracker="fuel">↻ Actualizar</button><button class="btn secondary" data-edit-tracker="fuel">⚙️ Configurar</button>`);
}

function autoreisenNextCheck(a){
  if(a.enabled===false)return 'Monitor desactivado';
  return 'Automática diaria: 07:30 · Las comprobaciones manuales no cambian este horario';
}
function autoreisenHistoryMarkup(a){
  const rows=(a.history||[]).slice(-8).reverse();
  return rows.length?`<div class="autoreisen-history">${rows.map(x=>`<div><span>${esc(formatDate(x.date,{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'}))}</span><strong>${formatMoney(x.price)}</strong></div>`).join('')}</div>`:'<p class="help-text">Todavía no hay histórico de precios.</p>';
}
function autoreisenControlMarkup(a){
  const status=state.autoreisenControlStatus;
  const editDisabled=canEdit()?'':'disabled';
  const automationDisabled=canManageAutomations()?'':'disabled';
  const secretStatus=status?.telegramSecrets===null?'No se pueden comprobar los secretos':status?.telegramSecrets?(status.telegramSecrets.bot&&status.telegramSecrets.chat?'Credenciales Telegram detectadas':'Faltan secretos de Telegram'):'Sin comprobar';
  const installStatus=status?status.installed?'Automatización instalada':'Automatización pendiente':'Sin comprobar';
  return `<details class="autoreisen-control" data-autoreisen-control>
    <summary><span>⚙️ Centro de control AutoReisen</span><span class="autoreisen-summary-badges"><b class="status-pill ${a.enabled===false?'off':'on'}">Monitor ${a.enabled===false?'OFF':'ON'}</b><b class="status-pill ${a.telegramEnabled===false?'off':'on'}">Telegram ${a.telegramEnabled===false?'OFF':'ON'}</b></span></summary>
    <div class="autoreisen-control-body">
      <div class="autoreisen-control-grid">
        <article class="autoreisen-control-panel"><h4>Monitor</h4>
          <label class="switch-row"><span><strong>Monitor AutoReisen</strong><small>Activa o pausa las comprobaciones automáticas.</small></span><input type="checkbox" data-autoreisen-field="enabled" ${a.enabled!==false?'checked':''} ${editDisabled}></label>
          <div class="control-field"><span>Programación automática</span><strong>Todos los días · 06:30</strong><small>Hora de España peninsular (Europe/Madrid). “Comprobar ahora” es independiente y no retrasa la siguiente comprobación automática.</small></div>
          <p class="control-next-check">${esc(autoreisenNextCheck(a))}</p>
        </article>
        <article class="autoreisen-control-panel"><h4>Telegram</h4>
          <label class="switch-row"><span><strong>Alertas por Telegram</strong><small>El monitor sigue funcionando aunque Telegram esté apagado.</small></span><input type="checkbox" data-autoreisen-field="telegramEnabled" ${a.telegramEnabled!==false?'checked':''} ${editDisabled}></label>
          <div class="telegram-alert-options">
            <label><input type="checkbox" data-autoreisen-field="telegramNotifyEveryCheck" ${a.telegramNotifyEveryCheck!==false?'checked':''} ${editDisabled}> Resultado de cada comprobación</label>
            <label><input type="checkbox" data-autoreisen-field="telegramNotifyPriceDrop" ${a.telegramNotifyPriceDrop!==false?'checked':''} ${editDisabled}> Baja de precio</label>
            <label><input type="checkbox" data-autoreisen-field="telegramNotifyBelowReserved" ${a.telegramNotifyBelowReserved!==false?'checked':''} ${editDisabled}> Precio inferior a la reserva</label>
            <label><input type="checkbox" data-autoreisen-field="telegramNotifyAvailability" ${a.telegramNotifyAvailability!==false?'checked':''} ${editDisabled}> Cambio de disponibilidad</label>
            <label><input type="checkbox" data-autoreisen-field="telegramNotifyError" ${a.telegramNotifyError!==false?'checked':''} ${editDisabled}> Errores del monitor</label>
            <label><input type="checkbox" data-autoreisen-field="telegramNotifyRecovery" ${a.telegramNotifyRecovery!==false?'checked':''} ${editDisabled}> Recuperación tras error</label>
          </div>
          <div class="telegram-thresholds"><label class="control-field"><span>Bajada mínima (€)</span><input type="number" min="0" step="0.01" data-autoreisen-number="telegramMinDropAmount" value="${esc(num(a.telegramMinDropAmount||0))}" ${editDisabled}></label><label class="control-field"><span>Bajada mínima (%)</span><input type="number" min="0" step="0.1" data-autoreisen-number="telegramMinDropPercent" value="${esc(num(a.telegramMinDropPercent||0))}" ${editDisabled}></label></div>
          <p class="help-text">“Resultado de cada comprobación” envía siempre el precio, diferencia frente a la reserva, tendencia, periodo y disponibilidad. Las demás opciones añaden alertas especiales.</p><p class="help-text">Con ambos límites de bajada a 0, Telegram avisa ante cualquier descenso. Si indicas límites, la bajada debe cumplirlos.</p>
        </article>
      </div>
      <div class="autoreisen-control-status"><div><span>Automatización</span><strong>${esc(installStatus)}</strong></div><div><span>Telegram</span><strong>${esc(secretStatus)}</strong></div><div><span>Última consulta</span><strong>${a.lastUpdated?esc(formatDate(a.lastUpdated,{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'})):'—'}</strong></div><div><span>Último error</span><strong class="${a.lastError?'error-text':''}">${esc(a.lastError||'Ninguno')}</strong></div></div>
      <div class="page-actions autoreisen-control-actions">
        <button type="button" class="btn primary" data-autoreisen-save ${editDisabled}>Guardar y sincronizar</button>
        <button type="button" class="btn secondary" data-autoreisen-run>▶ Comprobar ahora</button>
        <button type="button" class="btn secondary" data-autoreisen-telegram-test>✈ Probar Telegram</button>
        <button type="button" class="btn secondary" data-autoreisen-status>✓ Comprobar sistema</button>
        <button type="button" class="btn secondary" data-autoreisen-history-refresh>↻ Actualizar histórico</button>
        <button type="button" class="btn ghost" data-autoreisen-install ${automationDisabled}>↻ Instalar/actualizar automatización</button>
      </div>
      <div class="tracker-run-progress-wrap" data-tracker-run-progress="autoreisen">${trackerRunProgressMarkup('autoreisen')}</div>
      <p class="help-text">Comprobar ahora, Probar Telegram, Comprobar sistema, Actualizar histórico e Instalar/actualizar automatización funcionan aunque la edición esté bloqueada para usuarios con permisos de edición. Para cambiar ajustes o guardar sí debes desbloquear la edición.</p>
      <p class="help-text">La instalación automática actualiza el monitor y su workflow mediante el puente seguro de Cloudflare. No guarda tokens de GitHub ni de Telegram en MFE Viajes.</p>
      <details class="autoreisen-history-box"><summary>Histórico reciente</summary>${autoreisenHistoryMarkup(a)}</details>
    </div>
  </details>`;
}
function autoreisenFleetKey(row={}){return `${String(row.group||'').trim()}\u0000${String(row.model||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/\s+/g,' ').trim()}`;}
function autoreisenFleetVisibleGroups(a={}){return [...new Set((Array.isArray(a.fleetTrackGroups)?a.fleetTrackGroups:[]).map(x=>String(x||'').trim()).filter(Boolean))];}
function autoreisenFleetSelectionLabel(a={}){if(a.fleetTrackAll!==false)return 'Todas visibles';const groups=autoreisenFleetVisibleGroups(a);return groups.length?groups.map(x=>`Grupo ${x}`).join(' · '):`Grupo ${a.group||'—'}`;}
function autoreisenVisibleFleetRows(a={},rows=[]){const source=Array.isArray(rows)?rows:[];if(a.fleetTrackAll!==false)return source;const wanted=new Set(autoreisenFleetVisibleGroups(a));if(!wanted.size&&a.group)wanted.add(String(a.group));return source.filter(row=>wanted.has(String(row?.group||'').trim()));}
function autoreisenPreviousFleetPrice(a,row){const key=autoreisenFleetKey(row),history=[...(Array.isArray(a.fleetPriceHistory)?a.fleetPriceHistory:[])].sort((x,y)=>Date.parse(y?.date||0)-Date.parse(x?.date||0));let skippedCurrent=false;for(const snap of history){const match=(snap?.fleet||[]).find(x=>autoreisenFleetKey(x)===key&&num(x.total)>0);if(!match)continue;if(!skippedCurrent&&String(snap.date||'')===String(a.lastUpdated||'')){skippedCurrent=true;continue;}return num(match.total);}return 0;}
function autoreisenCurrentFleetRow(a={}){const rows=autoreisenFleetRowsFromState(a);if(!rows.length)return null;const exact=rows.find(row=>String(row?.group||'').trim()===String(a.group||'').trim()&&String(row?.model||'').trim()===String(a.model||'').trim());if(exact)return exact;const byModel=rows.find(row=>String(row?.model||'').trim()===String(a.model||'').trim());if(byModel)return byModel;const byPrice=rows.find(row=>Math.abs(num(row?.total)-num(a.currentPrice))<0.01);if(byPrice)return byPrice;return rows.slice().sort((x,y)=>num(x.total)-num(y.total))[0]||null;}
function autoreisenCompactStatusMarkup(a={}){const fleetTime=Date.parse(a.fleetLastCheckedAt||0)||0,lastTime=Date.parse(a.lastUpdated||0)||0,attemptTime=Date.parse(a.lastAttempt||0)||0,stamp=fleetTime>lastTime?a.fleetLastCheckedAt:a.lastUpdated,errorRelevant=Boolean(a.lastError)&&attemptTime>=Math.max(fleetTime,lastTime);const label=stamp?(errorRelevant?`Dato válido guardado ${formatDate(stamp,{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'})} · última comprobación con aviso`:`Actualizado ${formatDate(stamp,{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'})}`):(errorRelevant?'Hay un aviso pendiente del monitor automático':'Sin consulta automática disponible todavía');return `<small class="muted tracker-status ${errorRelevant?'error-text':''}">${esc(label+monitorFallbackStatusSuffix('autoreisen'))}</small>`;}
function autoreisenFleetPricesMarkup(a={}){
  const allRows=autoreisenFleetRowsFromState(a);
  const rows=autoreisenVisibleFleetRows(a,allRows);
  if(!allRows.length)return `<h4 class="cordial-subtitle">Flota disponible para estas fechas</h4><div class="autoreisen-fleet-empty"><strong>${esc(autoreisenFleetSelectionLabel(a))}</strong><span>La próxima comprobación guardará aquí todos los coches disponibles y sus precios.</span></div>`;
  if(!rows.length)return `<h4 class="cordial-subtitle">Flota disponible para estas fechas</h4><div class="autoreisen-fleet-empty"><strong>${esc(autoreisenFleetSelectionLabel(a))}</strong><span>No hay vehículos de las categorías visibles en la última consulta. Puedes cambiar la selección desde Configuración → Seguimientos → AutoReisen.</span></div>`;
  const selectedKey=autoreisenFleetKey({group:a.group,model:a.model});
  const cards=rows.map((row,index)=>{const previous=autoreisenPreviousFleetPrice(a,row),current=num(row.total),diff=previous>0?current-previous:null;const isSelected=autoreisenFleetKey(row)===selectedKey;const diffMarkup=diff===null?'':`<small class="autoreisen-fleet-diff ${diff<0?'good':diff>0?'bad':'same'}">${diff===0?'Sin cambio':`${diff>0?'+':''}${formatMoney(diff)} vs. anterior`}</small>`;const imageUrl=isImageSource(row.imageUrl)?String(row.imageUrl).trim():'';const photoMarkup=imageUrl?`<button class="autoreisen-fleet-photo clickable-image" type="button" data-image-popup="${esc(imageUrl)}" data-image-title="${esc(row.model||'Vehículo')}" aria-label="Ampliar imagen de ${esc(row.model||'vehículo')}"><img src="${esc(imageUrl)}" alt="${esc(row.model||'Vehículo')}" loading="lazy"></button>`:'';const badge=index===0?'Más barato':isSelected?'Reservado':'';return `<article class="autoreisen-fleet-price-card ${index===0?'is-cheapest':''} ${isSelected?'is-selected':''}">${photoMarkup}<div class="autoreisen-fleet-card-top"><span class="autoreisen-fleet-group">Grupo ${esc(row.group||'—')}</span>${badge?`<b>${badge}</b>`:''}</div><strong class="autoreisen-fleet-model">${esc(row.model||'Vehículo')}</strong><div class="autoreisen-fleet-money"><strong>${formatMoney(current)}</strong>${num(row.pricePerDay)>0?`<span>${formatMoney(num(row.pricePerDay))}/día</span>`:''}</div>${diffMarkup}</article>`;}).join('');
  const countText=rows.length===allRows.length?`${rows.length} coche${rows.length===1?'':'s'}`:`${rows.length} de ${allRows.length} coches`;
  return `<h4 class="cordial-subtitle">Flota disponible para estas fechas</h4><section class="autoreisen-fleet-results"><div class="autoreisen-fleet-results-head"><span>${esc(autoreisenFleetSelectionLabel(a))}</span><strong>${countText}</strong></div><div class="autoreisen-fleet-price-grid">${cards}</div><p class="autoreisen-fleet-visibility-note">La consulta guarda la flota completa. Configuración solo decide qué categorías se muestran aquí.</p></section>`;
}
function renderAutoreisenTrackerCard(statusText){
  const a=state.data.trackers.autoreisen,ref=trackerBudgetReference('autoreisen',a),liveRow=autoreisenCurrentFleetRow(a),liveStamp=[a.fleetLastCheckedAt,a.lastUpdated].filter(Boolean).sort((x,y)=>(Date.parse(y)||0)-(Date.parse(x)||0))[0]||'',hasAuto=num(liveRow?.total||a.currentPrice)>0&&Boolean(liveStamp),total=hasAuto?num(liveRow?.total||a.currentPrice):num(ref.total||a.reservedPrice),diff=hasAuto&&num(ref.total)>0?total-num(ref.total):null;
  const carImage=isImageSource(a.manualImageUrl)?String(a.manualImageUrl):isImageSource(a.imageUrl)?String(a.imageUrl):'';
  const imageMarkup=carImage?`<div class="autoreisen-overview-photo"><button class="autoreisen-car-photo clickable-image" type="button" data-image-popup="${esc(carImage)}" data-image-title="${esc(a.model||'Vehículo AutoReisen')}" aria-label="Ampliar imagen de ${esc(a.model||'vehículo')}"><img src="${esc(carImage)}" alt="${esc(a.model||'Vehículo AutoReisen')}" loading="lazy"></button></div>`:'';
  const budgetNote=ref.source==='Presupuesto'?`<div class="tracker-budget-reference">✓ Comparación automática con Presupuesto · ${esc(ref.label.toLowerCase())} ${formatMoney(ref.total)}</div>`:ref.source?`<div class="tracker-budget-reference is-fallback">Referencia manual · ${formatMoney(ref.total)}</div>`:'';
  const content=`<div class="tracker-route">${esc(a.pickup)} · Grupo ${esc(a.group)} · ${esc(a.model)}</div>${budgetNote}${trackerSearchDateMarkup('autoreisen',a)}<div class="autoreisen-overview ${carImage?'has-photo':''}"><div class="tracker-kpis autoreisen-kpis tracker-clean-comparison"><div class="tracker-kpi-card tracker-primary-kpi tracker-kpi-span-2"><span>${liveRow?'Precio flota':'Precio actual'}</span><strong>${hasAuto?formatMoney(total):'—'}</strong>${hasAuto?trackerComparisonMeta(total,ref.total,ref.label):''}</div><div class="tracker-kpi-card"><span>Periodo</span><strong>${formatDate(a.pickupAt.slice(0,10),{day:'2-digit',month:'short'})}–${formatDate(a.dropoffAt.slice(0,10),{day:'2-digit',month:'short'})}</strong></div><div class="tracker-kpi-card"><span>Disponibilidad</span><strong>${hasAuto?esc(liveRow?.availability||a.availability||'Disponible'):'—'}</strong></div></div>${imageMarkup}</div>${autoreisenCompactStatusMarkup(a)}${autoreisenFleetPricesMarkup(a)}<h4 class="cordial-subtitle">Evolución del coche reservado</h4>${autoreisenHistoryChart(a)}${autoreisenControlMarkup(a)}`;
  return trackerCard('autoreisen',a.title||'AutoReisen','🚗',content,`<button class="btn secondary" data-refresh-tracker="autoreisen">↻ Consultar último dato</button><button class="btn secondary" data-edit-tracker="autoreisen">✎ Reserva</button><button class="btn secondary" data-tracker-icon-edit="autoreisen">🖼 Icono</button>${safeLink(a.searchUrl,'Abrir AutoReisen','↗')}`);
}
function readAutoreisenControls(){
  const current=state.data.trackers.autoreisen;const root=$('[data-autoreisen-control]');if(!root)return current;
  const result={...current,scheduleMode:'daily',scheduleTime:'06:30',scheduleTimeZone:'Europe/Madrid'};
  $$('[data-autoreisen-field]',root).forEach(input=>{result[input.dataset.autoreisenField]=Boolean(input.checked);});$$('[data-autoreisen-number]',root).forEach(input=>{result[input.dataset.autoreisenNumber]=Math.max(0,num(input.value));});return result;
}
async function requireAutoreisenWorker(){
  const health=await fetchIntegrationHealth();
  if(!health?.autoreisenControl||health?.version!=='2.2.53')throw new Error(`El Worker Cloudflare está desactualizado. Se necesita v2.2.53 y responde ${health?.version||'desconocido'}. Ejecuta la actualización actual para reparar/publicar los Workers y vuelve a intentarlo.`);
  return health;
}
async function saveAutoreisenControl({toastSuccess=true}={}){
  if(!canEdit())throw new Error('Desbloquea la edición para cambiar el monitor.');
  synchronizeTrackerTripDataLocally();Object.assign(state.data.trackers.autoreisen,readAutoreisenControls());await saveSection('trackers');
  await requireAutoreisenWorker();
  const result=await callIntegrationWorker({action:'github-sync-autoreisen',config:state.data.trackers.autoreisen,runWorkflow:false});
  state.autoreisenControlStatus={...(state.autoreisenControlStatus||{}),lastSync:result.updatedAt};
  if(toastSuccess)toast('AutoReisen y Telegram sincronizados.');return result;
}
async function checkAutoreisenControlStatus(){
  toast('Comprobando automatización…');await requireAutoreisenWorker();const result=await callIntegrationWorker({action:'github-autoreisen-status'});if(typeof result?.installed!=='boolean')throw new Error('El Worker publicado todavía no incluye el control AutoReisen v2.2.53.');state.autoreisenControlStatus=result;render();toast(result.installed?'Automatización AutoReisen preparada.':'Falta instalar o actualizar la automatización.');return result;
}
async function installAutoreisenControl(){
  if(!canManageAutomations())throw new Error('Tu usuario no tiene permisos para instalar la automatización.');
  await requireAutoreisenWorker();toast('Actualizando AutoReisen en GitHub…');
  const result=await callIntegrationWorker({action:'github-autoreisen-install',config:state.data.trackers.autoreisen});if(result?.installed!==true)throw new Error('El Worker no ha confirmado la instalación de AutoReisen.');state.autoreisenControlStatus={installed:true,...result};render();toast('Automatización AutoReisen instalada/actualizada sin editar GitHub manualmente.');return result;
}
function newestAutoreisenMonitorEvent(rows=[]){
  return [...(Array.isArray(rows)?rows:[])].filter(Boolean).sort((a,b)=>Date.parse(b.checkedAt||b.receivedAt||0)-Date.parse(a.checkedAt||a.receivedAt||0))[0]||null;
}
async function pollAutoreisenRunResult(startedAt,{timeoutMs=210000,intervalMs=6500}={}){
  const deadline=Date.now()+timeoutMs,target=state.data.trackers.autoreisen;
  while(Date.now()<deadline){
    const history=await callPriceWorker({action:'monitor-history',type:'autoreisen'}).catch(()=>({results:[]}));
    const latest=newestAutoreisenMonitorEvent(history.results||[]),stamp=Date.parse(latest?.checkedAt||latest?.receivedAt||'');
    if(latest&&Number.isFinite(stamp)&&stamp>=startedAt-2500){
      target.lastAttempt=latest.checkedAt||latest.receivedAt||new Date().toISOString();
      if(latest.status==='error'||latest.ok===false){
        target.monitorStatus='error';target.lastError=latest.error||'La comprobación de AutoReisen ha fallado.';
        await saveSection('trackers');render();toast(`AutoReisen: ${target.lastError}`,'error');return {ok:false,event:latest};
      }
      const data=await callPriceWorker({action:'autoreisen'});applyAutomaticTrackerResult('autoreisen',data);await refreshAutoreisenHistory({silent:true});await saveSection('trackers');render();toast(`AutoReisen actualizado · ${formatMoney(target.currentPrice)}`);return {ok:true,event:latest};
    }
    await new Promise(resolve=>setTimeout(resolve,intervalMs));
  }
  toast('La comprobación sigue ejecutándose en GitHub. Puedes dejar esta pantalla; el resultado se sincronizará al volver a Seguimientos.');return {ok:null};
}
async function prepareAutoreisenAction(){
  synchronizeTrackerTripDataLocally();
  if(canEdit())return saveAutoreisenControl({toastSuccess:false});
  await requireAutoreisenWorker();
  return callIntegrationWorker({action:'github-sync-autoreisen',config:state.data.trackers.autoreisen,runWorkflow:false});
}
function applyAutoreisenFleetResult(result={},target=state.data.trackers.autoreisen){
  if(result?.ok===false||result?.status==='error')throw new Error(result?.error||'AutoReisen no devolvió una flota válida.');
  const checkedAt=String(result.checkedAt||new Date().toISOString());
  if(result.noAvailability){target.fleetPrices=[];target.fleetCatalog=[];target.fleetLastCheckedAt=checkedAt;target.lastUpdated=checkedAt;target.lastAttempt=checkedAt;target.lastError='';target.monitorStatus='ok';target.availability='No disponible';return {fleet:[],checkedAt};}
  if(!Array.isArray(result.fleet)||!result.fleet.length)throw new Error('La consulta terminó, pero AutoReisen no devolvió vehículos interpretables.');
  const liveMap=new Map();for(const x of result.fleet){const group=String(x?.group||'').trim(),model=String(x?.model||'').trim(),carId=String(x?.carId||'').trim(),imageUrl=String(x?.imageUrl||'').trim(),pricePerDay=num(x?.pricePerDay),total=num(x?.total),availability=String(x?.availability||'Disponible');if(group&&model&&total>0)liveMap.set(`${group}\u0000${model}`,{group,model,carId,imageUrl,pricePerDay,total,availability});}
  const fleet=[...liveMap.values()].sort((a,b)=>num(a.total)-num(b.total));if(!fleet.length)throw new Error('AutoReisen devolvió la página, pero no se pudo interpretar ningún precio de la flota.');
  target.fleetPrices=fleet;target.fleetCatalog=fleet;target.fleetLastCheckedAt=checkedAt;
  target.fleetPriceHistory=[...(Array.isArray(target.fleetPriceHistory)?target.fleetPriceHistory:[]).filter(x=>String(x?.date||'')!==checkedAt),{date:checkedAt,fleet:fleet.map(x=>({group:x.group,model:x.model,carId:x.carId||'',imageUrl:x.imageUrl||'',availability:x.availability||'Disponible',total:num(x.total),pricePerDay:num(x.pricePerDay)}))}].slice(-180);
  const selected=autoreisenBestFleetMatch(fleet,target.model)||fleet.find(x=>String(x.group)===String(target.group)&&String(x.model)===String(target.model))||fleet.find(x=>String(x.group)===String(target.group))||fleet[0];
  if(selected){target.currentPrice=num(selected.total);target.pricePerDay=num(selected.pricePerDay);target.availability=selected.availability||'Disponible';target.matchedModel=selected.model||target.model;if(isImageSource(selected.imageUrl))target.imageUrl=selected.imageUrl;const h={date:checkedAt,price:num(selected.total),source:result.source||'AutoReisen · consulta de flota'};target.history=[...(target.history||[]).filter(x=>String(x?.date||'')!==checkedAt),h].slice(-365);}
  target.lastUpdated=checkedAt;target.lastAttempt=checkedAt;target.lastError='';target.monitorStatus='ok';target.automatic=true;target.source=result.source||'AutoReisen · consulta de flota';
  return {fleet,checkedAt,selected};
}
async function runAutoreisenNow(){
  await prepareAutoreisenAction();const startedAt=Date.now(),target=state.data.trackers.autoreisen,requestId=`fleet-${Date.now()}-${Math.random().toString(36).slice(2,9)}`;
  state.trackerRunProgress.autoreisen={runFound:false,startedAfter:new Date(startedAt).toISOString(),localLabel:'consultando flota…',localPercentage:5,localTotal:3,localDone:0,localSteps:[{name:'Lanzar navegador AutoReisen',status:'in_progress'},{name:'Leer todos los coches y precios',status:'queued'},{name:'Guardar flota, fotos e histórico',status:'queued'}]};paintTrackerRunProgress('autoreisen');
  toast('Consultando la flota completa de AutoReisen para las fechas guardadas…');
  try{
    const run=await callIntegrationWorker({action:'github-autoreisen-run',mode:'fleet',force:true,requestId,config:target});if(run?.workflowTriggered!==true)throw new Error('No se ha podido iniciar la consulta completa de flota.');
    state.trackerRunProgress.autoreisen={...state.trackerRunProgress.autoreisen,localLabel:'navegador en ejecución…',localPercentage:30,localDone:1,localSteps:[{name:'Lanzar navegador AutoReisen',status:'completed',conclusion:'success'},{name:'Leer todos los coches y precios',status:'in_progress'},{name:'Guardar flota, fotos e histórico',status:'queued'}]};paintTrackerRunProgress('autoreisen');
    const deadline=Date.now()+210000;let data=null;while(Date.now()<deadline){await wait(6500);data=await callIntegrationWorker({action:'autoreisen-fleet-result',requestId});if(!data?.pending)break;}
    if(!data||data.pending)throw new Error('La consulta de flota sigue ejecutándose en GitHub Actions. Vuelve a pulsar actualizar dentro de un momento.');
    state.trackerRunProgress.autoreisen={...state.trackerRunProgress.autoreisen,localLabel:'guardando flota…',localPercentage:82,localDone:2,localSteps:[{name:'Lanzar navegador AutoReisen',status:'completed',conclusion:'success'},{name:'Leer todos los coches y precios',status:'completed',conclusion:'success'},{name:'Guardar flota, fotos e histórico',status:'in_progress'}]};paintTrackerRunProgress('autoreisen');
    const applied=applyAutoreisenFleetResult(data.result||{},target);await saveSection('trackers');
    state.trackerRunProgress.autoreisen={...state.trackerRunProgress.autoreisen,localLabel:'completado',localPercentage:100,localDone:3,localSteps:[{name:'Lanzar navegador AutoReisen',status:'completed',conclusion:'success'},{name:'Leer todos los coches y precios',status:'completed',conclusion:'success'},{name:'Guardar flota, fotos e histórico',status:'completed',conclusion:'success'}]};paintTrackerRunProgress('autoreisen');render();toast(applied.fleet.length?`AutoReisen actualizado · ${applied.fleet.length} coches`:'AutoReisen actualizado · sin disponibilidad');return applied;
  }catch(error){setTrackerRunError('autoreisen',error,startedAt);target.lastAttempt=new Date().toISOString();target.lastError=String(error?.message||error);target.monitorStatus='error';await saveSection('trackers').catch(()=>{});render();throw error;}
}
async function testAutoreisenTelegram(){
  await prepareAutoreisenAction();if(state.data.trackers.autoreisen.telegramEnabled===false)throw new Error('Telegram está desactivado en la configuración guardada. Desbloquea la edición para activarlo.');const startedAt=Date.now();toast('Lanzando prueba de Telegram…');try{const result=await callIntegrationWorker({action:'github-autoreisen-run',mode:'telegram-test',telegramTest:true});if(result?.workflowTriggered!==true)throw new Error('No se ha podido lanzar la prueba de Telegram.');startTrackerRunProgress('autoreisen',startedAt);toast('Prueba de Telegram lanzada. Puedes seguir los pasos aquí.');}catch(error){setTrackerRunError('autoreisen',error,startedAt);throw error;}
}
async function refreshAutoreisenHistory({silent=false}={}){
  if(!silent)toast('Actualizando histórico AutoReisen…');const data=await callPriceWorker({action:'monitor-history',type:'autoreisen'});const valid=(data.results||[]).filter(x=>x&&x.status!=='error'&&x.ok!==false);const rows=valid.map(x=>({date:x.checkedAt||x.receivedAt||'',price:num(x.total||x.price),source:x.source||'Monitor'})).filter(x=>x.date&&x.price>0);const fleetHistory=valid.map(x=>({date:x.checkedAt||x.receivedAt||'',fleet:(Array.isArray(x.fleet)?x.fleet:[]).map(row=>({group:row.group,model:row.model,carId:row.carId||'',imageUrl:row.imageUrl||'',availability:row.availability||'Disponible',total:num(row.total),pricePerDay:num(row.pricePerDay)})).filter(row=>row.group&&row.model&&row.total>0)})).filter(x=>x.date&&x.fleet.length);state.data.trackers.autoreisen.history=rows.slice(-365);state.data.trackers.autoreisen.fleetPriceHistory=fleetHistory.slice(-180);if(valid[0]?.fleet?.length){const newest=[...valid].sort((a,b)=>Date.parse(b.checkedAt||b.receivedAt||0)-Date.parse(a.checkedAt||a.receivedAt||0))[0];state.data.trackers.autoreisen.fleetPrices=(newest.fleet||[]).map(x=>({...x,total:num(x.total),pricePerDay:num(x.pricePerDay)}));}if(!silent){await saveSection('trackers');render();toast(`Histórico actualizado · ${rows.length} consultas · ${fleetHistory.length} con flota.`);}return rows;
}

function cordialNorm(value){return String(value||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/\s+/g,' ').trim();}
function cordialTargetMatch(row,a){
  const roomOk=cordialNorm(row?.roomType).includes(cordialNorm(a.targetRoom||'Classic Duplex'));
  return roomOk&&cordialIsClubRate(row)&&cordialIsOnlyAccommodation(row)&&cordialIsReservationOnline(row);
}
function cordialPositiveCancellation(row){return cordialHasAdvanceCancellation(row);}
function cordialTargetCandidate(a){return cordialPreferredClubTarget(a);}
function trackerSingleHistoryChart(rowsInput,label='Precio'){
  const rows=(rowsInput||[]).filter(x=>x?.date&&num(x.price)>0).sort((a,b)=>Date.parse(a.date||0)-Date.parse(b.date||0)).slice(-30);if(rows.length<2)return '<p class="help-text">El gráfico aparecerá cuando haya al menos dos comprobaciones correctas.</p>';
  const width=720,height=180,padX=38,padY=22,values=rows.map(x=>num(x.price)),lo=Math.min(...values),hi=Math.max(...values),range=Math.max(1,hi-lo),min=Math.max(0,lo-range*.12),max=hi+range*.12;
  const xFor=i=>padX+(width-padX*2)*(rows.length===1?0:i/(rows.length-1)),yFor=v=>padY+(height-padY*2)*(1-(v-min)/(max-min));
  const pts=rows.map((r,i)=>({x:xFor(i),y:yFor(num(r.price)),price:num(r.price),date:r.date}));const path=pts.map((p,i)=>`${i?'L':'M'} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(' '),first=rows[0],last=rows.at(-1);
  const points=pts.map(p=>{const text=`${label} · ${formatDate(p.date,{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'})} · ${formatMoney(p.price)}`;return `<circle cx="${p.x.toFixed(1)}" cy="${p.y.toFixed(1)}" r="4" class="cordial-chart-point tracker-chart-hover-point" tabindex="0" data-tracker-chart-tooltip="${esc(text)}"><title>${esc(text)}</title></circle>`;}).join('');
  return `<div class="cordial-chart-wrap"><svg class="cordial-chart tracker-single-chart" viewBox="0 0 ${width} ${height}" role="img" aria-label="Evolución de ${esc(label)}"><line x1="${padX}" y1="${height-padY}" x2="${width-padX}" y2="${height-padY}" class="cordial-chart-axis"/><path d="${path}" class="cordial-chart-line" fill="none"/><g>${points}</g><text x="${padX}" y="${height-5}" class="cordial-chart-label">${esc(formatDate(first.date,{day:'2-digit',month:'short'}))}</text><text x="${width-padX}" y="${height-5}" text-anchor="end" class="cordial-chart-label">${esc(formatDate(last.date,{day:'2-digit',month:'short'}))}</text></svg></div>`;
}
function trackerMultiSeriesChart(snapshotsInput=[],seriesRows=()=>[],ariaLabel='Evolución de precios'){
  const snapshots=(snapshotsInput||[]).filter(x=>x?.date).sort((a,b)=>Date.parse(a.date||0)-Date.parse(b.date||0)).slice(-30);
  if(!snapshots.length)return '<p class="help-text">El gráfico aparecerá cuando haya al menos una comprobación correcta.</p>';
  const seriesMap=new Map();
  snapshots.forEach((snap,sIndex)=>{for(const row of (seriesRows(snap)||[])){const key=String(row?.key||row?.label||'').trim(),label=String(row?.label||key).trim(),value=num(row?.value);if(!key||value<=0)continue;if(!seriesMap.has(key))seriesMap.set(key,{key,label,points:[]});seriesMap.get(key).points.push({sIndex,date:snap.date,value});}});
  const series=[...seriesMap.values()].filter(x=>x.points.length);if(!series.length)return '<p class="help-text">Todavía no hay precios suficientes para dibujar las series.</p>';
  const width=760,height=220,padX=42,padY=25,values=series.flatMap(x=>x.points.map(p=>p.value)),lo=Math.min(...values),hi=Math.max(...values),range=Math.max(1,hi-lo),min=Math.max(0,lo-range*.1),max=hi+range*.12;
  const xFor=i=>snapshots.length===1?width/2:padX+(width-padX*2)*(i/(snapshots.length-1)),yFor=v=>padY+(height-padY*2)*(1-(v-min)/(max-min));
  const graphics=series.map((serie,index)=>{const hue=Math.round((index*137.508+18)%360),pts=serie.points.map(p=>({...p,x:xFor(p.sIndex),y:yFor(p.value)}));const d=pts.length>1?pts.map((p,i)=>`${i?'L':'M'} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(' '):'';const points=pts.map(p=>{const text=`${serie.label} · ${formatDate(p.date,{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'})} · ${formatMoney(p.value)}`;return `<circle cx="${p.x.toFixed(1)}" cy="${p.y.toFixed(1)}" r="4" class="tracker-multi-series-point tracker-chart-hover-point" style="--series-hue:${hue}" tabindex="0" data-tracker-chart-tooltip="${esc(text)}"><title>${esc(text)}</title></circle>`;}).join('');return `${d?`<path d="${d}" class="tracker-multi-series-line" style="--series-hue:${hue}" fill="none"/>`:''}<g>${points}</g>`;}).join('');
  const legend=series.map((serie,index)=>{const hue=Math.round((index*137.508+18)%360);return `<span class="tracker-multi-legend-item" style="--series-hue:${hue}"><i></i>${esc(serie.label)}</span>`;}).join('');
  const first=snapshots[0],last=snapshots.at(-1);return `<div class="tracker-multi-chart-legend">${legend}</div><div class="cordial-chart-wrap"><svg class="cordial-chart tracker-multi-chart" viewBox="0 0 ${width} ${height}" role="img" aria-label="${esc(ariaLabel)}"><line x1="${padX}" y1="${height-padY}" x2="${width-padX}" y2="${height-padY}" class="cordial-chart-axis"/>${graphics}<text x="${padX}" y="${height-5}" class="cordial-chart-label">${esc(formatDate(first.date,{day:'2-digit',month:'short'}))}</text><text x="${width-padX}" y="${height-5}" text-anchor="end" class="cordial-chart-label">${esc(formatDate(last.date,{day:'2-digit',month:'short'}))}</text></svg></div>`;
}
function autoreisenHistoryChart(a){
  const snapshots=[...(Array.isArray(a.fleetPriceHistory)?a.fleetPriceHistory:[])];const stamp=a.fleetLastCheckedAt||a.lastUpdated||'';
  if(stamp&&Array.isArray(a.fleetPrices)&&a.fleetPrices.some(x=>num(x?.total)>0)&&!snapshots.some(x=>String(x?.date||'')===String(stamp)))snapshots.push({date:stamp,fleet:a.fleetPrices});
  const wantedGroups=a.fleetTrackAll===false?new Set(autoreisenFleetVisibleGroups(a)):null;
  return trackerMultiSeriesChart(snapshots,snap=>(snap.fleet||[]).filter(row=>!wantedGroups||!wantedGroups.size||wantedGroups.has(String(row.group||'').trim())).map(row=>({key:autoreisenFleetKey(row),label:`Grupo ${row.group||'—'} · ${row.model||'Vehículo'}`,value:num(row.total)})),'Evolución de precios de todos los coches AutoReisen');
}
function cordialRoomPriceSnapshot(options=[],date=''){
  // La evolución usa exactamente la misma tarifa flexible que los resúmenes de cada tipo.
  // Evita que el gráfico mezcle el precio Prepago (más barato, con gastos) con Reserva Online.
  const rooms=cordialSummaryRoomRows({options:Array.isArray(options)?options:[]});
  return {date,rooms:rooms.filter(row=>num(row.price)>0).map(row=>({room:row.room,price:num(row.price)}))};
}
function cordialHistoryChart(a){
  const snapshots=[...(Array.isArray(a.roomPriceHistory)?a.roomPriceHistory:[])];const stamp=a.lastUpdated||'';const current=cordialRoomPriceSnapshot(a.options||[],stamp);if(stamp&&current.rooms.length&&!snapshots.some(x=>String(x?.date||'')===String(stamp)))snapshots.push(current);
  return trackerMultiSeriesChart(snapshots,snap=>(snap.rooms||[]).map(row=>({key:cordialNorm(row.room),label:row.room,value:num(row.price)})),'Evolución de precios de habitaciones Club Cordial');
}
function cordialRoomMeta(a,room){
  const meta=a?.roomMeta&&typeof a.roomMeta==='object'?a.roomMeta:{};const wanted=cordialNorm(room);
  for(const [key,value] of Object.entries(meta)){if(cordialNorm(key)===wanted||cordialNorm(value?.name)===wanted)return value||{};}
  return {};
}
function cordialOptionsMarkup(a,selectedTarget=null){
  const options=cordialClubOptions(a);if(!options.length)return '<p class="help-text">Todavía no hay tarifas Club Cordial leídas. Pulsa “Comprobar ahora” para ejecutar la consulta.</p>';
  const groups=new Map();
  for(const row of options){
    let room=String(row.roomType||'Alojamiento').trim()||'Alojamiento';
    if(/^(club cordial\s*-|tarifa club cordial|oferta .*online|reserva online)/i.test(room))room='Alojamiento sin clasificar';
    if(!groups.has(room))groups.set(room,[]);groups.get(room).push(row);
  }
  const fallback='https://www.becordial.com/gran-canaria-sur/cordial-santa-agueda/viviendas/';
  return `<div class="cordial-options">${[...groups.entries()].map(([room,rows])=>{
    const roomTarget=rows.some(r=>r===selectedTarget||cordialTargetMatch(r,a)),meta=cordialRoomMeta(a,room),detail=String(meta.detailUrl||fallback),image=String(meta.imageUrl||'');
    const visual=image&&isValidUrl(image)?`<img class="cordial-room-thumb" src="${esc(image)}" alt="${esc(room)}" loading="lazy">`:'';
    const roomPhoto=image&&isValidUrl(image)?`<button class="cordial-room-photo clickable-image" type="button" data-image-popup="${esc(image)}" data-image-title="${esc(room)}" aria-label="Ampliar imagen de ${esc(room)}"><img src="${esc(image)}" alt="${esc(room)}" loading="lazy"></button>`:'';
    const detailLink=isValidUrl(detail)?`<a class="cordial-room-detail-link" href="${esc(detail)}" target="_blank" rel="noopener" title="Ver detalle de ${esc(room)}">↗ Ver detalle</a>`:'';
    const roomVisual=(roomPhoto||detailLink)?`<div class="cordial-room-visual">${roomPhoto||''}<div class="cordial-room-visual-actions">${detailLink||''}</div></div>`:'';
    return `<details class="cordial-room ${roomTarget?'cordial-room-target':''}" ${roomTarget?'open':''}><summary><span class="cordial-room-summary-main">${visual}<span class="cordial-room-name">${roomTarget?'<strong>':''}${esc(room)}${roomTarget?'</strong>':''}</span></span><span class="cordial-room-summary-actions"><span class="cordial-room-count">${rows.length} tarifa${rows.length===1?'':'s'} Club</span></span></summary>${roomVisual}<div class="cordial-rate-list">${rows.map(row=>{const target=row===selectedTarget||cordialTargetMatch(row,a);return `<div class="cordial-rate ${target?'cordial-target':''}"><div><${target?'strong':'span'}>${esc(row.rateName||'Club Cordial')}</${target?'strong':'span'}><small>${esc(cordialCancellationLabel(row))}${row.availability?` · ${esc(row.availability)}`:''}</small></div><div><${target?'strong':'span'}>${esc(row.board||'')}</${target?'strong':'span'}>${num(row.crossedPrice)>num(row.price)?`<small class="cordial-crossed">${formatMoney(row.crossedPrice)}</small>`:''}</div><strong class="cordial-rate-price">${formatMoney(row.price)}</strong>${target?'<span class="status-pill on cordial-objective-pill">✓ CLUB · CANCELACIÓN · SOLO ALOJAMIENTO</span>':''}</div>`;}).join('')}</div></details>`;}).join('')}</div>`;
}
function cordialControlMarkup(a){
  const status=state.cordialControlStatus,editDisabled=canEdit()?'':'disabled',automationDisabled=canManageAutomations()?'':'disabled',installStatus=status?status.installed?'Automatización instalada':'Automatización pendiente':'Sin comprobar';
  return `<details class="autoreisen-control cordial-control"><summary><span>⚙️ Centro de control Cordial</span><span class="autoreisen-summary-badges"><b class="status-pill ${a.enabled===false?'off':'on'}">Monitor ${a.enabled===false?'OFF':'ON'}</b><b class="status-pill on">Sin Telegram</b></span></summary><div class="autoreisen-control-body"><div class="autoreisen-control-grid"><article class="autoreisen-control-panel"><h4>Monitor</h4><label class="switch-row"><span><strong>Seguimiento diario</strong><small>Guarda precios e histórico sin enviar mensajes de Telegram.</small></span><input type="checkbox" data-cordial-enabled ${a.enabled!==false?'checked':''} ${editDisabled}></label><div class="control-field"><span>Programación automática</span><strong>Todos los días · ${esc(a.scheduleTime||'06:35')}</strong><small>Europe/Madrid. Las comprobaciones manuales no alteran el horario.</small></div></article><article class="autoreisen-control-panel"><h4>Tarifa destacada</h4><p><strong>${esc(a.targetRoom||'Classic Duplex')}</strong></p><p>Club Cordial · cancelación sin gastos</p><p>SOLO ALOJAMIENTO</p><small>En la app solo se muestran tarifas Club Cordial. El resumen prioriza la tarifa Reserva Online con cancelación sin gastos y solo alojamiento.</small></article></div><div class="autoreisen-control-status"><div><span>Automatización</span><strong>${esc(installStatus)}</strong></div><div><span>Última consulta</span><strong>${a.lastUpdated?esc(formatDate(a.lastUpdated,{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'})):'—'}</strong></div><div><span>Último error</span><strong class="${a.lastError?'error-text':''}">${esc(a.lastError||'Ninguno')}</strong></div></div><div class="page-actions autoreisen-control-actions"><button type="button" class="btn primary" data-cordial-save ${editDisabled}>Guardar y sincronizar</button><button type="button" class="btn secondary" data-cordial-run>▶ Comprobar ahora</button><button type="button" class="btn secondary" data-cordial-status>✓ Comprobar sistema</button><button type="button" class="btn secondary" data-cordial-history-refresh>↻ Actualizar histórico</button><button type="button" class="btn ghost" data-cordial-install ${automationDisabled}>↻ Instalar/actualizar automatización</button></div><div class="tracker-run-progress-wrap" data-tracker-run-progress="cordial">${trackerRunProgressMarkup('cordial')}</div><p class="help-text">La consulta se realiza con un navegador real en GitHub Actions. Si BeCordial cambia la estructura de su motor, se conserva el último precio válido y se registra el error para poder ajustar el lector. Instalar/actualizar la automatización funciona aunque la edición esté bloqueada si tu usuario tiene permisos.</p></div></details>`;
}
function renderCordialTrackerCard(statusText){
  const a=state.data.trackers.cordial,target=cordialPreferredClubTarget(a),targetPrice=num(target?.price),savedPrice=num(a.currentPrice),price=targetPrice>0?targetPrice:savedPrice,found=price>0&&(Boolean(target)||Boolean(a.lastUpdated)),ref=trackerBudgetReference('cordial',a),diff=num(ref.total)>0&&found?price-num(ref.total):null;
  const availability=target?(target.availability||'Disponible'):(found?(a.availability||'Disponible'):(a.availability||'No encontrado'));
  const roomName=a.targetRoom||'Classic Duplex',meta=cordialRoomMeta(a,roomName),heroImage=String(meta.imageUrl||'');
  const heroPhoto=heroImage&&isValidUrl(heroImage)?`<img class="cordial-target-hero-image" src="${esc(heroImage)}" alt="${esc(roomName)}" loading="lazy">`:'';
  const targetLabel=`${roomName} · Club Cordial · cancelación sin gastos · solo alojamiento`;
  const targetHero=found?`<div class="cordial-target-hero">${heroPhoto}<div class="cordial-target-hero-main"><span class="cordial-target-badge">✓ CLUB CORDIAL</span><strong>${formatMoney(price)}</strong></div><div class="cordial-target-hero-detail"><strong>${esc(roomName)}</strong><span>${esc(target?.rateName||a.targetRate||'')}</span><span>${esc(target?.board||a.targetBoard||'')}</span><small>${esc(target?cordialCancellationLabel(target):targetLabel)}</small></div></div>`:'';
  const budgetNote=ref.source==='Presupuesto'?`<div class="tracker-budget-reference">✓ Comparación automática con Presupuesto · ${esc(ref.label.toLowerCase())} ${formatMoney(ref.total)}</div>`:ref.source?`<div class="tracker-budget-reference is-fallback">Referencia manual · ${formatMoney(ref.total)}</div>`:'';
  const content=`<div class="tracker-route">${esc(a.hotel||'Cordial Santa Águeda & Perchel Beach Club')} · ${Math.max(1,num(a.adults)||2)} adultos</div>${budgetNote}${trackerSearchDateMarkup('cordial',a)}<div class="tracker-kpis tracker-comparison-kpis tracker-clean-comparison"><div class="tracker-kpi-card tracker-primary-kpi tracker-kpi-span-2 ${found?'cordial-kpi-found':''}"><span>Precio actual ${esc(roomName)}</span><strong>${found?formatMoney(price):'—'}</strong>${found?trackerComparisonMeta(price,ref.total,ref.label):''}</div><div class="tracker-kpi-card"><span>Periodo</span><strong>${formatDate(a.checkIn,{day:'2-digit',month:'short'})}–${formatDate(a.checkOut,{day:'2-digit',month:'short'})}</strong></div><div class="tracker-kpi-card ${found?'cordial-kpi-found':''}"><span>Disponibilidad</span><strong>${esc(availability)}</strong></div></div>${targetHero}<h4 class="cordial-subtitle">Habitaciones Club Cordial</h4>${cordialRoomTypesCompactMarkup(a)}<small class="muted tracker-status ${a.monitorStatus==='error'?'error-text':''}">${esc(statusText(a))}</small><h4 class="cordial-subtitle">Evolución de precios</h4>${cordialHistoryChart(a)}<h4 class="cordial-subtitle">Tarifas Club Cordial</h4>${cordialOptionsMarkup(a,target)}${cordialControlMarkup(a)}`;
  return trackerCard('cordial',a.title||'Cordial Santa Águeda','🏨',content,`<button class="btn secondary" data-refresh-tracker="cordial">↻ Consultar último dato</button><button class="btn secondary" data-edit-tracker="cordial">✎ Configurar</button><button class="btn secondary" data-tracker-icon-edit="cordial">🖼 Icono</button>${safeLink(a.searchUrl,'Abrir Cordial','↗')}`);
}
function readCordialControls(){const a=state.data.trackers.cordial,input=$('[data-cordial-enabled]');return {...a,enabled:input?Boolean(input.checked):a.enabled!==false};}
async function requireCordialWorker(){const health=await fetchIntegrationHealth();if(!health?.cordialControl||health?.version!=='2.2.53')throw new Error(`El Worker Cloudflare está desactualizado. Se necesita v2.2.53 y responde ${health?.version||'desconocido'}. Ejecuta la actualización actual para reparar/publicar los Workers y vuelve a intentarlo.`);return health;}
async function saveCordialControl({toastSuccess=true}={}){if(!canEdit())throw new Error('Desbloquea la edición para cambiar el seguimiento Cordial.');synchronizeTrackerTripDataLocally();Object.assign(state.data.trackers.cordial,readCordialControls());await saveSection('trackers');await requireCordialWorker();const result=await callIntegrationWorker({action:'github-sync-cordial',config:state.data.trackers.cordial,runWorkflow:false});state.cordialControlStatus={...(state.cordialControlStatus||{}),lastSync:result.updatedAt};if(toastSuccess)toast('Cordial sincronizado con GitHub.');return result;}
async function checkCordialControlStatus(){toast('Comprobando automatización Cordial…');await requireCordialWorker();const result=await callIntegrationWorker({action:'github-cordial-status'});state.cordialControlStatus=result;render();toast(result.installed?'Automatización Cordial preparada.':'Falta instalar o actualizar la automatización Cordial.');return result;}
async function installCordialControl(){if(!canManageAutomations())throw new Error('Tu usuario no tiene permisos para instalar la automatización.');await requireCordialWorker();toast('Actualizando Cordial en GitHub…');const result=await callIntegrationWorker({action:'github-cordial-install',config:state.data.trackers.cordial});if(result?.installed!==true)throw new Error('El Worker no ha confirmado la instalación de Cordial.');state.cordialControlStatus={installed:true,...result};render();toast('Automatización Cordial instalada/actualizada.');return result;}
function newestCordialMonitorEvent(rows=[]){return [...(Array.isArray(rows)?rows:[])].filter(Boolean).sort((a,b)=>Date.parse(b.checkedAt||b.receivedAt||0)-Date.parse(a.checkedAt||a.receivedAt||0))[0]||null;}
async function pollCordialRunResult(startedAt,{timeoutMs=210000,intervalMs=6500}={}){const deadline=Date.now()+timeoutMs,target=state.data.trackers.cordial;while(Date.now()<deadline){const history=await callPriceWorker({action:'monitor-history',type:'cordial'}).catch(()=>({results:[]})),latest=newestCordialMonitorEvent(history.results||[]),stamp=Date.parse(latest?.checkedAt||latest?.receivedAt||'');if(latest&&Number.isFinite(stamp)&&stamp>=startedAt-2500){target.lastAttempt=latest.checkedAt||latest.receivedAt||new Date().toISOString();if(latest.status==='error'||latest.ok===false){target.monitorStatus='error';target.lastError=latest.error||'La comprobación de Cordial ha fallado.';await saveSection('trackers');render();toast(`Cordial: ${target.lastError}`,'error');return {ok:false,event:latest};}const data=await callPriceWorker({action:'cordial'});applyAutomaticTrackerResult('cordial',data);await refreshCordialHistory({silent:true});await saveSection('trackers');render();toast(`Cordial actualizado${num(target.currentPrice)>0?` · ${formatMoney(target.currentPrice)}`:''}`);return {ok:true,event:latest};}await new Promise(resolve=>setTimeout(resolve,intervalMs));}toast('La comprobación de Cordial sigue ejecutándose en GitHub. El resultado se sincronizará al volver a Seguimientos.');return {ok:null};}
async function runCordialNow(){if(canEdit())await saveCordialControl({toastSuccess:false});else await requireCordialWorker();const startedAt=Date.now();state.trackerRunProgress.cordial={runFound:false,startedAfter:new Date(startedAt).toISOString(),localLabel:'lanzando…',localPercentage:2};paintTrackerRunProgress('cordial');toast('Lanzando comprobación de Cordial…');try{const result=await callIntegrationWorker({action:'github-cordial-run',config:state.data.trackers.cordial});if(result?.workflowTriggered!==true)throw new Error('No se ha podido lanzar el workflow Cordial.');startTrackerRunProgress('cordial',startedAt);toast('Cordial se está consultando con navegador real…');await pollCordialRunResult(startedAt);}catch(error){setTrackerRunError('cordial',error,startedAt);throw error;}}
async function refreshCordialHistory({silent=false}={}){if(!silent)toast('Actualizando histórico Cordial…');const data=await callPriceWorker({action:'monitor-history',type:'cordial'});const valid=(data.results||[]).filter(x=>x&&x.status!=='error'&&x.ok!==false),rows=valid.map(x=>({date:x.checkedAt||x.receivedAt||'',price:num(x.targetPrice||x.target?.price),source:x.source||'Cordial'})).filter(x=>x.date&&x.price>0),roomHistory=valid.map(x=>cordialRoomPriceSnapshot(x.options||[],x.checkedAt||x.receivedAt||'')).filter(x=>x.date&&x.rooms.length);state.data.trackers.cordial.history=rows.slice(-365);state.data.trackers.cordial.roomPriceHistory=roomHistory.slice(-180);if(!silent){await saveSection('trackers');render();toast(`Histórico Cordial actualizado · ${rows.length} consultas · ${roomHistory.length} con habitaciones.`);}return rows;}
const VUELING_BAG_WEIGHTS=[15,20,25,30];
function vuelingPassengerCount(a={}){return Math.max(1,Math.min(5,Math.max(1,num(a.adults)||1)+Math.max(0,num(a.children))+Math.max(0,num(a.infants))));}
function vuelingSeatedPassengerCount(a={}){return Math.max(1,Math.min(5,Math.max(1,num(a.adults)||1)+Math.max(0,num(a.children))));}
function normalizeVuelingCheckedBags(a={}){
  const seated=vuelingSeatedPassengerCount(a);
  let raw=Array.isArray(a.checkedBags)?a.checkedBags:[];
  if(!raw.length){
    const count=Math.max(0,Math.min(3,num(a.checkedBagCount)||0));
    const kg=VUELING_BAG_WEIGHTS.includes(num(a.checkedBagKg))?num(a.checkedBagKg):25;
    const passenger=Math.max(1,Math.min(seated,num(a.checkedBagPassenger)||1));
    raw=Array.from({length:count},()=>({kg,passenger,outbound:true,return:a.sameBaggageRoundTrip!==false}));
  }
  return raw.slice(0,3).map(item=>({
    kg:VUELING_BAG_WEIGHTS.includes(num(item?.kg))?num(item.kg):25,
    passenger:Math.max(1,Math.min(seated,num(item?.passenger)||1)),
    outbound:item?.outbound!==false,
    return:item?.return!==false
  })).filter(item=>item.outbound||item.return);
}
function vuelingBaggageShortLabel(a={}){
  const bags=normalizeVuelingCheckedBags(a);if(!bags.length)return 'Sin maletas';
  const weights=bags.map(b=>`${b.kg} kg`).join(' + ');
  return `${bags.length} ${bags.length===1?'maleta':'maletas'} · ${weights}`;
}
function vuelingBaggageControlLabel(a={}){
  const bags=normalizeVuelingCheckedBags(a);if(!bags.length)return 'Sin maleta facturada';
  return bags.map((b,i)=>{const trip=b.outbound&&b.return?'ida/vuelta':b.outbound?'solo ida':'solo vuelta';return `M${i+1} ${b.kg} kg · P${b.passenger} · ${trip}`;}).join(' · ');
}
function vuelingBudgetReference(a){
  const normalize=value=>String(value||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toUpperCase().replace(/[^A-Z0-9]+/g,' ').trim();
  const groups=state.data.budget?.groups||[];
  const group=groups.find(g=>g.id==='g-flights')||groups.find(g=>/VUELING|VUELO/.test(normalize(g.name)));
  if(!group)return {total:num(a.reservedPrice),outbound:0,return:0,baggage:0,source:num(a.reservedPrice)>0?'Configuración':'',matched:0};
  const entries=effectiveBudgetEntries(group).map(entry=>entry.item).filter(Boolean);
  const origin=normalize(a.origin),destination=normalize(a.destination),bagWeights=new Set(normalizeVuelingCheckedBags(a).map(b=>String(b.kg)));
  const routeMatch=(item,from,to)=>{const name=normalize(`${item.name||''} ${item.detail||''}`),fromPos=name.indexOf(from),toPos=name.indexOf(to);return fromPos>=0&&toPos>fromPos;};
  const outboundItems=entries.filter(item=>routeMatch(item,origin,destination));
  const returnItems=entries.filter(item=>routeMatch(item,destination,origin));
  const used=new Set([...outboundItems,...returnItems]);
  const baggageItems=entries.filter(item=>{const name=normalize(`${item.name||''} ${item.detail||''}`);return !used.has(item)&&/MALETA|EQUIPAJE/.test(name)&&(!bagWeights.size||[...bagWeights].some(kg=>name.includes(kg))||!/\b(?:15|20|25|30)\s*KG\b/.test(name));});
  const sumItems=items=>sum(items.map(itemAmount));
  const outbound=sumItems(outboundItems),returned=sumItems(returnItems),baggage=sumItems(baggageItems);
  const matched=outboundItems.length+returnItems.length+baggageItems.length;
  const total=matched?outbound+returned+baggage:num(a.reservedPrice);
  const labelFor=items=>items.length&&items.every(item=>item.status==='paid')?'Pagado':'Reservado';
  return {total,outbound,return:returned,baggage,source:matched?'Presupuesto':num(a.reservedPrice)>0?'Configuración':'',matched,label:matched?labelFor([...outboundItems,...returnItems,...baggageItems]):'Reservado',outboundLabel:labelFor(outboundItems),returnLabel:labelFor(returnItems),baggageLabel:labelFor(baggageItems)};
}
function signedMoney(value){const n=num(value);return `${n>0?'+':''}${formatMoney(n)}`;}
function trackerComparisonMeta(current,reserved,label='Reservado'){
  if(!(num(reserved)>0))return '';
  const diff=num(current)-num(reserved),cls=diff<0?'tracker-diff-better':diff>0?'tracker-diff-worse':'tracker-diff-same';
  return `<div class="tracker-kpi-meta"><span>${esc(label)} ${formatMoney(reserved)}</span><strong class="tracker-kpi-diff ${cls}">Diferencia ${signedMoney(diff)}</strong></div>`;
}
function vuelingComparisonMeta(current,reserved,label='Reservado'){return trackerComparisonMeta(current,reserved,label);}
function vuelingHistoryChart(a){
  const rows=(a.history||[]).filter(x=>x?.date&&num(x.total)>0).sort((x,y)=>Date.parse(x.date||0)-Date.parse(y.date||0)).slice(-30);if(rows.length<2)return '<p class="help-text">El gráfico aparecerá cuando haya al menos dos comprobaciones correctas.</p>';
  const width=720,height=180,padX=38,padY=22,series=[['total','Total'],['outbound','Ida'],['return','Vuelta'],['baggage','Equipaje']];
  const values=rows.flatMap(r=>series.map(([k])=>num(r[k])).filter(v=>v>0)),lo=Math.min(...values),hi=Math.max(...values),range=Math.max(1,hi-lo),min=Math.max(0,lo-range*.12),max=hi+range*.12;
  const xFor=i=>padX+(width-padX*2)*(rows.length===1?0:i/(rows.length-1)),yFor=v=>padY+(height-padY*2)*(1-(v-min)/(max-min));
  const paths=series.map(([key,label],sIndex)=>{const pts=rows.map((r,i)=>({x:xFor(i),y:yFor(num(r[key])),v:num(r[key]),date:r.date})).filter(p=>p.v>0);if(pts.length<2)return '';const d=pts.map((p,i)=>`${i?'L':'M'} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(' ');const points=pts.map(p=>{const text=`${label} · ${formatDate(p.date,{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'})} · ${formatMoney(p.v)}`;return `<circle cx="${p.x.toFixed(1)}" cy="${p.y.toFixed(1)}" r="3.8" class="vueling-chart-point vueling-series-${sIndex} tracker-chart-hover-point" tabindex="0" data-tracker-chart-tooltip="${esc(text)}"><title>${esc(text)}</title></circle>`;}).join('');return `<path d="${d}" class="vueling-chart-line vueling-series-${sIndex}" fill="none"/><g>${points}</g>`;}).join('');
  const first=rows[0],last=rows.at(-1);return `<div class="vueling-chart-legend">${series.map(([,label],i)=>`<span class="vueling-legend-${i} vueling-legend-style-${i}"><i></i>${esc(label)}</span>`).join('')}</div><div class="cordial-chart-wrap"><svg class="cordial-chart vueling-chart" viewBox="0 0 ${width} ${height}" role="img" aria-label="Evolución de precio total, ida, vuelta y equipaje Vueling"><line x1="${padX}" y1="${height-padY}" x2="${width-padX}" y2="${height-padY}" class="cordial-chart-axis"/>${paths}<text x="${padX}" y="${height-5}" class="cordial-chart-label">${esc(formatDate(first.date,{day:'2-digit',month:'short'}))}</text><text x="${width-padX}" y="${height-5}" text-anchor="end" class="cordial-chart-label">${esc(formatDate(last.date,{day:'2-digit',month:'short'}))}</text></svg></div>`;
}
function vuelingControlMarkup(a){
  const status=state.vuelingControlStatus,editDisabled=canEdit()?'':'disabled',automationDisabled=canManageAutomations()?'':'disabled',installStatus=status?status.installed?'Automatización instalada':'Automatización pendiente':'Sin comprobar';
  return `<details class="autoreisen-control vueling-control"><summary><span>⚙️ Centro de control Vueling</span><span class="autoreisen-summary-badges"><b class="status-pill ${a.enabled===false?'off':'on'}">Monitor ${a.enabled===false?'OFF':'ON'}</b><b class="status-pill ${a.telegramEnabled===false?'off':'on'}">Telegram ${a.telegramEnabled===false?'OFF':'ON'}</b></span></summary><div class="autoreisen-control-body"><div class="autoreisen-control-grid"><article class="autoreisen-control-panel"><h4>Monitor</h4><label class="switch-row"><span><strong>Seguimiento diario</strong><small>Recorre la reserva hasta el resumen final, sin comprar ni pagar.</small></span><input type="checkbox" data-vueling-enabled ${a.enabled!==false?'checked':''} ${editDisabled}></label><div class="control-field"><span>Programación</span><strong>Todos los días · ${esc(a.scheduleTime||'06:40')}</strong><small>Europe/Madrid</small></div></article><article class="autoreisen-control-panel"><h4>Reserva simulada</h4><p><strong>${esc(a.outboundFlight)} ${esc(a.origin)} → ${esc(a.destination)}</strong> · ${esc(a.outboundTime||'')}</p><p><strong>${esc(a.returnFlight)} ${esc(a.destination)} → ${esc(a.origin)}</strong> · ${esc(a.returnTime||'')}</p><p>${vuelingPassengerCount(a)} pasajeros · ${esc(a.fare||'FLY LIGHT')}</p><p><strong>Equipaje:</strong> ${esc(vuelingBaggageControlLabel(a))}</p><small>El proceso se detiene en “Detalles de tu reserva”.</small></article></div><div class="autoreisen-control-status"><div><span>Automatización</span><strong>${esc(installStatus)}</strong></div><div><span>Última consulta</span><strong>${a.lastUpdated?esc(formatDate(a.lastUpdated,{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'})):'—'}</strong></div><div><span>Último error</span><strong class="${a.lastError?'error-text':''}">${esc(a.lastError||'Ninguno')}</strong></div></div><div class="page-actions autoreisen-control-actions"><button type="button" class="btn primary" data-vueling-save ${editDisabled}>Guardar y sincronizar</button><button type="button" class="btn secondary" data-vueling-run>▶ Comprobar ahora</button><button type="button" class="btn secondary" data-vueling-telegram-test>✈ Probar Telegram</button><button type="button" class="btn secondary" data-vueling-status>✓ Comprobar sistema</button><button type="button" class="btn secondary" data-vueling-history-refresh>↻ Actualizar histórico</button><button type="button" class="btn ghost" data-vueling-install ${automationDisabled}>↻ Instalar/actualizar automatización</button></div><div class="tracker-run-progress-wrap" data-tracker-run-progress="vueling">${trackerRunProgressMarkup('vueling')}</div><p class="help-text">Vueling se ejecuta en un Worker independiente y GitHub Actions con Playwright. Si el flujo cambia, se conserva el último resultado válido y GitHub guarda capturas/HTML de diagnóstico.</p></div></details>`;
}
function renderVuelingTrackerCard(statusText){
  const a=state.data.trackers.vueling,has=num(a.currentPrice)>0&&Boolean(a.lastUpdated),reserved=vuelingBudgetReference(a);
  const budgetNote=reserved.source==='Presupuesto'?`<div class="tracker-budget-reference">✓ Comparación automática con Presupuesto · ${esc((reserved.label||'Reservado').toLowerCase())} ${formatMoney(reserved.total)}</div>`:reserved.source?`<div class="tracker-budget-reference is-fallback">Referencia manual · ${formatMoney(reserved.total)}</div>`:'';
  const content=`<div class="tracker-route">${esc(a.origin)} ⇄ ${esc(a.destination)} · ${esc(a.outboundFlight)} / ${esc(a.returnFlight)} · ${vuelingPassengerCount(a)} pasajeros</div>${budgetNote}${trackerSearchDateMarkup('vueling',a)}<div class="tracker-kpis vueling-kpis"><div class="vueling-kpi-card tracker-kpi-card tracker-primary-kpi vueling-total-kpi"><span>Precio total</span><strong>${has?formatMoney(a.currentPrice):'—'}</strong>${has?vuelingComparisonMeta(a.currentPrice,reserved.total,reserved.label):''}</div><div class="vueling-kpi-card tracker-kpi-card"><span>Ida · vuelo</span><strong>${has?formatMoney(a.outboundPrice):'—'}</strong>${has?vuelingComparisonMeta(a.outboundPrice,reserved.outbound,reserved.outboundLabel):''}</div><div class="vueling-kpi-card tracker-kpi-card"><span>Vuelta · vuelo</span><strong>${has?formatMoney(a.returnPrice):'—'}</strong>${has?vuelingComparisonMeta(a.returnPrice,reserved.return,reserved.returnLabel):''}</div><div class="vueling-kpi-card tracker-kpi-card"><span>Equipaje facturado · ${esc(vuelingBaggageShortLabel(a))}</span><strong>${has?formatMoney(a.baggagePrice):'—'}</strong>${has?vuelingComparisonMeta(a.baggagePrice,reserved.baggage,reserved.baggageLabel):''}</div><div><span>Tarifa</span><strong>${esc(a.fare||'FLY LIGHT')}</strong></div><div><span>Disponibilidad</span><strong>${esc(a.availability||'—')}</strong></div></div><small class="muted tracker-status ${a.monitorStatus==='error'?'error-text':''}">${esc(statusText(a))}</small><h4 class="cordial-subtitle">Evolución de precios</h4>${vuelingHistoryChart(a)}${vuelingControlMarkup(a)}`;
  return trackerCard('vueling',a.title||'Vueling','✈️',content,`<button class="btn secondary" data-refresh-tracker="vueling">↻ Consultar último dato</button><button class="btn secondary" data-edit-tracker="vueling">✎ Configurar</button><button class="btn secondary" data-tracker-icon-edit="vueling">🖼 Icono</button>${safeLink('https://www.vueling.com/es','Abrir Vueling','↗','', 'vueling')}`);
}
function readVuelingControls(){const a=state.data.trackers.vueling,input=$('[data-vueling-enabled]');return {...a,enabled:input?Boolean(input.checked):a.enabled!==false};}
async function requireVuelingWorker(){const h=await fetchVuelingHealth();if(h?.version!=='1.0.23')throw new Error(`El Worker Vueling está desactualizado. Se necesita v1.0.23 y responde ${h?.version||'desconocido'}. Ejecuta la actualización actual para reparar/publicar los Workers y vuelve a intentarlo.`);return h;}
async function saveVuelingControl({toastSuccess=true}={}){if(!canEdit())throw new Error('Desbloquea la edición para cambiar Vueling.');synchronizeTrackerTripDataLocally();Object.assign(state.data.trackers.vueling,readVuelingControls());await saveSection('trackers');await requireVuelingWorker();const r=await callVuelingWorker({action:'github-vueling-sync',config:state.data.trackers.vueling},{authenticated:true});state.vuelingControlStatus={...(state.vuelingControlStatus||{}),lastSync:r.updatedAt};if(toastSuccess)toast('Vueling sincronizado con GitHub.');return r;}
async function checkVuelingControlStatus(){toast('Comprobando automatización Vueling…');await requireVuelingWorker();const r=await callVuelingWorker({action:'github-vueling-status'},{authenticated:true});state.vuelingControlStatus=r;render();toast(r.installed?'Automatización Vueling preparada.':'Falta instalar/actualizar Vueling.');return r;}
async function installVuelingControl(){if(!canManageAutomations())throw new Error('Tu usuario no tiene permisos para instalar la automatización.');await requireVuelingWorker();toast('Instalando Vueling en GitHub…');const r=await callVuelingWorker({action:'github-vueling-install',config:state.data.trackers.vueling},{authenticated:true});if(r?.installed!==true)throw new Error('El Worker no confirmó la instalación Vueling.');state.vuelingControlStatus=r;render();toast('Automatización Vueling instalada/actualizada.');return r;}
function newestVuelingEvent(rows=[]){return [...(Array.isArray(rows)?rows:[])].filter(Boolean).sort((a,b)=>Date.parse(b.checkedAt||b.receivedAt||0)-Date.parse(a.checkedAt||a.receivedAt||0))[0]||null;}
function applyVuelingResult(data){const result=data?.result||data,a=state.data.trackers.vueling;if(!result||result.ok===false||result.status==='error')throw new Error(result?.error||data?.error||'Vueling no devolvió un resultado válido.');a.currentPrice=num(result.total);a.outboundPrice=num(result.outbound);a.returnPrice=num(result.return);a.baggagePrice=num(result.baggage||result.services);a.availability=result.availability||'Disponible';a.lastUpdated=result.checkedAt||new Date().toISOString();a.lastAttempt=a.lastUpdated;a.lastError='';a.monitorStatus='ok';a.source=result.source||'Vueling · Playwright';const row={date:a.lastUpdated,total:a.currentPrice,outbound:a.outboundPrice,return:a.returnPrice,baggage:a.baggagePrice,source:a.source};a.history=[...(a.history||[]).filter(x=>String(x?.date||'')!==String(row.date)),row].slice(-365);}
async function refreshVuelingHistory({silent=false}={}){if(!silent)toast('Actualizando histórico Vueling…');const data=await callVuelingWorker({action:'monitor-history'});const rows=(data.results||[]).filter(x=>x&&x.ok!==false&&x.status!=='error'&&num(x.total)>0).map(x=>({date:x.checkedAt||x.receivedAt||'',total:num(x.total),outbound:num(x.outbound),return:num(x.return),baggage:num(x.baggage||x.services),source:x.source||'Vueling'}));state.data.trackers.vueling.history=rows.slice(-365);if(!silent){await saveSection('trackers');render();toast(`Histórico Vueling actualizado · ${rows.length} registros.`);}return rows;}
async function pollVuelingRun(startedAt,{timeoutMs=540000,intervalMs=9000}={}){const deadline=Date.now()+timeoutMs,a=state.data.trackers.vueling;while(Date.now()<deadline){const h=await callVuelingWorker({action:'monitor-history'}).catch(()=>({results:[]})),latest=newestVuelingEvent(h.results||[]),stamp=Date.parse(latest?.checkedAt||latest?.receivedAt||'');if(latest&&Number.isFinite(stamp)&&stamp>=startedAt-2500){a.lastAttempt=latest.checkedAt||latest.receivedAt||new Date().toISOString();if(latest.status==='error'||latest.ok===false){a.monitorStatus='error';a.lastError=latest.error||'La comprobación Vueling ha fallado.';await saveSection('trackers');render();toast(`Vueling: ${a.lastError}`,'error');return {ok:false,event:latest};}const data=await callVuelingWorker({action:'vueling'});applyVuelingResult(data);await refreshVuelingHistory({silent:true});await saveSection('trackers');render();toast(`Vueling actualizado · ${formatMoney(a.currentPrice)}`);return {ok:true,event:latest};}await new Promise(r=>setTimeout(r,intervalMs));}toast('Vueling sigue ejecutándose en GitHub Actions. El resultado aparecerá al volver a Seguimientos.');return {ok:null};}
async function runVuelingNow(){if(canEdit())await saveVuelingControl({toastSuccess:false});else await requireVuelingWorker();const startedAt=Date.now();state.trackerRunProgress.vueling={runFound:false,startedAfter:new Date(startedAt).toISOString(),localLabel:'lanzando…',localPercentage:2};paintTrackerRunProgress('vueling');toast('Lanzando Vueling con navegador real…');try{const r=await callVuelingWorker({action:'github-vueling-run',config:state.data.trackers.vueling,force:true},{authenticated:true,timeoutMs:30000});if(r?.workflowTriggered!==true)throw new Error('No se pudo lanzar el workflow Vueling.');startTrackerRunProgress('vueling',startedAt);await pollVuelingRun(startedAt);}catch(error){setTrackerRunError('vueling',error,startedAt);throw error;}}
async function testVuelingTelegram(){if(canEdit())await saveVuelingControl({toastSuccess:false});else await requireVuelingWorker();if(state.data.trackers.vueling.telegramEnabled===false)throw new Error('Telegram está desactivado en Vueling.');const startedAt=Date.now();toast('Lanzando prueba de Telegram Vueling…');try{const r=await callVuelingWorker({action:'github-vueling-run',config:state.data.trackers.vueling,mode:'telegram-test',telegramTest:true,force:true},{authenticated:true,timeoutMs:30000});if(r?.workflowTriggered!==true)throw new Error('No se pudo lanzar la prueba de Telegram Vueling.');startTrackerRunProgress('vueling',startedAt);toast('Prueba de Telegram Vueling lanzada. Puedes seguir los pasos aquí.');}catch(error){setTrackerRunError('vueling',error,startedAt);throw error;}}
function openVuelingEditor(){
  const current=state.data.trackers.vueling;
  const bags=normalizeVuelingCheckedBags(current);
  const bagSlots=Array.from({length:3},(_,i)=>bags[i]||null);
  const values={textColor:'#ffffff',...current};
  for(let i=0;i<3;i++){
    const bag=bagSlots[i];const n=i+1;
    values[`bag${n}Kg`]=bag?.kg||0;
    values[`bag${n}Passenger`]=bag?.passenger||Math.min(n,vuelingSeatedPassengerCount(current));
    values[`bag${n}Trip`]=bag?(bag.outbound&&bag.return?'both':bag.outbound?'outbound':'return'):'both';
  }
  const weightOptions=[{value:0,label:'Sin maleta'},...VUELING_BAG_WEIGHTS.map(kg=>({value:kg,label:`${kg} kg`}))];
  const passengerOptions=Array.from({length:5},(_,i)=>({value:i+1,label:`Pasajero ${i+1}`}));
  const tripOptions=[{value:'both',label:'Ida y vuelta'},{value:'outbound',label:'Solo ida'},{value:'return',label:'Solo vuelta'}];
  openForm({title:'Configurar seguimiento Vueling',fields:[
    {name:'title',label:'Título del bloque',required:true,full:true},...trackerIconEditorFields(),{name:'origin',label:'Origen IATA',required:true},{name:'destination',label:'Destino IATA',required:true},{name:'departureDate',label:'Fecha ida',type:'date',required:true},{name:'returnDate',label:'Fecha vuelta',type:'date',required:true},
    {name:'outboundFlight',label:'Vuelo ida',required:true},{name:'returnFlight',label:'Vuelo vuelta',required:true},{name:'outboundTime',label:'Hora ida',type:'time',required:true},{name:'returnTime',label:'Hora vuelta',type:'time',required:true},{name:'adults',label:'Adultos',type:'number',step:'1',min:'1',max:'5',required:true},{name:'children',label:'Niños',type:'number',step:'1',min:'0',max:'4'},{name:'infants',label:'Bebés',type:'number',step:'1',min:'0',max:'4'},
    {name:'fare',label:'Tarifa',required:true},{name:'directOnly',label:'Solo vuelos directos',type:'checkbox',full:true},{name:'underseatBag',label:'1 pieza bajo el asiento (40x30x20)',type:'checkbox',full:true},{name:'sameHandBaggageAllPassengers',label:'Equipaje de mano · misma selección para todos',type:'checkbox',full:true},
    {name:'passenger1FirstName',label:'Pasajero 1 · Nombre',required:true},{name:'passenger1LastName',label:'Pasajero 1 · Apellidos',required:true},{name:'passenger2FirstName',label:'Pasajero 2 · Nombre'},{name:'passenger2LastName',label:'Pasajero 2 · Apellidos'},{name:'passenger3FirstName',label:'Pasajero 3 · Nombre'},{name:'passenger3LastName',label:'Pasajero 3 · Apellidos'},{name:'passenger4FirstName',label:'Pasajero 4 · Nombre'},{name:'passenger4LastName',label:'Pasajero 4 · Apellidos'},{name:'passenger5FirstName',label:'Pasajero 5 · Nombre'},{name:'passenger5LastName',label:'Pasajero 5 · Apellidos'},
    {name:'bag1Kg',label:'Maleta 1 · peso',type:'select',options:weightOptions},{name:'bag1Passenger',label:'Maleta 1 · pasajero',type:'select',options:passengerOptions},{name:'bag1Trip',label:'Maleta 1 · trayecto',type:'select',options:tripOptions},
    {name:'bag2Kg',label:'Maleta 2 · peso',type:'select',options:weightOptions},{name:'bag2Passenger',label:'Maleta 2 · pasajero',type:'select',options:passengerOptions},{name:'bag2Trip',label:'Maleta 2 · trayecto',type:'select',options:tripOptions},
    {name:'bag3Kg',label:'Maleta 3 · peso',type:'select',options:weightOptions},{name:'bag3Passenger',label:'Maleta 3 · pasajero',type:'select',options:passengerOptions},{name:'bag3Trip',label:'Maleta 3 · trayecto',type:'select',options:tripOptions},
    {name:'contactFirstName',label:'Nombre contacto',required:true},{name:'contactLastName',label:'Apellidos contacto',required:true},{name:'email',label:'Email',type:'email',required:true,full:true},{name:'country',label:'País',required:true},{name:'phonePrefix',label:'Prefijo',required:true},{name:'phone',label:'Móvil',required:true},
    {name:'marketingConsent',label:'Quiero recibir información y ofertas personalizadas',type:'checkbox',full:true},{name:'telegramEnabled',label:'Telegram activo',type:'checkbox',full:true},{name:'telegramNotifyEveryCheck',label:'Telegram en cada comprobación',type:'checkbox',full:true},{name:'telegramNotifyPriceDrop',label:'Telegram cuando baje el precio',type:'checkbox',full:true},{name:'reservedPrice',label:'Precio reservado manual (solo si Presupuesto no tiene desglose)',type:'number',step:'0.01',full:true},{name:'scheduleTime',label:'Hora diaria',type:'time'},{name:'color',label:'Color de acento',type:'color'},{name:'gradient1',label:'Degradado inicio',type:'color'},{name:'gradient2',label:'Degradado fin',type:'color'},{name:'textColor',label:'Color del texto del título',type:'color'}
  ],values,onSubmit:async v=>{
    await applyTrackerIconEditorValues(current,v,TRACKER_DEFAULT_ICONS.vueling||'✈️');delete v.titleIconFile;
    const adults=Math.max(1,Math.min(5,num(v.adults)||1)),children=Math.max(0,Math.min(4,num(v.children))),infants=Math.max(0,Math.min(4,num(v.infants)));
    if(adults+children+infants>5)throw new Error('Vueling admite en este seguimiento un máximo de 5 pasajeros en total.');
    const seated=Math.max(1,adults+children),checkedBags=[];
    for(let i=1;i<=3;i++){
      const kg=num(v[`bag${i}Kg`]);if(!VUELING_BAG_WEIGHTS.includes(kg))continue;
      const passenger=Math.max(1,num(v[`bag${i}Passenger`])||1);if(passenger>seated)throw new Error(`La maleta ${i} está asignada al pasajero ${passenger}, pero solo hay ${seated} viajeros con asiento.`);
      const trip=String(v[`bag${i}Trip`]||'both');checkedBags.push({kg,passenger,outbound:trip!=='return',return:trip!=='outbound'});
    }
    for(let i=1;i<=3;i++){delete v[`bag${i}Kg`];delete v[`bag${i}Passenger`];delete v[`bag${i}Trip`];}
    const firstBag=checkedBags[0];
    const next={...current,...v,origin:String(v.origin||'').toUpperCase(),destination:String(v.destination||'').toUpperCase(),outboundFlight:String(v.outboundFlight||'').toUpperCase(),returnFlight:String(v.returnFlight||'').toUpperCase(),adults,children,infants,checkedBags,checkedBagKg:firstBag?.kg||25,checkedBagCount:checkedBags.length,checkedBagPassenger:firstBag?.passenger||1,directOnly:Boolean(v.directOnly),underseatBag:Boolean(v.underseatBag),sameHandBaggageAllPassengers:Boolean(v.sameHandBaggageAllPassengers),sameBaggageRoundTrip:Boolean(firstBag&&checkedBags.every(b=>b.outbound&&b.return)),sameBaggageAllPassengers:false,marketingConsent:Boolean(v.marketingConsent),telegramEnabled:Boolean(v.telegramEnabled),telegramNotifyEveryCheck:Boolean(v.telegramNotifyEveryCheck),telegramNotifyPriceDrop:Boolean(v.telegramNotifyPriceDrop),reservedPrice:Math.max(0,num(v.reservedPrice)),scheduleTime:v.scheduleTime||'06:40',scheduleTimeZone:'Europe/Madrid'};
    Object.assign(current,next);await saveSection('trackers');let warning='';try{await requireVuelingWorker();await callVuelingWorker({action:'github-vueling-sync',config:current},{authenticated:true});}catch(e){warning=e.message;}render();if(warning)toast(`Vueling guardado. GitHub pendiente: ${warning}`,'error');else toast('Vueling guardado y sincronizado.');
  }});
}

function monitorFallbackTrackerInfo(id){
  return state.monitorFallbackStatus?.lastCheck?.trackers?.[id]||null;
}
function monitorFallbackStatusSuffix(id){
  const info=monitorFallbackTrackerInfo(id);if(!info)return '';
  if(info.dispatched){const when=info.dispatchedAt?formatDate(info.dispatchedAt,{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'}):'hoy';return ` · Respaldo Cloudflare lanzado ${when}`;}
  if(info.error)return ` · Respaldo pendiente: ${info.error}`;
  return '';
}
function monitorFallbackBanner(){
  const s=state.monitorFallbackStatus,last=s?.lastCheck;if(!s?.enabled)return '';
  const dispatched=last?.trackers?Object.entries(last.trackers).filter(([,v])=>v?.dispatched).map(([id])=>id):[];
  const errors=last?.trackers?Object.entries(last.trackers).filter(([,v])=>v?.error).map(([id])=>id):[];
  const label={autoreisen:'AutoReisen',cordial:'Cordial',vueling:'Vueling'};
  if(dispatched.length)return `<div class="tracker-fallback-banner is-active"><strong>⚠ Las automatizaciones principales no se ejecutaron hoy · Cloudflare lanzó el respaldo</strong><span>${esc(dispatched.map(id=>label[id]||id).join(' · '))}</span></div>`;
  if(errors.length)return `<div class="tracker-fallback-banner is-error"><strong>⚠ Respaldo Cloudflare con incidencias</strong><span>${esc(errors.map(id=>label[id]||id).join(' · '))}</span></div>`;
  return `<div class="tracker-fallback-banner"><strong>☁ Respaldo Cloudflare activo</strong><span>Comprobación diaria después de las 07:15 · Europe/Madrid</span></div>`;
}
async function refreshMonitorFallbackStatus({force=false,rerender=false}={}){
  const now=Date.now();if(!force&&state.monitorFallbackFetchedAt&&now-state.monitorFallbackFetchedAt<60000)return state.monitorFallbackStatus;
  try{
    let data=await callPriceWorker({action:'monitor-fallback-status'},{timeoutMs:10000});
    // Respaldo adicional del propio cliente: si la app se abre después de la ventana
    // diaria y Cloudflare todavía no ha completado la comprobación, un administrador
    // autenticado fuerza la misma verificación. Esto también recupera el día actual
    // cuando el Worker se publica después de la hora de sus Cron Triggers.
    const [hour,minute]=String(data?.localTime||'00:00').split(':').map(Number),afterWindow=(hour*60+minute)>=7*60+15;
    if(data?.enabled&&afterWindow&&data?.lastCheck?.completed!==true&&!DEMO_MODE&&typeof state.user?.getIdToken==='function'){
      try{
        await callIntegrationWorker({action:'monitor-fallback-run'});
        data=await callPriceWorker({action:'monitor-fallback-status'},{timeoutMs:10000});
      }catch(recoveryError){console.warn('Respaldo Cloudflare desde la app:',recoveryError.message);}
    }
    state.monitorFallbackStatus=data;state.monitorFallbackFetchedAt=Date.now();if(rerender&&state.activeTab==='trackers')render();return data;
  }
  catch(error){console.warn('Respaldo Cloudflare:',error.message);state.monitorFallbackFetchedAt=Date.now();return null;}
}

function renderTrackers(){
  synchronizeTrackerTripDataLocally();
  const t=state.data.trackers,ordered=(t.order||['autoreisen','cordial','vueling','fuel']).filter(id=>['autoreisen','cordial','vueling','fuel'].includes(id));
  const statusText=(x,id)=>{const base=x.lastError&&x.lastUpdated?`Último dato válido: ${formatDate(x.lastUpdated,{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'})}. Último intento fallido: ${x.lastError}`:x.lastUpdated?`Actualizado automáticamente ${formatDate(x.lastUpdated,{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'})}`:x.lastError?`Último intento fallido: ${x.lastError}`:'Sin consulta automática disponible todavía';return `${base}${monitorFallbackStatusSuffix(id)}`;};
  const cards={autoreisen:()=>renderAutoreisenTrackerCard(x=>statusText(x,'autoreisen')),cordial:()=>renderCordialTrackerCard(x=>statusText(x,'cordial')),vueling:()=>renderVuelingTrackerCard(x=>statusText(x,'vueling')),fuel:renderFuelTrackerCard};
  return `${lockedBanner()}${pageHead('Seguimientos','Alojamiento, vuelos, coche de alquiler y gasolina en tarjetas reordenables','')}${trackerSummaryStrip()}${monitorFallbackBanner()}<div class="tracker-grid">${ordered.filter(id=>t.visible?.[id]!==false).map(id=>cards[id]?.()||'').join('')}</div>`;
}
binders.trackers=()=>{
  void refreshMonitorFallbackStatus({rerender:true});
  resumeTrackerRunProgress();
  $$('[data-tracker-summary-target]').forEach(b=>{const open=()=>{const card=$(`[data-tracker-card="${b.dataset.trackerSummaryTarget}"]`);if(card)card.scrollIntoView({behavior:'smooth',block:'start'});};b.onclick=open;b.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();open();}});});
  $$('[data-tracker-summary-refresh]').forEach(button=>button.addEventListener('click',async event=>{event.preventDefault();event.stopPropagation();if(button.disabled)return;const id=String(button.dataset.trackerSummaryRefresh||'');const actions={autoreisen:runAutoreisenNow,cordial:runCordialNow,vueling:runVuelingNow};const action=actions[id];if(!action)return;const original=button.innerHTML;button.disabled=true;button.setAttribute('aria-busy','true');button.classList.add('is-running');try{await action();}catch(error){toast(error.message||String(error),'error');}finally{if(button.isConnected){button.disabled=false;button.removeAttribute('aria-busy');button.classList.remove('is-running');button.innerHTML=original;}}}));
  $$('.cordial-room-detail-link').forEach(link=>link.addEventListener('click',event=>event.stopPropagation()));
  $$('[data-tracker-move]').forEach(b=>b.onclick=async()=>{const[id,d]=b.dataset.trackerMove.split(':');moveArrayItem(state.data.trackers.order,state.data.trackers.order.indexOf(id),num(d));await saveSection('trackers');render();});
  $$('[data-tracker-toggle]').forEach(b=>b.onclick=async()=>{const id=b.dataset.trackerToggle;const label=id==='autoreisen'?'AutoReisen':id==='cordial'?(state.data.trackers.cordial?.title||'Cordial'):id==='vueling'?(state.data.trackers.vueling?.title||'Vueling'):id==='fuel'?'Gasolineras':'este seguimiento';if(!confirmAction(`¿Ocultar el bloque ${label}? Podrás restaurarlo en Configuración → Contenido → Seguimientos.`))return;state.data.trackers.visible[id]=false;await saveSection('trackers');render();toast(`${label} ocultado. Puedes restaurarlo desde Configuración.`);});
  $$('[data-edit-tracker]').forEach(b=>b.onclick=()=>editTracker(b.dataset.editTracker));
  $$('[data-tracker-icon-edit]').forEach(b=>b.onclick=()=>editTrackerTitleIcon(b.dataset.trackerIconEdit));
  $$('[data-refresh-tracker]').forEach(b=>b.onclick=()=>refreshTracker(b.dataset.refreshTracker));
  const bindAutoreisenAction=(selector,busyLabel,action)=>{const button=$(selector);if(!button)return;button.addEventListener('click',async()=>{if(button.disabled)return;const original=button.innerHTML;button.disabled=true;button.setAttribute('aria-busy','true');button.textContent=busyLabel;try{await action();}catch(e){toast(e.message||String(e),'error');}finally{if(button.isConnected){button.disabled=false;button.removeAttribute('aria-busy');button.innerHTML=original;}}});};
  bindAutoreisenAction('[data-autoreisen-save]','Guardando…',()=>saveAutoreisenControl());
  bindAutoreisenAction('[data-autoreisen-run]','▶ Lanzando…',()=>runAutoreisenNow());
  bindAutoreisenAction('[data-autoreisen-telegram-test]','✈ Enviando…',()=>testAutoreisenTelegram());
  bindAutoreisenAction('[data-autoreisen-status]','✓ Comprobando…',()=>checkAutoreisenControlStatus());
  bindAutoreisenAction('[data-autoreisen-history-refresh]','↻ Actualizando…',()=>refreshAutoreisenHistory());
  bindAutoreisenAction('[data-autoreisen-install]','↻ Instalando…',()=>installAutoreisenControl());
  bindAutoreisenAction('[data-cordial-save]','Guardando…',()=>saveCordialControl());
  bindAutoreisenAction('[data-cordial-run]','▶ Lanzando…',()=>runCordialNow());
  bindAutoreisenAction('[data-cordial-status]','✓ Comprobando…',()=>checkCordialControlStatus());
  bindAutoreisenAction('[data-cordial-history-refresh]','↻ Actualizando…',()=>refreshCordialHistory());
  bindAutoreisenAction('[data-cordial-install]','↻ Instalando…',()=>installCordialControl());
  bindAutoreisenAction('[data-vueling-save]','Guardando…',()=>saveVuelingControl());
  bindAutoreisenAction('[data-vueling-run]','▶ Lanzando…',()=>runVuelingNow());
  bindAutoreisenAction('[data-vueling-telegram-test]','✈ Enviando…',()=>testVuelingTelegram());
  bindAutoreisenAction('[data-vueling-status]','✓ Comprobando…',()=>checkVuelingControlStatus());
  bindAutoreisenAction('[data-vueling-history-refresh]','↻ Actualizando…',()=>refreshVuelingHistory());
  bindAutoreisenAction('[data-vueling-install]','↻ Instalando…',()=>installVuelingControl());
  $('[data-fuel-sort]')?.addEventListener('change',e=>{state.fuelSort=e.currentTarget.value;render();});
  $('[data-fuel-location]')?.addEventListener('click',()=>{if(!navigator.geolocation){toast('El dispositivo no ofrece geolocalización.','error');return;}navigator.geolocation.getCurrentPosition(pos=>{state.currentLocation={latitude:pos.coords.latitude,longitude:pos.coords.longitude,label:'ubicación actual'};render();toast('Distancias calculadas desde tu ubicación.');},error=>toast(`No se pudo obtener la ubicación: ${error.message}`,'error'),{enableHighAccuracy:true,timeout:12000});});
  $$('[data-fuel-favorite]').forEach(b=>b.onclick=async()=>{const key=b.dataset.fuelFavorite,f=state.data.trackers.fuel;f.favorites=f.favorites||[];const i=f.favorites.indexOf(key);if(i>=0)f.favorites.splice(i,1);else f.favorites.push(key);await saveSection('trackers');render();});
};
const AUTOREISEN_VERIFIED_OFFICES=[
  {id:'1',label:'Tenerife Norte (TFN)'},{id:'2',label:'Tenerife Sur (TFS)'},{id:'3',label:'Lanzarote (ACE)'},{id:'18',label:'Gran Canaria - Aeropuerto (LPA)'},{id:'19',label:'Fuerteventura (FUE)'}
];
const AUTOREISEN_REFERENCE_FLEET=[
  {group:'A',model:'Citröen C3 5P A/C',carId:''},
  {group:'C',model:'Seat Ibiza 5P A/C',carId:''},
  {group:'C',model:'VW Polo A/C',carId:''},
  {group:'D',model:'Seat Ibiza AUTOMATIC',carId:''},
  {group:'D',model:'Golf TSI AUTOMATIC',carId:''},
  {group:'E',model:'Hyundai i30',carId:''},
  {group:'E',model:'Seat Arona TSI Reference',carId:'119'},
  {group:'G',model:'Citröen C3 Aircross Family',carId:''},
  {group:'G',model:'D.Jogger 5 Pax Family',carId:''},
  {group:'H',model:'VW Golf 5P A/C',carId:''},
  {group:'H',model:'Citröen C4 PureTech',carId:''},
  {group:'H',model:'VW T-Cross',carId:''},
  {group:'H',model:'VW Taigo',carId:''},
  {group:'H',model:'VW T-Roc',carId:''}
];
const AUTOREISEN_GROUP_SUGGESTIONS=[...new Set(AUTOREISEN_REFERENCE_FLEET.map(x=>x.group))];
function autoreisenInferOfficeId(label=''){const n=String(label).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();if(n.includes('tenerife norte')||/\btfn\b/.test(n))return '1';if(n.includes('tenerife sur')||/\btfs\b/.test(n))return '2';if(n.includes('lanzarote')||/\bace\b/.test(n))return '3';if(n.includes('gran canaria')||/\blpa\b/.test(n))return '18';if(n.includes('fuerteventura')||/\bfue\b/.test(n))return '19';return '';}
function autoreisenCatalogOffices(current){
  const incoming=Array.isArray(current?.officeCatalog)?current.officeCatalog:[];const map=new Map();
  for(const x of [...AUTOREISEN_VERIFIED_OFFICES,...incoming]){const id=String(x?.id||x?.value||'').trim(),label=String(x?.label||x?.text||'').trim();if(id&&label)map.set(id,{id,label});}
  const ensure=(id,label)=>{id=String(id||'').trim();label=String(label||'').trim();if(id&&label&&!map.has(id))map.set(id,{id,label});};
  ensure(current?.pickupOfficeId,current?.pickup);ensure(current?.dropoffOfficeId,current?.dropoff);return [...map.values()];
}
function autoreisenCatalogFleet(current){
  const rows=Array.isArray(current?.fleetCatalog)?current.fleetCatalog:[];const map=new Map();
  for(const x of [...AUTOREISEN_REFERENCE_FLEET,...rows]){const group=String(x?.group||'').trim(),model=String(x?.model||'').trim(),carId=String(x?.carId||'').trim(),imageUrl=String(x?.imageUrl||'').trim(),pricePerDay=num(x?.pricePerDay),total=num(x?.total),availability=String(x?.availability||'').trim();if(group&&model)map.set(`${group}\u0000${model}`,{group,model,carId,imageUrl,pricePerDay,total,availability});}
  const group=String(current?.group||'').trim(),model=String(current?.model||'').trim(),carId=String(current?.carId||'').trim(),imageUrl=String(current?.imageUrl||'').trim();if(group&&model&&!map.has(`${group}\u0000${model}`))map.set(`${group}\u0000${model}`,{group,model,carId,imageUrl});
  return [...map.values()];
}
function autoreisenSelectOptions(rows,value,{sameOffice=false}={}){
  const options=[];if(sameOffice)options.push(`<option value="__same__">Misma oficina que recogida</option>`);
  for(const row of rows){const id=String(row.id||'').trim();options.push(`<option value="${esc(id)}" ${String(id)===String(value)?'selected':''}>${esc(row.label)}</option>`);}
  return options.join('');
}
function autoreisenModelTokens(value=''){return String(value).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim().split(' ').filter(x=>x.length>1&&!['o','or','similar','tsi','reference'].includes(x));}
function autoreisenBestFleetMatch(fleet,model=''){const tokens=autoreisenModelTokens(model);if(!tokens.length)return null;return fleet.find(x=>{const text=String(x.model||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();return tokens.every(t=>text.includes(t));})||null;}
function autoreisenFleetGroups(fleet,currentGroup,{includeReference=true}={}){
  const live=[...new Set((Array.isArray(fleet)?fleet:[]).map(x=>String(x.group||'').trim()).filter(Boolean))];
  const values=[...new Set([...live,...(includeReference?AUTOREISEN_GROUP_SUGGESTIONS:[])])].sort((a,b)=>a.localeCompare(b,undefined,{numeric:true}));
  if(currentGroup&&!values.includes(currentGroup))values.unshift(currentGroup);return values;
}
function autoreisenFleetModels(fleet,group,currentModel,currentCarId=''){
  const rows=fleet.filter(x=>String(x.group)===String(group));const values=rows.map(x=>({model:x.model,carId:x.carId||'',imageUrl:x.imageUrl||''}));
  if(currentModel&&!values.some(x=>x.model===currentModel))values.unshift({model:currentModel,carId:currentCarId,imageUrl:''});return values;
}
function readAutoreisenEditorDraft(form,current,fleet=[]){
  const pickupSelect=form.elements.pickupOfficeId,dropSelect=form.elements.dropoffOfficeId,group=form.elements.group,groupManual=form.elements.groupManual,model=form.elements.model,modelManual=form.elements.modelManual;
  const pickupOfficeId=String(pickupSelect?.value||current.pickupOfficeId||'').trim();const pickupLabel=pickupSelect?.selectedOptions?.[0]?.textContent?.trim()||current.pickup||'';
  const same=String(dropSelect?.value||'')==='__same__';const dropoffOfficeId=same?pickupOfficeId:String(dropSelect?.value||current.dropoffOfficeId||'').trim();const dropoffLabel=same?pickupLabel:(dropSelect?.selectedOptions?.[0]?.textContent?.trim()||current.dropoff||'');
  const groupValue=String(group?.value==='__manual__'?groupManual?.value:group?.value||'').trim(),modelValue=String(model?.value==='__manual__'?modelManual?.value:model?.value||'').trim();
  const norm=value=>String(value||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/\s+/g,' ').trim();
  const fleetMatch=(Array.isArray(fleet)?fleet:[]).find(x=>norm(x?.group)===norm(groupValue)&&norm(x?.model)===norm(modelValue));
  const sameSavedModel=norm(modelValue)===norm(current.model||'')&&norm(groupValue)===norm(current.group||'');
  const carId=String(fleetMatch?.carId||(sameSavedModel?current.carId:'')||'').trim();
  const imageUrl=String(fleetMatch?.imageUrl||(sameSavedModel?current.imageUrl:'')||'').trim();
  const manualImageUrl=String(form.elements.manualImageUrl?.value||current.manualImageUrl||'').trim();
  const fleetTrackAll=String(form.elements.fleetVisibilityMode?.value||'all')==='all';
  let fleetTrackGroups=[...form.querySelectorAll('[data-ar-track-group]:checked')].map(input=>String(input.value||'').trim()).filter(Boolean);
  fleetTrackGroups=[...new Set(fleetTrackGroups)];if(!fleetTrackAll&&!fleetTrackGroups.length&&groupValue)fleetTrackGroups=[groupValue];
  return {...current,pickup:pickupLabel.replace(/\s*\([A-Z]{3}\)\s*$/,''),dropoff:dropoffLabel.replace(/\s*\([A-Z]{3}\)\s*$/,''),pickupOfficeId,dropoffOfficeId,pickupAt:fromLocalInput(form.elements.pickupAt?.value||''),dropoffAt:fromLocalInput(form.elements.dropoffAt?.value||''),group:groupValue,model:modelValue,carId,imageUrl,manualImageUrl,fleetTrackAll,fleetTrackGroups,reservedPrice:num(form.elements.reservedPrice?.value),searchUrl:String(form.elements.searchUrl?.value||'').trim(),color:String(form.elements.color?.value||current.color||'#74B64C'),gradient1:String(form.elements.gradient1?.value||current.gradient1||'#294C1D'),gradient2:String(form.elements.gradient2?.value||current.gradient2||'#477C2F'),textColor:String(form.elements.textColor?.value||current.textColor||'#ffffff')};
}
function autoreisenUsesCustomDates(config={}){
  const settings=state.data.settings||{};
  const pickupDate=String(config.pickupAt||'').slice(0,10),dropoffDate=String(config.dropoffAt||'').slice(0,10);
  const tripPickup=String(settings.departureDateTime||'').slice(0,10),tripDropoff=String(settings.returnDateTime||'').slice(0,10);
  return Boolean((pickupDate&&tripPickup&&pickupDate!==tripPickup)||(dropoffDate&&tripDropoff&&dropoffDate!==tripDropoff));
}
async function persistAutoreisenManualDraft(current,draft,{offices=[],fleet=[]}={}){
  const customDates=autoreisenUsesCustomDates(draft);
  if(customDates)state.data.settings.autoreisenSyncWithTripDates=false;
  Object.assign(current,draft,{officeCatalog:offices,fleetCatalog:fleet});
  const results=await Promise.all([saveSection('trackers'),customDates?saveSection('settings'):Promise.resolve(true)]);
  if(results.some(ok=>ok===false))throw new Error('No se han podido guardar las fechas de AutoReisen.');
  return {customDates};
}
function autoreisenBrowserResultsUrl(config={}){
  const parts=value=>{const [date,time='00:00']=String(value||'').split('T');const [year,month,day]=date.split('-');return {year,month:String(Number(month||0)),day:String(Number(day||0)),time:time.slice(0,5)};};
  const p=parts(config.pickupAt),d=parts(config.dropoffAt),url=new URL('https://www.autoreisen.com/alquiler-coches/tarifas-flota.php');
  const rec=String(config.pickupOfficeId||'').trim(),dev=String(config.dropoffOfficeId||rec).trim();
  if(rec)url.searchParams.set('ofi_rec',rec);if(dev)url.searchParams.set('ofi_dev',dev);
  if(p.day)url.searchParams.set('dia_inicio',p.day);if(p.month&&p.year)url.searchParams.set('mes_inicio',`${p.month}-${p.year}`);if(p.time)url.searchParams.set('hora_inicio',p.time);
  if(d.day)url.searchParams.set('dia_final',d.day);if(d.month&&d.year)url.searchParams.set('mes_final',`${d.month}-${d.year}`);if(d.time)url.searchParams.set('hora_final',d.time);
  url.searchParams.set('fin','1');return url.toString();
}
async function openAutoreisenEditor(){
  const current=state.data.trackers.autoreisen;let offices=autoreisenCatalogOffices(current),fleet=autoreisenCatalogFleet(current);
  const pickupId=String(current.pickupOfficeId||autoreisenInferOfficeId(current.pickup)||'18'),dropId=String(current.dropoffOfficeId||autoreisenInferOfficeId(current.dropoff)||pickupId||'18');
  openModal(`<div class="modal-head"><h3>Configurar AutoReisen</h3><button class="close-btn" data-close-modal>×</button></div>
  <form id="modal-form"><div class="modal-body"><div class="form-row">
    <label class="field"><span>Oficina de recogida</span><select name="pickupOfficeId">${autoreisenSelectOptions(offices,pickupId)}</select></label>
    <label class="field"><span>Oficina de devolución</span><select name="dropoffOfficeId"><option value="__same__" ${dropId===pickupId?'selected':''}>Misma oficina que recogida</option>${autoreisenSelectOptions(offices,dropId)}</select></label>
    ${fieldHtml({name:'pickupAt',label:'Fecha/hora recogida',type:'datetime-local'},current.pickupAt)}
    ${fieldHtml({name:'dropoffAt',label:'Fecha/hora devolución',type:'datetime-local'},current.dropoffAt)}
    <div class="field full autoreisen-catalog-actions"><span>Opciones de AutoReisen</span><div class="page-actions"><button type="button" class="btn secondary small" data-ar-refresh-offices>↻ Actualizar oficinas</button><button type="button" class="btn secondary small" data-ar-refresh-fleet>🚗 Consultar flota para estas fechas</button><button type="button" class="btn secondary small" data-ar-open-autoreisen>↗ Abrir AutoReisen</button></div><div class="help-text" data-ar-catalog-status>El selector incluye el catálogo público de referencia de AutoReisen. “Consultar flota” lanza una comprobación real con navegador mediante GitHub Actions, porque AutoReisen bloquea las consultas HTTP directas del Worker.</div></div>
    <div class="field full autoreisen-fleet-tracking-config"><span>Categorías visibles en Seguimiento</span><div class="autoreisen-visibility-mode"><label class="autoreisen-visibility-option"><input type="radio" name="fleetVisibilityMode" value="all" ${current.fleetTrackAll!==false?'checked':''}><span><strong>Todas visibles</strong><small>Muestra todos los coches encontrados para las fechas seleccionadas.</small></span></label><label class="autoreisen-visibility-option"><input type="radio" name="fleetVisibilityMode" value="selected" ${current.fleetTrackAll===false?'checked':''}><span><strong>Solo categorías seleccionadas</strong><small>Elige una sola categoría o varias.</small></span></label></div><div class="autoreisen-category-picker" data-ar-track-groups></div><div class="help-text">La consulta guarda siempre la flota completa. Esta opción solo decide qué categorías ves en Seguimiento. Si eliges fechas distintas de las del viaje, AutoReisen las guardará como fechas independientes y dejará de volver automáticamente a septiembre.</div></div>
    <label class="field"><span>Grupo</span><select name="group"></select><input name="groupManual" autocomplete="off" placeholder="Escribe el grupo" hidden><div class="help-text">El desplegable muestra todos los grupos detectados para la consulta. Si necesitas uno distinto, elige “Otro grupo…”.</div></label>
    <label class="field"><span>Modelo orientativo</span><select name="model"></select><input name="modelManual" autocomplete="off" placeholder="Escribe el modelo" hidden><div class="help-text">Al cambiar de grupo se muestran sus modelos. La selección queda guardada hasta que tú la cambies.</div></label>
    ${fieldHtml({name:'reservedPrice',label:'Precio reservado',type:'number',step:'0.01'},current.reservedPrice)}
    ${fieldHtml({name:'searchUrl',label:'Enlace AutoReisen',type:'url',full:true},current.searchUrl)}
    ${fieldHtml({name:'manualImageUrl',label:'Imagen manual del coche (opcional)',type:'url',full:true,driveImage:true,help:'Esta es la FOTO DEL COCHE, no el icono del seguimiento. Se usa como prioridad sobre la imagen automática de AutoReisen.'},current.manualImageUrl||'')}
    ${trackerIconEditorFields().map(field=>fieldHtml(field,current[field.name]||'')).join('')}
    ${fieldHtml({name:'color',label:'Color de acento',type:'color'},current.color)}
    ${fieldHtml({name:'gradient1',label:'Degradado inicio',type:'color'},current.gradient1)}
    ${fieldHtml({name:'gradient2',label:'Degradado fin',type:'color'},current.gradient2)}
    ${fieldHtml({name:'textColor',label:'Color del texto del título',type:'color'},current.textColor||'#ffffff')}
  </div></div><div class="modal-actions"><button class="btn ghost" type="button" data-close-modal>Cancelar</button><button class="btn primary" type="submit">Guardar y sincronizar</button></div></form>`);
  $$('[data-close-modal]',els.modal).forEach(b=>b.addEventListener('click',closeModal));bindHexColorControls(els.modal);bindModalDriveUrlPickers(els.modal);
  const form=$('#modal-form',els.modal),groupInput=form.elements.group,groupManual=form.elements.groupManual,modelInput=form.elements.model,modelManual=form.elements.modelManual,status=$('[data-ar-catalog-status]',form),trackGroupsRoot=$('[data-ar-track-groups]',form),visibilityModeInputs=$$('input[name="fleetVisibilityMode"]',form);
  const MANUAL='__manual__';
  let fleetConfirmed=false,trackingSelection=new Set((Array.isArray(current.fleetTrackGroups)?current.fleetTrackGroups:[]).map(x=>String(x||'').trim()).filter(Boolean));
  if(!trackingSelection.size&&current.group)trackingSelection.add(String(current.group));
  const visibilityMode=()=>String(form.elements.fleetVisibilityMode?.value||'all');
  const renderTrackingGroups=()=>{
    const groups=autoreisenFleetGroups(fleet,current.group,{includeReference:true}),allVisible=visibilityMode()==='all';
    if(!trackGroupsRoot)return;trackGroupsRoot.innerHTML=groups.map(group=>`<label class="autoreisen-category-chip ${allVisible?'is-disabled':''}"><input type="checkbox" data-ar-track-group value="${esc(group)}" ${trackingSelection.has(group)?'checked':''} ${allVisible?'disabled':''}><span>Grupo ${esc(group)}</span></label>`).join('');
    $$('[data-ar-track-group]',trackGroupsRoot).forEach(input=>input.addEventListener('change',()=>{if(input.checked)trackingSelection.add(String(input.value));else trackingSelection.delete(String(input.value));}));
  };
  visibilityModeInputs.forEach(input=>input.addEventListener('change',()=>renderTrackingGroups()));
  const actualGroup=()=>groupInput.value===MANUAL?String(groupManual.value||'').trim():String(groupInput.value||'').trim();
  const syncManualFields=()=>{groupManual.hidden=groupInput.value!==MANUAL;modelManual.hidden=modelInput.value!==MANUAL;};
  const renderModels=(preferredModel='',forceValue=false)=>{
    const groupValue=actualGroup();
    const models=autoreisenFleetModels(fleet,groupValue,'','');
    const known=models.map(x=>String(x.model||''));
    modelInput.innerHTML=`${models.map(x=>`<option value="${esc(x.model)}">${esc(x.model)}</option>`).join('')}<option value="${MANUAL}">Otro modelo…</option>`;
    const wanted=String(preferredModel||'').trim();
    if(wanted&&known.includes(wanted)){modelInput.value=wanted;modelManual.value='';}
    else if(wanted){modelInput.value=MANUAL;modelManual.value=wanted;}
    else if(models.length){modelInput.value=models[0].model;modelManual.value='';}
    else{modelInput.value=MANUAL;if(forceValue)modelManual.value='';}
    syncManualFields();
  };
  const renderFleet=(preferredGroup=current.group,preferredModel=current.model,{forceValues=false}={})=>{
    const groups=autoreisenFleetGroups(fleet,'',{includeReference:!fleetConfirmed});
    const wantedGroup=String(preferredGroup||'').trim();
    groupInput.innerHTML=`${groups.map(x=>`<option value="${esc(x)}">${esc(x)}</option>`).join('')}<option value="${MANUAL}">Otro grupo…</option>`;
    if(wantedGroup&&groups.includes(wantedGroup)){groupInput.value=wantedGroup;groupManual.value='';}
    else if(wantedGroup){groupInput.value=MANUAL;groupManual.value=wantedGroup;}
    else if(groups.length){groupInput.value=groups[0];groupManual.value='';}
    else{groupInput.value=MANUAL;groupManual.value='';}
    syncManualFields();
    renderModels(preferredModel,forceValues);
  };
  renderFleet(current.group,current.model,{forceValues:true});renderTrackingGroups();
  groupInput.addEventListener('change',()=>{syncManualFields();if(groupInput.value===MANUAL){modelInput.innerHTML=`<option value="${MANUAL}">Otro modelo…</option>`;modelInput.value=MANUAL;modelManual.value='';syncManualFields();}else renderModels('',true);});
  groupManual.addEventListener('input',()=>{if(groupInput.value===MANUAL){modelInput.innerHTML=`<option value="${MANUAL}">Otro modelo…</option>`;modelInput.value=MANUAL;syncManualFields();}});
  modelInput.addEventListener('change',syncManualFields);
  const replaceOfficeOptions=(next)=>{if(!next?.length)return;const oldPickup=form.elements.pickupOfficeId.value,oldDrop=form.elements.dropoffOfficeId.value;offices=autoreisenCatalogOffices({...current,officeCatalog:next});form.elements.pickupOfficeId.innerHTML=autoreisenSelectOptions(offices,oldPickup);form.elements.dropoffOfficeId.innerHTML=`<option value="__same__">Misma oficina que recogida</option>${autoreisenSelectOptions(offices,oldDrop==='__same__'?'':oldDrop)}`;if(oldDrop==='__same__')form.elements.dropoffOfficeId.value='__same__';};
  $('[data-ar-refresh-offices]',form).onclick=async()=>{try{status.textContent='Consultando oficinas de AutoReisen…';const data=await callIntegrationWorker({action:'autoreisen-options',mode:'offices',config:readAutoreisenEditorDraft(form,current,fleet)});if(!Array.isArray(data.offices)||!data.offices.length)throw new Error('AutoReisen no devolvió oficinas válidas.');replaceOfficeOptions(data.offices);current.officeCatalog=offices;status.textContent=data.warning||`Oficinas actualizadas (${offices.length}) · ${data.source||'AutoReisen'}.`;}catch(error){status.textContent=`No se han sustituido las oficinas: ${error.message}`;toast(status.textContent,'error');}};
  let fleetRefreshToken=0;
  const refreshFleet=async()=>{
    const token=++fleetRefreshToken,button=$('[data-ar-refresh-fleet]',form),draft=readAutoreisenEditorDraft(form,current,fleet);
    const requestId=`fleet-${Date.now()}-${Math.random().toString(36).slice(2,9)}`;
    try{
      if(!draft.pickupOfficeId||!draft.dropoffOfficeId)throw new Error('Selecciona las oficinas de recogida y devolución.');
      if(!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/.test(draft.pickupAt)||!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/.test(draft.dropoffAt))throw new Error('Selecciona fechas y horas válidas.');
      if(Date.parse(draft.dropoffAt)<=Date.parse(draft.pickupAt))throw new Error('La devolución debe ser posterior a la recogida.');
      if(button)button.disabled=true;groupInput.disabled=true;modelInput.disabled=true;
      status.textContent='Guardando estas fechas y preparando la consulta real de AutoReisen…';
      const persisted=await persistAutoreisenManualDraft(current,draft,{offices,fleet});
      // La consulta puntual usa exactamente el borrador ya guardado y, además, deja
      // actualizado el monitor diario para que no vuelva a consultar el periodo anterior.
      try{await callIntegrationWorker({action:'github-sync-autoreisen',config:current,runWorkflow:false});}catch(syncError){console.warn('AutoReisen: la consulta puntual continúa aunque la sincronización diaria quede pendiente.',syncError);}
      if(token!==fleetRefreshToken)return;
      status.textContent=`Fechas guardadas${persisted.customDates?' como periodo independiente':''}. Abriendo AutoReisen con un navegador real en GitHub Actions… puede tardar alrededor de 1–3 minutos.`;
      const run=await callIntegrationWorker({action:'github-autoreisen-run',mode:'fleet',force:true,requestId,config:current});
      if(run?.workflowTriggered!==true)throw new Error('No se ha podido iniciar la consulta de flota.');
      const deadline=Date.now()+210000;let data=null;
      while(Date.now()<deadline&&token===fleetRefreshToken){
        await wait(6500);data=await callIntegrationWorker({action:'autoreisen-fleet-result',requestId});
        if(!data?.pending)break;
        const remaining=Math.max(0,Math.ceil((deadline-Date.now())/1000));status.textContent=`AutoReisen se está consultando con navegador… ${remaining}s de espera máxima. Puedes mantener esta ventana abierta.`;
      }
      if(token!==fleetRefreshToken)return;
      if(!data||data.pending){status.textContent='La consulta sigue ejecutándose en GitHub Actions. El catálogo de referencia continúa disponible; vuelve a pulsar “Consultar flota” dentro de un momento para una nueva comprobación.';return;}
      const result=data.result||{};if(result.ok===false||result.status==='error')throw new Error(result.error||'AutoReisen no devolvió una flota válida.');
      if(result.noAvailability){status.textContent='AutoReisen ha confirmado que no hay vehículos disponibles para esas oficinas y fechas. El catálogo inferior se mantiene solo como referencia.';return;}
      if(!Array.isArray(result.fleet)||!result.fleet.length)throw new Error('La consulta terminó, pero AutoReisen no devolvió vehículos interpretables.');
      const liveMap=new Map();for(const x of result.fleet){const group=String(x?.group||'').trim(),model=String(x?.model||'').trim(),carId=String(x?.carId||'').trim(),imageUrl=String(x?.imageUrl||'').trim(),pricePerDay=num(x?.pricePerDay),total=num(x?.total),availability=String(x?.availability||'Disponible');if(group&&model)liveMap.set(`${group}\u0000${model}`,{group,model,carId,imageUrl,pricePerDay,total,availability});}
      fleet=[...liveMap.values()];fleetConfirmed=true;renderTrackingGroups();const match=autoreisenBestFleetMatch(fleet,draft.model);
      const preferredGroup=match?.group||(fleet.some(x=>String(x.group)===String(draft.group))?draft.group:fleet[0]?.group||'');const preferredModel=match?.model||(preferredGroup===draft.group&&fleet.some(x=>String(x.group)===String(preferredGroup)&&String(x.model)===String(draft.model))?draft.model:'');
      renderFleet(preferredGroup,preferredModel,{forceValues:true});const groupCount=new Set(fleet.map(x=>String(x.group||'').trim()).filter(Boolean)).size;
      const checkedAt=String(result.checkedAt||new Date().toISOString());
      current.fleetPrices=fleet.map(x=>({...x,total:num(x.total),pricePerDay:num(x.pricePerDay)}));
      current.fleetCatalog=fleet;
      current.fleetLastCheckedAt=checkedAt;
      current.fleetPriceHistory=[...(Array.isArray(current.fleetPriceHistory)?current.fleetPriceHistory:[]),{date:checkedAt,fleet:current.fleetPrices.map(x=>({group:x.group,model:x.model,carId:x.carId||'',imageUrl:x.imageUrl||'',availability:x.availability||'Disponible',total:num(x.total),pricePerDay:num(x.pricePerDay)}))}].slice(-180);
      const selectedLive=autoreisenBestFleetMatch(current.fleetPrices,current.model)||current.fleetPrices.find(x=>String(x.group)===String(current.group))||current.fleetPrices[0];
      if(selectedLive){current.currentPrice=num(selectedLive.total);current.pricePerDay=num(selectedLive.pricePerDay);current.availability=selectedLive.availability||'Disponible';current.matchedModel=selectedLive.model||current.model;if(isImageSource(selectedLive.imageUrl))current.imageUrl=selectedLive.imageUrl;}
      current.lastUpdated=checkedAt;current.lastAttempt=checkedAt;current.lastError='';current.monitorStatus='ok';current.automatic=true;current.source=result.source||'AutoReisen · consulta de flota';
      await saveSection('trackers');
      status.textContent=`Flota confirmada con navegador para estas fechas: ${result.fleet.length} modelos · ${groupCount} grupo${groupCount===1?'':'s'}${result.source?` · ${result.source}`:''}. Ya está guardada en Seguimiento.`;
      toast('Flota de AutoReisen guardada para las fechas seleccionadas.');
    }catch(error){if(token!==fleetRefreshToken)return;status.textContent=`No se pudo completar la consulta con navegador: ${error.message} El catálogo de referencia sigue disponible y puedes abrir AutoReisen para comprobarlo manualmente.`;toast(`AutoReisen: ${error.message}`,'error');}
    finally{if(token===fleetRefreshToken){if(button)button.disabled=false;groupInput.disabled=false;modelInput.disabled=false;}}
  };
  $('[data-ar-refresh-fleet]',form).onclick=()=>refreshFleet();
  $('[data-ar-open-autoreisen]',form).onclick=()=>{const draft=readAutoreisenEditorDraft(form,current,fleet);window.open(autoreisenBrowserResultsUrl(draft),'_blank','noopener,noreferrer');};
  const markFleetPending=()=>{status.textContent='Oficina o fecha modificada. Pulsa “Consultar flota para estas fechas” para comprobar la disponibilidad real; mientras tanto se mantiene el catálogo de referencia.';};
  form.elements.pickupOfficeId.addEventListener('change',markFleetPending);
  form.elements.dropoffOfficeId.addEventListener('change',markFleetPending);
  form.elements.pickupAt.addEventListener('change',markFleetPending);
  form.elements.dropoffAt.addEventListener('change',markFleetPending);
  // Las oficinas sí se pueden refrescar directamente; la flota exacta se consulta solo cuando el usuario pulsa el botón para no lanzar workflows innecesarios al cambiar cada campo.
  callIntegrationWorker({action:'autoreisen-options',mode:'offices',config:current}).then(data=>{if(Array.isArray(data.offices)&&data.offices.length){replaceOfficeOptions(data.offices);offices=data.offices;status.textContent=data.warning||'Oficinas contrastadas con AutoReisen. Para disponibilidad real, pulsa “Consultar flota para estas fechas”.';}}).catch(()=>{});
  form.addEventListener('submit',async e=>{e.preventDefault();try{if(!validateHexColorControls(form))return;const next=readAutoreisenEditorDraft(form,current,fleet);if(!next.pickupOfficeId||!next.dropoffOfficeId)throw new Error('Selecciona las oficinas de recogida y devolución.');if(!next.group||!next.model)throw new Error('Selecciona un grupo y un modelo.');if(next.fleetTrackAll===false&&!next.fleetTrackGroups.length)throw new Error('Selecciona al menos una categoría visible o marca “Todas visibles”.');if(Date.parse(next.dropoffAt)<=Date.parse(next.pickupAt))throw new Error('La devolución debe ser posterior a la recogida.');await applyTrackerIconEditorValues(current,{titleIcon:form.elements.titleIcon?.value,titleIconUrl:form.elements.titleIconUrl?.value,titleIconFile:form.elements.titleIconFile?.files?.[0]||null},TRACKER_DEFAULT_ICONS.autoreisen||'🚗');const persisted=await persistAutoreisenManualDraft(current,{...next,titleIcon:current.titleIcon,titleIconUrl:current.titleIconUrl},{offices,fleet});let syncError='';try{await callIntegrationWorker({action:'github-sync-autoreisen',config:current,runWorkflow:false});}catch(error){syncError=error.message;}render();closeModal();if(syncError)toast(`AutoReisen guardado${persisted.customDates?' con fechas independientes':''}. GitHub queda pendiente: ${syncError}`,'error');else toast(`AutoReisen guardado${persisted.customDates?' con fechas independientes del viaje':''} y sincronizado con el monitor diario.`);}catch(error){toast(error.message||'No se pudo guardar AutoReisen.','error');}});
}

function openCordialEditor(){
  const current=state.data.trackers.cordial;
  openForm({title:'Configurar seguimiento Cordial',fields:[
    {name:'title',label:'Título del bloque',required:true,full:true},
    ...trackerIconEditorFields(),
    {name:'hotel',label:'Alojamiento',required:true,full:true},
    {name:'checkIn',label:'Entrada',type:'date',required:true},
    {name:'checkOut',label:'Salida',type:'date',required:true},
    {name:'adults',label:'Adultos',type:'number',step:'1',required:true},
    {name:'children',label:'Niños',type:'number',step:'1'},
    {name:'targetRoom',label:'Habitación destacada',required:true,help:'Se mostrará en negrita dentro de todas las opciones. Por defecto: Classic Duplex.'},
    {name:'targetRate',label:'Tarifa destacada',required:true,full:true,help:'Por defecto: Club Cordial - Reserva Online.'},
    {name:'targetBoard',label:'Régimen destacado',required:true,help:'Por defecto: SOLO ALOJAMIENTO.'},
    {name:'reservedPrice',label:'Precio reservado (opcional)',type:'number',step:'0.01',help:'Si lo indicas, la ficha mostrará la diferencia frente al precio actual.'},
    {name:'searchUrl',label:'Página de reserva Cordial',type:'url',full:true},
    {name:'color',label:'Color de acento',type:'color'},
    {name:'gradient1',label:'Degradado inicio',type:'color'},
    {name:'gradient2',label:'Degradado fin',type:'color'},{name:'textColor',label:'Color del texto del título',type:'color'}
  ],values:{textColor:'#ffffff',...current},onSubmit:async v=>{
    await applyTrackerIconEditorValues(current,v,TRACKER_DEFAULT_ICONS.cordial||'🏨');delete v.titleIconFile;
    const next={...current,...v,adults:Math.max(1,num(v.adults)||2),children:Math.max(0,num(v.children)||0),reservedPrice:Math.max(0,num(v.reservedPrice)),scheduleMode:'daily',scheduleTime:current.scheduleTime||'06:35',scheduleTimeZone:'Europe/Madrid'};
    Object.assign(current,next);await saveSection('trackers');let warning='';try{await requireCordialWorker();await callIntegrationWorker({action:'github-sync-cordial',config:current,runWorkflow:false});}catch(error){warning=error.message||'No se pudo sincronizar GitHub.';}render();if(warning)toast(`Seguimiento Cordial guardado. GitHub queda pendiente: ${warning}`,'error');else toast('Seguimiento Cordial guardado y sincronizado.');
  }});
}
function editTracker(type){
  if(type==='autoreisen'){openAutoreisenEditor();return;}
  if(type==='cordial'){openCordialEditor();return;}
  if(type==='vueling'){openVuelingEditor();return;}
  const current=state.data.trackers[type];const colorFields=[{name:'color',label:'Color de acento',type:'color'},{name:'gradient1',label:'Degradado inicio',type:'color'},{name:'gradient2',label:'Degradado fin',type:'color'},{name:'textColor',label:'Color del texto del título',type:'color'}];const fields=[{name:'fuelTankLitres',label:'Capacidad depósito',type:'number',step:'0.1'},{name:'fuelExpectedLitres',label:'Litros previstos',type:'number',step:'0.1'},{name:'carConsumption',label:'Consumo l/100 km',type:'number',step:'0.1'},{name:'fuelRadiusKm',label:'Radio km',type:'number',step:'1'},...colorFields];openForm({title:`Configurar ${type}`,fields,values:{textColor:'#ffffff',...state.data.settings,...current},onSubmit:async v=>{for(const k of ['fuelTankLitres','fuelExpectedLitres','carConsumption','fuelRadiusKm'])state.data.settings[k]=v[k];for(const k of ['color','gradient1','gradient2','textColor'])current[k]=v[k];await Promise.all([saveSection('settings'),saveSection('trackers')]);render();}});
}

function applyAutomaticTrackerResult(type,data){
  const result=data?.result||data,target=state.data.trackers[type];if(!target||!['autoreisen','cordial'].includes(type))throw new Error('Seguimiento no reconocido.');
  if(!result||result.ok===false||result.status==='error')throw new Error(result?.error||data?.error||'El monitor no ha devuelto un resultado válido.');
  if(type==='autoreisen'){
    target.currentPrice=num(result.total||result.price);target.pricePerDay=num(result.pricePerDay);target.availability=result.availability||'';target.matchedModel=result.model||result.matchedModel||'';
    const automaticImage=String(result.imageUrl||'').trim();if(isImageSource(automaticImage))target.imageUrl=automaticImage;
    if(Array.isArray(result.fleet)){target.fleetPrices=result.fleet.map(x=>({...x,total:num(x?.total),pricePerDay:num(x?.pricePerDay)}));if(result.fleet.length)target.fleetCatalog=result.fleet;}
    target.lastUpdated=result.checkedAt||data.checkedAt||new Date().toISOString();target.lastAttempt=data?.lastError?.checkedAt||target.lastUpdated;target.lastError=data?.lastError?.error||'';target.monitorStatus=target.lastError?'error':'ok';target.automatic=true;target.source=result.source||'Monitor diario';
    target.history=[...(target.history||[]),{date:target.lastUpdated,price:target.currentPrice,source:target.source}].filter((x,i,arr)=>arr.findIndex(y=>String(y.date)===String(x.date))===i).slice(-365);
    if(Array.isArray(target.fleetPrices)&&target.fleetPrices.length){const snapshot={date:target.lastUpdated,fleet:target.fleetPrices.map(x=>({group:x.group,model:x.model,carId:x.carId||'',imageUrl:x.imageUrl||'',availability:x.availability||'Disponible',total:num(x.total),pricePerDay:num(x.pricePerDay)}))};target.fleetPriceHistory=[...(target.fleetPriceHistory||[]).filter(x=>String(x?.date||'')!==String(snapshot.date)),snapshot].slice(-180);}return;
  }
  target.currentPrice=num(result.targetPrice||result.target?.price);target.availability=result.availability||'';target.options=Array.isArray(result.options)?result.options:[];target.roomMeta=result.roomMeta&&typeof result.roomMeta==='object'?result.roomMeta:(target.roomMeta||{});target.resultUrl=result.resultUrl||target.resultUrl||'';target.lastUpdated=result.checkedAt||data.checkedAt||new Date().toISOString();target.lastAttempt=data?.lastError?.checkedAt||target.lastUpdated;target.lastError=data?.lastError?.error||'';target.monitorStatus=target.lastError?'error':'ok';target.automatic=true;target.source=result.source||'BeCordial · monitor diario';
  if(target.currentPrice>0){const prior=(target.history||[]).filter(x=>String(x?.date||'')!==String(target.lastUpdated||''));target.history=[...prior,{date:target.lastUpdated,price:target.currentPrice,source:target.source}].slice(-365);}
  const roomSnap=cordialRoomPriceSnapshot(target.options||[],target.lastUpdated);if(roomSnap.rooms.length)target.roomPriceHistory=[...(target.roomPriceHistory||[]).filter(x=>String(x?.date||'')!==String(roomSnap.date)),roomSnap].slice(-180);
}
async function repairCordialAutomationOnUpgrade(){
  const key='mfe-cordial-automation-repair-2.2.11';
  if(DEMO_MODE||!roleCanEdit())return;
  try{if(localStorage.getItem(key)==='1')return;}catch{}
  try{
    await requireCordialWorker();
    await callIntegrationWorker({action:'github-sync-cordial',config:state.data.trackers.cordial,runWorkflow:false});
    try{localStorage.setItem(key,'1');}catch{}
    console.info('[cordial] Automatización 2.2.11 reparada/sincronizada en GitHub.');
  }catch(error){console.warn('[cordial] Reparación automática pendiente:',error?.message||error);}
}
async function syncMonitoredTrackers({silent=false}={}){
  if(state.monitorSyncDone)return;state.monitorSyncDone=true;let changed=false,labels=[];
  try{const data=await callPriceWorker({action:'autoreisen'});applyAutomaticTrackerResult('autoreisen',data);changed=true;labels.push('AutoReisen');}catch(error){console.warn('Monitor autoreisen:',error.message);}
  try{const data=await callPriceWorker({action:'cordial'});applyAutomaticTrackerResult('cordial',data);changed=true;labels.push('Cordial');}catch(error){console.warn('Monitor cordial:',error.message);}
  try{const data=await callVuelingWorker({action:'vueling'});applyVuelingResult(data);changed=true;labels.push('Vueling');}catch(error){console.warn('Monitor Vueling:',error.message);}
  if(changed&&roleCanEdit())await saveSection('trackers');if(changed&&state.activeTab==='trackers')render();if(changed&&!silent)toast(`Seguimientos sincronizados: ${labels.join(' · ')}.`);
}
async function refreshTracker(type){try{
  if(type==='autoreisen'){await runAutoreisenNow();return;}
  const labels={fuel:'gasolineras',autoreisen:'AutoReisen',cordial:'Cordial',vueling:'Vueling'};if(type==='fuel')setFuelLocalProgress({label:'consultando Worker…',percentage:15,total:3,done:0,steps:[{name:'Solicitar datos al Worker',status:'in_progress'},{name:'Recibir y procesar estaciones',status:'queued'},{name:'Guardar y actualizar mapa',status:'queued'}]});toast(type==='fuel'?'Actualizando gasolineras…':`Consultando el último seguimiento de ${labels[type]||type}…`);const data=type==='vueling'?await callVuelingWorker({action:'vueling'}):await callPriceWorker({action:type,config:state.data.trackers[type],settings:state.data.settings});
  if(type==='fuel'){setFuelLocalProgress({label:'procesando estaciones…',percentage:70,total:3,done:1,steps:[{name:'Solicitar datos al Worker',status:'completed',conclusion:'success'},{name:'Recibir y procesar estaciones',status:'in_progress'},{name:'Guardar y actualizar mapa',status:'queued'}]});state.data.trackers.fuel.stations=data.stations||[];state.data.trackers.fuel.lastUpdated=data.updatedAt||new Date().toISOString();}else if(type==='vueling')applyVuelingResult(data);else applyAutomaticTrackerResult(type,data);
  await saveSection('trackers');if(type==='fuel')state.trackerRunProgress.fuel={localLabel:'actualizado',localPercentage:100,localTotal:3,localDone:3,localSteps:[{name:'Solicitar datos al Worker',status:'completed',conclusion:'success'},{name:'Recibir y procesar estaciones',status:'completed',conclusion:'success'},{name:'Guardar y actualizar mapa',status:'completed',conclusion:'success'}]};render();toast(data.message||'Seguimiento actualizado.');
}catch(e){if(type==='fuel')setFuelLocalProgress({label:'error',percentage:100,total:3,done:0,error:e.message,steps:[{name:'Solicitar datos al Worker',status:'completed',conclusion:'failure'}]});const target=state.data.trackers[type];if(target){target.monitorStatus='error';target.lastError=e.message;target.lastAttempt=new Date().toISOString();await saveSection('trackers');}render();toast(`${e.message} Se conserva el último dato correcto.`, 'error');}}
async function renderFuelMap(){const el=$('#fuel-map');if(!el||!state.data.trackers.fuel.stations?.length)return;await ensureLeaflet();if(state.fuelMap){state.fuelMap.remove();state.fuelMap=null;}const L=window.L;state.fuelMap=L.map(el).setView([27.96,-15.58],10);L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap'}).addTo(state.fuelMap);for(const x of state.data.trackers.fuel.stations){if(!Number.isFinite(num(x.latitude))||!Number.isFinite(num(x.longitude)))continue;L.marker([num(x.latitude),num(x.longitude)]).addTo(state.fuelMap).bindPopup(`<strong>${esc(x.name)}</strong><br>${formatNumberEs(x.price,3)} €/l<br><a href="${mapsDirectionsUrl(`${x.latitude},${x.longitude}`)}" target="_blank">Cómo llegar</a>`);}}
async function ensureLeaflet(){if(window.L)return;if(!document.querySelector('link[data-leaflet]')){const l=document.createElement('link');l.rel='stylesheet';l.href='https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/leaflet.css';l.dataset.leaflet='1';document.head.append(l);}await new Promise((resolve,reject)=>{const s=document.createElement('script');s.src='https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/leaflet.js';s.onload=resolve;s.onerror=reject;document.head.append(s);});}

function injectSettingsForm(html, panelId, markup) {
  const pattern = new RegExp(`(<section class="settings-panel[^"]*" data-panel="${panelId}"><form[^>]*>)([\\s\\S]*?)(</form></section>)`);
  return html.replace(pattern, (_match, open, body, close) => `${open}${body}${markup}${close}`);
}
function integrationCard({id,icon,title,status,tone='warn',description='',actions='',extra=''}){
  const visual=String(icon||'').includes('<img')?String(icon):esc(icon);
  return `<article class="integration-card"><div class="integration-card-head"><span class="integration-icon">${visual}</span><div><h4>${esc(title)}</h4>${integrationStatusBadge(status,tone)}</div></div><p>${esc(description)}</p>${extra||''}<div class="integration-actions"><button type="button" class="btn secondary small" data-integration-test="${esc(id)}">✓ Comprobar</button>${actions}</div></article>`;
}
function renderIntegrationsPanel(){
  const s=state.data.settings,d=state.integrationDiagnostics;
  const firebaseOk=state.provider instanceof FirebaseProvider;
  const driveConfigured=Boolean(s.googleDriveApiKey&&s.googleDriveClientId&&s.googleDriveAppId);
  const workerOk=Boolean(d.worker?.ok);
  const githubOk=Boolean(d.github?.ok);
  const notificationOk=notificationPermissionInfo().tone==='good'&&Boolean(currentVapidKey());
  const firebaseUrl=s.firebaseConsoleUrl||`https://console.firebase.google.com/project/${encodeURIComponent(firebaseConfig.projectId||'')}/overview`;
  const messagingUrl=s.firebaseMessagingUrl||`https://console.firebase.google.com/project/${encodeURIComponent(firebaseConfig.projectId||'')}/messaging`;
  const repoUrl=String(s.githubRepoUrl||'').trim();
  const actionsUrl=String(s.githubActionsUrl||'').trim()||(repoUrl?`${repoUrl.replace(/\/$/,'')}/actions`:"");
  const driveCardConnected=drivePersistentConnected(state.drivePersistentStatus)||driveTemporaryConnected(state.drivePersistentStatus);
  const cards=[
    integrationCard({id:'firebase',icon:'🔥',title:'Firebase',status:firebaseOk?'Conectado':'No conectado',tone:integrationTone(firebaseOk),description:'Login, datos del viaje, usuarios y notificaciones.',actions:integrationExternalButton(firebaseUrl,'Abrir Firebase')}),
    integrationCard({id:'drive',icon:driveIconMarkup('integration-drive-icon'),title:'Google Drive',status:driveConfigured?driveConnectionLabel(state.drivePersistentStatus):'Pendiente',tone:integrationTone(Boolean(driveConfigured&&driveCardConnected),driveConfigured&&!driveCardConnected),description:drivePersistentConnected(state.drivePersistentStatus)?`Sesión persistente activa${state.drivePersistentStatus?.email?` para ${state.drivePersistentStatus.email}`:''}. Drive seguirá conectado entre reinicios.`:driveTemporaryConnected(state.drivePersistentStatus)?`Drive está conectado temporalmente${state.drivePersistentStatus?.email?` como ${state.drivePersistentStatus.email}`:''}. La sesión dura mientras el token del navegador siga vigente.`:(state.drivePersistentStatus?.configured?'El Client Secret está disponible. Conecta Drive una vez para activar la sesión persistente.':'Drive funciona con OAuth del navegador. Añade el Client Secret en Cloudflare para conservar la sesión entre reinicios.'),actions:`${drivePersistentConnected(state.drivePersistentStatus)?'<button type="button" class="btn secondary small" data-drive-persistent-disconnect>Desconectar</button>':(driveTemporaryConnected(state.drivePersistentStatus)?'<button type="button" class="btn canary-action-btn small" data-drive-persistent-connect>Hacer permanente</button>':(state.drivePersistentStatus?.configured!==false?'<button type="button" class="btn canary-action-btn small" data-drive-persistent-connect>Activar persistencia</button>':''))}${integrationExternalButton(s.googleDriveUrl||'https://drive.google.com/drive/my-drive','Abrir Drive')}`}),
    integrationCard({id:'calendar',icon:'📅',title:'Google Calendar',status:'Disponible',tone:'good',description:'Creación de eventos desde tareas y recordatorios.',actions:integrationExternalButton(s.googleCalendarUrl||'https://calendar.google.com/calendar/u/0/r','Abrir Calendar')}),
    integrationCard({id:'github',icon:'◉',title:'GitHub Actions',status:d.github?.label||(githubOk?'Configurado':'Sin comprobar'),tone:integrationTone(githubOk,workerOk&&!githubOk),description:'Configuración y ejecución automática de AutoReisen, Cordial y Vueling, con respaldo diario de Cloudflare.',actions:`${integrationExternalButton(repoUrl,'Abrir repositorio')}${integrationExternalButton(actionsUrl,'Abrir Actions')}`}),
    integrationCard({id:'cloudflare',icon:'☁',title:'Cloudflare Worker',status:d.worker?.label||(workerOk?'Activo':'Sin comprobar'),tone:integrationTone(workerOk,!d.checked),description:'Precios, imágenes, gasolineras, puente seguro con GitHub y respaldo automático de seguimientos.',actions:integrationExternalButton(s.cloudflareDashboardUrl||'https://dash.cloudflare.com/','Abrir Cloudflare')}),
    integrationCard({id:'notifications',icon:'🔔',title:'Notificaciones',status:notificationOk?'Preparadas':notificationPermissionInfo().label,tone:integrationTone(notificationOk,notificationPermissionInfo().tone!=='bad'),description:'Permisos del navegador, VAPID y Firebase Cloud Messaging.',actions:integrationExternalButton(messagingUrl,'Abrir Messaging')}),
    integrationCard({id:'weather',icon:'🌤️',title:'Open-Meteo',status:'Activo · sin clave',tone:'good',description:'Tiempo actual y previsión meteorológica del destino.',actions:integrationExternalButton('https://open-meteo.com/','Abrir Open-Meteo')})
  ].join('');
  return `<article class="card settings-section integration-center"><div class="settings-section-head"><div><h3>Centro de integraciones</h3><p class="muted">Comprueba conexiones, sincroniza las fechas y abre directamente cada servicio para editar su configuración.</p></div><button type="button" class="btn secondary small" data-integration-refresh>↻ Actualizar estados</button></div>
    <div class="integration-grid">${cards}</div>
    ${d.lastMessage?`<p class="integration-message">${esc(d.lastMessage)}</p>`:''}
  </article>
  <article class="card settings-section"><h3>Sincronización automática de AutoReisen</h3><div class="integration-sync-box"><div><strong>Fechas generales del viaje</strong><p>Inicio: ${formatDate(s.departureDateTime,{day:'2-digit',month:'short',year:'numeric'})} · Fin: ${formatDate(s.returnDateTime,{day:'2-digit',month:'short',year:'numeric'})}</p><small>Se conservan las horas configuradas de recogida y devolución.</small></div><div><strong>AutoReisen</strong><p>${formatDate(state.data.trackers.autoreisen.pickupAt,{day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'})} → ${formatDate(state.data.trackers.autoreisen.dropoffAt,{day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'})}</p></div></div>
    <label class="switch-row"><span>Sincronizar AutoReisen al guardar nuevas fechas del viaje</span><input type="checkbox" name="autoreisenSyncWithTripDates" ${s.autoreisenSyncWithTripDates!==false?'checked':''} ${disabledAttr()}></label>
    <label class="switch-row"><span>Ejecutar GitHub Actions después de sincronizar</span><input type="checkbox" name="githubRunWorkflowAfterSync" ${s.githubRunWorkflowAfterSync!==false?'checked':''} ${disabledAttr()}></label>
    <div class="page-actions integration-sync-actions"><button type="button" class="btn primary" data-integration-sync-dates ${canEdit()?'':'disabled'}>↻ Sincronizar fechas ahora</button><button type="button" class="btn secondary" data-integration-sync-run ${canEdit()?'':'disabled'}>▶ Sincronizar y ejecutar monitor</button></div>
  </article>
  <article class="card settings-section"><h3>Enlaces de administración</h3><div class="form-grid">
    ${settingsInput('firebaseConsoleUrl','Firebase Console',firebaseUrl,'url','',true)}
    ${settingsInput('firebaseMessagingUrl','Firebase Messaging',messagingUrl,'url','',true)}
    ${settingsInput('googleDriveUrl','Google Drive',s.googleDriveUrl||'https://drive.google.com/drive/my-drive','url','',true)}
    ${settingsInput('googleCalendarUrl','Google Calendar',s.googleCalendarUrl||'https://calendar.google.com/calendar/u/0/r','url','',true)}
    ${settingsInput('githubRepoUrl','Repositorio de GitHub',repoUrl,'url','',true)}
    ${settingsInput('githubActionsUrl','GitHub Actions',actionsUrl,'url','',true)}
    ${settingsInput('cloudflareDashboardUrl','Panel de Cloudflare',s.cloudflareDashboardUrl||'https://dash.cloudflare.com/','url','',true)}
  </div><p class="help-text">Estos enlaces solo sirven como accesos directos. Los tokens y secretos nunca se guardan dentro de la aplicación.</p></article>
  <article class="card settings-section"><h3>Configuración segura del puente GitHub</h3><div class="integration-security-info"><p>El Worker utiliza el usuario autenticado de Firebase para autorizar la sincronización. Los secretos de GitHub permanecen exclusivamente en Cloudflare.</p><div class="integration-uid"><span>UID del usuario actual</span><code>${esc(state.user?.uid||'No disponible')}</code><button type="button" class="mini-btn" data-copy-integration-uid>Copiar</button></div><p class="help-text">Configura en Cloudflare: <code>GITHUB_TOKEN</code>, <code>GITHUB_OWNER</code>, <code>GITHUB_REPO</code>, <code>FIREBASE_PROJECT_ID</code> e <code>INTEGRATION_ADMIN_UIDS</code>. La actualización incluye una guía detallada.</p></div></article>`;
}

function renderMobileDeployPanel(){
  const s=state.data.settings,d=state.integrationDiagnostics;
  const repoUrl=String(s.githubRepoUrl||'').trim();
  const workflowUrl=repoUrl?`${repoUrl.replace(/\/$/,'')}/actions/workflows/mfe-mobile-deploy.yml`:'';
  const actionsUrl=String(s.githubActionsUrl||'').trim()||(repoUrl?`${repoUrl.replace(/\/$/,'')}/actions`:'' );
  const workerOk=Boolean(d.worker?.ok);
  const githubOk=Boolean(d.github?.ok);
  const mobileOk=Boolean(d.mobileDeploy?.ok);
  const status=d.mobileDeploy?.label||mobileDeployRunLabel()||'Preparar una vez';
  return `<article class="card settings-section mfe-update-panel"><div class="settings-section-head"><div><h3>Actualización desde ZIP</h3></div><button type="button" class="btn secondary small" data-integration-test="mobiledeploy">✓ Comprobar</button></div>
    <div class="integration-sync-box compact-update-status"><div><strong>Estado</strong><p>${integrationStatusBadge(status,integrationTone(mobileOk,Boolean(workerOk&&githubOk)))}</p></div><div><strong>Accesos rápidos</strong><div class="page-actions integration-sync-actions">${workflowUrl?integrationExternalButton(workflowUrl,'Workflow móvil'):''}${actionsUrl?integrationExternalButton(actionsUrl,'Abrir Actions'):''}</div></div></div>
    <h4 class="cordial-subtitle">Diagnóstico previo</h4>${updateDiagnosticsMarkup()}
    ${mobileDeployProgressMarkup()}
    <div class="page-actions integration-sync-actions" style="margin-top:14px"><button type="button" class="btn secondary" data-update-diagnostics>🩺 Diagnóstico</button><button type="button" class="btn secondary" data-mobile-deploy-prepare ${canEdit()?'':'disabled'}>⚙ Preparar GitHub</button><button type="button" class="btn primary" data-mobile-deploy-upload ${canEdit()?'':'disabled'}>📦 Seleccionar ZIP y actualizar</button><button type="button" class="btn secondary" data-mobile-deploy-progress-refresh>↻ Progreso</button><button type="button" class="btn secondary" data-mobile-deploy-trigger>▶ Reintentar workflow</button></div><input type="file" data-mobile-deploy-file accept=".zip,application/zip,application/x-zip-compressed" class="mobile-release-picker" aria-label="Seleccionar ZIP de actualización"></article>`;
}

function renderSettings() {
  let html = renderSettingsLegacy();
  const s = state.data.settings;
  const order = (s.tabOrder || TABS.map(t=>t[0])).map(id=>TABS.find(t=>t[0]===id)).filter(Boolean);
  const trackerLabels = { autoreisen:["🚗","AutoReisen"], cordial:["🏨","Cordial Santa Águeda"], vueling:["✈️","Vueling"], fuel:["⛽","Gasolineras"] };
  const trackerOrder = (state.data.trackers.order || ["autoreisen","cordial","vueling","fuel"]).filter(id=>["autoreisen","cordial","vueling","fuel"].includes(id));
  const navCard = `<article class="card settings-section"><h3>Navegación · orden, visibilidad e iconos</h3>
    <div class="form-grid"><label class="field">Posición en móvil y tablet<select name="navigationPosition" ${disabledAttr()}><option value="top" ${s.navigationPosition==='top'?'selected':''}>Superior</option><option value="bottom" ${s.navigationPosition==='bottom'?'selected':''}>Inferior desplazable</option></select></label></div>
    <p class="help-text">Todo se gestiona en una sola lista: ordena, oculta/muestra y cambia el icono de cada pestaña. Configuración permanece siempre visible.</p>
    <div class="tab-order-list nav-settings-list">${order.map(([id,icon,label],i)=>{const visible=id==='settings'||s.enabledTabs.includes(id),custom=s.tabIconUrls?.[id];return `<div class="tab-order-row nav-settings-row" data-sort-item="tab|${encodeURIComponent(id)}"><span class="nav-settings-label"><span class="settings-tab-icon nav-settings-icon-preview" data-nav-icon-preview="${esc(id)}">${isImageSource(custom)?`<img src="${esc(custom)}" alt="">`:esc(icon)}</span>${esc(label)}${visible?'':' <small class="muted">· oculto</small>'}</span>${canEdit()?`<div class="row-actions"><button type="button" class="mini-btn ${visible?'active':''}" data-tab-visible="${esc(id)}" title="${id==='settings'?'Configuración siempre visible':visible?'Ocultar pestaña':'Mostrar pestaña'}" ${id==='settings'?'disabled':''}>${visible?'👁️':'🙈'}</button><label class="mini-btn nav-icon-upload" title="Cambiar icono">🖼️<input type="file" name="tabIconFile-${esc(id)}" data-tab-icon-file="${esc(id)}" accept="image/png,image/jpeg,image/webp,image/svg+xml" ${disabledAttr()}></label>${sortDragHandle(`tab|${encodeURIComponent(id)}`,'Arrastrar pestaña')}</div>`:''}</div>`;}).join('')}</div>
  </article>
  <article class="card settings-section"><h3>Cuenta atrás e imágenes</h3><div class="form-grid">
    ${settingsInput('countdownTitle','Título',s.countdownTitle)}
    ${settingsInput('countdownSubtitle','Subtítulo',s.countdownSubtitle)}
    ${settingsImageInput('countdownImageUrl','Imagen de la cuenta atrás (URL o Google Drive)',s.countdownImageUrl,'countdown')}
    ${settingsInput('countdownGradient1','Degradado inicio',s.countdownGradient1||s.theme.gradientStart,'color')}
    ${settingsInput('countdownGradient2','Degradado fin',s.countdownGradient2||s.theme.gradientEnd,'color')}
    ${settingsInput('countdownTextColor','Color del texto',s.countdownTextColor||'#ffffff','color')}
    ${settingsInput('countdownEndDateTime','Momento final de la cuenta atrás',s.countdownEndDateTime||'','datetime-local','',true)}
    <div class="help-text full">Si está vacío, la cuenta atrás termina en «Inicio del viaje / vuelo» (${formatDate(s.departureDateTime,{day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'})}).</div>
    <label class="switch-row full"><span>⏱️ Mostrar segundos en la cuenta atrás</span><input type="checkbox" name="countdownShowSeconds" ${s.countdownShowSeconds===true?'checked':''} ${disabledAttr()}></label>
    ${settingsInput('countdownOverlayOpacity','Oscurecimiento de imagen',s.countdownOverlayOpacity??.58,'range','min="0" max="0.95" step="0.05"')}
    ${settingsInput('countdownCropX','Encuadre horizontal',s.countdownImageCrop?.x??50,'range','min="0" max="100"')}
    ${settingsInput('countdownCropY','Encuadre vertical',s.countdownImageCrop?.y??50,'range','min="0" max="100"')}
    ${settingsInput('countdownZoom','Zoom',s.countdownImageCrop?.zoom||1,'number','min="1" max="3" step="0.1"')}
  </div>${imagePreviewBox(s.countdownImageUrl,'Cuenta atrás')}</article>
  <article class="card settings-section"><div class="settings-section-head"><div><h3>Seguimientos</h3><p class="muted">Activa, ordena, restaura, cambia el título y personaliza el icono de AutoReisen, Cordial, Vueling y Gasolineras. El icono puede ser un emoji, una imagen de Google Drive o un archivo local.</p></div>${canEdit()?'<button type="button" class="btn secondary small" data-tracker-restore-all>↺ Restaurar todos</button>':''}</div><div class="tab-order-list">${trackerOrder.map(id=>{const [icon,label]=trackerLabels[id]||['📡',id],visible=state.data.trackers.visible?.[id]!==false,title=state.data.trackers[id]?.title||label,customIcon=Boolean(state.data.trackers[id]?.titleIconUrl)||String(state.data.trackers[id]?.titleIcon||'')!==String(TRACKER_DEFAULT_ICONS[id]||icon);return `<div class="tab-order-row tracker-settings-row" data-sort-item="tracker|${encodeURIComponent(id)}"><label class="switch-row"><span class="tracker-settings-name"><span class="tracker-settings-icon-preview">${trackerTitleIconMarkup(id,icon)}</span>${esc(label)}${visible?'':' <small class="muted">· oculto</small>'}</span><input type="checkbox" name="tracker-visible-${id}" ${visible?'checked':''} ${disabledAttr()}></label><label class="tracker-title-field"><span>Título del bloque</span><input type="text" name="tracker-title-${id}" value="${esc(title)}" ${disabledAttr()}></label>${canEdit()?`<div class="row-actions">${id==='autoreisen'?'<button type="button" class="btn secondary small" data-settings-autoreisen-config>⚙ Configurar flota</button>':''}<button type="button" class="btn secondary small" data-tracker-icon-edit="${id}">🖼 Icono</button>${customIcon?`<button type="button" class="mini-btn" data-tracker-icon-reset="${id}" title="Restaurar icono predeterminado">↺</button>`:''}${visible?'':`<button type="button" class="btn secondary small" data-tracker-restore="${id}">↺ Restaurar</button>`}${sortDragHandle(`tracker|${encodeURIComponent(id)}`,'Arrastrar seguimiento')}</div>`:''}</div>`;}).join('')}</div></article>`;
  html = injectSettingsForm(html, 'manage', navCard);

  const drivePersistent=state.drivePersistentStatus||{},driveIsPersistent=drivePersistentConnected(drivePersistent),driveIsTemporary=driveTemporaryConnected(drivePersistent);
  const integration = `<article class="card settings-section"><div class="settings-section-head"><div><h3>Google Drive Picker y sesión persistente</h3><p class="muted">Autoriza Drive una sola vez. El Worker renueva la sesión automáticamente para que las imágenes y PDF puedan cargarse al abrir la app sin mostrar el login cada vez.</p></div>${driveIsPersistent?'<button type="button" class="btn secondary small" data-drive-persistent-disconnect>Desconectar Drive</button>':(driveIsTemporary?'<button type="button" class="btn canary-action-btn small" data-drive-persistent-connect>Hacer permanente</button>':(drivePersistent.configured!==false?'<button type="button" class="btn canary-action-btn small" data-drive-persistent-connect>Activar persistencia</button>':''))}</div><div class="drive-persistent-status ${drivePersistent.connected?'is-connected':''}"><strong>${driveIsPersistent?'🟢 Drive persistente':driveIsTemporary?'🟡 Drive temporal':'⚪ Drive pendiente'}</strong><span>${esc(driveIsPersistent?(drivePersistent.email||drivePersistent.name||'Autorización persistente activa'):driveIsTemporary?`${drivePersistent.email||drivePersistent.name||'Cuenta autorizada'} · Sesión temporal del navegador`:(drivePersistent.lastMessage||'Configura el secreto OAuth en Cloudflare y conecta una sola vez.'))}</span></div><div class="form-grid">
    ${settingsInput('googleDriveApiKey','API key',s.googleDriveApiKey,'text','',true)}
    ${settingsInput('googleDriveClientId','OAuth Client ID',s.googleDriveClientId,'text','',true)}
    ${settingsInput('googleDriveAppId','Número de proyecto',s.googleDriveAppId,'text','',true)}
  </div><p class="help-text">En Cloudflare añade el secreto <code>GOOGLE_DRIVE_CLIENT_SECRET</code> y, opcionalmente, <code>GOOGLE_DRIVE_CLIENT_ID</code>. El secreto no se guarda en MFE Viajes. Tras pulsar «Conectar Drive» una vez, el refresh token queda protegido en el KV del Worker.</p><p class="help-text">Permite navegar por carpetas y hacer selección múltiple en todos los gestores que admiten varios archivos. Los campos de archivo único —por ejemplo, un ticket o una imagen concreta— mantienen selección individual. El OCR de tickets continúa ejecutándose localmente en el dispositivo.</p></article>
  <article class="card settings-section"><h3>Mapa predeterminado</h3><label class="field">Vista<select name="mapType" ${disabledAttr()}><option value="satellite" ${s.mapType==='satellite'?'selected':''}>Satélite</option><option value="hybrid" ${s.mapType==='hybrid'?'selected':''}>Híbrido</option><option value="map" ${s.mapType==='map'?'selected':''}>Mapa</option><option value="terrain" ${s.mapType==='terrain'?'selected':''}>Terreno</option></select></label></article>`;
  html = injectSettingsForm(html, 'weather', integration);
  html = injectSettingsForm(html, 'integrations', renderIntegrationsPanel());
  html = injectSettingsForm(html, 'updates', renderMobileDeployPanel());
  const permission=notificationPermissionInfo();const nd=state.notificationDiagnostics;const tokenPreview=nd.token?`${nd.token.slice(0,20)}…${nd.token.slice(-12)}`:'No generado en esta sesión';
  const notificationsPanel=`<article class="card settings-section notification-panel"><div class="settings-section-head"><div><h3>Centro de notificaciones</h3><p class="muted">Comprueba primero la notificación local. Después genera el token FCM para probar una notificación push real desde Firebase Console.</p></div><button type="button" class="btn secondary small" data-notification-check>↻ Actualizar diagnóstico</button></div>
    <div class="notification-diagnostic-grid">
      <div class="notification-diagnostic"><span>Contexto seguro HTTPS</span>${notificationStatusBadge(window.isSecureContext?'Correcto':'No disponible',window.isSecureContext?'good':'bad')}</div>
      <div class="notification-diagnostic"><span>Permiso del navegador</span>${notificationStatusBadge(permission.label,permission.tone)}</div>
      <div class="notification-diagnostic"><span>Service worker / PWA</span>${notificationStatusBadge(nd.swStatus||(('serviceWorker' in navigator)?'Sin comprobar':'No compatible'),nd.swStatus==='Activo y listo'?'good':nd.swStatus?.startsWith('Error')?'bad':'warn')}</div>
      <div class="notification-diagnostic"><span>Firebase conectado</span>${notificationStatusBadge(state.provider instanceof FirebaseProvider?'Sí':'No',state.provider instanceof FirebaseProvider?'good':'bad')}</div>
      <div class="notification-diagnostic"><span>Compatibilidad FCM</span>${notificationStatusBadge(nd.fcmSupported===true?'Compatible':nd.fcmSupported===false?'No compatible':'Sin comprobar',nd.fcmSupported===true?'good':nd.fcmSupported===false?'bad':'warn')}</div>
      <div class="notification-diagnostic"><span>Clave VAPID</span>${notificationStatusBadge(currentVapidKey()?'Configurada':'Pendiente',currentVapidKey()?'good':'warn')}</div>
    </div>
    <div class="form-grid" style="margin-top:16px">${settingsInput('pushVapidKey','Clave pública VAPID de Firebase Cloud Messaging',s.pushVapidKey,'text','autocomplete="off"',true)}</div>
    <div class="page-actions notification-actions"><button type="button" class="btn secondary" data-notification-permission>🔔 Solicitar permiso</button><button type="button" class="btn secondary" data-notification-local-test>✓ Probar notificación local</button><button type="button" class="btn primary" data-notification-token>📋 Generar y copiar token FCM</button></div>
    <div class="notification-token-box"><span>Token de esta sesión</span><code>${esc(tokenPreview)}</code>${nd.token?'<button type="button" class="mini-btn" data-notification-copy-token title="Copiar token">Copiar</button>':''}</div>
    ${nd.lastMessage?`<p class="notification-last-message">${esc(nd.lastMessage)}</p>`:''}
    <div class="notification-help"><strong>Orden de prueba recomendado</strong><ol><li>Guarda la clave VAPID.</li><li>Solicita permiso.</li><li>Prueba la notificación local.</li><li>Genera y copia el token FCM.</li><li>En Firebase Console, abre Messaging, crea una campaña de notificación y usa «Enviar mensaje de prueba» pegando el token.</li></ol><p>La prueba local no necesita VAPID, servidor ni plan Blaze. El token FCM sí necesita Firebase, HTTPS, permiso concedido y una clave VAPID válida.</p></div>
  </article>`;
  html = injectSettingsForm(html, 'notifications', notificationsPanel);
  const coverOrderLabels={countdown:['⏳','Cuenta atrás'],weather:['🌤️','Tiempo'],flights:['🚌','Transportes · vuelos y autobuses'],lodging:['🏨','Alojamiento + ubicación'],budget:['💶','Resumen presupuesto'],trackersSummary:['📡','Seguimientos'],documents:['📎','Reservas y documentos'],mediaCarousels:['🗂️','Carruseles de imágenes y PDF'],externalImages:['🖼️','Imágenes adicionales']};
  const coverOrderManager=`<article class="card settings-section cover-order-manager"><h3>Orden y visibilidad de tarjetas de la Portada</h3><p class="muted">Cambia el orden y usa el ojo para mostrar u ocultar bloques del inicio. En Transportes y vuelos y en Documentos y reservas, la visibilidad se controla individualmente desde cada ficha de la Portada.</p><div class="tab-order-list">${(state.data.settings.coverOrder||[]).map((id,i)=>{const [icon,label]=coverOrderLabels[id]||['▣',id],individual=id==='flights'||id==='documents',visible=individual||!(state.data.settings.coverHiddenBlocks||[]).includes(id);return `<div class="tab-order-row" data-sort-item="cover-order|${encodeURIComponent(id)}"><span>${icon} ${esc(label)}${individual?' <small class="muted">· individual</small>':(visible?'':' <small class="muted">· oculto</small>')}</span>${canEdit()?`<div class="row-actions">${individual?'':`<button type="button" class="mini-btn ${visible?'active':''}" data-cover-visible="${esc(id)}" title="${visible?'Ocultar bloque':'Mostrar bloque'}">${visible?'👁️':'🙈'}</button>`}${sortDragHandle(`cover-order|${encodeURIComponent(id)}`,'Arrastrar bloque')}</div>`:''}</div>`;}).join('')}</div></article>`;
  const carouselManager=`<article class="card settings-section cover-carousel-manager"><div class="settings-section-head"><div><h3>Carruseles de imágenes y PDF</h3><p class="muted">Crea galerías con imágenes y PDF de Google Drive y decide si aparecen como bloque independiente en Portada o como desplegable dentro de Alojamiento.</p></div>${canEdit()?'<button type="button" class="btn primary small" data-settings-carousel-add>＋ Carrusel</button>':''}</div><div class="settings-cover-list">${(state.data.cover.mediaCarousels||[]).map((carousel,i)=>{const layoutKey=coverMediaLayoutKey(carousel,i),width=desktopCoverWidth(layoutKey),placement=coverCarouselPlacement(carousel),inLodging=placement==='lodging';return `<div class="settings-cover-row" data-sort-item="carousel|${i}"><div><strong>🗂️ ${esc(carousel.title||'Carrusel')}</strong><small>${esc(carousel.subtitle||'Sin subtítulo')} · ${(carousel.files||[]).length} archivo${(carousel.files||[]).length===1?'':'s'} · ${inLodging?'Dentro de Alojamiento · desplegable':`Portada · PC: ${width==='half'?'½ fila':'fila completa'}`}</small></div>${canEdit()?`<div class="row-actions settings-carousel-actions"><span class="settings-carousel-placement" aria-label="Ubicación del carrusel"><button type="button" class="mini-btn ${!inLodging?'active':''}" data-settings-carousel-placement="${i}:cover" title="Mostrar fuera, como bloque de Portada">Portada</button><button type="button" class="mini-btn ${inLodging?'active':''}" data-settings-carousel-placement="${i}:lodging" title="Mostrar dentro de Alojamiento como desplegable">🏨</button></span>${!inLodging?`<span class="settings-carousel-width" aria-label="Ancho en ordenador"><button type="button" class="mini-btn ${width==='half'?'active':''}" data-settings-carousel-width="${i}:half" title="Media fila en ordenador">½</button><button type="button" class="mini-btn ${width==='full'?'active':''}" data-settings-carousel-width="${i}:full" title="Fila completa en ordenador">1/1</button></span>`:''}${sortDragHandle(`carousel|${i}`,'Arrastrar carrusel')}<button type="button" class="mini-btn action-clip" data-settings-carousel-files="${i}" title="Imágenes y PDF de Google Drive">📎</button><button type="button" class="mini-btn" data-settings-carousel-edit="${i}" title="Editar">✎</button><button type="button" class="mini-btn" data-settings-carousel-delete="${i}" title="Eliminar">×</button></div>`:''}</div>`;}).join('')||'<div class="empty">No hay carruseles todavía.</div>'}</div><p class="help-text">Puedes mover cada galería entre Portada y Alojamiento en cualquier momento. Dentro de Alojamiento se muestra cerrada como un desplegable y conserva navegación, PDF e imágenes. En Portada puedes elegir ½ o 1/1 en ordenador.</p></article>`;
  const externalImagesManager=`<article class="card settings-section"><div class="settings-section-head"><div><h3>Imágenes adicionales</h3><p class="muted">Gestiona aquí las imágenes sueltas que aparecen en la Portada. Para instrucciones con varias páginas es mejor usar un carrusel.</p></div>${canEdit()?`<div class="row-actions"><button type="button" class="btn secondary small" data-settings-external-images-drive>${driveIconMarkup()} Añadir varias desde Drive</button><button type="button" class="btn primary small" data-settings-external-image-add>＋ Enlazar una imagen</button></div>`:''}</div><div class="settings-cover-list">${(state.data.cover.externalImages||[]).map((item,i)=>`<div class="settings-cover-row"><div><strong>🖼️ ${esc(item.title||'Imagen')}</strong><small>${esc(item.url||'Sin URL')}</small></div>${canEdit()?`<div class="row-actions"><button type="button" class="mini-btn" data-settings-external-image-edit="${i}" title="Editar">✎</button><button type="button" class="mini-btn" data-settings-external-image-delete="${i}" title="Eliminar">×</button></div>`:''}</div>`).join('')||'<div class="empty">No hay imágenes adicionales.</div>'}</div><p class="help-text">Puedes añadir varias imágenes de Google Drive en una sola selección. «Enlazar una imagen» se mantiene para URL o sustituciones individuales.</p></article>`;
  const tripTransportOrder=currentTripTransportOrder();
  const tripTransportRows=tripTransportOrder.map((ref,pos)=>{const move=canEdit()?sortDragHandle(`trip-transport|${encodeURIComponent(ref)}`,'Arrastrar transporte o alojamiento'):'';if(ref==='lodging')return `<div class="settings-cover-row" data-sort-item="trip-transport|${encodeURIComponent(ref)}"><div><strong>🏨 ${esc(state.data.cover.lodging?.name||'Alojamiento')}</strong><small>${formatDate(state.data.cover.lodging?.checkIn)} – ${formatDate(state.data.cover.lodging?.checkOut)}</small></div>${canEdit()?`<div class="row-actions">${move}<button type="button" class="mini-btn" data-settings-edit-lodging title="Editar alojamiento">✎</button></div>`:''}</div>`;const[kind,id]=ref.split(':');if(kind==='flight'){const i=(state.data.cover.flights||[]).findIndex((f,ix)=>String(f.id||`flight-${ix+1}`)===id),f=state.data.cover.flights?.[i];if(!f)return '';return `<div class="settings-cover-row" data-sort-item="trip-transport|${encodeURIComponent(ref)}"><div><strong>✈️ ${esc(f.type||'Vuelo')} · ${esc(f.number||'Sin número')}</strong><small>${esc(f.from||'')} → ${esc(f.to||'')} · ${formatDate(f.date,{day:'2-digit',month:'short'})}</small></div>${canEdit()?`<div class="row-actions">${move}<button type="button" class="mini-btn" data-settings-edit-flight="${i}" title="Editar vuelo">✎</button><button type="button" class="mini-btn boarding-pass-settings-btn" data-settings-wallet-flight="${i}" title="Tarjetas de embarque">${boardingPassMiniIconMarkup()}</button><button type="button" class="mini-btn" data-settings-delete-flight="${i}" title="Eliminar vuelo">×</button></div>`:''}</div>`;}const i=(state.data.cover.buses||[]).findIndex(b=>String(b.id)===id),bus=state.data.cover.buses?.[i];if(!bus)return '';const rowBusIcon=bus.visible===false?'<span class="settings-transport-icon">🙈</span>':iconMarkup(bus.icon||'🚌',busIdentityVisualUrl(bus,i),'settings-transport-icon');return `<div class="settings-cover-row" data-sort-item="trip-transport|${encodeURIComponent(ref)}"><div><strong class="settings-transport-title">${rowBusIcon}<span>${esc(bus.type||'Autobús')} · ${esc(bus.company||'Sin compañía')}</span></strong><small>${esc(bus.from||'')} → ${esc(bus.to||'')} · ${formatDate(bus.date,{day:'2-digit',month:'short'})} · ${formatMoney(busBudgetAmount(bus))}${bus.visible===false?' · oculto':''}</small></div>${canEdit()?`<div class="row-actions">${move}<button type="button" class="mini-btn ${bus.visible!==false?'active':''}" data-settings-bus-visible="${i}" title="${bus.visible!==false?'Ocultar trayecto':'Mostrar trayecto'}">${bus.visible!==false?'👁️':'🙈'}</button><button type="button" class="mini-btn action-clip" data-settings-bus-files="${i}" title="Billetes, archivos y enlaces">📎</button><button type="button" class="mini-btn" data-settings-edit-bus="${i}" title="Editar autobús">✎</button><button type="button" class="mini-btn" data-settings-delete-bus="${i}" title="Eliminar autobús">×</button></div>`:''}</div>`;}).join('');
  const coverManager=`<article class="card settings-section" data-tripdata-section="travel"><div class="settings-section-head"><div><h3>Vuelos, autobuses y alojamiento</h3><p class="muted">Hotel, vuelos, coche y seguimientos se conservan al archivar como plantilla. Cambia solo fechas, precios o reservas cuando prepares el siguiente viaje.</p></div>${canEdit()?'<div class="row-actions trip-template-actions"><button type="button" class="btn secondary small" data-recover-trip-template>↺ Recuperar último archivado</button><button type="button" class="btn secondary small" data-settings-add-bus>＋ Autobús</button><button type="button" class="btn primary small" data-settings-add-flight>＋ Vuelo</button></div>':''}</div>${canEdit()?'<div class="trip-template-reset-bar"><span>Los reseteos completos piden el PIN aunque Configuración ya esté desbloqueada.</span><div class="row-actions"><button type="button" class="btn danger small" data-reset-flights-protected>Resetear vuelos</button><button type="button" class="btn danger small" data-reset-lodging-protected>Resetear alojamiento</button></div></div>':''}<div class="settings-cover-list">${tripTransportRows}<div class="settings-cover-row"><div><strong>📈 Seguimiento Cordial</strong><small>${formatDate(state.data.trackers.cordial?.checkIn)} – ${formatDate(state.data.trackers.cordial?.checkOut)} · ${esc(state.data.trackers.cordial?.targetRoom||'Classic Duplex')}</small></div>${canEdit()?'<button type="button" class="btn secondary small" data-settings-edit-cordial>Configurar</button>':''}</div><div class="settings-cover-row"><div><strong>✈️ Seguimiento Vueling</strong><small>${esc(state.data.trackers.vueling?.outboundFlight||'')} / ${esc(state.data.trackers.vueling?.returnFlight||'')} · ${vuelingPassengerCount(state.data.trackers.vueling)} pasajeros · ${esc(state.data.trackers.vueling?.fare||'FLY LIGHT')}</small></div>${canEdit()?'<button type="button" class="btn secondary small" data-settings-edit-vueling>Configurar</button>':''}</div></div></article>`;
  const rental=state.data.trackers.autoreisen||{};
  const rentalManager=`<article class="card settings-section" data-tripdata-section="rental"><div class="settings-section-head"><div><h3>Alquiler de coche y movilidad</h3><p class="muted">Personaliza la reserva de AutoReisen y los parámetros de gasolineras desde Datos viaje.</p></div></div><div class="settings-cover-list"><div class="settings-cover-row"><div><strong>🚗 AutoReisen · ${esc(rental.model||rental.group||'Coche de alquiler')}</strong><small>${esc(rental.pickup||'Recogida')} → ${esc(rental.dropoff||'Devolución')} · ${formatMoney(rental.reservedPrice||0)}</small></div>${canEdit()?'<button type="button" class="btn secondary small" data-settings-edit-autoreisen>Editar alquiler</button>':''}</div><div class="settings-cover-row"><div><strong>⛽ Gasolineras</strong><small>Consumo, depósito, litros previstos, radio y colores</small></div>${canEdit()?'<button type="button" class="btn secondary small" data-settings-edit-fuel>Configurar</button>':''}</div></div></article>`;
  const storesManager=`<article class="card settings-section" data-tripdata-section="stores"><div class="settings-section-head"><div><h3>Supermercados</h3><p class="muted">Crea, ordena y personaliza los supermercados que se utilizan en Lista de la compra y Compra real. Cada uno puede tener su propio código postal de compra.</p></div>${canEdit()?'<button type="button" class="btn primary small" data-settings-store-add>＋ Supermercado</button>':''}</div><div class="settings-store-list">${(state.data.shopping.stores||[]).map((store,i)=>`<div class="settings-store-row" data-sort-item="store|${i}">${isImageSource(store.logoUrl)?`<img src="${esc(store.logoUrl)}" alt="">`:`<span class="settings-store-icon">${esc(store.icon||'🛒')}</span>`}<div><strong>${esc(store.name)}</strong><small>${store.active===false?'Inactivo':'Activo'}${store.postalCode?` · ${esc(store.postalCode)}`:''}</small></div>${canEdit()?`<div class="row-actions"><button type="button" class="mini-btn" data-settings-store-toggle="${i}" title="Activar o desactivar">${store.active===false?'○':'●'}</button>${sortDragHandle(`store|${i}`,'Arrastrar supermercado')}<button type="button" class="mini-btn" data-settings-store-edit="${i}" title="Editar">✎</button><button type="button" class="mini-btn" data-settings-store-delete="${i}" title="Eliminar">×</button></div>`:''}</div>`).join('')||'<div class="empty">No hay supermercados configurados.</div>'}</div></article>`;
  const tripDataSections={travel:coverManager,rental:rentalManager,stores:storesManager};
  const tripDataOrder=currentTripDataSectionOrder();
  const tripDataLabels={travel:'Vuelos, autobuses y alojamiento',rental:'Alquiler de coche y movilidad',stores:'Supermercados'};
  const tripDataOrderManager=canEdit()?`<article class="card settings-section tripdata-order-manager"><h3>Orden de los bloques</h3><p class="muted">Cambia el orden de las secciones de Datos viaje.</p><div class="tab-order-list">${tripDataOrder.map((id,i)=>`<div class="tab-order-row" data-sort-item="tripdata|${encodeURIComponent(id)}"><span>${esc(tripDataLabels[id]||id)}</span><div class="row-actions">${sortDragHandle(`tripdata|${encodeURIComponent(id)}`,'Arrastrar sección')}</div></div>`).join('')}</div></article>`:'';
  html=html.replace(/(<section class="settings-panel[^"]*" data-panel="tripdata"><form[^>]*>)([\s\S]*?)(<\/form><\/section>)/,(_m,open,body,close)=>`${open}${tripDataOrderManager}${tripDataOrder.map(id=>tripDataSections[id]).join('')}${body}${close}`);
  const poolCfg=poolPanelConfig();
  const poolSectionLabels={webcams:'📹 Webcams',pools:'🏊 Fichas de piscinas',temperatureChart:'🌡️ Gráfico de temperatura',source:'↗ Fuente original'};
  const livePoolRows=orderedPoolList(state.poolMeasurements?.pools||[]);
  const poolManager=`<article class="card settings-section pool-settings-manager"><div class="settings-section-head"><div><h3>Piscinas y webcams</h3><p class="muted">Personaliza el bloque de Cordial Santa Águeda: orden, visibilidad, títulos, colores, fichas y webcams.</p></div>${canEdit()?'<button type="button" class="btn secondary small" data-pool-settings-reset>↺ Restaurar</button>':''}</div><div class="form-grid"><label class="switch-row full"><span>Mostrar bloque de piscinas</span><input type="checkbox" data-pool-enabled ${poolCfg.enabled!==false?'checked':''} ${disabledAttr()}></label><label class="field">Título<input type="text" data-pool-setting="title" value="${esc(poolCfg.title||'Piscinas y servicios')}" ${disabledAttr()}></label><label class="field">Etiqueta superior<input type="text" data-pool-setting="kicker" value="${esc(poolCfg.kicker||'DATOS EN DIRECTO')}" ${disabledAttr()}></label><label class="field">Color botón webcam<input type="color" data-pool-setting="webcamButtonColor" value="${esc(poolCfg.webcamButtonColor||'#244c78')}" ${disabledAttr()}></label><label class="field">Texto botón webcam<input type="color" data-pool-setting="webcamButtonText" value="${esc(poolCfg.webcamButtonText||'#ffffff')}" ${disabledAttr()}></label><label class="field">Fondo fichas<input type="color" data-pool-setting="cardBackground" value="${esc(poolCfg.cardBackground||'#171a20')}" ${disabledAttr()}></label><label class="field">Borde fichas<input type="color" data-pool-setting="cardBorder" value="${esc(poolCfg.cardBorder||'#343b49')}" ${disabledAttr()}></label><label class="field">Fondo temperatura<input type="color" data-pool-setting="temperatureBackground" value="${esc(poolCfg.temperatureBackground||'#10263a')}" ${disabledAttr()}></label><label class="field">Texto temperatura<input type="color" data-pool-setting="temperatureText" value="${esc(poolCfg.temperatureText||'#ffffff')}" ${disabledAttr()}></label><label class="field">Fondo parámetros<input type="color" data-pool-setting="metricBackground" value="${esc(poolCfg.metricBackground||'#20242d')}" ${disabledAttr()}></label></div><h4 class="cordial-subtitle">Orden y visibilidad del bloque</h4><div class="tab-order-list">${(poolCfg.sectionOrder||[]).map((id,i)=>{const visible=!(poolCfg.hiddenSections||[]).includes(id);return `<div class="tab-order-row" data-sort-item="pool-section|${encodeURIComponent(id)}"><span>${esc(poolSectionLabels[id]||id)}${visible?'':' <small class="muted">· oculto</small>'}</span>${canEdit()?`<div class="row-actions"><button class="mini-btn ${visible?'active':''}" type="button" data-pool-section-visible="${esc(id)}">${visible?'👁️':'🙈'}</button>${sortDragHandle(`pool-section|${encodeURIComponent(id)}`,'Arrastrar bloque de piscinas')}</div>`:''}</div>`;}).join('')}</div><h4 class="cordial-subtitle">Webcams</h4><div class="settings-cover-list">${Object.entries(poolCfg.webcams||{}).map(([id,w])=>`<div class="settings-cover-row"><div><strong>📹 ${esc(w.label||id)}</strong><small>${w.enabled===false?'Oculta':'Visible'} · popup de vídeo directo</small></div>${canEdit()?`<div class="row-actions"><button class="mini-btn ${w.enabled!==false?'active':''}" data-pool-webcam-toggle="${esc(id)}">${w.enabled!==false?'👁️':'🙈'}</button><button class="mini-btn" data-pool-webcam-edit="${esc(id)}">✎</button></div>`:''}</div>`).join('')}</div><h4 class="cordial-subtitle">Fichas de piscinas</h4><p class="help-text">Arrastra las fichas para cambiar el orden en Alojamiento.</p>${livePoolRows.length?`<div class="settings-cover-list">${livePoolRows.map((pool,i)=>{const key=poolConfigKey(pool.name),ps=poolStyleFor(pool);return `<div class="settings-cover-row pool-settings-pool-row" data-sort-item="pool-card|${encodeURIComponent(key)}"><div><strong>🏊 ${esc(pool.name||'Piscina')}</strong><small>Orden ${i+1} · colores individuales opcionales</small><div class="pool-settings-colors"><label>Ficha <input type="color" data-pool-style="${esc(key)}:background" value="${esc(ps.background)}"></label><label>Temp. <input type="color" data-pool-style="${esc(key)}:temperatureBackground" value="${esc(ps.temperatureBackground)}"></label><label>Texto <input type="color" data-pool-style="${esc(key)}:temperatureText" value="${esc(ps.temperatureText)}"></label></div></div>${canEdit()?`<div class="row-actions">${sortDragHandle(`pool-card|${encodeURIComponent(key)}`,'Arrastrar ficha de piscina')}<button class="mini-btn" data-pool-card-reset="${esc(key)}">↺</button></div>`:''}</div>`;}).join('')}</div>`:'<div class="empty">Abre una vez Alojamiento para que aparezcan aquí las piscinas reales detectadas.</div>'}</article>`;
  html=html.replace(/(<section class="settings-panel[^\"]*" data-panel="manage"><form[^>]*>)([\s\S]*?)(<\/form><\/section>)/,(_m,open,body,close)=>`${open}${poolManager}${coverOrderManager}${carouselManager}${externalImagesManager}${body}${close}`);
  if(canEdit()){
    html += `<div class="settings-bottom-save"><button class="btn primary" type="button" data-save-settings>${saveButtonContent('Guardar todos los cambios')}</button></div>`;
    html += `<div class="settings-floating-save is-visible ${state.settingsDirty?'is-dirty':''}" data-settings-floating-save aria-hidden="false"><small class="settings-floating-save-note" data-settings-save-note>${state.settingsDirty?'Cambios sin guardar':'Listo para guardar'}</small><button class="btn primary" type="button" data-save-settings title="${state.settingsDirty?'Hay cambios sin guardar':'Guardar cambios'}" aria-label="${state.settingsDirty?'Guardar cambios pendientes':'Guardar cambios'}">${saveButtonContent('Guardar cambios')}</button></div>`;
  }
  return html;
}
let integrationDelegatedActionsBound=false;
function bindIntegrationDelegatedActions(){
  if(integrationDelegatedActionsBound)return;
  integrationDelegatedActionsBound=true;
  document.addEventListener('click',async event=>{
    const testButton=event.target.closest?.('[data-integration-test]');
    const refreshButton=event.target.closest?.('[data-integration-refresh]');
    const button=testButton||refreshButton;
    if(!button)return;
    event.preventDefault();event.stopPropagation();
    if(button.dataset.integrationBusy==='1')return;
    button.dataset.integrationBusy='1';
    const original=button.innerHTML;
    button.disabled=true;
    button.innerHTML='⏳ Comprobando…';
    try{
      if(testButton)await testIntegration(testButton.dataset.integrationTest);
      else await runIntegrationDiagnostics();
    }catch(error){
      console.error('Centro de integraciones:',error);
      toast(error?.message||'No se pudo completar la comprobación.','error');
    }finally{
      if(button.isConnected){button.disabled=false;button.innerHTML=original;delete button.dataset.integrationBusy;}
    }
  },true);
}
bindIntegrationDelegatedActions();

const bindSettingsLegacy=binders.settings;
binders.settings=()=>{
  bindSettingsLegacy();
  if(!state.poolMeasurements&&!state.poolMeasurementsLoading)void loadPoolMeasurements({silent:true});
  $('[data-mobile-deploy-prepare]')?.addEventListener('click',()=>prepareMobileDeploy().catch(error=>toast(error.message,'error')));
  const mobileReleasePicker=$('[data-mobile-deploy-file]');
  $('[data-mobile-deploy-upload]')?.addEventListener('click',()=>{try{openMobileReleasePicker();}catch(error){toast(error.message,'error');}});
  mobileReleasePicker?.addEventListener('change',()=>{const file=mobileReleasePicker.files?.[0];processMobileReleaseFile(file).catch(error=>toast(`No se pudo lanzar la actualización: ${error.message}`,'error'));});
  $('[data-mobile-deploy-progress-refresh]')?.addEventListener('click',()=>fetchMobileDeployProgress({silent:false}).catch(error=>toast(error.message,'error')));
  $('[data-mobile-deploy-trigger]')?.addEventListener('click',()=>retryMobileDeployWorkflow().catch(error=>toast(error.message,'error')));
  $('[data-update-diagnostics]')?.addEventListener('click',()=>runUpdateDiagnostics({silent:false}).catch(error=>toast(error.message,'error')));
  $('[data-pool-enabled]')?.addEventListener('change',async e=>{state.data.settings.poolPanel.enabled=e.target.checked;await saveSection('settings');render();});
  $$('[data-pool-setting]').forEach(input=>input.addEventListener('change',async()=>{state.data.settings.poolPanel[input.dataset.poolSetting]=input.value;await saveSection('settings');render();}));
  $$('[data-pool-section-visible]').forEach(b=>b.onclick=async()=>{const id=b.dataset.poolSectionVisible,hidden=new Set(state.data.settings.poolPanel.hiddenSections||[]);hidden.has(id)?hidden.delete(id):hidden.add(id);state.data.settings.poolPanel.hiddenSections=[...hidden];await saveSection('settings');render();});
  $$('[data-pool-webcam-toggle]').forEach(b=>b.onclick=async()=>{const id=b.dataset.poolWebcamToggle,w=state.data.settings.poolPanel.webcams[id]||{};state.data.settings.poolPanel.webcams[id]={...w,enabled:w.enabled===false};await saveSection('settings');render();});
  $$('[data-pool-webcam-edit]').forEach(b=>b.onclick=()=>{const id=b.dataset.poolWebcamEdit,w=state.data.settings.poolPanel.webcams[id]||{};openForm({title:'Editar webcam',fields:[{name:'label',label:'Texto del botón',full:true}],values:{label:w.label||id},onSubmit:async v=>{state.data.settings.poolPanel.webcams[id]={...w,label:v.label||id};await saveSection('settings');render();}});});
  $$('[data-pool-style]').forEach(input=>input.addEventListener('change',async()=>{const [key,field]=input.dataset.poolStyle.split(':');state.data.settings.poolPanel.poolStyles=state.data.settings.poolPanel.poolStyles||{};state.data.settings.poolPanel.poolStyles[key]={...(state.data.settings.poolPanel.poolStyles[key]||{}),[field]:input.value};await saveSection('settings');render();}));
  $$('[data-pool-card-reset]').forEach(b=>b.onclick=async()=>{delete state.data.settings.poolPanel.poolStyles[b.dataset.poolCardReset];await saveSection('settings');render();});
  $('[data-pool-settings-reset]')?.addEventListener('click',async()=>{if(!confirmAction('¿Restaurar la personalización de piscinas y webcams?'))return;state.data.settings.poolPanel=clone(SEED_DATA.settings.poolPanel);await saveSection('settings');render();toast('Piscinas y webcams restauradas.');});
  bindHexColorControls(els.content);
  bindSettingsDirtyTracking();
  $$('[data-tab-order]').forEach(b=>b.onclick=async()=>{const[id,d]=b.dataset.tabOrder.split(':');moveArrayItem(state.data.settings.tabOrder,state.data.settings.tabOrder.indexOf(id),num(d));await saveSection('settings');render();});
  $$('[data-tab-visible]').forEach(b=>b.onclick=async()=>{const id=b.dataset.tabVisible;if(!id||id==='settings')return;const enabled=new Set(state.data.settings.enabledTabs||[]);if(enabled.has(id))enabled.delete(id);else enabled.add(id);enabled.add('settings');state.data.settings.enabledTabs=[...enabled];await saveSection('settings');render();toast(`${TABS.find(t=>t[0]===id)?.[2]||id}: ${enabled.has(id)?'visible':'oculta'}.`);});
  $$('[data-tab-icon-file]').forEach(input=>input.addEventListener('change',()=>{const file=input.files?.[0];if(!file)return;const preview=$(`[data-nav-icon-preview="${CSS.escape(input.dataset.tabIconFile)}"]`);if(preview){const url=URL.createObjectURL(file);preview.innerHTML=`<img src="${esc(url)}" alt="Vista previa">`;setTimeout(()=>URL.revokeObjectURL(url),5000);}setSettingsDirty(true);}));
  $$('[data-cover-order]').forEach(b=>b.onclick=async()=>{const[id,d]=b.dataset.coverOrder.split(':');const order=state.data.settings.coverOrder||[];if(moveArrayItem(order,order.indexOf(id),num(d))){await saveSection('settings');render();}});
  $$('[data-cover-visible]').forEach(b=>b.onclick=async()=>{const id=b.dataset.coverVisible;if(id==='flights'||id==='documents')return;const hidden=new Set(state.data.settings.coverHiddenBlocks||[]);if(hidden.has(id))hidden.delete(id);else hidden.add(id);state.data.settings.coverHiddenBlocks=[...hidden];await saveSection('settings');render();toast(`${coverOrderLabels[id]?.[1]||id}: ${hidden.has(id)?'oculto':'visible'} en Portada.`);});
  $('[data-settings-carousel-add]')?.addEventListener('click',()=>openCoverCarouselEditor());
  $('[data-settings-external-image-add]')?.addEventListener('click',()=>editExternalImage());
  $('[data-settings-external-images-drive]')?.addEventListener('click',()=>addExternalImagesFromDrive());
  $$('[data-settings-external-image-edit]').forEach(b=>b.onclick=()=>editExternalImage(num(b.dataset.settingsExternalImageEdit)));
  $$('[data-settings-external-image-delete]').forEach(b=>b.onclick=async()=>{const i=num(b.dataset.settingsExternalImageDelete),item=state.data.cover.externalImages?.[i];if(!item)return;if(!confirmAction(`¿Eliminar la imagen «${item.title||'Imagen'}» de la Portada?`))return;state.data.cover.externalImages.splice(i,1);await saveSection('cover');render();});
  $$('[data-settings-carousel-edit]').forEach(b=>b.onclick=()=>openCoverCarouselEditor(num(b.dataset.settingsCarouselEdit)));
  $$('[data-settings-carousel-files]').forEach(b=>b.onclick=()=>manageCoverCarouselFiles(num(b.dataset.settingsCarouselFiles)));
  $$('[data-settings-carousel-placement]').forEach(b=>b.onclick=async()=>{const[i,placementRaw]=String(b.dataset.settingsCarouselPlacement||'').split(':'),carousel=state.data.cover.mediaCarousels?.[num(i)];if(!carousel)return;carousel.placement=placementRaw==='lodging'?'lodging':'cover';state.data.settings.desktopCoverOrder=desktopCoverOrder();await saveSection('cover');await saveSection('settings');render();toast(carousel.placement==='lodging'?`«${carousel.title||'Carrusel'}» está dentro de Alojamiento como desplegable.`:`«${carousel.title||'Carrusel'}» vuelve a la Portada.`);});
  $$('[data-settings-carousel-width]').forEach(b=>b.onclick=async()=>{const[i,widthRaw]=String(b.dataset.settingsCarouselWidth||'').split(':'),carousel=state.data.cover.mediaCarousels?.[num(i)];if(!carousel)return;const key=coverMediaLayoutKey(carousel,num(i));state.data.settings.desktopCoverWidths=state.data.settings.desktopCoverWidths||{};state.data.settings.desktopCoverWidths[key]=widthRaw==='half'?'half':'full';state.data.settings.desktopCoverOrder=desktopCoverOrder();await saveSection('settings');render();});
  $$('[data-settings-carousel-move]').forEach(b=>b.onclick=async()=>{const[i,d]=b.dataset.settingsCarouselMove.split(':').map(num);if(moveArrayItem(state.data.cover.mediaCarousels,i,d)){state.data.settings.desktopCoverOrder=desktopCoverOrder();await saveSection('cover');await saveSection('settings');render();}});
  $$('[data-settings-carousel-delete]').forEach(b=>b.onclick=async()=>{const i=num(b.dataset.settingsCarouselDelete),item=state.data.cover.mediaCarousels?.[i];if(!item)return;if(!confirmAction(`¿Eliminar el carrusel «${item.title||'Carrusel'}» y quitar sus enlaces de la Portada? Los archivos originales de Google Drive no se borrarán.`))return;const key=coverMediaLayoutKey(item,i);state.data.cover.mediaCarousels.splice(i,1);if(state.data.settings.desktopCoverWidths)delete state.data.settings.desktopCoverWidths[key];state.data.settings.desktopCoverOrder=desktopCoverOrder();await saveSection('cover');await saveSection('settings');render();});
  $$('[data-tracker-order]').forEach(b=>b.onclick=async()=>{const[id,d]=b.dataset.trackerOrder.split(':');const order=state.data.trackers.order||[];moveArrayItem(order,order.indexOf(id),num(d));await saveSection('trackers');render();});
  $$('[data-tracker-icon-edit]').forEach(b=>b.onclick=()=>editTrackerTitleIcon(b.dataset.trackerIconEdit));
  $$('[data-tracker-icon-reset]').forEach(b=>b.onclick=()=>resetTrackerTitleIcon(b.dataset.trackerIconReset));
  $('[data-settings-autoreisen-config]')?.addEventListener('click',()=>openAutoreisenEditor());
  $$('[data-tracker-restore]').forEach(b=>b.onclick=async()=>{const id=b.dataset.trackerRestore;if(!['autoreisen','cordial','vueling','fuel'].includes(id))return;state.data.trackers.visible[id]=true;if(!state.data.trackers.order.includes(id))state.data.trackers.order.push(id);await saveSection('trackers');render();toast(`${id==='autoreisen'?'AutoReisen':id==='cordial'?(state.data.trackers.cordial?.title||'Cordial'):id==='vueling'?(state.data.trackers.vueling?.title||'Vueling'):'Gasolineras'} restaurado en Seguimientos.`);});
  $('[data-tracker-restore-all]')?.addEventListener('click',async()=>{state.data.trackers.order=[...new Set([...(state.data.trackers.order||[]),'autoreisen','cordial','vueling','fuel'])];state.data.trackers.visible.autoreisen=true;state.data.trackers.visible.cordial=true;state.data.trackers.visible.vueling=true;state.data.trackers.visible.fuel=true;await saveSection('trackers');render();toast('Todos los bloques de Seguimientos están restaurados.');});
  $$('[data-settings-drive-image]').forEach(button=>button.onclick=async()=>{try{const selected=(await selectFromDrive({multiple:false,mimeTypes:'image/png,image/jpeg,image/webp,image/gif,image/svg+xml',includeToken:true,sharedDrives:false}))[0];if(!selected)return;toast('Importando imagen de Google Drive…');const imported=await importDriveImage(selected,'settings-images');const stable=imported?.url||'';if(!stable)throw new Error('No se ha podido guardar una copia estable de la imagen.');const input=$(`[name="${CSS.escape(button.dataset.settingsDriveImage)}"]`);if(input){input.value=stable;input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}));setSettingsDirty(true);const label=button.querySelector('span');if(label)label.textContent='Sustituir desde Drive';button.title='Sustituir desde Drive';const previewKey=button.dataset.previewTarget;if(previewKey==='app'){const preview=$('[data-icon-preview="app"]');if(preview)preview.innerHTML=`<img src="${esc(stable)}" alt="Vista previa">`;}else{const box=button.closest('.settings-section')?.querySelector('.url-preview,.image-placeholder');if(box){box.outerHTML=imagePreviewBox(stable,previewKey==='countdown'?'Cuenta atrás':'Vista previa');}}toast('Imagen importada desde Google Drive. Guarda los cambios para aplicarla.');}}catch(error){toast(`No se pudo seleccionar la imagen: ${error.message}`,'error');}});
  $$('[data-drive-persistent-connect]').forEach(b=>b.onclick=async()=>{try{b.disabled=true;toast('Abriendo autorización de Google Drive…');await connectPersistentDrive({browserAccess:true,selectAccount:true});await refreshDrivePersistentStatus({silent:true,force:true});render();if(drivePersistentConnected(state.drivePersistentStatus))toast('Google Drive conectado de forma permanente.');else toast('Drive conectado, pero la sesión sigue siendo temporal. Vuelve a pulsar «Hacer permanente» si el Worker acaba de reiniciarse.','error');}catch(error){toast(`No se pudo conectar Drive: ${error.message}`,'error');b.disabled=false;}});
  $$('[data-drive-persistent-disconnect]').forEach(b=>b.onclick=async()=>{if(!confirmAction('¿Desconectar Google Drive de MFE Viajes? La próxima vez tendrás que autorizarlo de nuevo.'))return;try{await disconnectPersistentDrive();await runIntegrationDiagnostics({silent:true});render();toast('Google Drive desconectado.');}catch(error){toast(`No se pudo desconectar Drive: ${error.message}`,'error');}});
  $$('[data-integration-sync-dates]').forEach(b=>b.onclick=()=>synchronizeAutoreisenWithTrip({runWorkflow:false}).catch(()=>{}));
  $$('[data-integration-sync-run]').forEach(b=>b.onclick=()=>synchronizeAutoreisenWithTrip({runWorkflow:true}).catch(()=>{}));
  $$('[data-copy-integration-uid]').forEach(b=>b.onclick=async()=>{const uid=state.user?.uid||'';if(!uid)return toast('UID no disponible.','error');await navigator.clipboard.writeText(uid);toast('UID copiado.');});
  $$('[data-notification-check]').forEach(b=>b.onclick=()=>runNotificationDiagnostics());
  $$('[data-notification-permission]').forEach(b=>b.onclick=requestNotificationPermission);
  $$('[data-notification-local-test]').forEach(b=>b.onclick=testLocalNotification);
  $$('[data-notification-token]').forEach(b=>b.onclick=generateAndCopyFcmToken);
  $$('[data-notification-copy-token]').forEach(b=>b.onclick=copyCurrentFcmToken);
  $('[data-settings-add-flight]')?.addEventListener('click',()=>editFlight());
  $$('[data-settings-edit-flight]').forEach(button=>button.onclick=()=>editFlight(num(button.dataset.settingsEditFlight)));
  $$('[data-settings-wallet-flight]').forEach(button=>button.onclick=()=>editFlightWallet(num(button.dataset.settingsWalletFlight)));
  $$('[data-settings-delete-flight]').forEach(button=>button.onclick=async()=>{const index=num(button.dataset.settingsDeleteFlight);if(confirmAction('¿Eliminar este vuelo?')){state.data.cover.flights.splice(index,1);await saveSection('cover');render();}});
  $$('[data-trip-transport-order]').forEach(button=>button.onclick=async()=>{const[index,delta]=button.dataset.tripTransportOrder.split(':').map(num);const current=currentTripTransportOrder();if(!moveArrayItem(current,index,delta))return;state.data.settings.tripTransportOrder=current;await saveSection('settings');render();});
  $$('[data-tripdata-section-order]').forEach(button=>button.onclick=async()=>{const[index,delta]=button.dataset.tripdataSectionOrder.split(':').map(num);const current=currentTripDataSectionOrder();if(!moveArrayItem(current,index,delta))return;state.data.settings.tripDataSectionOrder=current;await saveSection('settings');render();});
  $('[data-settings-add-bus]')?.addEventListener('click',()=>editBus());
  $$('[data-settings-edit-bus]').forEach(button=>button.onclick=()=>editBus(num(button.dataset.settingsEditBus)));
  $$('[data-settings-bus-visible]').forEach(button=>button.onclick=async()=>{const bus=state.data.cover.buses?.[num(button.dataset.settingsBusVisible)];if(!bus)return;bus.visible=bus.visible===false;await saveSection('cover');render();toast(bus.visible?'Trayecto de autobús visible.':'Trayecto de autobús oculto.');});
  $$('[data-settings-bus-files]').forEach(button=>button.onclick=()=>manageBusFiles(num(button.dataset.settingsBusFiles)));
  $$('[data-settings-delete-bus]').forEach(button=>button.onclick=async()=>{const index=num(button.dataset.settingsDeleteBus),bus=state.data.cover.buses?.[index];if(!bus)return;if(confirmAction(`¿Eliminar el trayecto ${bus.type||'de autobús'}?`)){state.data.cover.buses.splice(index,1);await saveSection('cover');render();}});
  $('[data-settings-edit-lodging]')?.addEventListener('click',editLodging);
  $('[data-recover-trip-template]')?.addEventListener('click',recoverReusableTripTemplateFromLatestArchive);
  $('[data-reset-flights-protected]')?.addEventListener('click',()=>promptProtectedTripDataReset('flights'));
  $('[data-reset-lodging-protected]')?.addEventListener('click',()=>promptProtectedTripDataReset('lodging'));
  $('[data-settings-edit-autoreisen]')?.addEventListener('click',()=>editTracker('autoreisen'));
  $('[data-settings-edit-cordial]')?.addEventListener('click',()=>editTracker('cordial'));
  $('[data-settings-edit-vueling]')?.addEventListener('click',()=>editTracker('vueling'));
  $('[data-settings-edit-fuel]')?.addEventListener('click',()=>editTracker('fuel'));
  $('[data-settings-store-add]')?.addEventListener('click',()=>editStore());
  $$('[data-settings-store-edit]').forEach(b=>b.onclick=()=>editStore(num(b.dataset.settingsStoreEdit)));
  $$('[data-settings-store-toggle]').forEach(b=>b.onclick=async()=>{const i=num(b.dataset.settingsStoreToggle);state.data.shopping.stores[i].active=state.data.shopping.stores[i].active===false;await saveSection('shopping');render();});
  $$('[data-settings-store-move]').forEach(b=>b.onclick=async()=>{const[i,d]=b.dataset.settingsStoreMove.split(':').map(num);moveArrayItem(state.data.shopping.stores,i,d);await saveSection('shopping');render();});
  $$('[data-settings-store-delete]').forEach(b=>b.onclick=async()=>{const i=num(b.dataset.settingsStoreDelete);if(confirmAction('¿Eliminar este supermercado y todos sus productos?')){state.data.shopping.stores.splice(i,1);await saveSection('shopping');render();}});
  for(const person of ['mikel','nerea']){
    const preview=$(`[data-official-header-preview="${person}"]`);
    const updatePreview=()=>{if(!preview)return;const g1=$(`[name="official-${person}-gradient1"]`)?.value||'#184f68';const g2=$(`[name="official-${person}-gradient2"]`)?.value||'#257b91';const text=$(`[name="official-${person}-textColor"]`)?.value||'#ffffff';preview.style.setProperty('--preview-g1',g1);preview.style.setProperty('--preview-g2',g2);preview.style.setProperty('--preview-text',text);};
    $$(`[name^="official-${person}-"]`).forEach(input=>input.addEventListener('input',updatePreview));
  }
};

async function enterApp(user) {
  state.user=user; state.profile=await state.provider.profile(user);
  const isPrimaryAdmin=String(user?.email||"").trim().toLowerCase()===PRIMARY_ADMIN_EMAIL;
  if(!state.profile && isPrimaryAdmin){
    state.profile={displayName:"Mikel",role:"admin",apps:{travel:true}};
  }
  if(!state.profile) throw new Error("Tu usuario existe en Firebase Auth, pero no tiene perfil en mfeUsers.");
  if(state.profile.apps?.travel !== true && state.profile.role !== "admin") throw new Error("Tu usuario no tiene permiso para entrar en MFE Viajes.");
  state.data=normalizeData(await state.provider.load());
  state.pinVerified=roleCanEdit()&&sessionStorage.getItem(EDIT_PIN_SESSION_KEY)==="1";
  state.unlocked=roleCanEdit()&&sessionStorage.getItem(EDIT_UNLOCK_SESSION_KEY)==="1";
  state.settingsUnlocked=false;
  if(pendingShoppingRepair&&roleCanEdit()){
    try{await state.provider.saveSection("shopping",state.data.shopping);pendingShoppingRepair=false;}catch(error){console.warn("No se pudo guardar la reparación de productos",error);}
  }
  if(pendingReminderMigration&&roleCanEdit()){
    try{
      await Promise.all([
        state.provider.saveSection("tasks",state.data.tasks),
        state.provider.saveSection("cover",state.data.cover)
      ]);
      pendingReminderMigration=false;
    }catch(error){console.warn("No se pudo guardar la migración de recordatorios",error);}
  }
  if(pendingOfficialDocumentMigration&&roleCanEdit()){
    try{await state.provider.saveSection("emergency",state.data.emergency);pendingOfficialDocumentMigration=false;}
    catch(error){console.warn("No se pudieron guardar los identificadores de documentos oficiales",error);}
  }
  if(pendingTicketItemMigration&&roleCanEdit()){
    try{await state.provider.saveSection("purchases",state.data.purchases);pendingTicketItemMigration=false;}
    catch(error){console.warn("No se pudo guardar la agrupación de productos OCR existentes",error);}
  }
  if(pendingExtrasMigration&&roleCanEdit()){
    try{
      // Guardamos primero Compra real para no perder ningún extra si la segunda escritura fallara.
      await state.provider.saveSection("purchases",state.data.purchases);
      await state.provider.saveSection("budget",state.data.budget);
      pendingExtrasMigration=false;
    }catch(error){console.warn("No se pudo guardar la migración de Extras a Compra real",error);}
  }
  if(pendingMenuMigration&&roleCanEdit()){
    try{await state.provider.saveSection("menu",state.data.menu);pendingMenuMigration=false;}
    catch(error){console.warn("No se pudo guardar la sincronización de días del Menú",error);}
  }
  if(pendingItineraryMigration&&roleCanEdit()){
    try{await state.provider.saveSection("itinerary",state.data.itinerary);pendingItineraryMigration=false;}
    catch(error){console.warn("No se pudo guardar la vista predeterminada del Itinerario",error);}
  }
  if(pendingFlightServiceVisualMigration&&roleCanEdit()){
    try{await state.provider.saveSection("cover",state.data.cover);pendingFlightServiceVisualMigration=false;}
    catch(error){console.warn("No se pudo guardar la sincronización automática de iconos de vuelo",error);}
  }
  if(pendingBudgetBusVisualMigration&&roleCanEdit()){
    try{await state.provider.saveSection("budget",state.data.budget);pendingBudgetBusVisualMigration=false;}
    catch(error){console.warn("No se pudo guardar la sincronización del título de Autobús aeropuerto con la ficha del trayecto",error);}
  }
  if(pendingConceptIconMemoryMigration&&roleCanEdit()){
    try{await state.provider.saveSection("budget",state.data.budget);pendingConceptIconMemoryMigration=false;}
    catch(error){console.warn("No se pudo guardar la memoria de iconos por concepto",error);}
  }
  els.login.classList.add("hidden");els.boot.classList.add("hidden");els.shell.classList.remove("hidden");updateHeader();render();scheduleTaskNotifications();scheduleShoppingAutoPriceChecks();scheduleFlightOpsRefresh();void repairCordialAutomationOnUpgrade();syncMonitoredTrackers({silent:true}).catch(console.warn);loadFlightOps({silent:true}).then(result=>{if(state.activeTab==='cover')render();return ensureFlightOpsAutomation({runWorkflow:!result,silent:true});}).catch(()=>{});
  if(mobileDeployRequestId())startMobileDeployProgressPolling();
  if(DEMO_MODE) { state.weather=sampleWeather(state.data.settings.weatherPlace); render(); }
  else if(state.data.settings.weatherPlace || (state.data.settings.weatherLatitude && state.data.settings.weatherLongitude)) { try{state.weather=await loadOpenMeteoWeather();render();}catch(error){console.warn(error);} }
}
function showLogin(message="") {
  applyStoredIdentity();
  els.boot.classList.add("hidden");els.shell.classList.add("hidden");els.login.classList.remove("hidden");els.loginMessage.textContent=message;els.demoLogin.classList.toggle("hidden",!(state.provider instanceof LocalProvider));
}

async function boot() {
  try {
    const placeholder=!firebaseConfig.apiKey || firebaseConfig.apiKey==="REEMPLAZAR";
    state.provider=(DEMO_MODE||placeholder)?new LocalProvider():new FirebaseProvider();
    const existing=await state.provider.init();
    if(state.provider instanceof LocalProvider) showLogin(placeholder&&!DEMO_MODE?"Configuración Firebase incompleta: se ha activado el modo demostración.":"");
    else if(existing) await enterApp(existing); else showLogin();
  } catch(error) { console.error(error);showLogin(error.message||"No se ha podido iniciar la app."); }
}

els.loginForm.addEventListener("submit",async e=>{
  e.preventDefault();els.loginMessage.textContent="Accediendo…";
  try { const user=await state.provider.login(els.loginEmail.value.trim(),els.loginPassword.value);await enterApp(user);els.loginMessage.textContent=""; }
  catch(error){
    console.error(error);
    els.loginMessage.textContent=isFirestorePermissionError(error)
      ? "El acceso de Firebase se ha validado, pero Firestore ha rechazado los permisos. Revisa que tu perfil mfeUsers y las reglas de MFE Viajes sigan publicados."
      : (error.message||"No se ha podido iniciar sesión.");
  }
});
els.demoLogin.addEventListener("click",async()=>{try{const user=await state.provider.login("demo@mfe.local","");await enterApp(user);}catch(error){els.loginMessage.textContent=error.message;}});
els.logout.addEventListener("click",async()=>{clearInterval(state.flightOpsTimer);state.flightOpsTimer=null;for(const url of state.driveObjectUrls.values())if(String(url).startsWith('blob:'))URL.revokeObjectURL(url);state.driveObjectUrls.clear();clearDriveAccessToken();state.drivePersistentStatus={checked:false,connected:false,persistentConnected:false,configured:null,temporary:false,email:"",name:"",lastMessage:""};try{sessionStorage.removeItem(EDIT_PIN_SESSION_KEY);sessionStorage.removeItem(EDIT_UNLOCK_SESSION_KEY);}catch{}await state.provider.logout();state.user=null;state.profile=null;state.unlocked=false;state.settingsUnlocked=false;state.pinVerified=false;clearInterval(state.countdownTimer);showLogin();});
els.editLock.addEventListener("click",toggleUnlock);

window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();state.installPrompt=e;els.install.classList.remove("hidden");});
els.install.addEventListener("click",async()=>{if(!state.installPrompt)return;state.installPrompt.prompt();await state.installPrompt.userChoice;state.installPrompt=null;els.install.classList.add("hidden");});
if("serviceWorker" in navigator) window.addEventListener("load",async()=>{try{const registration=await navigator.serviceWorker.register(`./sw.js?v=${APP_VERSION}-r1`,{updateViaCache:"none"});await registration.update().catch(()=>{});let reloading=false;navigator.serviceWorker.addEventListener("controllerchange",()=>{if(reloading)return;reloading=true;window.location.reload();},{once:true});}catch(error){console.warn(error);}});

boot();
