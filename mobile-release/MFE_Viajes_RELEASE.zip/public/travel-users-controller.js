import {renderTravelUserManagement} from './travel-users-ui.js?v=2.4.57';

// Controlador puro del panel; cada operación privilegiada se ejecuta en Cloud Functions.
export function createTravelUsersController({provider,canManage,unlocked,openForm,confirm,toast,render,active,userId,esc,refreshOwnProfile,loadTimeoutMs=30000}){
  const model={users:[],loaded:false,loading:false,attempted:false,error:'',errorCode:''};
  // Usar un límite de espera: una función de Firebase no disponible nunca debe
  // dejar bloqueado el panel ni el botón Actualizar indefinidamente.
  const call=(action,values={})=>provider().call('manageTravelUsers',{action,...values});
  const timeout=(promise,ms)=>{
    let id;
    const expired=new Promise((_,reject)=>{id=setTimeout(()=>{
      const error=new Error('Tiempo de espera agotado al consultar Firebase (30 segundos).');
      error.code='functions/deadline-exceeded';reject(error);
    },ms);});
    return Promise.race([Promise.resolve(promise),expired]).finally(()=>clearTimeout(id));
  };
  function describeError(error){
    const code=String(error?.code||'').toLowerCase();
    if(/unauthenticated/.test(code))return 'La sesión ha caducado. Cierra sesión y vuelve a entrar en MFE Viajes.';
    if(/permission-denied/.test(code))return 'Firebase ha denegado la lista de usuarios. Comprueba que tu perfil tiene rol Administrador de Viajes y acceso activo.';
    if(/not-found|unimplemented/.test(code))return 'No se encuentra manageTravelUsers en Firebase. Vuelve a publicar la función con ACTUALIZAR_MFE.bat.';
    if(/deadline-exceeded/.test(code))return 'Firebase no ha respondido en 30 segundos. Puede tratarse de la función apagada, la conexión o el primer arranque. Pulsa Reintentar.';
    if(/unavailable|network-request-failed/.test(code))return 'No se pudo conectar con Firebase Functions. Comprueba la red y que manageTravelUsers esté publicada en europe-west1.';
    if(/internal|resource-exhausted/.test(code))return 'La función manageTravelUsers ha fallado en Firebase. Revisa su registro en Firebase Console → Functions → Logs.';
    return error?.message||'No se pudieron cargar los usuarios desde Firebase.';
  };
  // Un render inicial fallido no debe retener model.loading=true. Nunca se llama
  // fuera del try/finally de load().
  const updateView=()=>{if(active())render();};
  const requireUnlock=()=>{
    if(!canManage()||!unlocked())throw Error('Desbloquea Configuración para gestionar usuarios.');
  };
  async function load(force=false){
    if(!canManage()||model.loading||(model.loaded&&!force))return;
    model.loading=true;model.attempted=true;model.error='';model.errorCode='';
    try{
      updateView();
      // El callable puede quedarse pendiente si Firebase Functions no está accesible.
      // Si ocurre, salimos del spinner y permitimos un nuevo intento.
      const response=await timeout(call('list'),loadTimeoutMs);
      if(!response||!Array.isArray(response.users))throw new Error('Firebase no ha devuelto una lista de usuarios válida.');
      model.users=response.users;model.loaded=true;
    }catch(error){
      console.error('[MFE Usuarios] Error al cargar:',error);
      model.error=describeError(error);
      model.errorCode=String(error?.code||'functions/unknown');
    }finally{
      model.loading=false;
      try{updateView();}catch(error){
        // Esta segunda protección evita dejar la UI bloqueada aunque falle
        // otro componente de Configuración al volver a dibujar la pantalla.
        console.error('[MFE Usuarios] Error al redibujar:',error);
      }
    }
  }
  async function change(action,payload){
    requireUnlock();
    await timeout(call(action,payload),55000);
    if(payload?.uid===userId()) await refreshOwnProfile?.();
    await load(true);
    toast('Usuarios actualizados.');
  }
  const fields=(existing=false)=>[
    {name:'displayName',label:'Nombre visible',required:true,full:true},
    {name:'email',label:'Correo electrónico',type:'email',required:true,full:true},
    ...(!existing?[{name:'password',label:'Contraseña inicial (8 caracteres como mínimo)',type:'password',required:true,full:true,help:'No se almacena en MFE Viajes. Compártela de forma privada.'}]:[]),
    {name:'role',label:'Rol de Viajes',type:'select',full:true,options:[{value:'viewer',label:'Solo lectura'},{value:'editor',label:'Editor'},{value:'admin',label:'Administrador'}]}
  ];
  const find=id=>model.users.find(u=>u.uid===id);
  function handleErrors(promise){Promise.resolve(promise).catch(error=>toast(error.message||'Error de usuarios','error'));}
  function bind(root=document){
    if(!canManage())return;
    // No repetir automáticamente tras un error: un render previo provocaba un
    // bucle infinito de fallos/cargas y ocultaba la explicación al usuario.
    if(!model.attempted&&!model.loading)handleErrors(load());
    root.querySelectorAll('[data-users-refresh], [data-users-retry]').forEach(button=>button.addEventListener('click',()=>handleErrors(load(true))));
    if(!unlocked())return;
    root.querySelector('[data-users-create]')?.addEventListener('click',()=>openForm({title:'Crear usuario',fields:fields(),values:{role:'viewer'},onSubmit:v=>change('create',v)}));
    root.querySelector('[data-users-grant]')?.addEventListener('click',()=>openForm({title:'Acceso de cuenta existente',fields:[{name:'email',label:'Correo de la cuenta Firebase',type:'email',required:true,full:true},{name:'displayName',label:'Nombre',required:true,full:true},{name:'role',label:'Rol de Viajes',type:'select',options:[{value:'viewer',label:'Solo lectura'},{value:'editor',label:'Editor'},{value:'admin',label:'Administrador'}]}],values:{role:'viewer'},onSubmit:v=>change('grant',v)}));
    root.querySelectorAll('[data-users-edit]').forEach(button=>button.addEventListener('click',()=>{
      const u=find(button.dataset.usersEdit);if(!u)return;
      openForm({title:'Editar datos y rol',fields:fields(true),values:u,onSubmit:async v=>{
        if(u.otherApps?.length&&u.email!==v.email&&!confirm('Cambiar el correo afecta al inicio de sesión de sus otras aplicaciones. ¿Continuar?'))return false;
        await change('update',{uid:u.uid,...v});
      }});
    }));
    root.querySelectorAll('[data-users-access]').forEach(button=>button.addEventListener('click',()=>{
      const u=find(button.dataset.usersAccess);if(!u)return;
      if(!confirm(`${u.enabled?'¿Desactivar':'¿Activar'} el acceso de ${u.displayName||u.email} a MFE Viajes?`))return;
      handleErrors(change('access',{uid:u.uid,enabled:!u.enabled}));
    }));
    root.querySelectorAll('[data-users-reset]').forEach(button=>button.addEventListener('click',()=>{
      const u=find(button.dataset.usersReset);if(!u?.email||!confirm(`¿Enviar correo de recuperación a ${u.email}?`))return;
      handleErrors(provider().resetUserPassword(u.email).then(()=>toast('Solicitud de recuperación de contraseña enviada.')));
    }));
    root.querySelectorAll('[data-users-remove]').forEach(button=>button.addEventListener('click',()=>{
      const u=find(button.dataset.usersRemove);if(!u||!confirm(`¿Retirar el acceso de ${u.displayName||u.email} a MFE Viajes? Su cuenta y datos de otras apps se conservan.`))return;
      handleErrors(change('remove',{uid:u.uid}));
    }));
    root.querySelectorAll('[data-users-delete]').forEach(button=>button.addEventListener('click',()=>{
      const u=find(button.dataset.usersDelete);if(!u||!confirm(`¿ELIMINAR DEFINITIVAMENTE la cuenta Firebase de ${u.email}? No se podrá deshacer. Solo para cuentas exclusivas de Viajes.`))return;
      handleErrors(change('deleteAccount',{uid:u.uid}));
    }));
  }
  return {load,bind,html:()=>renderTravelUserManagement(model,{unlocked:unlocked(),currentUid:userId(),esc}),reset:()=>{model.users=[];model.loaded=false;model.loading=false;model.attempted=false;model.error='';model.errorCode='';}};
}
