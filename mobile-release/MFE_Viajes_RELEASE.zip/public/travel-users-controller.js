import {renderTravelUserManagement} from './travel-users-ui.js?v=2.4.56';

// Controlador puro del panel; cada operación privilegiada se ejecuta en Cloud Functions.
export function createTravelUsersController({provider,canManage,unlocked,openForm,confirm,toast,render,active,userId,esc,refreshOwnProfile}){
  const model={users:[],loaded:false,loading:false,error:''};
  const call=(action,values={})=>provider().call('manageTravelUsers',{action,...values});
  const requireUnlock=()=>{
    if(!canManage()||!unlocked())throw Error('Desbloquea Configuración para gestionar usuarios.');
  };
  async function load(force=false){
    if(!canManage()||model.loading||(model.loaded&&!force))return;
    model.loading=true;model.error='';if(active())render();
    try{
      const response=await call('list');
      model.users=response?.users||[];model.loaded=true;
    }catch(error){model.error=error?.message||'No se pudieron cargar los usuarios.';}
    finally{model.loading=false;if(active())render();}
  }
  async function change(action,payload){
    requireUnlock();
    await call(action,payload);
    if(payload?.uid===userId()) await refreshOwnProfile?.();
    await load(true);
    toast('Usuarios actualizados.');
  }
  const fields=(existing=false)=>[
    {name:'displayName',label:'Nombre visible',required:true,full:true},
    {name:'email',label:'Correo electrónico',type:'email',required:true,full:true},
    ...(!existing?[{name:'password',label:'Contraseña inicial (8 caracteres como mínimo)',type:'password',required:true,full:true,help:'No se almacena en MFE Viajes. Compártela de forma privada.'}]:[]),
    {name:'role',label:'Rol de Viajes',type:'select',full:true,options:[{value:'viewer',label:'Solo lectura'},{value:'editor',label:'Editor'},{value:'admin',label:'Administrador'}]}
  ];
  const find=id=>model.users.find(u=>u.uid===id);
  function handleErrors(promise){Promise.resolve(promise).catch(error=>toast(error.message||'Error de usuarios','error'));}
  function bind(root=document){
    if(!canManage())return;
    if(!model.loaded&&!model.loading)handleErrors(load());
    root.querySelector('[data-users-refresh]')?.addEventListener('click',()=>handleErrors(load(true)));
    if(!unlocked())return;
    root.querySelector('[data-users-create]')?.addEventListener('click',()=>openForm({title:'Crear usuario',fields:fields(),values:{role:'viewer'},onSubmit:v=>change('create',v)}));
    root.querySelector('[data-users-grant]')?.addEventListener('click',()=>openForm({title:'Acceso de cuenta existente',fields:[{name:'email',label:'Correo de la cuenta Firebase',type:'email',required:true,full:true},{name:'displayName',label:'Nombre',required:true,full:true},{name:'role',label:'Rol de Viajes',type:'select',options:[{value:'viewer',label:'Solo lectura'},{value:'editor',label:'Editor'},{value:'admin',label:'Administrador'}]}],values:{role:'viewer'},onSubmit:v=>change('grant',v)}));
    root.querySelectorAll('[data-users-edit]').forEach(button=>button.addEventListener('click',()=>{
      const u=find(button.dataset.usersEdit);if(!u)return;
      openForm({title:'Editar datos y rol',fields:fields(true),values:u,onSubmit:async v=>{
        if(u.otherApps?.length&&u.email!==v.email&&!confirm('Cambiar el correo afecta al inicio de sesión de sus otras aplicaciones. ¿Continuar?'))return false;
        await change('update',{uid:u.uid,...v});
      }});
    }));
    root.querySelectorAll('[data-users-access]').forEach(button=>button.addEventListener('click',()=>{
      const u=find(button.dataset.usersAccess);if(!u)return;
      if(!confirm(`${u.enabled?'¿Desactivar':'¿Activar'} el acceso de ${u.displayName||u.email} a MFE Viajes?`))return;
      handleErrors(change('access',{uid:u.uid,enabled:!u.enabled}));
    }));
    root.querySelectorAll('[data-users-reset]').forEach(button=>button.addEventListener('click',()=>{
      const u=find(button.dataset.usersReset);if(!u?.email||!confirm(`¿Enviar correo de recuperación a ${u.email}?`))return;
      handleErrors(provider().resetUserPassword(u.email).then(()=>toast('Solicitud de recuperación de contraseña enviada.')));
    }));
    root.querySelectorAll('[data-users-remove]').forEach(button=>button.addEventListener('click',()=>{
      const u=find(button.dataset.usersRemove);if(!u||!confirm(`¿Retirar el acceso de ${u.displayName||u.email} a MFE Viajes? Su cuenta y datos de otras apps se conservan.`))return;
      handleErrors(change('remove',{uid:u.uid}));
    }));
    root.querySelectorAll('[data-users-delete]').forEach(button=>button.addEventListener('click',()=>{
      const u=find(button.dataset.usersDelete);if(!u||!confirm(`¿ELIMINAR DEFINITIVAMENTE la cuenta Firebase de ${u.email}? No se podrá deshacer. Solo para cuentas exclusivas de Viajes.`))return;
      handleErrors(change('deleteAccount',{uid:u.uid}));
    }));
  }
  return {load,bind,html:()=>renderTravelUserManagement(model,{unlocked:unlocked(),currentUid:userId(),esc}),reset:()=>{model.users=[];model.loaded=false;model.loading=false;model.error='';}};
}
