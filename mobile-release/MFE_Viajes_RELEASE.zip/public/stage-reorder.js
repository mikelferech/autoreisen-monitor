// GC27 v2.4.56 · Itinerario proyectado. No modifica reservas externas ni elimina históricos.
const cp = x => structuredClone(x);
const iso = x => /^\d{4}-\d{2}-\d{2}$/.test(String(x||'').slice(0,10)) ? String(x).slice(0,10) : '';
const withDate = (original, date) => date ? date + (String(original||'').match(/T.*/)?.[0] || '') : String(original||'');
const addDays = (date,n) => { const d=new Date(date+'T12:00:00Z');d.setUTCDate(d.getUTCDate()+n);return d.toISOString().slice(0,10); };
const shiftDate = (date,oldStart,newStart) => iso(date)&&iso(oldStart)&&iso(newStart) ? addDays(newStart,Math.round((Date.parse(iso(date)+'T12:00:00Z')-Date.parse(iso(oldStart)+'T12:00:00Z'))/86400000)) : date;
const airport = island => /fuerteventura|corralejo/i.test(island||'') ? {code:'FUE',label:'Fuerteventura (FUE)'} : {code:'LPA',label:'Gran Canaria (LPA)'};
const fields = (object,keys) => Object.fromEntries(keys.filter(k=>Object.hasOwn(object||{},k)).map(k=>[k,cp(object[k])]));
const CURRENT = ['currentPrice','lastUpdated','lastError','lastAttempt','monitorStatus','availability','source','resultUrl'];
const rentalFields=['pickupAt','dropoffAt',...CURRENT,'fleetPrices','fleetLastCheckedAt','monitorStatus','needsReservationReview'];
const hotelFields=['checkIn','checkOut',...CURRENT,'options','verifiedOffers','needsReservationReview'];
const cordialFields=['checkIn','checkOut',...CURRENT,'options','targetPrice'];
const vuelingFields=['origin','destination','departureDate','returnDate','outboundFlight','returnFlight','outboundPrice','returnPrice','returnOrigin','returnDestination','itineraryMultiCity','enabled',...CURRENT];
const flightFields=['id','date','departure','arrival','from','to','type','airline','number','status','source','checkInNotifyAt','leaveNotifyAt','lastUpdated','gate','terminal','checkInCounters','scheduleNeedsReview'];
const stageIds = stages => (stages?.items||[]).map((s,i)=>String(s.id||`week-${i+1}`));
export function stageSortIds(stages={}){
  const ids=stageIds(stages),requested=Array.isArray(stages.order)?stages.order:[];
  return [...new Set([...requested.filter(id=>ids.includes(id)),...ids])];
}
export function stageOrderIsInverted(stages={}) { const a=stageSortIds(stages),ids=stageIds(stages);return a.length===2&&a[0]===ids[1]; }
export function previewStageInversion(data){
  const items=data?.stages?.items||[];
  if(items.length!==2||!items.every(s=>iso(s.start)&&iso(s.end)))throw Error('Configura primero las fechas de ambas etapas.');
  const order=stageSortIds(data.stages),byId=new Map(items.map(s=>[s.id,s]));
  const [first,second]=order.map(id=>byId.get(id));
  if(!first||!second||first.id===second.id)throw Error('Las etapas deben tener identificadores distintos.');
  if(first.end!==second.start)throw Error('Las semanas deben ser consecutivas; revisa su fecha de enlace antes de invertir.');
  return {order:[second.id,first.id],before:[{island:first.island,start:first.start,end:first.end},{island:second.island,start:second.start,end:second.end}],after:[{island:second.island,start:first.start,end:first.end},{island:first.island,start:second.start,end:second.end}],interisland:{from:airport(second.island),to:airport(first.island),date:second.start},newInbound:airport(second.island),newOutbound:airport(first.island)};
}
function resetCurrent(obj,clearArrays=[]){
  if(!obj)return;
  Object.assign(obj,{currentPrice:'',lastUpdated:'',lastAttempt:'',lastError:'',monitorStatus:'pending',availability:'',source:''});
  for(const key of clearArrays)if(Array.isArray(obj[key]))obj[key]=[];
}
function updateFlight(flight,date,from,to){
  if(!flight)return;
  const previousRoute=String(flight.from||'')+'|'+String(flight.to||'');
  const nextRoute=from.label+'|'+to.label;
  flight.date=date;
  if(flight.departure)flight.departure=withDate(flight.departure,date);
  if(flight.arrival)flight.arrival=withDate(flight.arrival,date);
  flight.from=from.label;flight.to=to.label;
  if(previousRoute!==nextRoute){
    // El identificador de un vuelo anterior NUNCA vale para la ruta invertida.
    flight.number='';flight.scheduleNeedsReview=true;flight.status='Ruta prevista · billete por confirmar';
    flight.source='Plan de viaje: revisar antes de comprar';
    for(const k of ['gate','terminal','checkInCounters','lastUpdated'])flight[k]='';
    flight.checkInNotifyAt=0;flight.leaveNotifyAt=0;
  }
}
const findFlight = (flights,kind) => flights.find(f => kind==='inter' ? /escala/i.test(f.type||'')||/binter/i.test(f.airline||'') : kind==='out' ? f.id==='flight-out'||f.type==='IDA' : f.id==='flight-back'||f.type==='VUELTA');
function patchStageDates(data,newOrder){
  const items=data.stages.items,byId=new Map(items.map(s=>[s.id,s]));
  const old=stageSortIds(data.stages),[oldFirst,oldSecond]=old.map(id=>byId.get(id)),slots=[{start:oldFirst.start,end:oldFirst.end},{start:oldSecond.start,end:oldSecond.end}];
  const dateMap=new Map();
  newOrder.forEach((id,i)=>{const stage=byId.get(id),prev={start:stage.start,end:stage.end},slot=slots[i];dateMap.set(id,{old:prev,now:slot});stage.start=slot.start;stage.end=slot.end;
    if(stage.hotel?.checkIn)stage.hotel.checkIn=slot.start;
    if(stage.hotel?.checkOut)stage.hotel.checkOut=slot.end;
    if(stage.car?.pickupAt)stage.car.pickupAt=withDate(stage.car.pickupAt,slot.start);
    if(stage.car?.dropoffAt)stage.car.dropoffAt=withDate(stage.car.dropoffAt,slot.end);
    if(stage.binter?.date)stage.binter.date=slots[1].start;
  });
  return {slots,dateMap};
}
function moveDatedRecords(records,oldStages,dateMap){
  if(!Array.isArray(records))return;
  for(const row of records){
    const date=iso(row?.date);if(!date)continue;
    const stage=oldStages.find(s=>date>=s.start&&(date<s.end||date===s.end&&s===oldStages.at(-1)));
    if(!stage)continue;
    const mapping=dateMap.get(stage.id);if(!mapping)continue;
    const translated=shiftDate(date,mapping.old.start,mapping.now.start);
    // Preserve the last checkout day if a record exists on it.
    row.date=translated>mapping.now.end?mapping.now.end:translated;
  }
}
export function invertTripPlan(source){
  const data=cp(source),preview=previewStageInversion(data),stages=data.stages,items=stages.items;
  const beforeOrder=stageSortIds(stages),oldStages=beforeOrder.map(id=>cp(items.find(s=>s.id===id)));
  const one=items[0],two=items[1],p=data.trackers||{},settings=data.settings||{},cover=data.cover||{};
  const snapshot={order:beforeOrder,
    stageDates:items.map(s=>({id:s.id,start:s.start,end:s.end,hotel:fields(s.hotel,hotelFields),car:fields(s.car,rentalFields),binter:cp(s.binter||null)})),
    lodging:fields(cover.lodging,hotelFields),autoreisen:fields(p.autoreisen,rentalFields),cordial:fields(p.cordial,cordialFields),vueling:fields(p.vueling,vuelingFields),
    settings:fields(settings,['destination','weatherPlace','weatherLatitude','weatherLongitude','departureDateTime','returnDateTime','tripTransportOrder','lodgingPageOrder']),
    flights:(cover.flights||[]).map((f,i)=>({id:f.id||`idx-${i}`,fields:fields(f,flightFields)})),flightOrder:(cover.flights||[]).map((f,i)=>f.id||`idx-${i}`),activities:cp(data.itinerary?.activities||[]),menuDays:cp(data.menu?.days||[])};
  const {slots,dateMap}=patchStageDates(data,preview.order);
  // La primera fuente de datos sigue siendo Gran Canaria; no intercambiar reservas ni IDs.
  if(one){if(cover.lodging?.checkIn)cover.lodging.checkIn=one.start;if(cover.lodging?.checkOut)cover.lodging.checkOut=one.end;
    if(p.cordial){p.cordial.checkIn=one.start;p.cordial.checkOut=one.end;resetCurrent(p.cordial,['options']);}
    if(p.autoreisen){if(p.autoreisen.pickupAt)p.autoreisen.pickupAt=withDate(p.autoreisen.pickupAt,one.start);if(p.autoreisen.dropoffAt)p.autoreisen.dropoffAt=withDate(p.autoreisen.dropoffAt,one.end);resetCurrent(p.autoreisen,['fleetPrices']);}
  }
  if(two){resetCurrent(two.hotel,['verifiedOffers']);resetCurrent(two.car,['fleetPrices']);}
  for(const booking of [cover.lodging,p.autoreisen,two.hotel,two.car])if(booking&&Object.keys(booking).length)booking.needsReservationReview=true;
  const first=items.find(s=>s.id===preview.order[0]),second=items.find(s=>s.id===preview.order[1]);
  const newFirst=airport(first.island),newSecond=airport(second.island),home={code:'BIO',label:'Bilbao (BIO)'};
  // El vuelo de enlace se define por la cronología, NO por la isla que se llamaba «etapa 2».
  if(!two.binter)two.binter={};
  two.binter.date=second.start;two.binter.origin=newFirst.code;two.binter.destination=newSecond.code;resetCurrent(two.binter);
  const flights=cover.flights||[];
  const outbound=findFlight(flights,'out'),inbound=findFlight(flights,'back'),inter=findFlight(flights,'inter');
  updateFlight(outbound,first.start,home,newFirst);updateFlight(inbound,second.end,newSecond,home);
  if(inter)updateFlight(inter,second.start,newFirst,newSecond);
  cover.flights=flights.sort((a,b)=>String(a.date||'').localeCompare(String(b.date||''))||String(a.departure||'').localeCompare(String(b.departure||'')));
  const vueling=p.vueling;
  if(vueling){vueling.origin='BIO';vueling.destination=newFirst.code;vueling.returnOrigin=newSecond.code;vueling.returnDestination='BIO';vueling.departureDate=first.start;vueling.returnDate=second.end;vueling.outboundFlight='';vueling.returnFlight='';resetCurrent(vueling);vueling.outboundPrice='';vueling.returnPrice='';vueling.itineraryMultiCity=true;vueling.enabled=false;vueling.monitorStatus='pending-route';vueling.lastError='Seguimiento Vueling de ida/vuelta no admite regreso desde un aeropuerto distinto. Confirmar vuelos multitrayecto antes de activarlo.';}
  const departure=settings.departureDateTime||first.start+'T12:00',ret=settings.returnDateTime||second.end+'T12:00';
  settings.departureDateTime=withDate(departure,first.start);settings.returnDateTime=withDate(ret,second.end);
  settings.destination=first.island+' · '+second.island;
  if(Array.isArray(settings.lodgingPageOrder)){const others=settings.lodgingPageOrder.filter(x=>x!=='fuerteventura');settings.lodgingPageOrder=preview.order[0]===items[1].id?['fuerteventura',...others]:[...others,'fuerteventura'];}else if(preview.order[0]===items[1].id){settings.lodgingPageOrder=['fuerteventura','hero','details','media','map'];}
  // El panel meteorológico principal está vinculado a Gran Canaria y el segundo a Fuerteventura.
  // Cambia su orden visual, no sus fuentes: así no se duplican previsiones ni se intercambian ciudades.
  // Los gastos/reservas permanecen vinculados a su isla por ID, mientras actividades y menús acompañan su semana.
  moveDatedRecords(data.itinerary?.activities,oldStages,dateMap);
  moveDatedRecords(data.menu?.days,oldStages,dateMap);
  if(Array.isArray(settings.tripTransportOrder)){
    const flightKeys=cover.flights.filter(x=>x.id).map(x=>'flight:'+x.id),positions=settings.tripTransportOrder.map((key,i)=>key.startsWith('flight:')?i:-1).filter(i=>i>=0);
    positions.forEach((index,i)=>{if(flightKeys[i])settings.tripTransportOrder[index]=flightKeys[i];});
  }
  stages.order=preview.order;stages.lastInversion={at:new Date().toISOString(),snapshot,changedFlightIds:flights.filter(f=>f.scheduleNeedsReview).map(f=>f.id)};
  return {data,preview};
}
export function undoTripPlan(source){
  const data=cp(source),s=data.stages||{},snap=s.lastInversion?.snapshot;
  if(!snap)throw Error('No hay una inversión reciente que deshacer.');
  const restore=(obj,values)=>{if(obj&&values)Object.assign(obj,cp(values));};
  s.order=cp(snap.order);
  for(const original of snap.stageDates||[]){const target=s.items.find(x=>x.id===original.id);if(!target)continue;target.start=original.start;target.end=original.end;if(!Object.hasOwn(original.hotel||{},'needsReservationReview')&&target.hotel)delete target.hotel.needsReservationReview;if(!Object.hasOwn(original.car||{},'needsReservationReview')&&target.car)delete target.car.needsReservationReview;restore(target.hotel,original.hotel);restore(target.car,original.car);if(original.binter===null)delete target.binter;else target.binter=cp(original.binter);}
  if(!Object.hasOwn(snap.lodging||{},'needsReservationReview')&&data.cover?.lodging)delete data.cover.lodging.needsReservationReview;if(!Object.hasOwn(snap.autoreisen||{},'needsReservationReview')&&data.trackers?.autoreisen)delete data.trackers.autoreisen.needsReservationReview;restore(data.cover?.lodging,snap.lodging);restore(data.trackers?.autoreisen,snap.autoreisen);restore(data.trackers?.cordial,snap.cordial);restore(data.trackers?.vueling,snap.vueling);if(data.trackers?.vueling){for(const key of ['returnOrigin','returnDestination','itineraryMultiCity'])if(!Object.hasOwn(snap.vueling||{},key))delete data.trackers.vueling[key];}restore(data.settings,snap.settings);
  if(data.cover){const byKey=new Map((data.cover.flights||[]).map((f,i)=>[f.id||`idx-${i}`,f]));for(const saved of snap.flights||[]){const f=byKey.get(saved.id);if(!f)continue;for(const key of flightFields)if(!Object.hasOwn(saved.fields||{},key))delete f[key];restore(f,saved.fields);}data.cover.flights=(snap.flightOrder||[]).map(id=>byKey.get(id)).filter(Boolean);}
  if(data.itinerary)data.itinerary.activities=cp(snap.activities);
  if(data.menu)data.menu.days=cp(snap.menuDays);
  delete s.lastInversion;
  return data;
}
