// UI de administración de perfiles. No incluye ninguna credencial privilegiada.
export function renderTravelUserManagement(model={}, {unlocked=false,currentUid='',esc=(v)=>String(v)}={}) {
  const items=Array.isArray(model.users)?model.users:[];
  const busy=!!model.loading;
  const roles={admin:'Administrador',editor:'Editor',viewer:'Solo lectura'};
  const actions=(u)=>{
    if(!unlocked)return '<small>Desbloquea el candado para editar.</small>';
    const self=u.uid===currentUid;
    return `<div class="travel-user-actions">
      <button type="button" class="btn secondary small" data-users-edit="${esc(u.uid)}">✎ Editar datos y rol</button>
      <button type="button" class="btn secondary small" data-users-reset="${esc(u.uid)}" ${u.missingAuth?'disabled':''}>Contraseña</button>
      <button type="button" class="btn secondary small" data-users-access="${esc(u.uid)}" ${self?'disabled title="No puedes desactivar tu acceso"':''}>${u.enabled?'Desactivar acceso':'Activar acceso'}</button>
      <button type="button" class="btn danger small" data-users-remove="${esc(u.uid)}" ${self?'disabled':''}>Retirar acceso</button>
      ${!u.otherApps?.length&&!self?`<button type="button" class="btn danger small" data-users-delete="${esc(u.uid)}">Eliminar cuenta</button>`:''}
    </div>`;
  };
  const rows=items.map(u=>`<div class="travel-user-row">
    <div class="travel-user-info"><strong>${esc(u.displayName||'Usuario')}</strong><small>${esc(u.email||'Sin correo · cuenta no encontrada')}</small>
      <span class="travel-user-meta">${esc(roles[u.role]||u.role)} · ${u.enabled?'Acceso activo':'Sin acceso a Viajes'}${u.otherApps?.length?` · Otras apps: ${esc(u.otherApps.join(', '))}`:''}${u.lastSignIn?` · Último acceso: ${esc(u.lastSignIn)}`:''}</span></div>
    ${actions(u)}
  </div>`).join('');
  return `<article class="card settings-section travel-users-manager">
    <div class="settings-section-head"><div><h3>👥 Usuarios y permisos</h3><p class="muted">Gestiona cuentas y roles de MFE Viajes sin salir de la aplicación.</p></div><button class="btn secondary small" type="button" data-users-refresh ${busy?'disabled':''}>↻ Actualizar</button></div>
    <p class="help-text">Solo administradores. Hogar y Ahorro conservan sus permisos. Para que la desactivación se aplique también a Firestore, las reglas de acceso nuevas deben estar publicadas. Consulta SEGURIDAD_USUARIOS.md.</p>
    <div class="page-actions">
      <button class="btn primary" type="button" data-users-create ${unlocked?'':'disabled'}>+ Crear usuario</button>
      <button class="btn secondary" type="button" data-users-grant ${unlocked?'':'disabled'}>Dar acceso a cuenta existente</button>
    </div>
    ${model.error?`<div class="travel-users-failure" role="alert"><strong>⚠️ No se ha podido cargar la lista</strong><p>${esc(model.error)}</p><small>Código: ${esc(model.errorCode||'desconocido')} · El acceso de los usuarios no se modifica por este error.</small><button class="btn secondary small" type="button" data-users-retry>↻ Reintentar carga</button></div>`:''}
    ${busy?'<div class="travel-users-loading" role="status"><strong>⏳ Conectando con Firebase…</strong><small>La consulta se cancelará automáticamente si no responde en 30 segundos; después podrás reintentar.</small></div>':rows||(!model.error?'<p class="empty">No hay usuarios cargados. Pulsa Actualizar.</p>':'')}
    <p class="help-text">Eliminar cuenta solo se ofrece para usuarios que no tienen permisos de otras MFE Apps. Retirar acceso conserva la cuenta y su historial.</p>
  </article>`;
}
