# MFE Viajes v2.4.55 · Invertir etapas y Dunas móvil

- Pestaña Etapas: «Invertir etapas» con vista previa de fechas, hoteles, coches y enlace FUE/LPA, y botón «Deshacer inversión».
- Reprogramación coherente por isla de alojamientos, AutoReisen, Cordial, Dunas y vuelo interinsular; cambia el itinerario previsto de los vuelos exteriores y las consultas sin transferir reservas reales ni borrar históricos.
- Los números de vuelos afectados quedan pendientes de confirmar, preservando su configuración anterior para deshacer.
- Actividades y menús se desplazan con la isla; compras, gastos, documentos y reservas permanecen asociados a sus IDs originales.
- Seguimientos de Fuerteventura/Gran Canaria y Binter sincronizan sus nuevas fechas tras confirmar.
- Dunas Seguimiento: diseño de tarifas en una columna móvil, precios legibles y solo una tarifa destacada.
- Actualización incluye la reparación Cordial 5 adultos/1 Beach Club House de la v2.4.54, y no modifica el monitor remoto durante la preparación del ZIP.

**ATENCIÓN:** Invertir reorganiza la planificación de la app; NO modifica billetes ni reservas ya contratados. Los vuelos con otra ruta deben revisarse antes de utilizarlos. La actualización no aplica una inversión por sí misma: queda a decisión del usuario.
