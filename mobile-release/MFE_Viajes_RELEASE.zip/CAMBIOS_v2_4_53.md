# MFE Viajes GC27 v2.4.53 · Cordial

- Diagnóstico **real** de la ejecución GitHub 6 de noviembre: «Monitor Cordial desactivado desde MFE Viajes.»; job verde sin consulta.
- El monitor mantiene la opción de desactivar el cron, pero las ejecuciones forzadas desde «Comprobar ahora» sí se realizan.
- Activación de seguimiento diario Cordial en la configuración base.
- Archivo `cordial-run.mjs` sincronizado con el instalador del Worker; no reintroducirá el bloqueo en siguientes instalaciones.
- Prueba específica de la igualdad exacta entre el monitor publicado por Cloudflare y el incluido en ZIP.

**Importante:** sin ejecutar de nuevo el trabajo de GitHub con el monitor corregido, no es posible certificar las tarifas del motor BeCordial. Los 2.965,26 € del PDF son un precio de esa captura, no una cotización de hoy.
