# GC27 v2.4.61 · Alojamiento

- En Reserva, Dunas dispone de una ficha de documentos del mismo tipo que Cordial, con Web, Check-in, visor, adjuntos PDF/Drive, edición, orden y eliminación. Se crea una vez y respeta la eliminación del usuario.
- Eliminados Fotos y Reservar de los accesos superiores de Cordial y Dunas (permanecen Web, Cómo llegar, opiniones y Check-in).
- PDF y galerías de Cordial, así como su mapa, se muestran dentro del bloque Primera estancia · Gran Canaria: se mueven juntos cuando se reordena Alojamiento.
- Cada tarjeta de piscina permite arrastrar desde su control ⋮⋮ en Alojamiento. El orden se conserva en la configuración y se mantiene con nuevas lecturas del monitor.
- Actualización solo Firebase Hosting en Spark; no hay cambios en monitorizaciones, Workers ni Functions.
