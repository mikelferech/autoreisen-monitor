@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul
echo AVISO: Firebase es un proyecto compartido con Cuentas Hogar y otras aplicaciones.
echo Antes de usar este script, COMPARA firestore.rules con las reglas ACTUALES.
echo No publiques estas reglas sin integrar antes todos los cambios de otros proyectos.
choice /C SN /M "Has revisado y fusionado las reglas del proyecto completo"
if errorlevel 2 exit /b 1
where firebase >nul 2>&1
if errorlevel 1 (
  npx --yes firebase-tools@latest deploy --only firestore:rules --project presupuesto-hogar-9dead
) else (
  firebase deploy --only firestore:rules --project presupuesto-hogar-9dead
)
pause
