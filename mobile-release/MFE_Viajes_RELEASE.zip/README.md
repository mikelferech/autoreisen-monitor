# MFE Viajes 2026 · v2.2.155

## v2.2.155 · Desbloqueo local reforzado en Android

- Refuerza WebAuthn para intentar usar el autenticador interno del móvil/tablet: `authenticatorAttachment: platform`, `residentKey: discouraged`, `userVerification: required`, `hints: client-device` y transporte `internal`.
- Las credenciales creadas en v2.2.154 se consideran antiguas y deben activarse una vez de nuevo desde Configuración → Acceso.
- Si Android devuelve un autenticador no local, MFE no guarda esa credencial y conserva el PIN como alternativa.

- Añade WebAuthn opcional por dispositivo para desbloquear edición y Configuración mediante huella, rostro o bloqueo de pantalla.
- Cada móvil/tablet se configura de forma independiente por usuario; el PIN de MFE permanece siempre como respaldo.
- La aplicación no recibe ni guarda datos biométricos: Android/Chrome solo confirma que la verificación del dispositivo fue correcta.
- No cambia ningún Worker.

- Corrige la navegación interna de **Configuración**: todos los apartados vuelven a abrirse correctamente.
- Mantiene **Actualización app** como apartado independiente, separado de Integraciones.
- Los botones rápidos **M/N** de las tarjetas de embarque usan exactamente el mismo color/degradado configurado para Vueling que **Check-in** y **Mis viajes**.
- Sustituye el pictograma reducido por un icono de tarjeta de embarque más legible.
- Si las tarjetas de **Mikel y Nerea** ya están guardadas, Check-in permanece oscurecido e inhabilitado; si falta alguna, Check-in sigue activo.
- Esta release no modifica Workers. Worker principal vigente **2.2.25**; Worker Vueling **1.0.21**.

## v2.2.143 · Iconos de Seguimientos más intuitivos y PNG persistente

- **AutoReisen, Cordial y Vueling** incluyen ahora el icono directamente dentro de sus propios editores de configuración.
- Cada ficha de Seguimientos añade además un botón **🖼 Icono** junto a Configurar/Reserva para cambiarlo sin buscarlo en Configuración general.
- En **Editar alojamiento** se puede cambiar también el icono de **Cordial/Alojamiento** que aparece en la pastilla-resumen y en la cabecera del seguimiento.
- Los iconos seleccionados desde **Google Drive** se descargan y convierten a **PNG 128×128 embebido**, conservando transparencia y sin depender después de permisos/URLs de Drive o Firebase Storage.
- La **Imagen manual del coche** de AutoReisen queda claramente identificada como foto del vehículo y no como icono del seguimiento.
- Se mantiene también el editor central en **Configuración → Seguimientos**.
- **No modifica ningún Worker**. `ACTUALIZAR_MFE.bat` publicará únicamente Firebase Hosting.

## v2.2.142 · Amanecer y atardecer en la previsión diaria

- Cada tarjeta diaria de **Tiempo** muestra ahora la hora de **amanecer 🌅** y **atardecer 🌇**.
- Los horarios se obtienen directamente de **Open-Meteo** usando la zona horaria del destino (`timezone=auto`).
- Se mantienen los 7 días de previsión y el diseño compacto de las tarjetas.
- **No modifica ningún Worker**. `ACTUALIZAR_MFE.bat` omitirá la actualización de Cloudflare y publicará únicamente Firebase Hosting.
- Se conservan los cambios de v2.2.141: reparación de Cordial y pastillas-resumen superiores de Seguimientos.

## v2.2.131 · Icono Android con fondo oscuro
- Los cinco accesos rápidos de Alojamiento mantienen un ancho mínimo uniforme en escritorio para evitar que Booking se vea más estrecho que Google o Tripadvisor.
- Cuando Cloudflare tenga que lanzar seguimientos ausentes, el aviso indica expresamente que las automatizaciones principales no se ejecutaron y que Cloudflare lanzó el respaldo, mostrando los seguimientos afectados.

## v2.2.131 · Arrastre directo en Portada y Compra real

- Se eliminan las flechas **↑ / ↓** de reordenación y se sustituyen por un único asa **⋮⋮** para arrastrar directamente cada elemento a su nueva posición.
- La reordenación libre se aplica a los lugares que ya permitían cambiar orden: documentos de Portada, bloques de Presupuesto, productos de Lista de la compra, Tareas, Documentación oficial, Seguimientos, navegación, orden de Portada, carruseles, transportes/alojamiento, supermercados, secciones de Datos viaje y gestores de archivos.
- En **Maletas**, los elementos pueden arrastrarse a cualquier posición y también **cambiar de bloque** dentro de la misma maleta.
- El arrastre funciona con ratón y mediante Pointer Events en tablet/móvil; al arrastrar cerca del borde superior o inferior se ayuda al desplazamiento de listas largas.
- No se modifica ningún Worker.


## v2.2.116 · Alojamiento unificado

- Los accesos **Web, Cómo llegar, Google, Tripadvisor y Booking** aparecen juntos a la derecha de las fechas en escritorio, con adaptación automática en tablet y móvil.
- Los desplegables de **Plano / Instrucciones** quedan inmediatamente debajo. Cerrados respetan la fotografía situada a la derecha; al abrir uno, su visor se extiende a todo el ancho de la ficha y queda visualmente por encima de la zona de imagen.
- Solo puede mantenerse **un desplegable abierto a la vez** para evitar una ficha excesivamente larga.
- **📍 UBICACIÓN · SATÉLITE** pasa a formar parte de la propia ficha Alojamiento, debajo de los desplegables. Deja de existir como tarjeta independiente de la Portada.
- Se conserva la opción de mover cada carrusel entre **Portada** y **Alojamiento** desde Configuración.
- No se modifica ningún Worker.

## v2.2.107 · Tripadvisor España

- El botón de **Tripadvisor** del alojamiento migra automáticamente los enlaces antiguos `tripadvisor.com` a **`tripadvisor.es`**.
- El enlace predeterminado del Resort Cordial Santa Águeda usa la ficha española indicada para el hotel.
- En Android se mantiene el intento de apertura de la app de Tripadvisor; la URL web de respaldo queda en español.

## v2.2.107 · Plano e instrucciones dentro de Alojamiento

- Cada carrusel de imágenes/PDF puede estar **fuera en la Portada** o **dentro de la ficha Alojamiento**.
- Dentro de Alojamiento se muestra como un **desplegable cerrado**, conservando imágenes, PDF, navegación y selección de página.
- Los carruseles existentes cuyo título contiene **Plano** o **Instrucciones** pasan inicialmente a Alojamiento; desde Configuración se pueden devolver a Portada en cualquier momento.
- Configuración → Contenido muestra un selector **Portada / 🏨** por carrusel. El ancho ½ / 1/1 sigue aplicándose únicamente cuando el carrusel está fuera en Portada.
- El estado abierto del desplegable se conserva al avanzar o retroceder dentro del carrusel durante la sesión.

## v2.2.106 · Reparación y verificación del Worker principal

El estado vigente de Cloudflare pasa a Worker principal **2.2.25** y Worker Vueling **1.0.21**. La v2.2.155 no modifica ningún Worker.

## v2.2.103 · Centro de integraciones con clics blindados
- Los botones **Comprobar** y **Actualizar estados** usan delegación global de clics, por lo que siguen funcionando aunque el panel de Configuración se vuelva a renderizar.
- Cada comprobación muestra feedback inmediato **Comprobando…** en el propio botón y un aviso de estado.
- Cloudflare/GitHub incorporan timeout de 8 segundos para evitar botones aparentemente bloqueados cuando el Worker no responde.
- No modifica ningún Worker.

## v2.2.102 · Estado de Drive más claro y selector más rápido
- El Centro de integraciones distingue explícitamente **Persistente · cuenta**, **Temporal · cuenta** y **Listo para conexión persistente**.
- Si el Client Secret está disponible pero la sesión actual es temporal, aparece **Activar persistencia** en lugar de dar la conexión por permanente.
- El token temporal de Drive se conserva en `sessionStorage` durante la pestaña, por lo que los selectores vuelven a abrir mucho más rápido tras refrescar.
- Las comprobaciones de estado/token persistente se limitan a 4 segundos para no retrasar el navegador de Drive si Cloudflare no responde.
- No modifica ningún Worker.

## v2.2.102 · Selector de cuenta de Google Drive inmediato
- Corrige el botón **Cambiar cuenta / acceso** del navegador de Drive, que podía quedarse indefinidamente en «Abriendo…» en Firefox.
- Google OAuth se inicia como primera operación del clic, sin esperar antes al Worker ni a otras consultas asíncronas, evitando el bloqueo de popups tardíos.
- Google Identity se precarga en segundo plano al abrir el navegador de Drive; el botón muestra **Preparando acceso…** hasta que está realmente listo.
- El cambio de cuenta utiliza un token temporal directo para navegar inmediatamente; la sesión persistente continúa siendo independiente y opcional.
- No modifica ningún Worker.


## v2.2.102 · Formato monetario español uniforme
- Todos los importes visibles fuerzan el formato español con separador de millares incluso en cantidades de cuatro cifras: `1.647,88 €`, `10.000,00 €`, etc.
- Los importes monetarios muestran siempre dos decimales y mantienen el símbolo de euro con el espaciado español.
- Portada, Presupuesto, tablas, PDFs, Lista de la compra, Extras y Seguimientos comparten el mismo formateador monetario.
- Los precios de combustible y distancias visibles pasan también a coma decimal española.
- No modifica ningún Worker.


## v2.2.98 · KPIs de Presupuesto unificados con Portada
- Presupuesto usa el mismo orden que Portada: Presupuesto total, Total por persona, Pagado y Por pagar.
- Las cuatro tarjetas comparten el mismo estilo visual; Pagado y Por pagar incluyen los donuts con porcentaje real.
- Las dos primeras tarjetas quedan centradas verticalmente igual que en Portada.
- Se eliminan los importes secundarios por persona de Pagado/Por pagar para mantener equivalencia visual con Portada.


## v2.2.98 · Alineación vertical de KPIs en Portada
- Las tarjetas **Presupuesto total** y **Total por persona** centran verticalmente su contenido para quedar alineadas con **Pagado** y **Por pagar**.
- No cambia el tamaño de las tarjetas ni los gráficos circulares.
- No se modifica ningún Worker.

## Distribución de Portada en escritorio · v2.2.48

- Nuevo botón **Editar distribución** en Portada para administradores/usuarios con permiso de edición.
- En ordenadores (≥ 1100 px) cada bloque puede configurarse como **ancho completo** o **media fila**, permitiendo colocar dos bloques por fila.
- Los bloques se pueden **reordenar arrastrando y soltando** mientras el modo de distribución está activo.
- La distribución de escritorio se guarda en Firebase de forma independiente; **tablet y móvil conservan la disposición actual** y el orden normal de Portada.
- Incluye **Restaurar escritorio** para volver al orden normal y todos los bloques a ancho completo.
- Los bloques complejos (vuelos, alojamiento, cuenta atrás, documentos) adaptan internamente su maquetación cuando se usan a media fila para evitar contenido demasiado estrecho.

## Menú sincronizado con el viaje · v2.2.48

- Los días de la pestaña **Menú** se generan automáticamente con todas las fechas comprendidas entre el inicio y el fin configurados en **Datos del viaje** (ambos inclusive).
- Si cambian las fechas del viaje, el Menú se reajusta conservando los platos y notas de las fechas que sigan coincidiendo.
- Cada día permite ocultar de forma independiente **Desayuno**, **Comida** y **Cena**. Una comida oculta desaparece tanto de la pestaña Menú como del PDF.
- Los días ya no se añaden o eliminan manualmente: la fuente de verdad son las fechas generales del viaje.

## Cambios

- **Nuevo Histórico de precios de Lista de la compra**, accesible desde la propia Lista sin crear una pestaña nueva en el menú principal.
- Guarda hasta **180 comprobaciones** compactas y hasta **1.000 cambios de precio**, con evolución del total combinado, total por supermercado y precio unitario por producto.
- La página histórica mantiene **logos de supermercados y fotos de productos**, añade filtros por supermercado, producto y periodo, gráficos por supermercado y producto, y un registro cronológico de cambios.
- Después de cada actualización se muestran claramente los productos que han cambiado, con **precio anterior, precio nuevo, diferencia en euros y porcentaje**.
- Frecuencia configurable: **una vez al día**, **cada 2 días** o **solo manual**. La comprobación automática se ejecuta cuando la app está abierta; si estaba cerrada, la revisión pendiente se lanza en la siguiente apertura.
- El PDF A6 de la Lista de la compra fuerza que **cada supermercado empiece en una página nueva**; si un supermercado necesita varias páginas, puede continuar en las siguientes.
- Los iconos de los títulos de **AutoReisen, Cordial, Vueling y Gasolineras** ya se pueden personalizar con emoji, **imagen de Google Drive** o **archivo local**, y restaurar al icono predeterminado.
- El gráfico de Vueling diferencia mejor series casi superpuestas (por ejemplo Vuelta 151,98 € y Maleta 152,00 €) mediante trazo, marcador y etiqueta final distintos, sin modificar los valores reales.
- Se mantienen la comparación automática con Presupuesto y la sincronización de datos generales del viaje.
- Estado actual: Worker principal **2.2.25** y Worker Vueling **1.0.21**.


### Novedades v2.2.48

- PDF de Presupuesto: eliminado el subtítulo “Financial travel brief” y el resumen de vuelos; maquetación compacta en dos columnas para concentrar el presupuesto completo en una sola hoja A4 cuando los datos actuales lo permiten.
- PDF de Menú: eliminado “Taste plan · Gran Canaria”, conservando el encabezado editorial.
- PDF de Maletas: nuevo encabezado editorial amarillo con detalles azul marino, invirtiendo la combinación cromática del Menú.
- PDF de Lista de la compra: encabezado modernizado con el mismo lenguaje visual azul/amarillo del Menú.


- **Presupuesto → Exportar PDF**: documento A4 vertical tipo dashboard, compacto en una sola hoja con los datos actuales, resumen de total/pagado/pendiente/por persona, distribución por categorías y desglose completo por grupos.
- **Menú → Exportar PDF**: documento **A4 horizontal** diseñado para ocupar todo el folio, con todos los días distribuidos en tarjetas editoriales y desayuno/comida/cena claramente diferenciados.
- Ambos PDF reutilizan los datos actuales del viaje y mantienen Livvic mediante Google Fonts.
- Estado actual: Worker principal **2.2.25** y Worker Vueling **1.0.21**.

## Despliegue

La **v2.2.155 no modifica ningún Worker**. `ACTUALIZAR_MFE.bat` validará la versión y publicará únicamente Firebase Hosting.

Tras el despliegue, el Worker principal debe responder **2.2.25**, el Worker de Vueling **1.0.21** y el footer debe mostrar **MFE Viajes · v2.2.155**.

## v2.2.98 · Gráficos circulares de presupuesto en Portada
- Las tarjetas **Pagado** y **Por pagar** de Portada incorporan gráficos circulares tipo donut calculados con las proporciones reales respecto al presupuesto total.
- **Pagado** usa un degradado verde/turquesa y **Por pagar** un degradado coral/rosa, manteniendo el importe principal como protagonista.
- El porcentaje aparece dentro del gráfico y se actualiza automáticamente al cambiar el presupuesto.
- Se mantiene el comportamiento responsive para escritorio, tablet y móvil.
- No cambia ningún Worker.

## v2.2.98 · Confirmación fiable del selector de Google Drive
- El botón **Seleccionar** del navegador interno de Drive reutiliza el mismo access token con el que ya se ha navegado y listado los archivos, evitando una segunda renovación OAuth al confirmar.
- La selección de PNG/PDF deja de quedar bloqueada si la comprobación persistente del Worker falla después de haber abierto correctamente Drive.
- Si el token de navegación hubiera caducado, el selector permanece abierto y pide renovar explícitamente desde **Cambiar cuenta / acceso**, sin lanzar popups tardíos.
- El cambio es global para todos los selectores de Drive de la app.
- No cambia ningún Worker.

## v2.2.93 · Selector de Google Drive global resistente
- Corrige una regresión global por la que los botones de **Google Drive** podían parecer inactivos si la comprobación de sesión persistente del Worker quedaba esperando respuesta.
- El navegador de Drive se abre **inmediatamente al pulsar cualquier botón**, mientras el estado de la sesión se comprueba en paralelo.
- Todas las llamadas autenticadas al Worker de integraciones incorporan ahora un **timeout controlado**, evitando esperas indefinidas.
- Si Drive necesita renovar permisos de navegación, la app ya no intenta abrir un segundo popup OAuth automáticamente: mantiene el navegador abierto y muestra **Cambiar cuenta / acceso**, que se ejecuta mediante un clic real del usuario y no puede ser bloqueado como popup tardío.
- Los errores de Drive se muestran dentro del propio navegador de archivos, con opción visible para reconectar la cuenta.
- La corrección es global: afecta a iconos, PDF, Documentos oficiales, carruseles, tickets, imágenes y cualquier otro selector de Drive de la app.
- No requiere actualizar Workers.

## v2.2.92 · Cordial resistente al nuevo panel de cookies
- El diagnóstico real del 29/08 mostró que Cordial fallaba porque el iframe `/cookies/manager` quedaba bloqueando la página sin exponer a tiempo un botón de aceptación.
- La automatización Cordial pasa a **2.2.09**: espera explícitamente el iframe, amplía los selectores de consentimiento y añade un cierre de respaldo mediante las APIs de cookies/Magnific Popup del propio sitio.
- Si aun así la capa permanece, retira únicamente el overlay bloqueante del DOM para permitir usar el formulario ya cargado.
- Worker principal **2.2.19**; Vueling continúa en **1.0.20**.
- Mantiene el respaldo automático diario de seguimientos añadido en 2.2.18.

## v2.2.90 · Cloudflare sin `whoami` ni `auth token`
- El actualizador crea un perfil OAuth aislado en `%LOCALAPPDATA%\MFE_Viajes\cloudflare-auth`, eliminando interferencias con sesiones/credenciales antiguas de Wrangler.
- Se fija **Wrangler 4.119.0** y se ejecuta una sola vez para `login --device --no-use-keyring`; después no vuelve a invocarse Wrangler.
- El token `oauth_token` se lee directamente del `default.toml` generado por el login y se usa contra la API oficial de Cloudflare.
- Si Windows muestra el `Assertion failed ... UV_HANDLE_CLOSING` al terminar Wrangler pero el token ya quedó escrito, el proceso puede continuar de forma segura.
- Antes de publicar se comprueba que existe `MFE_TRACKERS`; después se verifican de nuevo bindings, Worker **2.2.19**, `monitorFallback` y la respuesta real del endpoint.
- `ACTUALIZAR_MFE.bat` continúa siendo el único archivo que debe ejecutarse.

## v2.2.89 · Login Cloudflare automático y actualización verificada en Windows
- Corrige el error «Not logged in» observado al ejecutar la actualización en un equipo sin una sesión activa de Wrangler.
- `ACTUALIZAR_WORKERS.bat` comprueba `wrangler whoami`; si no hay sesión, lanza automáticamente `wrangler login --device --no-use-keyring`, espera la autorización y vuelve a verificar la sesión. Si el flujo por dispositivo falla, intenta el OAuth normal como respaldo.
- El script PowerShell captura stdout y stderr de Wrangler con `Start-Process`, evitando que Windows PowerShell 5 convierta mensajes de un programa nativo en `NativeCommandError` al usar `ErrorActionPreference=Stop`.
- El despliegue conserva en modo estricto KV, secretos y variables del Worker actual, instala los Cron Triggers mediante la API oficial y verifica por HTTP la versión **2.2.19**, `monitorFallback` y `MFE_TRACKERS` antes de permitir Firebase.
- `ACTUALIZAR_MFE.bat` sigue siendo el único archivo que hay que ejecutar.

## v2.2.87 · Respaldo automático de Seguimientos
- Se mantienen los horarios normales de GitHub Actions: **AutoReisen 06:30**, **Cordial 06:35** y **Vueling 06:40**, en `Europe/Madrid`.
- El Worker principal **2.2.19** añade una segunda capa de seguridad: después de las **07:15 (Europe/Madrid)** comprueba en GitHub si existe alguna ejecución del día para cada uno de los tres workflows.
- Si falta un seguimiento, Cloudflare lanza únicamente ese workflow mediante `workflow_dispatch`; si ya existe una ejecución manual o programada, no crea otra.
- El control guarda el resultado diario en `MFE_TRACKERS` para evitar duplicados y permite un segundo intento si hubo un error parcial.
- La pestaña Seguimientos muestra el estado del respaldo y distingue cuándo Cloudflare tuvo que lanzar una ejecución ausente. Si la app se abre después de las 07:15 y la comprobación diaria aún no existe o quedó incompleta, un administrador autenticado fuerza también esa misma verificación como respaldo adicional.
- Los Cron Triggers de Cloudflare se publican a **05:20 UTC y 06:20 UTC**; el Worker aplica la hora local de Madrid y solo actúa a partir de las 07:15, cubriendo automáticamente CEST/CET.
- Se incluye **`ACTUALIZAR_WORKERS.bat`**, que actualiza solo `mfe-viajes-precios`, conserva variables/secrets remotos y usa el endpoint oficial `/content` de Cloudflare para sustituir únicamente el código y no tocar la configuración del Worker.
- Worker principal: **2.2.18**. Worker Vueling: **1.0.20** (sin cambios).

## Ajustes visuales del histórico de compra

- Corregido el padding interno de las tarjetas del Histórico de precios para que las esquinas redondeadas no invadan títulos ni textos, especialmente en móvil.
- Más espacio interior en las tarjetas del histórico para que las esquinas y el borde de color no invadan logo, título ni texto.
- Eliminada la cifra inferior duplicada en euros de los gráficos; se conserva el valor superior y las fechas.



## v2.2.83 · Textos personalizados del autobús persistentes
- Corrige la pérdida de los campos **Presupuesto · texto del concepto** y **Presupuesto · texto del detalle** después de refrescar o volver a cargar datos desde Firebase.
- La normalización del bloque Autobús conserva ahora `budgetTitle` y `budgetDetail`, de modo que un texto editado manualmente tiene prioridad sobre el texto automático.
- Se añade validación de regresión para impedir que estos campos vuelvan a eliminarse en futuras migraciones.
- No requiere actualizar Workers.

## v2.2.82 · Columnas de Presupuesto alineadas
- Se compactan **Horario / Duración / Vuelo** en el bloque Vueling para que **Importe** y **Estado** queden alineados con las demás tablas.
- Los datos de horario, duración y número de vuelo usan una tipografía ligeramente menor y más compacta.
- Los encabezados **IMPORTE** y **ESTADO** comparten exactamente el mismo tamaño y peso tipográfico en las tablas de Presupuesto.
- No requiere cambios en Workers.

## v2.2.82 · Vuelos integrados en filas y progreso de pago
- En **Presupuesto → Vuelo**, las filas de ida y vuelta incorporan directamente las columnas **Horario**, **Duración** y **Vuelo**; la fila de equipaje deja esas columnas vacías.
- Se elimina el bloque redundante **Datos de los vuelos** que aparecía debajo de la tabla de Vueling.
- Los encabezados **Importe** y **Estado** usan exactamente el mismo tamaño tipográfico en todas las tablas de Presupuesto.
- Debajo de los cuatro indicadores principales se añade una línea de **Progreso de pago**: el total del presupuesto es la referencia completa y el tramo ya pagado aparece relleno, con porcentaje e importes.
- No se modifican Workers.

## v2.2.79 · Botones uniformes y miniatura PDF global
- En las fichas de autobús, **Comprar billetes** y los botones de Google Maps comparten exactamente la misma altura y alineación.
- En Alojamiento, **Google, Tripadvisor y Booking** usan la misma altura de botón para que la fila quede uniforme.
- En **Reservas y documentos**, los botones de archivos y enlaces se muestran **uno por línea** dentro de cada tarjeta.
- Se incorpora el nuevo icono PDF proporcionado por el usuario como miniatura/icono visual para archivos PDF en toda la app (documentos oficiales, enlaces de archivos, navegador de Drive y carruseles PDF).
- No se modifican Workers.

## v2.2.48 · Gráficos de Seguimientos y diagnóstico GitHub
- Ejes horizontales más compactos en AutoReisen, Cordial y Vueling.
- Se eliminan las cifras laterales del eje Y: el importe exacto aparece al pasar el ratón o tocar cada punto.
- Tooltips interactivos por punto con serie, fecha/hora e importe.
- Vueling usa líneas simples y uniformes, sin trazos discontinuos ni etiquetas superpuestas.
- El Worker 2.2.15 traduce `Bad credentials` de GitHub a un diagnóstico claro del secreto `GITHUB_TOKEN`. La automatización AutoReisen sigue en 2.2.14; no cambia su flujo de navegador.


## v2.2.52 · horario unificado de Seguimientos
- AutoReisen se programa a **06:30**, Cordial a **06:35** y Vueling a **06:40**, siempre en **Europe/Madrid**.
- La app migra automáticamente los horarios anteriores: AutoReisen → 06:30, Cordial → 06:35 y Vueling → 06:40.
- Los workflows mantienen `timezone: Europe/Madrid` para respetar CET/CEST.

- Para aquella actualización de horario se utilizó Worker principal **2.2.17** y Worker Vueling **1.0.20**; la versión actual v2.2.90 sustituye el Worker principal por **2.2.18**.


## v2.2.52 · carruseles de Portada
- El orden configurado en Carruseles de imágenes y PDF se replica en la Portada de escritorio.
- Cada carrusel permite elegir directamente desde Configuración entre media fila (½) o fila completa (1/1) en ordenador.
- La cuadrícula recoloca automáticamente los carruseles por filas; tablet y móvil siguen en una sola columna.


## v2.2.53 · correcciones de Configuración y actualización con doble clic
- Corregido el botón **Añadir varias desde Drive** de Imágenes adicionales para que renderice el icono de Google Drive en lugar del texto literal `${driveIconMarkup()}`.
- Añadida una validación de regresión para detectar interpolaciones `${...}` mal introducidas dentro de fragmentos HTML entre comillas simples.
- Nuevo **ACTUALIZAR_MFE.bat** en la raíz del ZIP. Valida la versión y despliega Firebase Hosting con doble clic.
- Si una versión futura incluye **ACTUALIZAR_WORKERS.bat**, `ACTUALIZAR_MFE.bat` lo detectará y ejecutará antes de Firebase, de modo que el mismo archivo pueda centralizar toda la actualización.
- Si Firebase CLI no está instalado globalmente, intenta usar `npx firebase-tools` como alternativa.




## v2.2.78 · Autobús: adjuntos solo en documentos y Presupuesto sin compra
- La tarjeta principal del autobús en Portada ya no muestra los PDF/adjuntos; estos quedan centralizados en **Reservas y documentos** y en el gestor del trayecto.
- El bloque automático **Autobús aeropuerto** de Presupuesto mantiene los PDF asociados, pero deja de mostrar el botón/enlace **Comprar billetes**.
- El enlace de compra continúa disponible en la tarjeta del autobús de Portada y en la configuración del trayecto.
- No requiere cambios en Workers.

## v2.2.71 · Ficha y Presupuesto de autobús depurados
- La ficha **Autobús** de Reservas y documentos muestra solo los billetes/archivos reales de los trayectos y elimina pseudoarchivos antiguos como el botón «Autobús».
- El icono de la ficha documental y del encabezado automático de Presupuesto se toma siempre del **icono actual del trayecto**, evitando que quede una versión antigua en caché/configuración.
- Se amplía y protege la columna de acciones de **Presupuesto → Autobús aeropuerto** para que 📎, editar y sincronización no queden recortados por el borde.
- No requiere actualización de Workers.

## v2.2.71 · Billetes de autobús enlazados a Drive
- Se elimina de la tarjeta de Portada el texto fijo **«Autobús al aeropuerto antes del vuelo de ida.»**.
- Los PDF de billetes del autobús seleccionados desde Google Drive se guardan ahora como **enlaces persistentes por `driveFileId`**, sin intentar copiarlos a Firebase Storage.
- La selección múltiple de PDF se **guarda automáticamente** en el trayecto en cuanto se confirma en Drive y el gestor permanece abierto para seguir añadiendo, ordenar o renombrar archivos.
- El guardado usa el **ID estable del trayecto** en lugar de depender solo de su posición en la lista, evitando pérdidas si se reordenan los transportes.
- No cambia ningún Worker.

## v2.2.67 · Autobús ida/vuelta emparejado con vuelos
- La Portada deja de ordenar bus y vuelo solo por fecha: **IDA = autobús → vuelo** y **VUELTA = vuelo → autobús**.
- Si están visibles ambos autobuses, en escritorio se muestran en dos filas: **bus ida + vuelo ida** y **vuelo vuelta + bus vuelta**.
- Si solo hay un autobús visible, ese autobús ocupa fila completa y los dos vuelos permanecen juntos en su propia fila; el bus de vuelta queda después de los vuelos.
- Los autobuses de la misma compañía pueden reutilizar el icono/logo de Drive del otro trayecto cuando uno de ellos no tenga imagen propia, evitando que la vuelta vuelva al emoji por defecto.
- El mismo icono heredado se utiliza también en Presupuesto y en Datos del viaje.
- No requiere actualización de Workers.

## v2.2.66 · Autobuses, iconos Drive y rutas compactas
- Corrige el marcador **AUTO** del Presupuesto: ya no se parte verticalmente y se sustituye por un icono de sincronización **↻** más compacto.
- El botón de cambiar icono usa ahora **🖼️**, más intuitivo que el símbolo cuadrado anterior.
- Los iconos y logos enlazados mediante URLs privadas de Google Drive (incluido `open?id=...`) se cargan con la sesión persistente de Drive y muestran un emoji de respaldo si el archivo no puede abrirse.
- El icono personalizado del autobús se reutiliza en Portada, Presupuesto y Datos del viaje cuando corresponde.
- **Comprar billetes** pasa a la zona inferior de acciones, inmediatamente antes de **Cómo llegar a salida**, eliminando el solapamiento con el destino.
- En autobuses y vuelos, origen, flecha y destino quedan más centrados y próximos entre sí.
- No requiere cambios en Workers.

## v2.2.64 · Billetes de autobús, iconos Drive y cuatro reservas por fila
- En **Presupuesto → Autobús aeropuerto**, cada trayecto incorpora un botón 📎 para gestionar **varios billetes PDF/archivos**, incluyendo selección múltiple desde Google Drive. Los archivos siguen sincronizados con el mismo trayecto de Datos del viaje y aparecen como botones en el detalle.
- En la tarjeta de autobús de **Portada**, el icono personalizado (incluida imagen PNG de Google Drive) se muestra **antes de IDA/VUELTA**. Se prioriza el icono personalizado sobre el logo de compañía cuando ambos existen.
- Se corrige el reparto de ancho del autobús para que **Comprar billetes no se solape con el destino**; en anchuras intermedias el botón pasa a una línea segura sin invadir la ruta.
- Las imágenes elegidas desde Google Drive en los selectores de Configuración se **importan a una URL estable** en lugar de conservar una miniatura privada de Drive. Esto corrige iconos PNG seleccionados correctamente pero que después no se aplicaban o dejaban de mostrarse.
- Las fichas de **Reservas y documentos** de Portada usan **cuatro columnas en una sola fila en escritorio**, con tarjetas y botones ligeramente más compactos. Tablet mantiene dos columnas y móvil una.
- No es necesario actualizar Workers.

## v2.2.63 · Transportes compactos y orden configurable
- En la Portada, el autobús del aeropuerto pasa a una **franja compacta de ancho completo**; los vuelos de ida y vuelta quedan juntos en la fila siguiente en escritorio.
- En Presupuesto, **Autobús aeropuerto** aparece antes de Vuelos y todos los bloques del presupuesto se pueden mover con ↑/↓. El orden elegido queda guardado.
- En **Configuración → Datos viaje** se puede cambiar el orden de las secciones principales y también ordenar individualmente vuelos, autobuses y alojamiento con ↑/↓.
- Se mantiene toda la configuración del autobús añadida en v2.2.62, incluidos archivos, enlaces, visibilidad, colores, iconos y sincronización con Presupuesto.
- No es necesario actualizar Workers.

## v2.2.62 · Autobús al aeropuerto
- Nuevo modelo de **Autobuses** integrado con los vuelos en la Portada y ordenado cronológicamente por hora de salida.
- Configuración completa en **Datos del viaje → Vuelos, autobuses y alojamiento**: compañía, línea/servicio, origen, destino, fecha, horarios, duración, pasajeros, precio por persona, estado de pago, referencia, notas, Maps, compra de billetes, iconos, logo, colores y degradados.
- Cada trayecto se puede **mostrar u ocultar individualmente**. Los trayectos ocultos tampoco computan en Presupuesto.
- Archivos, billetes y enlaces gestionables con el mismo selector múltiple de Google Drive/archivos usado en el resto de la app.
- Nuevo grupo automático **Autobús aeropuerto** en Presupuesto, sincronizado con los datos del trayecto y con estado pagado/no pagado editable.
- GC 2026 queda precargado con la ida **Donostia / San Sebastián → Aeropuerto de Bilbao**, 14/09/2026 04:00–05:15, 2 pasajeros, 4,16 € por persona y compra en Avanza/PESA. La vuelta queda creada pero oculta.
- No es necesario actualizar Workers.

## v2.2.61 · Botón flotante menos invasivo
- El botón flotante de **Guardar cambios** en Configuración permanece visible, pero ahora se muestra **traslúcido** mientras no hay cambios pendientes.
- Al pasar el ratón por encima (o al enfocarlo), el control se vuelve completamente opaco para facilitar la interacción.
- Cuando se modifica cualquier ajuste, el botón recupera opacidad completa y muestra un estado visual más claro.
- El texto auxiliar se ha movido **encima del botón**, en formato mucho más pequeño y discreto, para reducir la sensación invasiva en escritorio.
- Se mantiene el botón de guardado del final de Configuración y no es necesario actualizar Workers.

## v2.2.56 · Corrección del guardado flotante
- El botón flotante **Guardar cambios** permanece visible desde que se entra en Configuración con edición desbloqueada, incluso antes de modificar un campo.
- El aviso cambia entre **Configuración lista para guardar** y **Cambios sin guardar** según el estado del formulario.
- Se eleva su capa visual para evitar que tarjetas, menús o paneles puedan taparlo; en móvil continúa por encima de la navegación inferior y respeta el área segura.
- No se modifican los Workers de AutoReisen/Cordial ni Vueling.

## v2.2.55 · Configuración simplificada y guardado flotante
- El botón flotante **Guardar cambios** usa seguimiento delegado de formularios y permanece a la altura visible del usuario en escritorio; en móvil/tablet queda por encima de la navegación inferior.
- **Navegación · orden, visibilidad e iconos** concentra en una sola lista el orden de las pestañas, el ojo para mostrar/ocultar y la carga de un icono personalizado. Se eliminan los bloques independientes «Pestañas visibles» e «Iconos de las pestañas».
- **Orden y visibilidad de tarjetas de la Portada** añade un ojo en cada fila para ocultar o restaurar Cuenta atrás, Tiempo, Vuelos, Alojamiento, Presupuesto, Mapa, Reservas/documentos, Carruseles e Imágenes adicionales.
- La Cuenta atrás incorpora **Mostrar segundos**, desactivado por defecto para conservar el aspecto actual; al activarlo se actualiza cada segundo.
- Las imágenes elegidas desde Google Drive también activan inmediatamente el aviso de cambios pendientes.


## v2.2.61 · Persistencia de anchos en Portada
- Corregida la regresión por la que un carrusel/galería configurado como **1/1** podía volver a **½** después de refrescar la app.
- Los anchos específicos `mediaCarousel:<id>` guardados como `full` o `half` tienen ahora prioridad absoluta sobre el antiguo ajuste global `mediaCarousels`.
- La corrección se aplica tanto al editor **Distribución de Portada** como a los controles de ancho disponibles en **Configuración**.
- Los valores ya guardados como 1/1 en Firestore se recuperan correctamente al desplegar esta versión; no hace falta volver a configurarlos si el valor persistido ya era `full`.
- No es necesario actualizar Workers.



## v2.2.71 · Billetes Drive y actualización PWA reforzada
- El gestor de billetes del autobús muestra los PDF seleccionados **inmediatamente** al volver del navegador de Drive y los persiste después, evitando regresar a una lista vacía durante el guardado.
- Los billetes de Drive se guardan como enlaces persistentes mediante `driveFileId`, sin importar/copiar el PDF a Firebase Storage.
- El gestor del autobús muestra la indicación **Drive directo** para poder comprobar visualmente que está cargada la versión nueva del código.
- Se refuerza la actualización de la PWA: Service Worker versionado, `updateViaCache: none`, actualización explícita y recarga al cambiar el controlador.
- `index.html` se sirve con `no-store` para reducir el riesgo de mantener una interfaz anterior tras desplegar una versión nueva.
- No requiere actualización de Workers.


## v2.2.71 · Billetes de autobús sincronizados con Reservas y documentos
- La ficha de **Autobús** en Reservas y documentos reutiliza automáticamente los PDF/billetes guardados en los trayectos de autobús.
- Los archivos añadidos desde Presupuesto o desde la tarjeta del trayecto aparecen también en la ficha documental sin subirlos por duplicado.
- El clip de la ficha Autobús abre directamente el gestor del trayecto visible; si hay ida y vuelta visibles permite elegir cuál gestionar.
- Se mantiene un único origen de datos (`cover.buses[].files`) para evitar desincronizaciones.


## v2.2.78 · Categorías de transporte y borde superior de alojamiento
- La tarjeta de **Alojamiento** incorpora un borde superior de color, siguiendo el lenguaje visual de vuelos y autobuses.
- Las tarjetas de **Vuelo** muestran una etiqueta discreta «VUELO» sobre IDA/VUELTA.
- Las tarjetas de **Autobús** muestran una etiqueta discreta «AUTOBÚS» sobre IDA/VUELTA.
- Las etiquetas usan el mismo estilo tipográfico de la categoría «ALOJAMIENTO» para unificar la Portada.
- Sin cambios en Workers.



## v2.2.82 · Presupuesto y PDF unificados
- Los textos automáticos del autobús en Presupuesto pueden personalizarse desde el lápiz del trayecto mediante «Presupuesto · texto del concepto» y «Presupuesto · texto del detalle».
- Los conceptos manuales de Presupuesto ya no muestran un botón separado para cambiar icono: emoji, URL e imagen se editan desde el mismo lápiz.
- Los Extras eliminan la etiqueta genérica «Extra» del detalle y el acceso pasa a llamarse simplemente «Ver».
- Todos los botones que abren o generan PDF usan el icono PDF gráfico estándar de la app, incluidos Presupuesto, Maletas, Lista de la compra, tickets y Menú.
- El antiguo bloque independiente «Resumen de vuelos» se elimina y sus datos se integran de forma compacta dentro del bloque «Vuelo Vueling».
- No requiere cambios en Workers.


## v2.2.88 · Corrección anterior del actualizador de Cloudflare
- Primera corrección del despliegue del Worker principal **2.2.19** en Windows después de separar la publicación del código y los Cron Triggers.
- Esta versión histórica todavía dependía de una sesión Wrangler preexistente; la v2.2.90 sustituye ese requisito por login automático y endurece la captura de errores de PowerShell.
- El Worker Vueling permanece en **1.0.20**.


## v2.2.98 · Google Drive con modo de respaldo temporal
- Google Drive deja de depender obligatoriamente del `GOOGLE_DRIVE_CLIENT_SECRET` para funcionar durante la sesión actual.
- Si la sesión persistente del Worker no está disponible, «Cambiar cuenta / acceso» usa OAuth directo del navegador con permisos de navegación y mantiene Drive operativo.
- El navegador de Drive ya no abre popups OAuth automáticamente durante una carga de carpeta; si necesita autorización lo indica y espera un clic explícito.
- Las peticiones de listado de Drive tienen timeout de 15 segundos y ya no pueden quedarse indefinidamente en «Cargando Google Drive…».
- Se mantiene la sesión persistente como vía preferida cuando Cloudflare detecta correctamente el secreto.


- Corregido `ACTUALIZAR_WORKERS.bat`: ahora publica mediante **Workers Script Content API** (`/content`), que reemplaza solo el código del Worker sin reconstruir configuración/bindings.
- El actualizador captura y muestra el cuerpo real de error de Cloudflare si una publicación devuelve HTTP 4xx/5xx.
- Antes y después de cada publicación compara nombres/tipos de bindings para verificar que KV, variables y secrets siguen intactos.
