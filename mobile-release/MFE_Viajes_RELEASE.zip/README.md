# MFE Viajes GC27 v2.4.62 · Foto y mapa a media anchura en ambos alojamientos

Actualización sobre la versión v2.4.61. Publica únicamente Firebase Hosting (compatible con Spark); no publica Functions, Firestore, Cloudflare ni monitores.

## Alojamiento

- En ordenadores (ancho >= 900 px), Cordial Santa Águeda y Dunas Club muestran fotografía a la izquierda y mapa a la derecha, cada uno ocupando el 50 % del espacio disponible, salvo el pequeño espacio de separación.
- Ambas parejas usan el mismo alto total (390 px), con el mapa ajustado bajo su encabezado, sin deformar fotografías.
- En tablet y móvil (ancho < 900 px) los dos bloques se apilan a una columna; alto de 310 px o 280 px en pantallas muy estrechas.
- Se conservan los planos/PDF en la estancia Cordial y las reservas, controles y fichas ordenables de v2.4.61.
- La disposición de Portada permanece igual.

## Instalación desde Windows

1. Extraer ZIP en una carpeta nueva.
2. Ejecutar `ACTUALIZAR_MFE.bat`; se mantiene abierta la ventana de resultados.
3. Se comprueba la versión publicada 2.4.62 después de publicar solo Firebase Hosting.

No requiere el plan Blaze.

---

# MFE Viajes GC27 v2.4.61 · Mapa y PDF dentro de Cordial, documentos Dunas y piscinas arrastrables

## Novedades
- Portada → Seguimientos: resalta **solo el coche preferido** en cada AutoReisen y **solo Beach Club House / Reserva Online / Solo alojamiento** en Cordial, al estilo de Dunas. Si no hay un precio verificable de la opción seleccionada, no se resalta otra por error.
- Presupuesto: añade **Binter · vuelo interislas** y **Parking · epark Bilbao** como bloques independientes a los viajes ya creados sin borrar otros bloques, y también en viajes nuevos.
- epark se muestra **solo** en su bloque (ya no dentro de Autobús), con importe y estado de pago tomados de la reserva en Datos del viaje.
- Binter recoge automáticamente el importe **reservado** para el total de pasajeros si lo tienes configurado; no suma automáticamente ofertas del monitor. Puedes añadir conceptos manuales, archivos y precios de la reserva.
- Presupuesto mantiene **＋ Añadir bloque** con grupos editables, eliminables y reordenables para otros gastos.

## Instalación gratis (Firebase Spark)
1. Descomprime el ZIP en Windows.
2. Ejecuta `ACTUALIZAR_MFE.bat`.
3. Valida y despliega **solo Firebase Hosting** del sitio viajes. No ejecuta Firebase Functions (requiere Blaze), Firestore Rules ni Cloudflare Workers.
4. Recarga la app; confirma v2.4.61. Si el móvil conserva versión antigua, prueba `recuperar-actualizacion.html`.

**Importante:** El panel de «Usuarios y permisos» creado en versiones anteriores sigue requiriendo la función `manageTravelUsers` para funcionar. En Spark no se puede publicar esa función; las cuentas se pueden administrar desde Firebase Console, como ya se explicó. Esta versión no modifica esa limitación.

No altera los monitores de Cordial, AutoReisen, Dunas ni Binter, ni los históricos del viaje. `CAMBIOS_v2_4_60.md` documenta la nueva disposición; la v2.4.59 mantiene el resto de las mejoras.

## Instalador Windows · correccion del cierre inmediato

Se ha corregido el formato de los cuatro archivos BAT a CRLF (Windows), UTF-8 sin BOM.
`ACTUALIZAR_MFE.bat` mantiene abierta la ventana en caso de error y despliega **solo Hosting**.
Si Windows cierra aun la ventana, abre PowerShell en esta carpeta y ejecuta:

```powershell
cmd /k call .\ACTUALIZAR_MFE.bat
```

El comando muestra el error real y conserva la ventana abierta.

### Instalador Windows: reparación de rutas (06/11/2026)

- Repara el error `Cannot find module D:\D:\Descargas\...\public\app.js` que aparecía en la prueba `test-users-management.mjs`.
- Añade una validación explícita de rutas nativas de Windows y mantiene los archivos BAT en formato CRLF.
- Ejecuta `ACTUALIZAR_MFE.bat` desde la carpeta descomprimida. Si aparece otro error, usa `cmd /k call .\ACTUALIZAR_MFE.bat` en PowerShell para mantener visible el mensaje.
- El despliegue sigue siendo exclusivamente Hosting en el proyecto Spark; no se publican Cloud Functions ni monitores.

## Cambios v2.4.61

En Alojamiento: mapa y PDF de Cordial integrados en Primera estancia; ficha editable de Dunas dentro de Reserva con herramientas de documento; fotos y reservar retirados de los controles superiores de Alojamiento de ambos hoteles; fichas de piscinas reordenables arrastrando ⋮⋮ directamente (se guarda el orden en Configuración). No altera automatizaciones ni el plan gratuito Spark.
