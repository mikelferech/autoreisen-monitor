# MFE Viajes GC27 · v2.4.57

**Reparación v2.4.57:** «Usuarios y permisos» muestra un error y ofrece reintento si Firebase no devuelve la lista en 30 segundos. Esto evita quedarse en «Cargando usuarios…» y facilita identificar fallos de despliegue o permisos.

**Instalación Windows:** descomprime el ZIP y ejecuta `ACTUALIZAR_MFE.bat` desde la raíz. Se verifican las versiones, se conservan los Workers existentes, se publica únicamente la nueva Cloud Function `manageTravelUsers` y después la web de Viajes.

## Nueva función · Usuarios y permisos

El administrador dispone de **Configuración → Usuarios y permisos**, desde PC o móvil, para:

- Crear usuarios con nombre, correo, contraseña inicial y rol.
- Dar acceso a una cuenta Firebase que ya existe.
- Editar los datos y el rol de Viajes sin cambiar los permisos de Hogar/Ahorro.
- Activar, desactivar, retirar acceso a Viajes, restablecer contraseña y consultar último inicio de sesión.
- Eliminar una cuenta Firebase solamente si no tiene acceso a otras aplicaciones.

Los roles son Administrador, Editor y Solo lectura. El servidor comprueba el rol de cada petición y protege al último administrador.

**IMPORTANTE:** el proyecto Firebase es compartido. El instalador no modifica las reglas de Firestore automáticamente. Para que la desactivación y los roles queden protegidos también a nivel de base de datos, debes **fusionar y publicar** las reglas indicadas en `SEGURIDAD_USUARIOS.md` tras revisar las reglas actuales del proyecto. No utilices el script de reglas sin esa revisión. Firebase Functions puede requerir plan Blaze/facturación.

## Funciones conservadas

- Invertir etapas (Gran Canaria / Fuerteventura) sin borrar reservas, vuelos ni históricos; vista previa y deshacer.
- Tarifas de Dunas adaptadas a móvil.
- Monitor de Cordial para cinco adultos, habitación Beach Club House, tarifa con cancelación gratuita; copia de lector y Worker sincronizadas.

Los vuelos contratados y las reservas externas no se modifican automáticamente.

## Comprobaciones

`node scripts/validate-release.mjs`
`node scripts/test-users-management.mjs`
`node scripts/test-users-server.mjs`
`node scripts/test-users-loading.mjs`
`node scripts/test-stage-inversion.mjs`

El ZIP incluye las herramientas de actualización de Windows y Android existentes y el código de los seguimientos.

La exportación en PDF de la lista de la compra mantiene el salto para que cada supermercado empiece en una página nueva.
