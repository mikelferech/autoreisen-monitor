# MFE Viajes GC27 · v2.4.55

**Instalación Windows:** descomprime el ZIP completo y ejecuta `ACTUALIZAR_MFE.bat` desde la carpeta. El script valida código, Workers y publica Firebase Hosting. No necesita cambiar archivos de configuración de versiones anteriores.

**Nueva función:** desbloquear edición → **Etapas** → **Invertir etapas**. Se muestra vista previa para confirmar. La app reorganiza fechas, alojamientos, alquileres, vuelos previstos, Binter, seguimientos, actividades y menús manteniendo la asociación por isla. Aparece **Deshacer inversión** hasta aplicar una nueva. Los localizadores, documentos, importes reservados y compras se conservan. Los billetes contratados requieren gestión externa, que la app no puede realizar.

**Corrección móvil:** tarjetas de tarifas de Dunas en columna única con precio alineado y visible.

**Advertencias:** la inversión no modifica reservas en aerolíneas, hoteles ni AutoReisen. Las rutas y vuelos nuevos son una planificación, por lo que las referencias/horarios antiguos deben volver a confirmarse. La obtención de precios en la nueva semana depende de los servicios externos.

**Pruebas:** `node scripts/validate-release.mjs` y `node scripts/test-stage-inversion.mjs`.

Monitor de Cordial corregido en v2.4.54, incluido en este paquete; Worker precios v2.2.58 y Vueling v1.0.23.
