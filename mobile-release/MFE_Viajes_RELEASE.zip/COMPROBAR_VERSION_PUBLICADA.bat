@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
title GC 27 - Comprobar version publicada
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\VERIFICAR_PUBLICACION.ps1" -ExpectedVersion 2.4.54 -Attempts 2
if errorlevel 1 (
  echo.
  echo Si aun no has publicado este ZIP, es normal: se espera la v2.4.54.
  echo Comprueba que tu app use el sitio https://mfe-viajes-2026.web.app/
)
pause
