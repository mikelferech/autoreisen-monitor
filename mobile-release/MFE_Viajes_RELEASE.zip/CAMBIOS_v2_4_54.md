# MFE Viajes v2.4.54 · Reparación confirmada del monitor Cordial

- Corregido el selector real de ocupación de BeCordial: #who_popup, contador de adultos y campo `allocations`.
- Conserva cinco adultos en una Beach Club House y preserva `allocations` durante el POST.
- Consulta real GitHub Actions 42190740091 correcta: Club Cordial, Reserva Online, solo alojamiento, cancelación gratuita, 2.965,26 € (6-13/09/2027).
- Sin cambios en las otras pestañas, viajes ni monitores.
- Actualizado el monitor integrado en Cloudflare para que las sincronizaciones posteriores no repongan una versión antigua.
- `ACTUALIZAR_MFE.bat` en la raíz.
