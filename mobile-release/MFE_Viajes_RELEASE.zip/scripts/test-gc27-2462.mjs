import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
const app=fs.readFileSync(new URL('../public/app.js',import.meta.url),'utf8');
const css=fs.readFileSync(new URL('../public/styles.css',import.meta.url),'utf8');
const ver=JSON.parse(fs.readFileSync(new URL('../public/version.json',import.meta.url),'utf8'));
assert.equal(ver.version,'2.4.62');
const source=(start,end)=>{const from=app.indexOf(start),to=app.indexOf(end,from);assert.ok(from>=0&&to>from,start);return app.slice(from,to);};
const lodging=source('function renderLodgingPage(){','\nfunction bindLodgingSectionOrdering(){');
const dunas=source('function renderStage2LodgingCard({fullDetails=false}={}){','\nfunction renderStage2CoverMonitorSummary(){');
assert.match(lodging,/class="lodging-visual-pair" aria-label="Fotografía y mapa de Cordial Santa Águeda"/);
assert.match(lodging,/\$\{cordialPhotoMap\}\$\{cordialMedia\}/);
assert.doesNotMatch(lodging,/\$\{cordialMedia\}\$\{cordialMap\}/);
assert.match(dunas,/fullDetails\?dunasPhotoMap:photo/);
assert.match(dunas,/fullDetails\?'':dunasMap/);
assert.match(dunas,/class="lodging-visual-pair" aria-label="Fotografía y mapa de Dunas Club"/);
// Check that the actual Cordial lodging renderer places both visual elements inside the same row.
const env={
 state:{data:{cover:{lodging:{name:'Cordial',imageUrl:'https://example.org/hotel.jpg'},mediaCarousels:[{placement:'lodging'}],documents:[]},trackers:{cordial:{}},settings:{mapType:'satellite',mapQuery:'Cordial'},budget:{groups:[]},stages:{enabled:true,items:[{},{hotel:{name:'Dunas'}}]}}},
 TRACKER_DEFAULT_ICONS:{cordial:'🏨'},num:x=>Number(x)||0,sum:arr=>arr.reduce((a,v)=>a+v,0),esc:x=>String(x??''),formatMoney:x=>String(x),formatDate:x=>String(x??''),
 defaultLodgingReviewButtons:()=>({}),isValidUrl:()=>false,iconMarkup:()=>'',resilientImageMarkup:()=>'',brandIconMarkup:()=>'',googleMapsIconMarkup:()=>'',serviceIconMarkup:()=>'',coloredServiceLink:()=>'',providerPalette:()=>({g1:'#111',g2:'#333'}),lockedBanner:()=>'',pageHead:()=>'',canEdit:()=>false,mapsDirectionsUrl:()=>'',safeLink:()=>'',isImageSource:()=>true,poolPanelConfig:()=>({enabled:false}),multiStageEnabled:()=>true,tripStages:()=>[{},{hotel:{name:'Dunas'}}],renderStage2LodgingCard:()=>'',stageOrderIsInverted:()=>false,renderDocument:()=>'',coverCarouselPlacement:x=>x.placement,renderLodgingCarouselAccordion:()=>'<div id="pdf-cordial">PDF</div>'
};
vm.createContext(env);
vm.runInContext(lodging+'\nthis.renderLodgingPage=renderLodgingPage;',env);
const html=env.renderLodgingPage();
const visual=html.match(/<div class="lodging-visual-pair" aria-label="Fotografía y mapa de Cordial Santa Águeda">([\s\S]*?)<\/section><\/div>/)?.[0]||'';
assert.match(visual,/lodging-visual-photo/);assert.match(visual,/lodging-page-image/);assert.match(visual,/cordial-stage-map/);assert.match(visual,/Mapa de Cordial Santa Águeda/);
assert.ok(html.indexOf('id="pdf-cordial"')>html.indexOf('stage-lodging-primary'),'Cordial keeps its PDFs inside its lodging block');
const cssSection=css.slice(css.indexOf('/* v2.4.62'));
assert.match(cssSection,/grid-template-columns:repeat\(2,minmax\(0,1fr\)\)!important/);
assert.match(cssSection,/height:390px!important/);
assert.match(cssSection,/@media\(max-width:899px\)/);
assert.match(cssSection,/@media\(max-width:480px\)/);
assert.match(cssSection,/body\[data-active-tab="lodging"\]/);
console.log('OK · GC27 v2.4.62: dos pares foto/mapa en 50/50, altura uniforme y disposición móvil vertical.');
