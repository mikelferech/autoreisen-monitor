import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const read=rel=>readFile(path.join(root,rel),'utf8');
for(const rel of ['public/app.js','public/sw.js','functions/index.js','CLOUDFLARE_WORKER_v2_2_35.js']){
  const r=spawnSync(process.execPath,['--check',path.join(root,rel)],{encoding:'utf8'});
  assert.equal(r.status,0,`${rel} no pasa node --check:\n${r.stderr}`);
}
const index=await read('public/index.html');
const app=await read('public/app.js');
const worker=await read('CLOUDFLARE_WORKER_v2_2_35.js');
assert.match(index,/GC 26 · v2\.3\.27/);
assert.match(app,/const APP_VERSION = "2\.3\.27"/);
assert.match(app,/github-mobile-release-upload-init/);
assert.match(app,/github-mobile-release-upload-chunk/);
assert.match(app,/github-mobile-release-upload-finalize/);
assert.match(worker,/const WORKER_VERSION = "2\.2\.35"/);
assert.match(worker,/github-mobile-release-upload-init/);
assert.match(worker,/github-mobile-release-upload-chunk/);
assert.match(worker,/github-mobile-release-upload-finalize/);
console.log('OK · Validación de rescate móvil v2.3.27.');
