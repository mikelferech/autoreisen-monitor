import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
const source=fs.readFileSync(new URL('../public/app.js',import.meta.url),'utf8');
const css=fs.readFileSync(new URL('../public/styles.css',import.meta.url),'utf8');
const names=['stageQuoteRooms','stageQuoteRoomName','stageMonitorConfigReady','stageBinterItem','stageMonitorIdentity','stageCarSelectedRow','stageCarPhoto','renderStage2AutoReisenFleet','stage2LodgingReviewLinks','renderStage2LodgingCard','renderStage2LodgingReservationDetails','renderStage2CoverMonitorSummary','renderSecondStageWeather','renderStage2TrackerCards','applyStageMonitorResult'];
function extract(name){
 const pat=new RegExp('^(?:async )?function '+name+'\\(', 'm');const hit=pat.exec(source);assert.ok(hit,`Función ${name} inexistente`);
 const start=hit.index;const later=source.slice(start+10).search(/^\s*(?:async )?function\s+\w+\(/m);
 const until=later<0?source.length:start+10+later;
 return source.slice(start,until);
}
const s2={id:'week-2',label:'Semana 2',island:'Fuerteventura',start:'2027-09-13',weatherPlace:'Corralejo',hotel:{name:'Dunas Club',checkIn:'2027-09-13',checkOut:'2027-09-20',reservedPrice:1008},car:{provider:'AutoReisen',pickupAt:'2027-09-13T12:00',dropoffAt:'2027-09-20T12:00',group:'E',model:'Seat Arona',reservedPrice:171.28,imageUrl:'https://example.org/coche-equivocado.jpg',fleetPrices:[{group:'E',model:'Seat Arona TSI',imageUrl:'https://example.org/seat-arona.jpg',total:200,pricePerDay:28.57},{group:'A',model:'Citroen C3',imageUrl:'https://example.org/c3.jpg',total:160,pricePerDay:22.86} ]}};
const state={data:{settings:{mapType:'satellite',people:5},cover:{flights:[{airline:'Binter',date:'2026-09-13',from:'Gran Canaria (LPA)',to:'Fuerteventura (FUE)'}]},stages:{enabled:true,items:[{id:'week-1'},s2]}} ,stageWeather:{'week-2':{current:{icon:'☀️',temp:28,text:'Sol'},forecast:[]}}};
const context={state,tripStages:()=>state.data.stages.items,stageTitle:(s,i)=>`${s.label||'Semana '+(i+1)} · ${s.island||''}`,esc:x=>String(x??''),num:x=>Number(x)||0,
 isImageSource:x=>/^https:\/\//.test(String(x||'')),isValidUrl:x=>/^https:\/\//.test(String(x||'')),safeLink:(url,label)=>`<a href="${url}">${label}</a>`,
 mapsDirectionsUrl:x=>`https://www.google.com/maps?q=${encodeURIComponent(x)}`,googleMapsIconMarkup:()=>'<img alt="maps">', brandIconMarkup:x=>`<b>${x}</b>`,iconMarkup:(icon,url)=>`<span>${icon}</span>`,
 coloredServiceLink:(url,label)=>`<a href="${url}">${label}</a>`,defaultLodgingReviewButtons:()=>({googleReviewsLabel:'Google',googleReviewsColor:'#fff',tripadvisorReviewsLabel:'Tripadvisor',tripadvisorReviewsColor:'#fff',bookingReviewsLabel:'Booking',bookingReviewsColor:'#fff'}),
 formatDate:x=>String(x||'—'),formatMoney:x=>Number(x).toFixed(2)+' €',canEdit:()=>true,visibleFiles:x=>x||[],renderFileButton:()=>'',
 sortDragHandle:()=>'<button>⋮⋮</button>',trackerRunProgressMarkup:()=>'<div class="progress"></div>',trackerSingleHistoryChart:()=>'<div>grafico</div>',autoreisenBestFleetMatch:(rows,model)=>rows.find(row=>row.model.toLowerCase().includes(model.toLowerCase())),
 autoreisenFleetPricesMarkup:obj=>`<div id="fleet">${obj.fleetPrices.map(x=>x.model+' '+x.total+' €').join(' | ')}</div>`,
 renderAccuWeatherButton:()=>'<a title="AccuWeather">AccuWeather</a>',formatNumberEs:x=>String(x),
 saveSection:async()=>true,render:()=>{}, callPriceWorker:async()=>null, multiStageEnabled:()=>true,STAGE_MONITOR_TYPES:{car:'autoreisen-stage2',hotel:'dunas',binter:'binter-stage2'},
};
vm.createContext(context);
for(const name of names){const block=extract(name);vm.runInContext(block,context,{filename:`app.js:function:${name}`});}
const lodging=context.renderStage2LodgingCard();
for(const name of ['Dunas Club','2027-09-13','2027-09-20','Google','Tripadvisor','Booking','Cómo llegar','UBICACIÓN','iframe'])assert.ok(lodging.includes(name),'Portada Dunas no muestra: '+name);
for(const name of ['Check-in online','Fotos','Reservar','Seguimiento Dunas Club'])assert.ok(!lodging.includes(name),'Portada Dunas incluye un control que sobra: '+name);
const fullLodging=context.renderStage2LodgingCard({fullDetails:true});
for(const name of ['Check-in online','Fotos','Reservar','Google','Tripadvisor','Booking','iframe'])assert.ok(fullLodging.includes(name),'Pestaña Alojamiento Dunas no muestra: '+name);
assert.doesNotMatch(lodging,/data-stage-edit-reservation="1:car"/);
const weather=context.renderSecondStageWeather();assert.match(weather,/AccuWeather/);assert.match(weather,/Corralejo/);
const binter=context.stageBinterItem();assert.equal(binter.date,'2027-09-13','Binter no corrige vuelo desfasado 2026');
const car=context.stageCarPhoto(s2.car);assert.equal(car,'https://example.org/seat-arona.jpg','Foto no corresponde al coche seleccionado');
const fleet=context.renderStage2AutoReisenFleet(s2.car);assert.match(fleet,/Seat Arona TSI/);assert.match(fleet,/Citroen C3/);
const tcar=context.renderStage2TrackerCards('car');assert.match(tcar,/id="fleet"/);assert.match(tcar,/data-stage-monitor-refresh="car"/);
const tBinter=context.renderStage2TrackerCards('binter');assert.match(tBinter,/data-stage-edit-binter/);assert.match(tBinter,/Binter/);
const summary=context.renderStage2CoverMonitorSummary();assert.match(summary,/Dunas Club/);assert.match(summary,/Binter/);assert.match(summary,/AutoReisen FUE/);
const identity=context.stageMonitorIdentity('car',s2.car);
const result={queryIdentity:identity,checkedAt:'2026-11-05T13:00:00.000Z',total:180,price:180,model:'Seat Arona TSI',fleet:[{group:'E',model:'Seat Arona TSI',imageUrl:'https://example.org/seat-arona-updated.jpg',total:180,pricePerDay:25.71},{group:'A',model:'Citroen C3',imageUrl:'https://example.org/c3.jpg',total:140,pricePerDay:20}],source:'AutoReisen stage2'};
context.callPriceWorker=async()=>({result});await context.applyStageMonitorResult('car');assert.equal(s2.car.currentPrice,180);assert.equal(s2.car.fleetPrices.length,2);assert.equal(context.stageCarPhoto(s2.car),'https://example.org/seat-arona-updated.jpg');
assert.match(css,/data-trip-stages="2".*\.main-content/s,'Portada dos islas no amplía ancho completo');
assert.match(css,/data-cover-layout-id="weather"/);
assert.match(css,/data-cover-layout-id="lodging"/);
assert.doesNotMatch(source.slice(source.indexOf('function renderLodgingPage()'),source.indexOf('binders.lodging=()')),/stageReservationCard\([^)]*,\s*'car'/,'Alojamiento todavía muestra el coche');
console.log('OK · Prueba funcional GC27: HTML de Dunas, AccuWeather, Binter, flota completa, foto correcta, guardado de precios y portada ancha.');
