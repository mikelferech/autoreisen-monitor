import assert from 'node:assert/strict';
import {createTravelUsersController} from '../public/travel-users-controller.js';

const root={querySelectorAll:()=>[],querySelector:()=>null};
const opt={canManage:()=>true,unlocked:()=>true,openForm:()=>{},confirm:()=>true,toast:()=>{},active:()=>true,userId:()=> 'admin',esc:s=>String(s)};

// Regresión real v2.4.56: ante fallo, render -> bind -> load se ejecutaba
// infinitamente y escondía el error bajo «Cargando usuarios…».
let rejectedCalls=0, ctrl, renders=0;
ctrl=createTravelUsersController({...opt,
  provider:()=>({call:()=>{rejectedCalls++;return Promise.reject(Object.assign(new Error('Sin permisos'),{code:'functions/permission-denied'}));}}),
  render:()=>{renders++;if(ctrl)ctrl.bind(root);},
  loadTimeoutMs:20
});
await ctrl.load();
assert.equal(rejectedCalls,1,'No debe relanzarse el listado tras un error de Firebase');
assert.ok(renders>=2,'Debe mostrarse el error tras el intento');
assert.match(ctrl.html(),/Firebase ha denegado la lista de usuarios/);
assert.match(ctrl.html(),/data-users-retry/);
assert.doesNotMatch(ctrl.html(),/Cargando usuarios/);
ctrl.bind(root);ctrl.bind(root);
assert.equal(rejectedCalls,1,'Volver a enlazar la vista no debe iniciar otra carga');

// Firestore Functions pendiente: debe salir del spinner y habilitar el reintento.
let hangingCalls=0; let blocker;
blocker=createTravelUsersController({...opt,
  provider:()=>({call:()=>{hangingCalls++;return new Promise(()=>{});}}),
  render:()=>blocker?.bind(root),
  loadTimeoutMs:25
});
await blocker.load();
assert.equal(hangingCalls,1);
assert.match(blocker.html(),/Firebase no ha respondido/);
assert.match(blocker.html(),/Reintentar carga/);
assert.doesNotMatch(blocker.html(),/Cargando usuarios/);

// Reintento manual correcto: debe presentar la lista sin pérdida de permisos.
let attempts=0;let recovery;
recovery=createTravelUsersController({...opt,
  provider:()=>({call:()=>{attempts++;return attempts===1?Promise.reject(Object.assign(new Error('Unreachable'),{code:'functions/unavailable'})):Promise.resolve({users:[{uid:'u1',displayName:'Correcto',email:'test@example.com',role:'viewer',enabled:true,otherApps:[]}]});}}),
  render:()=>recovery?.bind(root),
  loadTimeoutMs:100
});
await recovery.load();
assert.match(recovery.html(),/No se pudo conectar/);
await recovery.load(true);
assert.equal(attempts,2);
assert.match(recovery.html(),/Correcto/);
assert.doesNotMatch(recovery.html(),/travel-users-failure/);

// Si el render lanzase un error, no se debe quedar model.loading=true.
let renderFails=true;let broken;
broken=createTravelUsersController({...opt,
  provider:()=>({call:()=>Promise.resolve({users:[]})}),
  render:()=>{if(renderFails){renderFails=false;throw Error('Render inicial fallido');}},
  loadTimeoutMs:50
});
await broken.load();
assert.doesNotMatch(broken.html(),/Cargando usuarios/);
await broken.load(true);
assert.doesNotMatch(broken.html(),/Cargando usuarios/);
console.log('OK · usuarios v2.4.62: sin bucle de recargas, tiempo máximo, reintento y recuperación.');
