import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
const read=p=>readFileSync(new URL(p,import.meta.url),'utf8');
const app=read('../public/app.js');
const ui=read('../public/travel-users-ui.js');
const backend=read('../functions/travel-users.js');
const rules=read('../firestore.rules');
const install=read('../ACTUALIZAR_MFE.bat');
const version=JSON.parse(read('../public/version.json'));
assert.equal(version.version,'2.4.62');
for(const file of ['../public/app.js','../public/travel-users-ui.js','../public/travel-users-controller.js','../functions/travel-users.js','../functions/index.js']) {
  const check=spawnSync(process.execPath,['--check',fileURLToPath(new URL(file,import.meta.url))],{encoding:'utf8'});
  assert.equal(check.status,0,`${file}: ${check.stderr}`);
}
assert.match(app,/function roleCanEdit\(\) \{ return \["admin","editor"\]\.includes\(state\.profile\?\.travelRole/);
assert.match(app,/data-panel="users"/);
assert.match(read('../public/travel-users-controller.js'),/\[data-users-create\]/);
assert.match(read('../public/travel-users-controller.js'),/\[data-users-edit\]/);
assert.match(read('../public/travel-users-controller.js'),/\[data-users-remove\]/);
assert.match(read('../public/travel-users-controller.js'),/\[data-users-reset\]/);
assert.match(app,/function travelAdmin\(\)/);
assert.match(app,/unlocked:\(\)=>travelAdmin\(\)\&\&state\.settingsUnlocked/);
assert.match(ui,/data-users-access/);
assert.match(ui,/data-users-delete/);
assert.match(backend,/await assertAdmin\(request\)/);
assert.match(backend,/getAuth\(\)/);
assert.match(backend,/lastAdminGuard/);
assert.match(backend,/if\(uid===actor \|\| isPrimary\)/);
assert.match(backend,/otherApps|other\.length/);
assert.match(backend,/revokeRefreshTokens/);
assert.match(backend,/travelRole:role/);
assert.match(rules,/function travelRole\(\)/);
assert.match(rules,/travelProfile\(\)\.get\('travelEnabled', true\)/);
assert.doesNotMatch(install,/--only functions:manageTravelUsers/,'En Spark el instalador no debe intentar desplegar funciones');
assert.doesNotMatch(install,/npm install --prefix functions/,'No instalar dependencias de Functions innecesariamente');
assert.doesNotMatch(install,/call .*ACTUALIZAR_WORKERS\.bat/);
assert.doesNotMatch(install,/deploy --only firestore:rules/,'No se deben sobrescribir automáticamente las reglas del proyecto compartido');
assert.match(read('../ACTIVAR_REGLAS_USUARIOS.bat'),/Has revisado y fusionado/);
// La presentación es un módulo independiente que se puede probar sin Firestore.
const {renderTravelUserManagement}=await import('../public/travel-users-ui.js');
const esc=s=>String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
const html=renderTravelUserManagement({users:[
 {uid:'u1',email:'test@example.com',displayName:'Usuario Uno',role:'viewer',enabled:true,otherApps:[]},
 {uid:'u2',email:'x@example.com',displayName:'Usuario <b>X</b>',role:'admin',enabled:true,otherApps:['hogar']}
]},{unlocked:true,currentUid:'some-other-user',esc});
assert.match(html,/data-users-edit="u1"/);
assert.match(html,/data-users-delete="u1"/);
assert.doesNotMatch(html,/data-users-delete="u2"/);
assert.match(html,/Usuario &lt;b&gt;X&lt;\/b&gt;/);
const locked=renderTravelUserManagement({users:[{uid:'u1',email:'test@example.com',role:'viewer',enabled:true}]},{unlocked:false,currentUid:'u1',esc});
assert.doesNotMatch(locked,/data-users-delete=/);
console.log('OK · MFE Viajes v2.4.62: seguridad de usuarios, UI responsive, roles, bloqueo y funciones de Firebase.');
