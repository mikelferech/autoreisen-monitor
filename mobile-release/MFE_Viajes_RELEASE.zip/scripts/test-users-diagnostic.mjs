import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
const code=readFileSync(new URL('../functions/travel-users.js',import.meta.url),'utf8');
class HttpsError extends Error{constructor(code,message,details){super(message);this.code=code;this.details=details;}}
const request={auth:{uid:'admin',token:{email:'admin@example.com'}},data:{action:'list'}};
const logs=[];
async function run({profileFailure=null,listFailure=null,authFailure=false,invalidNames=false}={}){
  const entries=[
    {id:'admin',data:()=>({role:'admin',apps:{travel:true},displayName: invalidNames?987:'Admin',email:'admin@example.com'})},
    {id:'viewer',data:()=>({role:'viewer',apps:{travel:true},displayName:invalidNames?{legacy:'Viewer'}:'Viewer',email:'viewer@example.com'})}
  ];
  const firestore={
    doc:()=>({get:async()=>{if(profileFailure)throw profileFailure;return entries[0];}}),
    collection:()=>({limit:()=>({get:async()=>{if(listFailure)throw listFailure;return {docs:entries};}})})
  };
  const auth={getUsers:async users=>{if(authFailure)throw Object.assign(new Error('Insufficient permissions'),{code:7});return {users:users.map(u=>({uid:u.uid,displayName:u.uid,email:u.uid+'@example.com',metadata:{lastSignInTime:'today'}}))};}};
  const module={exports:{}};
  vm.runInNewContext(code,{module,exports:module.exports,require:id=>{
    if(id==='firebase-functions/v2/https')return {onCall:(_opts,handler)=>handler,HttpsError};
    if(id==='firebase-admin/auth')return {getAuth:()=>auth};
    if(id==='firebase-admin/firestore')return {getFirestore:()=>firestore,FieldValue:{serverTimestamp:()=>({})}};
    throw Error(id);
  },console:{error:(...args)=>logs.push(args),log:()=>{}}},{filename:'travel-users.js'});
  return module.exports.buildManager()(request);
}
const normal=await run();assert.equal(normal.users.length,2);assert.equal(normal.server,'2.4.58');
const mixed=await run({invalidNames:true});assert.equal(mixed.users.length,2);assert.ok(mixed.users.every(x=>typeof x.displayName==='string'));
const noAuth=await run({authFailure:true});assert.equal(noAuth.users.length,2);assert.equal(noAuth.warnings.length,1);assert.ok(noAuth.users.every(x=>x.missingAuth));
await assert.rejects(run({profileFailure:Object.assign(new Error('Forbidden'),{code:7})}),e=>e.code==='failed-precondition'&&e.details.phase==='profile-read');
await assert.rejects(run({listFailure:Object.assign(new Error('Unavailable'),{code:14})}),e=>e.code==='unavailable'&&e.details.phase==='list-firestore');
await assert.rejects(run({listFailure:new Error('Unknown Firestore error')}),e=>e.code==='internal'&&e.details.phase==='list-firestore');
assert.ok(logs.some(x=>x.includes('profile-read')));
assert.ok(logs.some(x=>x.includes('list-firestore')));
console.log('OK · usuarios: diagnóstico Firestore/Auth por fase, nombres heredados, datos mínimos y errores sanitizados.');
