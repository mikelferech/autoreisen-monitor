import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
const code=readFileSync(new URL('../functions/travel-users.js',import.meta.url),'utf8');
class HttpsError extends Error {constructor(code,message){super(message);this.code=code;}}
const profiles=new Map([['admin1',{email:'admin@example.com',displayName:'Admin',role:'admin',apps:{travel:true}}],['other1',{email:'other@example.com',displayName:'Otro',role:'admin',apps:{travel:true,hogar:true}}]]);
const authUsers=new Map([['admin1',{uid:'admin1',email:'admin@example.com',displayName:'Admin',metadata:{lastSignInTime:'today'}}],['other1',{uid:'other1',email:'other@example.com',displayName:'Otro'}]]);
let counter=1;
function snap(uid){const data=profiles.get(uid);return {id:uid,exists:!!data,data:()=>data};}
const db={
  doc:path=>{const uid=path.split('/')[1];return {
    get:async()=>snap(uid),
    set:async(data)=>profiles.set(uid,{...(profiles.get(uid)||{}),...data}),
    delete:async()=>profiles.delete(uid)
  };},
  collection:name=>({
    add:async()=>({}),
    where:(field,op,value)=>({get:async()=>({docs:[...profiles].filter(([,p])=>p[field]===value).map(([uid])=>snap(uid))})}),
    limit:()=>({get:async()=>({docs:[...profiles.keys()].map(snap)})})
  })
};
const auth={
  createUser:async ({email,displayName,password})=>{if(!password||password.length<8)throw Error('password');const uid='new'+counter++;const u={uid,email,displayName,metadata:{}};authUsers.set(uid,u);return u;},
  getUsers:async ids=>({users:ids.map(x=>authUsers.get(x.uid)).filter(Boolean)}),
  getUser:async uid=>{if(!authUsers.has(uid))throw Object.assign(Error('notfound'),{code:'auth/user-not-found'});return authUsers.get(uid);},
  getUserByEmail:async email=>{const u=[...authUsers.values()].find(x=>x.email===email);if(!u)throw Object.assign(Error('notfound'),{code:'auth/user-not-found'});return u;},
  updateUser:async (uid,update)=>{Object.assign(authUsers.get(uid),update);return authUsers.get(uid);},
  deleteUser:async uid=>authUsers.delete(uid),
  revokeRefreshTokens:async ()=>{}
};
const module={exports:{}};
vm.runInNewContext(code,{module,exports:module.exports,require:id=>{
  if(id==='firebase-functions/v2/https')return {onCall:(_opts,handler)=>handler,HttpsError};
  if(id==='firebase-admin/auth')return {getAuth:()=>auth};
  if(id==='firebase-admin/firestore')return {getFirestore:()=>db,FieldValue:{serverTimestamp:()=>Date.now()}};
  throw Error('Unexpected import '+id);
},console},{filename:'travel-users.js'});
const fn=module.exports.buildManager();
const call=(actor,data)=>fn({auth:actor?{uid:actor,token:{email:authUsers.get(actor)?.email||''}}:null,data});
await assert.rejects(call(null,{action:'list'}),e=>e.code==='unauthenticated');
const adminList=await call('admin1',{action:'list'});assert.ok(adminList.users.length>=2);
const created=await call('admin1',{action:'create',email:'test@example.com',displayName:'Prueba',password:'InitialTest123!',role:'viewer'});
assert.equal(profiles.get(created.uid).travelRole,'viewer');assert.equal(profiles.get(created.uid).role,'viewer');assert.equal(profiles.get(created.uid).apps.travel,true);
await assert.rejects(call(created.uid,{action:'list'}),e=>e.code==='permission-denied');
await call('admin1',{action:'update',uid:created.uid,email:'test2@example.com',displayName:'Nombre nuevo',role:'editor'});
assert.equal(profiles.get(created.uid).travelRole,'editor');assert.equal(authUsers.get(created.uid).email,'test2@example.com');
await call('admin1',{action:'access',uid:created.uid,enabled:false});
assert.equal(profiles.get(created.uid).apps.travel,false);assert.equal(profiles.get(created.uid).travelEnabled,false);
await call('admin1',{action:'access',uid:created.uid,enabled:true});
assert.equal(profiles.get(created.uid).apps.travel,true);
await assert.rejects(call('admin1',{action:'access',uid:'admin1',enabled:false}),e=>e.code==='failed-precondition');
await assert.rejects(call('admin1',{action:'deleteAccount',uid:'other1'}),e=>e.code==='failed-precondition');
await call('admin1',{action:'deleteAccount',uid:created.uid});assert.equal(profiles.has(created.uid),false);
await call('admin1',{action:'grant',email:'other@example.com',displayName:'Otro',role:'viewer'});
assert.equal(profiles.get('other1').apps.hogar,true);assert.equal(profiles.get('other1').role,'admin');assert.equal(profiles.get('other1').travelRole,'viewer');
console.log('OK · Firebase simulado: permisos, alta, edición, roles, bloqueo, borrado seguro y otras MFE Apps.');
