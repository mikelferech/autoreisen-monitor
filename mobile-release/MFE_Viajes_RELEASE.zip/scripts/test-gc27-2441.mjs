import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {quoteUrl,parseVisibleRates} from '../monitoring/dunas.mjs';
const read=file=>readFileSync(new URL('../'+file,import.meta.url),'utf8');
const app=read('public/app.js'),css=read('public/styles.css'),index=read('public/index.html');
const worker=read('CLOUDFLARE_WORKER_v2_2_54.js'),ps=read('scripts/update-workers.ps1');
const monitor=read('monitoring/dunas.mjs'),pools=read('monitoring/pools.mjs');
const version=JSON.parse(read('public/version.json')).version;
assert.equal(version,'2.4.53');
assert.match(index,/GC 27 · v2\.4\.53/);
assert.match(ps,/Expected='2\.2\.58'/);
assert.match(worker,/const WORKER_VERSION = "2\.2\.58";/);
assert.match(worker,/const POOLS_AUTOMATION_VERSION = "1\.0\.8";/);
function embedded(name){
  const line=worker.split('\n').find(v=>v.startsWith('const '+name+' = '));
  assert.ok(line,'No se ha empaquetado '+name+' en Worker');
  assert.ok(line.endsWith(';'));
  return JSON.parse(line.slice(('const '+name+' = ').length,-1));
}
assert.equal(embedded('DUNAS_FILE'),monitor,'Worker contiene un Dunas distinto del proyecto');
assert.equal(embedded('POOLS_FILE'),pools,'Worker contiene piscinas distintas del proyecto');
const url=quoteUrl({checkIn:'2027-09-13',checkOut:'2027-09-20',adults:5,rooms:1});
assert.match(url,/guests%5B0%5D%5Badults%5D=5/);
assert.doesNotMatch(url,/guests%5B1%5D/);
const rates=parseVisibleRates([
  {text:'ALOJAMIENTO · NON REFUND 10% · Tarifa web · 1.120,00 € · 952,00 €'},
  {text:'ALOJAMIENTO · Cancelación gratuita · Tarifa web · 1.120,00 € · 1.008,00 €'},
  {text:'ALOJAMIENTO Y DESAYUNO · Cancelación gratuita · Tarifa web · 1.557,50 € · 1.445,50 €'}
]);
assert.deepEqual(rates.map(x=>x.total),[952,1008,1445.5]);
assert.equal(rates[0].rate,'No reembolsable');
assert.equal(rates[1].rate,'Cancelación gratuita');
assert.equal(rates[2].board,'Alojamiento y desayuno');
assert.match(monitor,/parseVisibleRates/);
assert.doesNotMatch(monitor,/await candidate.btn.click/);
assert.match(pools,/const discoverLocations=value=>/);
assert.match(pools,/location_name\|\|value\.pool_name/);
assert.match(app,/data-gc27-open-autoreisen/);
assert.match(app,/data-edit-parking-appearance/);
assert.match(app,/function editParkingAppearance/);
assert.match(app,/parking:`<section class="parking-cover-section">/);
assert.doesNotMatch(app,/flights:`<section class="\$\{journeyGridClass\(\)\}">\$\{journeyCards\}\$\{renderParkingCard\(\)\}/);
assert.match(app,/data-settings-edit-parking>🅿️ Reserva epark · fechas y precio/);
assert.match(app,/\<div class="sun-times"\>/);
assert.match(app,/googleReviewsColor\|\|defaults.googleReviewsColor/);
assert.match(css,/parking-own-block \[data-edit-parking-appearance\]/);
assert.match(css,/body\.design-premium\[data-active-tab="budget"\] \.main-content/);
assert.match(css,/leaflet-container img\.leaflet-tile/);
assert.match(app,/Drive no encuentra este archivo con la cuenta conectada \(404\)/);
assert.match(app,/data-relink-drive-carousel/);
assert.doesNotMatch(app,/(?<!\$)\$\(\s*['"`]\[.*?\]['"`]\s*\)\s*\.forEach\s*\(/);
console.log('OK · GC27 2.4.42: 19 verificaciones de Portada, parking, Google Drive, Dunas, piscinas, mapa, Worker e instalador.');
