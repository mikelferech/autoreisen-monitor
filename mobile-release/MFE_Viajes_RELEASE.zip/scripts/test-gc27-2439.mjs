import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
const read=(s)=>readFileSync(new URL('../'+s,import.meta.url),'utf8');
const app=read('public/app.js'),css=read('public/styles.css'),pool=read('monitoring/pools.mjs'),worker=read('CLOUDFLARE_WORKER_v2_2_54.js');
const cfg=JSON.parse(read('monitoring/config.json'));
assert.equal(cfg.autoreisen.enabled,true,'AutoReisen Gran Canaria debe estar activo');
assert.equal(cfg.cordial.enabled,true,'Cordial debe estar activo');
assert.equal(cfg.autoreisen.pickupAt.slice(0,10),'2027-09-06','AutoReisen GC no debe consultar junio');
assert.equal(cfg.autoreisen.dropoffAt.slice(0,10),'2027-09-13');
assert.equal(cfg.autoreisen.model,'Dacia Sandero Stepway Autom.');
assert.equal(cfg.autoreisenStage2.model,'Dacia Sandero Stepway Autom.');
assert.equal(cfg.dunas.adults,5);
assert.equal(cfg.dunas.rooms,3,'Cinco adultos no caben en una sola suite de dos adultos');
assert.equal(cfg.binterStage2.date,'2027-09-13');
assert.match(app,/function stageQuoteRooms\(/);
assert.match(app,/startTrackerRunProgress\(STAGE_MONITOR_TYPES\[kind\],start\)/,'Falta progreso real GitHub para Fuerteventura');
assert.match(worker,/if\(key==='autoreisen-stage2'\)return 'autoreisen-stage2.yml'/);
assert.match(worker,/if\(key==='dunas'\)return 'dunas-monitor.yml'/);
assert.match(worker,/if\(key==='binter-stage2'\)return 'binter-stage2.yml'/);
assert.match(css,/premium-cover-hero-copy h2\{font-size:clamp[\s\S]*white-space:nowrap/,'El título debe estar en una línea en PC');
assert.match(css,/text-overflow:clip!important/,'No debe mostrar puntos suspensivos');
assert.match(css,/data-active-tab="trackers"\] \.main-content/);
assert.match(css,/data-active-tab="lodging"\] \.main-content/);
assert.match(app,/stage-parking-entry/);
assert.match(app,/\$\$\('\[data-edit-parking\]'\)/);
assert.match(app,/originLabel=binterFlight/);
assert.match(app,/destinationLabel=binterFlight/);
assert.match(app,/function renderFuelMap\(/);
assert.match(app,/renderFuelMap\(\)/);
assert.match(app,/function gc27DisplayedPoolList/);
assert.match(pool,/MFE_POOLS_AUTOMATION_VERSION: 1\.0\.7/);
assert.match(pool,/function poolsFromGalileusDaily/);
assert.match(pool,/location_name/);
assert.match(pool,/popover-trigger/);
const rawFunction=pool.slice(pool.indexOf('function poolsFromGalileusDaily('),pool.indexOf('function poolsFromNetwork('));
const context=vm.createContext({
 clean:x=>String(x??'').trim().replace(/\s+/g,' '),
 metricNumber:x=>Number(String(x).replace(',','.')),
});
vm.runInContext(rawFunction,context);
const example=[
 {location_id:1,location_name:'PISCINA INFINITY',records:[
  {DESCRIPCION:'Medir Temperatura Ambiente a las 07:00',FECHA:'2026-11-04T00:00:00',REGISTRO:21},
  {DESCRIPCION:'Medir Temperatura Agua a las 07:00',FECHA:'2026-11-04T00:00:00',REGISTRO:25.6},
  {DESCRIPCION:'Medir Cloro Libre Residual a las 07:00 - SILOÉ',FECHA:'2026-11-04T00:00:00',REGISTRO:1.85}
 ]},
 {location_id:2,location_name:'PISCINA INTERIOR',records:[
  {DESCRIPCION:'Medir Temperatura Agua a las 07:00',FECHA:'2026-11-04T00:00:00',REGISTRO:27.2}
 ]}
];
const result=context.poolsFromGalileusDaily(example);
assert.equal(result.length,2,'Debe conservar todas las ubicaciones reales devueltas por API');
assert.equal(result[0].measurements[0].temperature,25.6,'Debe elegir temperatura del agua, no del ambiente');
assert.equal(result[1].measurements[0].temperature,27.2);
assert.equal(result[0].measurements[0].metrics.length,3,'Debe conservar controles y horas');
console.log('OK · GC27 v2.4.40: configuraciones reales 2027, progreso GitHub, parking, mapas y parser Galileus multivaso verificados.');
