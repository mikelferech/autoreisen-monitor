import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {stageSortIds,previewStageInversion,invertTripPlan,undoTripPlan} from '../public/stage-reorder.js';
const obj=()=>({stages:{enabled:true,items:[
{id:'week-1',island:'Gran Canaria',start:'2027-09-06',end:'2027-09-13',weatherPlace:'Arguineguín',hotel:{},car:{}},
{id:'week-2',island:'Fuerteventura',start:'2027-09-13',end:'2027-09-20',weatherPlace:'Corralejo',hotel:{name:'Dunas Club',checkIn:'2027-09-13',checkOut:'2027-09-20',reservedPrice:1008,currentPrice:1008,verifiedOffers:[{board:'Solo alojamiento',total:1008}]},car:{pickupAt:'2027-09-13T13:00',dropoffAt:'2027-09-20T16:00',reservedPrice:210.97,fleetPrices:[{total:210.97}]},binter:{date:'2027-09-13',origin:'LPA',destination:'FUE'}}]},
settings:{destination:'Gran Canaria · Fuerteventura',weatherPlace:'Arguineguín',departureDateTime:'2027-09-06T08:40',returnDateTime:'2027-09-20T21:20',tripTransportOrder:['flight:out','flight:inter','flight:back','lodging']},
cover:{lodging:{name:'Cordial',checkIn:'2027-09-06',checkOut:'2027-09-13',reservedPrice:2965.26},flights:[{id:'out',type:'IDA',from:'Bilbao (BIO)',to:'Gran Canaria (LPA)',date:'2027-09-06',departure:'2027-09-06T08:40',number:'VY112'},{id:'inter',type:'ESCALA',airline:'Binter',from:'Gran Canaria (LPA)',to:'Fuerteventura (FUE)',date:'2027-09-13',number:'NT111'},{id:'back',type:'VUELTA',from:'Gran Canaria (LPA)',to:'Bilbao (BIO)',date:'2027-09-20',number:'VY222'}]},
trackers:{cordial:{checkIn:'2027-09-06',checkOut:'2027-09-13',reservedPrice:2965.26,currentPrice:2965.26,history:[{price:2965.26}]},autoreisen:{pickupAt:'2027-09-06T08:00',dropoffAt:'2027-09-13T15:00',reservedPrice:171.28,currentPrice:180,history:[{price:180}]},vueling:{origin:'BIO',destination:'LPA',departureDate:'2027-09-06',returnDate:'2027-09-20',outboundFlight:'VY112',returnFlight:'VY222'}},
itinerary:{activities:[{id:'gc1',date:'2027-09-08',location:'Maspalomas'},{id:'fue1',date:'2027-09-14',location:'Corralejo'}]},menu:{days:[{date:'2027-09-08',dinner:'GC'},{date:'2027-09-14',dinner:'FUE'}]},purchases:{records:[{stageId:'week-2',amount:23}]}});
const x=obj(),p=previewStageInversion(x);assert.equal(p.after[0].island,'Fuerteventura');
const {data:y}=invertTripPlan(x);assert.deepEqual(stageSortIds(y.stages),['week-2','week-1']);
assert.equal(y.stages.items[0].start,'2027-09-13');assert.equal(y.stages.items[1].start,'2027-09-06');
assert.equal(y.cover.lodging.checkIn,'2027-09-13');assert.equal(y.trackers.cordial.checkIn,'2027-09-13');
assert.equal(y.stages.items[1].hotel.checkIn,'2027-09-06');assert.equal(y.stages.items[1].car.pickupAt,'2027-09-06T13:00');
assert.equal(y.stages.items[1].binter.origin,'FUE');assert.equal(y.stages.items[1].binter.destination,'LPA');
assert.equal(y.cover.flights.find(f=>f.type==='IDA').to,'Fuerteventura (FUE)');
assert.equal(y.cover.flights.find(f=>f.type==='ESCALA').from,'Fuerteventura (FUE)');
assert.equal(y.cover.flights.find(f=>f.type==='VUELTA').from,'Gran Canaria (LPA)');
assert.equal(y.trackers.vueling.destination,'FUE');assert.equal(y.trackers.vueling.outboundFlight,'');assert.equal(y.trackers.vueling.enabled,false);assert.equal(y.trackers.vueling.itineraryMultiCity,true);
assert.equal(y.stages.items[1].hotel.reservedPrice,1008);assert.equal(y.stages.items[0].id,'week-1');
assert.equal(y.itinerary.activities.find(a=>a.id==='gc1').date,'2027-09-15');
assert.equal(y.itinerary.activities.find(a=>a.id==='fue1').date,'2027-09-07');
assert.equal(y.purchases.records[0].stageId,'week-2');assert.equal(y.trackers.cordial.history[0].price,2965.26);
const restored=undoTripPlan(y);assert.deepEqual(stageSortIds(restored.stages),['week-1','week-2']);
assert.equal(restored.trackers.cordial.currentPrice,2965.26);assert.equal(restored.cover.flights[0].number,'VY112');
assert.equal(restored.cover.flights[1].number,'NT111');assert.equal(restored.cover.flights[2].number,'VY222');
assert.equal(restored.itinerary.activities[0].date,'2027-09-08');
console.log('OK · inversión y deshacer: dos etapas, fechas, vuelos, Binter, hoteles, coches, seguimientos, actividades, reservas e históricos.');

const app=readFileSync(new URL('../public/app.js',import.meta.url),'utf8'),css=readFileSync(new URL('../public/styles.css',import.meta.url),'utf8');
for(const term of ['data-stage-invert','data-stage-undo','performStageInversion','stageOrderIsInverted','github-sync-cordial'])assert.ok(app.includes(term),'Falta '+term);
assert.match(css,/dunas-cover-rates\.dunas-price-offers-grid/);
assert.match(readFileSync(new URL('../public/sw.js',import.meta.url),'utf8'),/stage-reorder\.js/);
