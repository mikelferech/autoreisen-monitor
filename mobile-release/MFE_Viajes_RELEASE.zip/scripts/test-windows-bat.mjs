import assert from 'node:assert/strict';
import {readFileSync, readdirSync} from 'node:fs';
import {join, dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
const root=join(dirname(fileURLToPath(import.meta.url)),'..');
for (const filename of ['ACTUALIZAR_MFE.bat','ACTUALIZAR_WORKERS.bat','ACTIVAR_REGLAS_USUARIOS.bat','COMPROBAR_VERSION_PUBLICADA.bat']) {
  const raw=readFileSync(join(root,filename));
  assert.equal(raw[0],64,filename+' debe comenzar por @ sin marca BOM');
  const lf=[...raw].filter(x=>x===10).length;
  let crlf=0;
  for(let i=1;i<raw.length;i++) if(raw[i]===10&&raw[i-1]===13) crlf++;
  assert.ok(lf>0&&lf===crlf,filename+' debe usar CRLF en todas las lineas, no LF de Unix');
}
// Las rutas obtenidas de URL de archivo deben convertirse con fileURLToPath: en Windows,
// URL.pathname empieza por /D:/ y node --check lo interpreta como D:\\D:\\...
for (const file of ['test-users-management.mjs','test-cordial-worker.mjs','test-autoreisen-worker.mjs','test-vueling-worker.mjs']) {
  const source=readFileSync(join(root,'scripts',file),'utf8');
  assert.match(source,/fileURLToPath\(/,file+' debe usar rutas nativas de Windows');
  assert.doesNotMatch(source,/\b(?:temp|tmp|repairedTemp)\.pathname\b|new URL\([^\n]*\)\.pathname/,file+' no debe pasar URL.pathname a node --check');
}
const bat=readFileSync(join(root,'ACTUALIZAR_MFE.bat'),'utf8');
assert.match(bat,/deploy --only hosting:viajes --project presupuesto-hogar-9dead/);
assert.match(bat,/:fail[\s\S]*pause/);
console.log('OK: lanzadores Windows CRLF, sin BOM, pausa en errores y Hosting solo.');
