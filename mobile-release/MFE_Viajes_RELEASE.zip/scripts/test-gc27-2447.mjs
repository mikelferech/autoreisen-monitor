import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {parseVisibleRates} from '../monitoring/dunas.mjs';
import {__cordialTest} from '../monitoring/cordial.mjs';
const app=fs.readFileSync(new URL('../public/app.js',import.meta.url),'utf8');
const pools=fs.readFileSync(new URL('../monitoring/pools.mjs',import.meta.url),'utf8');
const worker=fs.readFileSync(new URL('../CLOUDFLARE_WORKER_v2_2_54.js',import.meta.url),'utf8');
const room='Suites Apartments (5 adultos)';
const offers=parseVisibleRates([
 {text:'NON REFUND 10% · No reembolsable 952,00 €',board:'ALOJAMIENTO',roomName:room},
 {text:'Long Stay · Cancelación gratuita 1.008,00 €',board:'ALOJAMIENTO',roomName:room},
 {text:'Tarifa web Cancelación gratuita 1.445,50 €',board:'ALOJAMIENTO Y DESAYUNO',roomName:room},
 {text:'Tarifa web Cancelación gratuita 2.093,00 €',board:'MEDIA PENSIÓN',roomName:room},
 {text:'Tarifa web Cancelación gratuita 2.593,50 €',board:'PENSIÓN COMPLETA',roomName:room}
]);
assert.deepEqual(offers.map(x=>x.board),['Solo alojamiento','Solo alojamiento','Alojamiento y desayuno','Media pensión','Pensión completa']);
assert.deepEqual(offers.map(x=>x.total),[952,1008,1445.5,2093,2593.5]);
assert.match(app,/resultado descartado por fechas u ocupación diferentes/);
assert.match(app,/quoteIdentity/);
assert.doesNotMatch(app,/precio web de 2\.965,26 €;/);
assert.match(pools,/nombre\|name/);
const source=app.match(/function gc27DisplayedPoolList\(pools=\[\]\)\{[\s\S]*?\n\}/)?.[0];
assert.ok(source);const ctx=vm.createContext({});vm.runInContext(source,ctx);
const clean=ctx.gc27DisplayedPoolList([{name:'Nombre'},{name:'PISCINA INFINITY'},{name:'PISCINA INFINITY'},{name:'PISCINA INFANTIL'}]);
assert.equal(clean.length,2);
const roomA={roomType:'Classic Duplex',rateName:'Club Cordial - Reserva Online',board:'SOLO ALOJAMIENTO',price:990};
assert.equal(__cordialTest.selectTargetOption([roomA],{targetRoom:'Beach Club House',targetRate:'Club Cordial - Reserva Online',targetBoard:'SOLO ALOJAMIENTO'}),null);
assert.match(app,/bindLodgingSectionOrdering/);
assert.match(worker,/DUNAS_FILE = /);
console.log('OK · v2.4.57 · precios por régimen, piscinas únicas, Cordial sin datos cruzados y orden en Alojamiento');
