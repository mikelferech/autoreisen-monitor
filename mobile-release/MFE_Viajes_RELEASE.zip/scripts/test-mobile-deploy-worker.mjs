import assert from 'node:assert/strict';
import {generateKeyPairSync, createSign} from 'node:crypto';

const workerModule=await import(new URL('../CLOUDFLARE_WORKER_v2_2_28.js',import.meta.url));
const worker=workerModule.default;

const {publicKey,privateKey}=generateKeyPairSync('rsa',{modulusLength:2048});
const publicJwk=publicKey.export({format:'jwk'});publicJwk.kid='test-kid';publicJwk.alg='RS256';publicJwk.use='sig';
const b64url=value=>Buffer.from(value).toString('base64url');
const now=Math.floor(Date.now()/1000),header=b64url(JSON.stringify({alg:'RS256',typ:'JWT',kid:'test-kid'})),payload=b64url(JSON.stringify({aud:'demo-project',iss:'https://securetoken.google.com/demo-project',sub:'admin-uid',iat:now-10,exp:now+3600}));
const signingInput=`${header}.${payload}`,signer=createSign('RSA-SHA256');signer.update(signingInput);signer.end();const token=`${signingInput}.${signer.sign(privateKey).toString('base64url')}`;

const files=new Map();let dispatches=0,enabled=0,releaseCommit='',dispatchRequestId='',workflowState='disabled_manually';
const workflowPath='.github/workflows/mfe-mobile-deploy.yml',releasePath='mobile-release/MFE_Viajes_RELEASE.zip';
function ghPath(url){const u=new URL(url),marker='/contents/',i=u.pathname.indexOf(marker);if(i<0)return null;return u.pathname.slice(i+marker.length).split('/').map(decodeURIComponent).join('/');}

globalThis.fetch=async(input,options={})=>{
  const url=typeof input==='string'?input:input.url,method=String(options.method||'GET').toUpperCase();
  if(url.startsWith('https://www.googleapis.com/service_accounts/v1/jwk/'))return Response.json({keys:[publicJwk]});
  if(!url.startsWith('https://api.github.com/'))throw new Error(`fetch inesperado: ${url}`);
  if(url.includes('/actions/workflows?per_page=100'))return Response.json({total_count:1,workflows:[{id:77,name:'Actualizar MFE Viajes · móvil',path:workflowPath,state:workflowState}]});
  if(url.endsWith('/actions/workflows/77/enable')){assert.equal(method,'PUT');enabled++;workflowState='active';return new Response(null,{status:204});}
  if(url.endsWith('/actions/workflows/77/dispatches')){dispatches++;const body=JSON.parse(options.body||'{}');dispatchRequestId=String(body?.inputs?.request_id||'');return new Response(null,{status:204});}
  if(url.includes('/actions/workflows/mfe-mobile-deploy.yml/runs?')){
    const runs=[];
    if(dispatchRequestId)runs.push({id:992,name:'Actualizar MFE Viajes · móvil',display_title:`MFE móvil · ${dispatchRequestId}`,status:'queued',conclusion:null,event:'workflow_dispatch',head_sha:releaseCommit||'branch-head',created_at:new Date().toISOString(),run_started_at:'',updated_at:new Date().toISOString(),html_url:'https://example.invalid/actions/runs/992'});
    if(releaseCommit)runs.push({id:991,name:'Actualizar MFE Viajes · móvil',display_title:`MFE móvil · ${releaseCommit}`,status:'queued',conclusion:null,event:'push',head_sha:releaseCommit,created_at:new Date().toISOString(),run_started_at:'',updated_at:new Date().toISOString(),html_url:'https://example.invalid/actions/runs/991'});
    return Response.json({workflow_runs:runs});
  }
  const path=ghPath(url);
  if(path){
    if(method==='GET'){
      if(!files.has(path))return Response.json({message:'Not Found'},{status:404});
      const value=files.get(path),content=path===releasePath?value:Buffer.from(value).toString('base64');
      return Response.json({sha:`sha-${path.length}`,content});
    }
    if(method==='PUT'){
      const body=JSON.parse(options.body||'{}');
      if(path===releasePath){files.set(path,body.content);releaseCommit='release-commit-abcdef123456';return Response.json({commit:{sha:releaseCommit,html_url:'https://example.invalid/commit/release'},content:{sha:'zip-sha'}});}
      files.set(path,Buffer.from(body.content,'base64').toString('utf8'));
      return Response.json({commit:{sha:`commit-${path.length}`,html_url:'https://example.invalid/commit/workflow'},content:{sha:`sha-${path.length}`}});
    }
  }
  throw new Error(`GitHub mock no contempla ${method} ${url}`);
};

const env={FIREBASE_PROJECT_ID:'demo-project',INTEGRATION_ADMIN_UIDS:'admin-uid',GITHUB_TOKEN:'test-token',GITHUB_OWNER:'owner',GITHUB_REPO:'repo',GITHUB_BRANCH:'main'};
const req=new Request('https://worker.invalid/',{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`},body:JSON.stringify({action:'github-mobile-release-upload',releaseName:'MFE_Viajes_2026_v2_2_186_COMPLETA.zip',releaseBase64:'UEsDBFAKEZIPDATA'})});
const res=await worker.fetch(req,env),text=await res.text();let data;try{data=JSON.parse(text);}catch{data={raw:text};}
assert.equal(res.status,200,text);assert.equal(data.ok,true,text);assert.equal(data.workflowTriggered,true);assert.equal(data.runFound,true);assert.equal(String(data.runId),'991');assert.equal(data.triggerMode,'push');assert.equal(data.requestId,releaseCommit);assert.equal(enabled,1);assert.equal(dispatches,0,'El push confirmado no debe crear un workflow_dispatch duplicado');assert.ok(files.has(workflowPath));assert.ok(files.has(releasePath));assert.match(files.get(workflowPath),/push:\s*[\s\S]*mobile-release\/MFE_Viajes_RELEASE\.zip/);
console.log('OK · actualización móvil: workflow habilitado, push del ZIP y runId real confirmados sin falso positivo.');

const retryReq=new Request('https://worker.invalid/',{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`},body:JSON.stringify({action:'github-mobile-deploy-trigger',requestId:'retry-186'})});
const retryRes=await worker.fetch(retryReq,env),retryText=await retryRes.text();let retryData;try{retryData=JSON.parse(retryText);}catch{retryData={raw:retryText};}
assert.equal(retryRes.status,200,retryText);assert.equal(retryData.workflowTriggered,true,retryText);assert.equal(retryData.runFound,true,retryText);assert.equal(String(retryData.runId),'992');assert.equal(retryData.requestId,'retry-186');assert.equal(retryData.triggerMode,'workflow_dispatch');assert.equal(dispatches,1,'El botón de reintento debe lanzar exactamente un workflow_dispatch');
console.log('OK · reintento manual del workflow confirmado con runId real.');
