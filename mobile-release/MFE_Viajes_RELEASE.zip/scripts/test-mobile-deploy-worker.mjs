import assert from 'node:assert/strict';
import {generateKeyPairSync, createSign} from 'node:crypto';

const workerModule=await import(new URL('../CLOUDFLARE_WORKER_v2_2_29.js',import.meta.url));
const worker=workerModule.default;
const {publicKey,privateKey}=generateKeyPairSync('rsa',{modulusLength:2048});
const publicJwk=publicKey.export({format:'jwk'});publicJwk.kid='test-kid';publicJwk.alg='RS256';publicJwk.use='sig';
const b64url=value=>Buffer.from(value).toString('base64url');
const now=Math.floor(Date.now()/1000),header=b64url(JSON.stringify({alg:'RS256',typ:'JWT',kid:'test-kid'})),payload=b64url(JSON.stringify({aud:'demo-project',iss:'https://securetoken.google.com/demo-project',sub:'admin-uid',iat:now-10,exp:now+3600}));
const signingInput=`${header}.${payload}`,signer=createSign('RSA-SHA256');signer.update(signingInput);signer.end();const token=`${signingInput}.${signer.sign(privateKey).toString('base64url')}`;
const files=new Map();let repositoryDispatches=0,releaseCommit='',lastRequestId='';
const workflowPath='.github/workflows/mfe-mobile-deploy.yml',releasePath='mobile-release/MFE_Viajes_RELEASE.zip';
function ghPath(url){const u=new URL(url),marker='/contents/',i=u.pathname.indexOf(marker);if(i<0)return null;return u.pathname.slice(i+marker.length).split('/').map(decodeURIComponent).join('/');}
globalThis.fetch=async(input,options={})=>{
  const url=typeof input==='string'?input:input.url,method=String(options.method||'GET').toUpperCase();
  if(url.startsWith('https://www.googleapis.com/service_accounts/v1/jwk/'))return Response.json({keys:[publicJwk]});
  if(!url.startsWith('https://api.github.com/'))throw new Error(`fetch inesperado: ${url}`);
  if(url.endsWith('/repos/owner/repo/dispatches')){assert.equal(method,'POST');const body=JSON.parse(options.body||'{}');assert.equal(body.event_type,'mfe-mobile-deploy');lastRequestId=String(body.client_payload?.request_id||'');repositoryDispatches++;return new Response(null,{status:204});}
  if(url.includes('/actions/workflows?per_page=100'))return Response.json({total_count:1,workflows:[{id:77,name:'Actualizar MFE Viajes · móvil',path:workflowPath,state:'active'}]});
  if(url.includes('/actions/workflows/mfe-mobile-deploy.yml/runs?')){
    const runs=lastRequestId?[{id:993,name:'Actualizar MFE Viajes · móvil',display_title:`MFE móvil · ${lastRequestId}`,status:'queued',conclusion:null,event:'repository_dispatch',head_sha:releaseCommit||'branch-head',created_at:new Date().toISOString(),run_started_at:'',updated_at:new Date().toISOString(),html_url:'https://example.invalid/actions/runs/993'}]:[];
    return Response.json({workflow_runs:runs});
  }
  if(url.includes('/actions/runs/993/jobs?'))return Response.json({jobs:[]});
  const path=ghPath(url);
  if(path){
    if(method==='GET'){
      if(!files.has(path))return Response.json({message:'Not Found'},{status:404});
      const value=files.get(path),content=path===releasePath?value:Buffer.from(value).toString('base64');
      return Response.json({sha:`sha-${path.length}`,content});
    }
    if(method==='PUT'){
      const body=JSON.parse(options.body||'{}');
      if(path===releasePath){files.set(path,body.content);releaseCommit='release-commit-188abcdef';return Response.json({commit:{sha:releaseCommit,html_url:'https://example.invalid/commit/release'},content:{sha:'zip-sha'}});}
      files.set(path,Buffer.from(body.content,'base64').toString('utf8'));return Response.json({commit:{sha:`commit-${path.length}`,html_url:'https://example.invalid/commit/workflow'},content:{sha:`sha-${path.length}`}});
    }
  }
  throw new Error(`GitHub mock no contempla ${method} ${url}`);
};
const env={FIREBASE_PROJECT_ID:'demo-project',INTEGRATION_ADMIN_UIDS:'admin-uid',GITHUB_TOKEN:'test-token',GITHUB_OWNER:'owner',GITHUB_REPO:'repo',GITHUB_BRANCH:'main'};
const headers={'Content-Type':'application/json',Authorization:`Bearer ${token}`};
const req=new Request('https://worker.invalid/',{method:'POST',headers,body:JSON.stringify({action:'github-mobile-release-upload',releaseName:'MFE_Viajes_2026_v2_2_188_COMPLETA.zip',releaseBase64:'UEsDBFAKEZIPDATA'})});
const res=await worker.fetch(req,env),text=await res.text();const data=JSON.parse(text);
assert.equal(res.status,200,text);assert.equal(data.ok,true,text);assert.equal(data.uploaded,true);assert.equal(data.workflowTriggered,true);assert.equal(data.triggerMode,'repository_dispatch');assert.equal(data.runFound,false);assert.ok(data.requestId.startsWith('mfe-'));assert.equal(repositoryDispatches,1);assert.ok(files.has(workflowPath));assert.ok(files.has(releasePath));assert.match(files.get(workflowPath),/repository_dispatch:/);assert.match(files.get(workflowPath),/mfe-mobile-deploy/);
console.log('OK · ZIP subido y repository_dispatch aceptado sin depender de Actions:write.');
const statusReq=new Request('https://worker.invalid/',{method:'POST',headers,body:JSON.stringify({action:'github-mobile-deploy-run-status',requestId:data.requestId})});
const statusRes=await worker.fetch(statusReq,env),statusText=await statusRes.text();const status=JSON.parse(statusText);assert.equal(status.runFound,true,statusText);assert.equal(String(status.run.id),'993');assert.equal(status.run.event,'repository_dispatch');
console.log('OK · runId localizado por request_id.');
const retryReq=new Request('https://worker.invalid/',{method:'POST',headers,body:JSON.stringify({action:'github-mobile-deploy-trigger',requestId:data.requestId})});
const retryRes=await worker.fetch(retryReq,env),retryText=await retryRes.text();const retry=JSON.parse(retryText);assert.equal(retry.workflowTriggered,true,retryText);assert.equal(retry.triggerMode,'repository_dispatch');assert.equal(repositoryDispatches,2);
console.log('OK · reintento repository_dispatch sin volver a subir ZIP.');
