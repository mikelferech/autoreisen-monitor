import assert from 'node:assert/strict';
import fs from 'node:fs';
const read=f=>fs.readFileSync(new URL('../'+f,import.meta.url),'utf8');
const app=read('public/app.js'),css=read('public/styles.css'),pool=read('monitoring/pools.mjs'),version=JSON.parse(read('public/version.json'));
assert.equal(version.version,'2.4.57');
assert.match(app,/settings\.cordialSyncWithLodging!==false/);
assert.match(app,/state\.data\.settings\.cordialSyncWithLodging=false/);
assert.match(app,/selectionMigratedToJogger=true/);
assert.match(app,/renderDunasCoverRates\(item\)/);
assert.match(app,/item\.verifiedOffers=Array\.isArray\(result\.offers\)/);
assert.match(app,/historicalPools=\(p\.history\|\|\[\]\)/);
assert.match(pool,/return \[\.\.\.map\.values\(\)\]\.map\(p=>/);
assert.match(css,/v2\.4\.57/);
const worker=read('CLOUDFLARE_WORKER_v2_2_54.js');
for(const [name,file] of [['POOLS_FILE',pool],['DUNAS_FILE',read('monitoring/dunas.mjs')]]){
 const match=worker.match(new RegExp('const '+name+' = ("(?:\\\\.|[^"\\\\])*");'));
 assert.ok(match,name+' no insertado');assert.equal(JSON.parse(match[1]),file);
}
console.log('OK · GC27 v2.4.57: Cordial independiente, D.Jogger, paridad de colores, piscinas históricas y tarifas verificables.');
