import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
const read=name=>readFileSync(new URL('../'+name,import.meta.url),'utf8');
const app=read('public/app.js');const html=read('public/index.html');const sw=read('public/sw.js');const css=read('public/styles.css');
const version=JSON.parse(read('public/version.json'));
assert.equal(version.version,'2.4.55');
assert.match(html,/app\.js\?v=2\.4\.55/);assert.match(sw,/mfe-viajes-v2\.4\.55/);
assert.match(read('ACTUALIZAR_MFE.bat'),/test-gc27-2440\.mjs/);
// Error exacto de Firefox: $(...) devuelve elemento/NULL y nunca se puede llamar a forEach.
assert.doesNotMatch(app,/(?<!\$)\$\(\s*['"`]\[.*?\]['"`]\s*\)\s*\.forEach\s*\(/,
  'Queda un selector único con .forEach que vuelve a bloquear los lápices');
for(const selector of ['data-stage-add-purchase','data-stage-edit-binter','data-stage-lodging-track','data-refresh-weather','data-lodging-open-tab']){
  assert.match(app,new RegExp("\\$\\$\\('\\["+selector+"\\]\\'\\)\\.forEach"),selector+' debe enlazar todos los botones');
}
assert.match(app,/try\{\(binders\[state\.activeTab\]/,'Un error de editor no debe bloquear otros controles');
assert.match(app,/followStageMonitorRun\(kind,start\)/,'Las ejecuciones de segunda isla necesitan consultar el resultado');
assert.match(app,/remote\?\.lastUnavailable,remote\?\.lastError,remote\?\.result/,'La consulta debe verificar resultados, falta de disponibilidad y fallos del monitor');
for(const field of ['titleIconFile','titleIconUrl','gradient1','gradient2','textColor']){
  assert.ok(app.includes("{name:'"+field+"'"),'Falta edición del campo '+field);
}
assert.match(app,/fileToSquareDataUrl\(values\.iconFile,128\)/,'epark debe guardar icono PNG');
assert.match(app,/fileToSquareDataUrl\(v\.titleIconFile,128\)/,'Dunas y AutoReisen FUE deben guardar icono PNG');
assert.match(app,/style="--provider-g1:\$\{esc\(p\.gradient1/,'epark debe aplicar su degradado personalizado');
assert.match(app,/stageCarSelectedRow\(item\)/,'La tarifa del Dacia seleccionado debe poder aparecer en el resumen');
assert.match(app,/safeLink\(h\.website\|\|official,'Web','🌐','lodging-quick-link'\)/,'Dunas debe poner Web, no Web oficial');
// Prueba real de selección sobre datos de flota, no solo presencia de un texto.
const start=app.indexOf('function stageCarSelectedRow(car={}){');const end=app.indexOf('\nfunction stageCarPhoto(',start);
assert.ok(start>0&&end>start);
const scope=vm.createContext({});vm.runInContext(app.slice(start,end),scope);
const chosen=scope.stageCarSelectedRow({model:'Dacia Sandero Stepway Autom.',group:'D',fleetPrices:[
 {model:'Seat Arona TSI',group:'D',total:180.1,imageUrl:'seat.jpg'},
 {model:'Dacia Sandero Stepway Autom.',group:'D',total:210.97,imageUrl:'dacia.jpg'}]});
assert.equal(chosen?.total,210.97);
assert.match(css,/stage-tracker-title-icon/);
console.log('OK · GC27 v2.4.42: todos los selectores seguros, lápices, colores/iconos, Dacia, parking, consulta de GitHub y versión coherente.');
