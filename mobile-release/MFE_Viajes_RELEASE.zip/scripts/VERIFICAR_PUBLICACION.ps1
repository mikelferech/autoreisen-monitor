param(
  [string]$ExpectedVersion='2.4.56',
  [int]$Attempts=4
)
$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSScriptRoot
$rc=Join-Path $root '.firebaserc'
if(-not(Test-Path $rc)){throw 'No se encuentra .firebaserc.'}
$data=Get-Content $rc -Raw | ConvertFrom-Json
$project=[string]$data.projects.default
$sites=@($data.targets.$project.hosting.viajes)
if($sites.Count -ne 1){throw 'Hosting:viajes no tiene un sitio de Firebase unico configurado.'}
$site=[string]$sites[0]
$base="https://$site.web.app"
Write-Host "`nComprobando version PUBLICADA en $base (proyecto $project)" -ForegroundColor Cyan
$observed=''
for($i=1;$i -le $Attempts;$i++){
  $query=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
  try{
    $headers=@{'Cache-Control'='no-cache, no-store';Pragma='no-cache'}
    $index=Invoke-WebRequest -UseBasicParsing -Uri "$base/?check=$query" -Headers $headers -TimeoutSec 25
    $app=Invoke-WebRequest -UseBasicParsing -Uri "$base/app.js?check=$query" -Headers $headers -TimeoutSec 25
    $meta=Invoke-WebRequest -UseBasicParsing -Uri "$base/version.json?check=$query" -Headers $headers -TimeoutSec 25
    $htmlVersion=[regex]::Match([string]$index.Content,'GC\s*27\s*·\s*v(\d+\.\d+\.\d+)').Groups[1].Value
    $jsVersion=[regex]::Match([string]$app.Content,'const APP_VERSION\s*=\s*"(\d+\.\d+\.\d+)"').Groups[1].Value
    $markerVersion=''
    try{$markerVersion=([string]($meta.Content | ConvertFrom-Json).version)}catch{}
    $observed="HTML=$htmlVersion JS=$jsVersion JSON=$markerVersion"
    Write-Host "Intento ${i}: $observed"
    if($htmlVersion -eq $ExpectedVersion -and $jsVersion -eq $ExpectedVersion -and $markerVersion -eq $ExpectedVersion){
      Write-Host "PUBLICACION VERIFICADA: v$ExpectedVersion" -ForegroundColor Green
      Write-Host "Abre en tu navegador: $base/recuperar-actualizacion.html?c=$query"
      exit 0
    }
  }catch{
    $observed=$_.Exception.Message
    Write-Warning "No se ha podido comprobar el sitio: $observed"
  }
  if($i -lt $Attempts){Start-Sleep -Seconds 3}
}
Write-Host "`nNO SE HA CONFIRMADO LA VERSION $ExpectedVersion." -ForegroundColor Red
Write-Host "Sitio revisado: $base"
Write-Host "Ultima respuesta: $observed"
Write-Host 'Si tu navegador utiliza otra URL, puede que estes viendo un Hosting diferente.'
Write-Host 'Si usa este sitio y los archivos antiguos siguen ahi, revisa el despliegue en Firebase.'
exit 1
