import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
const app=fs.readFileSync(new URL('../public/app.js',import.meta.url),'utf8');
const css=fs.readFileSync(new URL('../public/styles.css',import.meta.url),'utf8');
const ver=JSON.parse(fs.readFileSync(new URL('../public/version.json',import.meta.url),'utf8'));
assert.equal(ver.version,'2.4.62');
const begin=app.indexOf('function renderLodgingPage(){'),end=app.indexOf('\nfunction bindLodgingSectionOrdering(){',begin);
assert.ok(begin>=0&&end>begin,'Alojamiento debe conservar su propia pestaña');
const lodgingSource=app.slice(begin,end);
assert.ok(lodgingSource.includes('section class="stage-lodging-primary"'),'Primera estancia debe tener cabecera unida a su hotel');
assert.ok(lodgingSource.includes('class="lodging-reservations-combined"')||lodgingSource.includes('lodging-reservations-combined'),'Ambas reservas deben estar en la ficha general Reserva');
assert.ok(!lodgingSource.includes('renderStage2LodgingReservationDetails'),'No debe existir reserva Dunas debajo de su hotel');
const state={data:{cover:{lodging:{name:'Cordial Santa Águeda',checkIn:'2027-09-06',checkOut:'2027-09-13'},documents:[],mediaCarousels:[]},trackers:{cordial:{}},settings:{mapType:'satellite',lodgingPageOrder:['fuerteventura','hero','details','map']},budget:{groups:[{id:'g-lodging',name:'Cordial Santa Águeda',items:[{name:'ROL80645K',amount:2965.26,status:'unpaid'}]}]},stages:{enabled:true,items:[{id:'week-1',island:'Gran Canaria',hotel:{}},{id:'week-2',island:'Fuerteventura',hotel:{name:'Dunas Club',reservation:'DUNAS123',reservedPrice:1008,status:'paid',currentPrice:1039}}]}}};
const env={state,console,TRACKER_DEFAULT_ICONS:{cordial:'🏨'},
 num:x=>Number(x)||0,sum:arr=>arr.reduce((a,b)=>a+b,0),esc:x=>String(x??''),formatMoney:x=>new Intl.NumberFormat('es-ES',{style:'currency',currency:'EUR'}).format(Number(x)),formatDate:x=>String(x??''),
 defaultLodgingReviewButtons:()=>({}),isValidUrl:()=>false,iconMarkup:()=>'<span>hotel</span>',resilientImageMarkup:()=>'',
 brandIconMarkup:()=>'',googleMapsIconMarkup:()=>'',serviceIconMarkup:()=>'',coloredServiceLink:()=>'',providerPalette:()=>({g1:'#123',g2:'#456'}),
 lockedBanner:()=>'',pageHead:()=>'<h1>Alojamiento</h1>',canEdit:()=>true,mapsDirectionsUrl:()=>'',safeLink:(url,label)=>'<a>'+label+'</a>',
 isImageSource:()=>false,poolPanelConfig:()=>({enabled:false}),multiStageEnabled:()=>state.data.stages.enabled,tripStages:()=>state.data.stages.items,
 renderStage2LodgingCard:()=>'<section class="stage2-lodging-full">Dunas ficha</section>',stageOrderIsInverted:()=>false,
 renderDocument:()=>'',coverCarouselPlacement:()=>'',renderLodgingCarouselAccordion:()=>'',
 };
vm.createContext(env);vm.runInContext(lodgingSource+'\nthis.renderLodgingPage=renderLodgingPage;',env);
const html=env.renderLodgingPage();
assert.match(html,/🏨 Primera estancia · Gran Canaria/);
assert.match(html,/🏨 Segunda estancia · Fuerteventura/);
assert.ok(html.indexOf('Primera estancia · Gran Canaria')<html.indexOf('Cordial Santa Águeda'),'El título GC debe preceder la primera estancia');
assert.ok(html.indexOf('Segunda estancia · Fuerteventura')<html.indexOf('Dunas ficha'),'El título FUE debe preceder Dunas');
const start=html.indexOf('<h3>Reserva</h3>'),endReserve=html.indexOf('lodging-pools-panel',start)>0?html.indexOf('lodging-pools-panel',start):html.indexOf('<section class="lodging-page-section"',start);
const reserve=html.slice(start,endReserve);
for(const value of ['Cordial Santa Águeda','Dunas Club','ROL80645K','DUNAS123','2965,26','1008,00','1039,00'])assert.ok(reserve.includes(value),'Reserva principal debe contener '+value);
assert.equal((html.match(/<h3>Reserva<\/h3>/g)||[]).length,1,'Un único cuadro principal Reserva');
assert.doesNotMatch(html,/Reserva · Dunas Club/,'Sin tarjeta de reserva adicional bajo Dunas');
assert.match(app,/const root=document\.querySelector\('body\[data-active-tab="lodging"\] \.stage-lodging-primary'\)/,'Cabecera GC y hotel deben arrastrarse juntos');
assert.match(css,/\.lodging-reservations-combined \.lodging-bookings/);
state.data.stages.enabled=false;const onlyCordial=env.renderLodgingPage();assert.doesNotMatch(onlyCordial,/Dunas Club|DUNAS123/,'Viaje de una estancia no debe mostrar segunda reserva');
console.log('OK · v2.4.62: Primera y segunda estancia, dos reservas en un cuadro, sin duplicados y orden arrastrable.');
