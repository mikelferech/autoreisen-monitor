'use strict';

// Gestión de identidades MFE Viajes. Ninguna operación privilegiada se realiza en el cliente.
const {onCall, HttpsError} = require('firebase-functions/v2/https');
const {getAuth} = require('firebase-admin/auth');
const {getFirestore, FieldValue} = require('firebase-admin/firestore');

const ROLES = new Set(['admin', 'editor', 'viewer']);
const PRIMARY_ADMIN_EMAIL = 'mikelferech@gmail.com';
const USERS_BACKEND_VERSION = '2.4.58';
const clean = (v, max=140) => String(v ?? '').trim().slice(0, max);
const roleOf = p => p?.travelRole || p?.role || 'viewer';
const permitted = p => p?.travelEnabled !== false && p?.apps?.travel === true;
const isAdmin = p => permitted(p) && roleOf(p) === 'admin';
const invalid = message => {throw new HttpsError('invalid-argument', message);};
const emailOf = value => {
  const s = clean(value, 254).toLowerCase();
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s)) invalid('Introduce una dirección de correo válida.');
  return s;
};
const roleValue = role => {
  const value = clean(role, 20);
  if(!ROLES.has(value)) invalid('Rol no válido.');
  return value;
};
// La SDK puede emitir números gRPC y excepciones no tipadas. No devolver PII
// ni mensajes internos al cliente, pero sí la fase y un código recuperable.
const normal = (err, phase='operation') => {
  if(err instanceof HttpsError) return err;
  const code=String(err?.code??'').toLowerCase();
  if(code === 'auth/email-already-exists') return new HttpsError('already-exists','Ya existe una cuenta con ese correo. Usa «Dar acceso a cuenta existente».');
  if(code === 'auth/user-not-found') return new HttpsError('not-found','No existe ese usuario en Firebase.');
  if(code === 'auth/invalid-email') return new HttpsError('invalid-argument','Correo no válido.');
  if(code==='7'||/permission.denied/.test(code)) return new HttpsError('failed-precondition',`Permisos insuficientes de la función en Firebase (${phase}). Comprueba la cuenta de servicio.`,{phase,server:USERS_BACKEND_VERSION});
  if(code==='5'||/not.found/.test(code)) return new HttpsError('failed-precondition',`No se encuentra el recurso de Firebase requerido (${phase}).`,{phase,server:USERS_BACKEND_VERSION});
  if(code==='14'||/unavailable|deadline|timeout/.test(code)) return new HttpsError('unavailable',`Firebase no responde durante ${phase}.`,{phase,server:USERS_BACKEND_VERSION});
  return new HttpsError('internal',`Error del servidor al ejecutar ${phase}.`,{phase,server:USERS_BACKEND_VERSION});
};
const safeText=(value, fallback='',limit=180) => typeof value==='string'?value.slice(0,limit):fallback;
function logFailure(phase,error){
  // Diagnóstico sin UID, correo ni otros datos personales.
  console.error('[MFE-USERS]',USERS_BACKEND_VERSION,'Fase:',phase,'Código:',String(error?.code??'sin código'),'Tipo:',String(error?.name||'Error'),'Mensaje:',String(error?.message||'sin detalle').slice(0,380));
}

function buildManager() {
  const db = getFirestore();
  const auth = getAuth();
  async function assertAdmin(request) {
    if(!request.auth) throw new HttpsError('unauthenticated','Debes iniciar sesión.');
    let snap;
    try{snap=await db.doc(`mfeUsers/${request.auth.uid}`).get();}
    catch(error){logFailure('profile-read',error);throw normal(error,'profile-read');}
    const profile = snap.data();
    if(!isAdmin(profile) && !(String(request.auth.token?.email||'').toLowerCase()===PRIMARY_ADMIN_EMAIL && profile?.travelEnabled!==false)) throw new HttpsError('permission-denied','Solo los administradores de Viajes pueden gestionar usuarios.');
    return request.auth.uid;
  }
  async function lastAdminGuard(targetUid, nextRole, nextEnabled) {
    const snap=await db.collection('mfeUsers').where('travelRole','==','admin').get();
    const legacy=await db.collection('mfeUsers').where('role','==','admin').get();
    const candidates=new Map([...snap.docs,...legacy.docs].map(doc=>[doc.id,doc.data()]));
    const others=[...candidates].filter(([uid,p])=>uid!==targetUid && isAdmin(p));
    if(nextRole!=='admin'||!nextEnabled) {
      if(!others.length) throw new HttpsError('failed-precondition','No puedes retirar el permiso al último administrador activo.');
    }
  }
  async function log(actor,action,target) {
    await db.collection('mfeTravelUserAudit').add({actor,action,target,at:FieldValue.serverTimestamp()}).catch(err=>console.error('Audit:',err));
  }
  return onCall({region:'europe-west1',timeoutSeconds:45,memory:'256MiB',maxInstances:3},async request=>{
    const action=clean(request.data?.action,25);
    let phase='auth-check';
    try {
      const actor=await assertAdmin(request);
      if(action==='list') {
        phase='list-firestore';
        const snap=await db.collection('mfeUsers').limit(400).get();
        const docs=snap.docs.filter(d=>{
          const p=d.data()||{};
          return p?.apps?.travel===true || p.travelRole!=null || p.role==='admin';
        });
        const users=[];const warnings=[];
        for(let i=0;i<docs.length;i+=75) {
          const part=docs.slice(i,i+75);
          phase='list-auth';
          let found;
          try{found=await auth.getUsers(part.map(d=>({uid:d.id})));}
          catch(error){
            // Aun si el servicio no puede leer metadatos Auth, mostrar los perfiles
            // de Firestore con sus roles. Nunca exponer el error ni asumir otra identidad.
            logFailure('list-auth-metadata',error);
            warnings.push('No se pudieron leer los metadatos de Firebase Authentication.');
            found={users:[]};
          }
          const byId=new Map((found.users||[]).map(u=>[u.uid,u]));
          phase='list-normalize';
          for(const doc of part) {
            const p=doc.data()||{},user=byId.get(doc.id);
            const apps=p.apps&&typeof p.apps==='object'&&!Array.isArray(p.apps)?p.apps:{};
            users.push({
              uid:doc.id,
              email:safeText(user?.email||p.email),
              displayName:safeText(p.displayName)||safeText(user?.displayName)||safeText(p.email)||'Usuario',
              role:ROLES.has(roleOf(p))?roleOf(p):'viewer',
              enabled:permitted(p),emailVerified:user?.emailVerified===true,
              lastSignIn:safeText(user?.metadata?.lastSignInTime),
              otherApps:Object.entries(apps).filter(([k,v])=>k!=='travel'&&v===true).map(([k])=>k),
              missingAuth:!user
            });
          }
        }
        phase='list-sort';
        users.sort((a,b)=>String(a.displayName).localeCompare(String(b.displayName),'es'));
        return {users,me:actor,server:USERS_BACKEND_VERSION,warnings:[...new Set(warnings)]};
      }
      if(action==='create' || action==='grant') {
        const email=emailOf(request.data?.email),displayName=clean(request.data?.displayName,100),role=roleValue(request.data?.role||'viewer');
        if(!displayName)invalid('El nombre es obligatorio.');
        let user,created=false;
        if(action==='create') {
          const password=String(request.data?.password||'');
          if(password.length<8 || password.length>128)invalid('La contraseña inicial debe tener entre 8 y 128 caracteres.');
          user=await auth.createUser({email,password,displayName,emailVerified:false});created=true;
        } else {
          user=await auth.getUserByEmail(email);
        }
        const ref=db.doc(`mfeUsers/${user.uid}`);
        try{
          const old=(await ref.get()).data()||{};
          await ref.set({
            ...old,
            email, displayName, travelRole:role, travelEnabled:true,
            // El rol global pertenece al proyecto compartido: no se eleva por ser admin en Viajes.
            role: old.role || 'viewer',
            apps: {...(old.apps||{}), travel:true, ...(!Object.keys(old.apps||{}).length?{hogar:false,ahorro:false}:{})},
            updatedAt:FieldValue.serverTimestamp()
          },{merge:true});
        }catch(error){if(created) await auth.deleteUser(user.uid).catch(console.error);throw error;}
        await log(actor,action,user.uid);
        return {uid:user.uid,email,created};
      }
      if(!['update','access','remove','deleteAccount'].includes(action)) invalid('Operación desconocida.');
      const uid=clean(request.data?.uid,150);
      if(!uid)invalid('Identificador de usuario obligatorio.');
      const ref=db.doc(`mfeUsers/${uid}`);
      const snap=await ref.get();
      if(!snap.exists)throw new HttpsError('not-found','El perfil solicitado no existe.');
      const old=snap.data();
      const user=await auth.getUser(uid);
      const isPrimary=String(user.email||'').toLowerCase()===PRIMARY_ADMIN_EMAIL;
      if(action==='deleteAccount') {
        if(uid===actor || isPrimary)throw new HttpsError('failed-precondition','No puedes eliminar tu cuenta ni la cuenta principal.');
        const other=Object.entries(old.apps||{}).filter(([k,v])=>k!=='travel'&&v===true);
        if(other.length)throw new HttpsError('failed-precondition','Esta cuenta utiliza otras aplicaciones. Retira solo el acceso a Viajes.');
        await lastAdminGuard(uid,'viewer',false);
        await auth.deleteUser(uid);
        await ref.delete();
        await log(actor,action,uid);
        return {ok:true,deleted:true};
      }
      let nextRole=roleOf(old),nextEnabled=permitted(old),updates={updatedAt:FieldValue.serverTimestamp()};
      if(action==='update') {
        nextRole=roleValue(request.data?.role||nextRole);
        if(isPrimary && nextRole!=='admin')throw new HttpsError('failed-precondition','La cuenta principal debe conservar el rol administrador.');
        const displayName=clean(request.data?.displayName,100),email=emailOf(request.data?.email||user.email);
        if(!displayName)invalid('El nombre es obligatorio.');
        if(isPrimary && email!==String(user.email||'').toLowerCase())throw new HttpsError('failed-precondition','El correo del administrador principal está vinculado a reglas de otras aplicaciones y no se cambia desde aquí.');
        if(email!==user.email || displayName!==user.displayName){
          await auth.updateUser(uid,{email,displayName});
        }
        updates={...updates,email,displayName,travelRole:nextRole};
      }
      if(action==='access' || action==='remove') {
        nextEnabled=action==='remove'?false:request.data?.enabled===true;
        if(!nextEnabled && (uid===actor || isPrimary))throw new HttpsError('failed-precondition','No puedes desactivar tu propio acceso ni el de la cuenta principal.');
        updates={...updates,travelEnabled:nextEnabled,apps:{...(old.apps||{}),travel:nextEnabled}};
      }
      await lastAdminGuard(uid,nextRole,nextEnabled);
      await ref.set(updates,{merge:true});
      await auth.revokeRefreshTokens(uid).catch(console.error);
      await log(actor,action,uid);
      return {ok:true};
    }catch(error){
      logFailure(phase,error);
      throw normal(error,phase);
    }
  });
}
module.exports={buildManager,roleOf,permitted,isAdmin};
