'use strict';

// Gestión de identidades MFE Viajes. Ninguna operación privilegiada se realiza en el cliente.
const {onCall, HttpsError} = require('firebase-functions/v2/https');
const {getAuth} = require('firebase-admin/auth');
const {getFirestore, FieldValue} = require('firebase-admin/firestore');

const ROLES = new Set(['admin', 'editor', 'viewer']);
const PRIMARY_ADMIN_EMAIL = 'mikelferech@gmail.com';
const clean = (v, max=140) => String(v ?? '').trim().slice(0, max);
const roleOf = p => p?.travelRole || p?.role || 'viewer';
const permitted = p => p?.travelEnabled !== false && p?.apps?.travel === true;
const isAdmin = p => permitted(p) && roleOf(p) === 'admin';
const invalid = message => {throw new HttpsError('invalid-argument', message);};
const emailOf = value => {
  const s = clean(value, 254).toLowerCase();
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s)) invalid('Introduce una dirección de correo válida.');
  return s;
};
const roleValue = role => {
  const value = clean(role, 20);
  if(!ROLES.has(value)) invalid('Rol no válido.');
  return value;
};
const normal = err => {
  if(err instanceof HttpsError) return err;
  if(err?.code === 'auth/email-already-exists') return new HttpsError('already-exists','Ya existe una cuenta con ese correo. Usa «Dar acceso a cuenta existente».');
  if(err?.code === 'auth/user-not-found') return new HttpsError('not-found','No existe ese usuario en Firebase.');
  if(err?.code === 'auth/invalid-email') return new HttpsError('invalid-argument','Correo no válido.');
  return new HttpsError('internal','No se pudo completar la operación. Revisa el registro de Firebase Functions.');
};

function buildManager() {
  const db = getFirestore();
  const auth = getAuth();
  async function assertAdmin(request) {
    if(!request.auth) throw new HttpsError('unauthenticated','Debes iniciar sesión.');
    const snap = await db.doc(`mfeUsers/${request.auth.uid}`).get();
    const profile = snap.data();
    if(!isAdmin(profile) && !(String(request.auth.token.email||'').toLowerCase()===PRIMARY_ADMIN_EMAIL && profile?.travelEnabled!==false)) throw new HttpsError('permission-denied','Solo los administradores de Viajes pueden gestionar usuarios.');
    return request.auth.uid;
  }
  async function lastAdminGuard(targetUid, nextRole, nextEnabled) {
    const snap=await db.collection('mfeUsers').where('travelRole','==','admin').get();
    const legacy=await db.collection('mfeUsers').where('role','==','admin').get();
    const candidates=new Map([...snap.docs,...legacy.docs].map(doc=>[doc.id,doc.data()]));
    const others=[...candidates].filter(([uid,p])=>uid!==targetUid && isAdmin(p));
    if(nextRole!=='admin'||!nextEnabled) {
      if(!others.length) throw new HttpsError('failed-precondition','No puedes retirar el permiso al último administrador activo.');
    }
  }
  async function log(actor,action,target) {
    await db.collection('mfeTravelUserAudit').add({actor,action,target,at:FieldValue.serverTimestamp()}).catch(err=>console.error('Audit:',err));
  }
  return onCall({region:'europe-west1',timeoutSeconds:45,memory:'256MiB',maxInstances:3},async request=>{
    const actor=await assertAdmin(request);
    const action=clean(request.data?.action,25);
    try {
      if(action==='list') {
        const snap=await db.collection('mfeUsers').limit(400).get();
        const docs=snap.docs.filter(d=>d.data()?.apps?.travel===true || d.data()?.travelRole!=null || d.data()?.role==='admin');
        const users=[];
        for(let i=0;i<docs.length;i+=75) {
          const part=docs.slice(i,i+75);
          const found=await auth.getUsers(part.map(d=>({uid:d.id}))).catch(()=>({users:[]}));
          const byId=new Map(found.users.map(u=>[u.uid,u]));
          for(const doc of part) {
            const p=doc.data(),user=byId.get(doc.id);
            users.push({uid:doc.id,email:user?.email||p.email||'',displayName:p.displayName||user?.displayName||'',role:roleOf(p),enabled:permitted(p),emailVerified:user?.emailVerified===true,lastSignIn:user?.metadata?.lastSignInTime||'',otherApps:Object.entries(p.apps||{}).filter(([k,v])=>k!=='travel'&&v===true).map(([k])=>k),missingAuth:!user});
          }
        }
        users.sort((a,b)=>a.displayName.localeCompare(b.displayName,'es'));
        return {users,me:actor};
      }
      if(action==='create' || action==='grant') {
        const email=emailOf(request.data?.email),displayName=clean(request.data?.displayName,100),role=roleValue(request.data?.role||'viewer');
        if(!displayName)invalid('El nombre es obligatorio.');
        let user,created=false;
        if(action==='create') {
          const password=String(request.data?.password||'');
          if(password.length<8 || password.length>128)invalid('La contraseña inicial debe tener entre 8 y 128 caracteres.');
          user=await auth.createUser({email,password,displayName,emailVerified:false});created=true;
        } else {
          user=await auth.getUserByEmail(email);
        }
        const ref=db.doc(`mfeUsers/${user.uid}`);
        try{
          const old=(await ref.get()).data()||{};
          await ref.set({
            ...old,
            email, displayName, travelRole:role, travelEnabled:true,
            // El rol global pertenece al proyecto compartido: no se eleva por ser admin en Viajes.
            role: old.role || 'viewer',
            apps: {...(old.apps||{}), travel:true, ...(!Object.keys(old.apps||{}).length?{hogar:false,ahorro:false}:{})},
            updatedAt:FieldValue.serverTimestamp()
          },{merge:true});
        }catch(error){if(created) await auth.deleteUser(user.uid).catch(console.error);throw error;}
        await log(actor,action,user.uid);
        return {uid:user.uid,email,created};
      }
      if(!['update','access','remove','deleteAccount'].includes(action)) invalid('Operación desconocida.');
      const uid=clean(request.data?.uid,150);
      if(!uid)invalid('Identificador de usuario obligatorio.');
      const ref=db.doc(`mfeUsers/${uid}`);
      const snap=await ref.get();
      if(!snap.exists)throw new HttpsError('not-found','El perfil solicitado no existe.');
      const old=snap.data();
      const user=await auth.getUser(uid);
      const isPrimary=String(user.email||'').toLowerCase()===PRIMARY_ADMIN_EMAIL;
      if(action==='deleteAccount') {
        if(uid===actor || isPrimary)throw new HttpsError('failed-precondition','No puedes eliminar tu cuenta ni la cuenta principal.');
        const other=Object.entries(old.apps||{}).filter(([k,v])=>k!=='travel'&&v===true);
        if(other.length)throw new HttpsError('failed-precondition','Esta cuenta utiliza otras aplicaciones. Retira solo el acceso a Viajes.');
        await lastAdminGuard(uid,'viewer',false);
        await auth.deleteUser(uid);
        await ref.delete();
        await log(actor,action,uid);
        return {ok:true,deleted:true};
      }
      let nextRole=roleOf(old),nextEnabled=permitted(old),updates={updatedAt:FieldValue.serverTimestamp()};
      if(action==='update') {
        nextRole=roleValue(request.data?.role||nextRole);
        if(isPrimary && nextRole!=='admin')throw new HttpsError('failed-precondition','La cuenta principal debe conservar el rol administrador.');
        const displayName=clean(request.data?.displayName,100),email=emailOf(request.data?.email||user.email);
        if(!displayName)invalid('El nombre es obligatorio.');
        if(isPrimary && email!==String(user.email||'').toLowerCase())throw new HttpsError('failed-precondition','El correo del administrador principal está vinculado a reglas de otras aplicaciones y no se cambia desde aquí.');
        if(email!==user.email || displayName!==user.displayName){
          await auth.updateUser(uid,{email,displayName});
        }
        updates={...updates,email,displayName,travelRole:nextRole};
      }
      if(action==='access' || action==='remove') {
        nextEnabled=action==='remove'?false:request.data?.enabled===true;
        if(!nextEnabled && (uid===actor || isPrimary))throw new HttpsError('failed-precondition','No puedes desactivar tu propio acceso ni el de la cuenta principal.');
        updates={...updates,travelEnabled:nextEnabled,apps:{...(old.apps||{}),travel:nextEnabled}};
      }
      await lastAdminGuard(uid,nextRole,nextEnabled);
      await ref.set(updates,{merge:true});
      await auth.revokeRefreshTokens(uid).catch(console.error);
      await log(actor,action,uid);
      return {ok:true};
    }catch(error){console.error('manageTravelUsers',action,error);throw normal(error);}
  });
}
module.exports={buildManager,roleOf,permitted,isAdmin};
