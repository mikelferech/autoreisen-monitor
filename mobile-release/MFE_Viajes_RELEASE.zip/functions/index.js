const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { initializeApp } = require("firebase-admin/app");
const { getFirestore } = require("firebase-admin/firestore");
const { getStorage } = require("firebase-admin/storage");
const vision = require("@google-cloud/vision");
const cheerio = require("cheerio");

initializeApp();
const db = getFirestore();
const REGION = "europe-west1";

async function requireTravelUser(request, edit = false) {
  if (!request.auth) throw new HttpsError("unauthenticated", "Debes iniciar sesión.");
  const snap = await db.doc(`mfeUsers/${request.auth.uid}`).get();
  if (!snap.exists) throw new HttpsError("permission-denied", "No existe el perfil de acceso.");
  const profile = snap.data();
  const hasAccess = profile.role === "admin" || profile.apps?.travel === true;
  if (!hasAccess) throw new HttpsError("permission-denied", "No tienes acceso a MFE Viajes.");
  if (edit && !["admin", "editor"].includes(profile.role)) throw new HttpsError("permission-denied", "No tienes permiso de edición.");
  return profile;
}

function findProductJson(value) {
  if (!value) return null;
  if (Array.isArray(value)) {
    for (const item of value) { const found = findProductJson(item); if (found) return found; }
    return null;
  }
  if (typeof value !== "object") return null;
  const type = value["@type"];
  if (type === "Product" || (Array.isArray(type) && type.includes("Product"))) return value;
  if (value["@graph"]) return findProductJson(value["@graph"]);
  for (const child of Object.values(value)) { const found = findProductJson(child); if (found) return found; }
  return null;
}

exports.importProductFromUrl = onCall({ region: REGION, timeoutSeconds: 30, memory: "512MiB" }, async (request) => {
  await requireTravelUser(request, true);
  const rawUrl = String(request.data?.url || "").trim();
  let url;
  try { url = new URL(rawUrl); } catch { throw new HttpsError("invalid-argument", "La URL no es válida."); }
  if (!['http:', 'https:'].includes(url.protocol)) throw new HttpsError("invalid-argument", "Solo se admiten URLs web.");

  const controller = new AbortController(); const timer = setTimeout(() => controller.abort(), 16000);
  let response;
  try {
    response = await fetch(url, { signal: controller.signal, redirect: "follow", headers: {
      "User-Agent": "Mozilla/5.0 (compatible; MFEViajes/1.0; +private-travel-planner)",
      "Accept-Language": "es-ES,es;q=0.9,en;q=0.6"
    }});
  } catch (error) { throw new HttpsError("unavailable", `No se pudo abrir la página: ${error.message}`); }
  finally { clearTimeout(timer); }
  if (!response.ok) throw new HttpsError("unavailable", `La tienda respondió ${response.status}.`);
  const html = await response.text(); const $ = cheerio.load(html);

  let product = null;
  $('script[type="application/ld+json"]').each((_, node) => {
    if (product) return;
    try { product = findProductJson(JSON.parse($(node).text())); } catch { /* JSON-LD inválido */ }
  });
  const offers = Array.isArray(product?.offers) ? product.offers[0] : product?.offers;
  const name = product?.name || $('meta[property="og:title"]').attr("content") || $("h1").first().text().trim();
  const imageValue = product?.image || $('meta[property="og:image"]').attr("content") || "";
  const image = Array.isArray(imageValue) ? imageValue[0] : (typeof imageValue === "object" ? imageValue.url : imageValue);
  const priceRaw = offers?.price || offers?.lowPrice || $('meta[property="product:price:amount"]').attr("content") || $('[itemprop="price"]').attr("content") || "";
  const price = Number.parseFloat(String(priceRaw).replace(/[^0-9,.-]/g, "").replace(",", "."));

  if (!name && !Number.isFinite(price)) throw new HttpsError("not-found", "La página no expone datos estructurados del producto. Introduce el precio manualmente.");
  return { name: name || "", image: image || "", price: Number.isFinite(price) ? price : null, currency: offers?.priceCurrency || "EUR" };
});

function parseEuropeanNumber(value) {
  const clean = String(value).replace(/\s/g, "").replace(/\.(?=\d{3}(?:\D|$))/g, "").replace(",", ".");
  const number = Number.parseFloat(clean); return Number.isFinite(number) ? number : null;
}
function parseReceipt(text) {
  const lines = text.split(/\r?\n/).map(s => s.trim()).filter(Boolean);
  const store = lines.find(line => /[A-ZÁÉÍÓÚÑ]{3,}/.test(line)) || lines[0] || "";
  const dateMatch = text.match(/\b(\d{1,2})[\/.\-](\d{1,2})[\/.\-](\d{2,4})\b/);
  let date = "";
  if (dateMatch) { let year = dateMatch[3]; if (year.length === 2) year = `20${year}`; date = `${year}-${dateMatch[2].padStart(2,"0")}-${dateMatch[1].padStart(2,"0")}`; }
  let total = null;
  for (const line of [...lines].reverse()) {
    const match = line.match(/(?:TOTAL|IMPORTE|A PAGAR|TOTAL EUR)[^0-9]*(\d+[.,]\d{2})/i);
    if (match) { total = parseEuropeanNumber(match[1]); break; }
  }
  const items = [];
  for (const line of lines) {
    if (/TOTAL|SUBTOTAL|IVA|TARJETA|EFECTIVO|CAMBIO|IMPORTE|NIF|CIF|TEL|GRACIAS/i.test(line)) continue;
    const match = line.match(/^(.{3,}?)\s+(\d+[.,]\d{2})\s*(?:€|EUR)?$/i);
    if (match) { const price = parseEuropeanNumber(match[2]); if (price !== null) items.push({ name:match[1].replace(/\s{2,}/g," ").trim(), price }); }
  }
  return { store:store.slice(0,80), date, total, items:items.slice(0,150), rawText:text };
}

function driveDownloadUrl(rawUrl) {
  try { const url=new URL(rawUrl); if(url.hostname.includes("drive.google.com")){const id=url.pathname.match(/\/file\/d\/([^/]+)/)?.[1]||url.searchParams.get("id");if(id)return `https://drive.google.com/uc?export=download&id=${encodeURIComponent(id)}`;}return rawUrl; } catch { return rawUrl; }
}
async function readTicketSource(storagePath, rawUrl) {
  if(storagePath){if(!storagePath.startsWith("travelApps/"))throw new HttpsError("invalid-argument","Ruta de ticket no válida.");const file=getStorage().bucket().file(storagePath);const[metadata]=await file.getMetadata();const[buffer]=await file.download();return{buffer,contentType:metadata.contentType||"",storagePath};}
  if(!rawUrl)throw new HttpsError("invalid-argument","Falta el archivo o enlace del ticket.");const response=await fetch(driveDownloadUrl(rawUrl),{redirect:"follow",headers:{"User-Agent":"Mozilla/5.0 MFEViajes OCR"}});if(!response.ok)throw new HttpsError("unavailable",`No se pudo descargar el ticket: HTTP ${response.status}. Revisa los permisos de Drive.`);return{buffer:Buffer.from(await response.arrayBuffer()),contentType:response.headers.get("content-type")||"",storagePath:""};
}
async function visionTextFromPdf(buffer) {
  const bucket=getStorage().bucket();const token=`ocr-temp/${Date.now()}-${Math.random().toString(36).slice(2)}.pdf`;const input=bucket.file(token);await input.save(buffer,{contentType:"application/pdf"});const outputPrefix=`ocr-output/${Date.now()}-${Math.random().toString(36).slice(2)}/`;const client=new vision.ImageAnnotatorClient();try{const[operation]=await client.asyncBatchAnnotateFiles({requests:[{inputConfig:{gcsSource:{uri:`gs://${bucket.name}/${token}`},mimeType:"application/pdf"},features:[{type:"DOCUMENT_TEXT_DETECTION"}],outputConfig:{gcsDestination:{uri:`gs://${bucket.name}/${outputPrefix}`},batchSize:5}}]});await operation.promise();const[files]=await bucket.getFiles({prefix:outputPrefix});let text="";for(const file of files){if(!file.name.endsWith('.json'))continue;const[jsonBuffer]=await file.download();const data=JSON.parse(jsonBuffer.toString('utf8'));for(const response of data.responses||[])text+=`${response.fullTextAnnotation?.text||response.textAnnotations?.[0]?.description||""}\n`;}return text;}finally{await input.delete({ignoreNotFound:true});const[outs]=await bucket.getFiles({prefix:outputPrefix});await Promise.all(outs.map(f=>f.delete({ignoreNotFound:true})));}}
exports.ocrTicket = onCall({ region: REGION, timeoutSeconds: 300, memory: "1GiB" }, async (request) => {
  await requireTravelUser(request, true);const source=await readTicketSource(String(request.data?.storagePath||"").trim(),String(request.data?.url||"").trim());let text="";const isPdf=/pdf/i.test(source.contentType)||String(request.data?.url||"").toLowerCase().includes('.pdf');if(isPdf)text=await visionTextFromPdf(source.buffer);else{const client=new vision.ImageAnnotatorClient();const[result]=await client.documentTextDetection({image:{content:source.buffer}});text=result.fullTextAnnotation?.text||result.textAnnotations?.[0]?.description||"";}if(!text)throw new HttpsError("not-found","No se ha detectado texto en el ticket.");return parseReceipt(text);
});

// Recordatorios push de tareas y vuelos. Requiere desplegar Functions y disponer de tokens FCM activos.
const { onSchedule } = require("firebase-functions/v2/scheduler");
const { getMessaging } = require("firebase-admin/messaging");

function dueReminder(item, field, sentField, now, windowMs = 20 * 60 * 1000) {
  const timestamp = Number(item?.[field] || 0);
  return Boolean(timestamp && !item?.[sentField] && timestamp <= now + 2 * 60 * 1000 && timestamp >= now - windowMs);
}

exports.sendTravelReminders = onSchedule({
  region: REGION,
  schedule: "every 15 minutes",
  timeZone: "Europe/Madrid",
  timeoutSeconds: 120
}, async () => {
  const tripId = "viaje-verano-2026";
  const now = Date.now();
  const [tasksSnap, coverSnap, devicesSnap] = await Promise.all([
    db.doc(`travelApps/${tripId}/sections/tasks`).get(),
    db.doc(`travelApps/${tripId}/sections/cover`).get(),
    db.collection(`travelApps/${tripId}/pushDevices`).where("enabled", "==", true).get()
  ]);
  const tokens = devicesSnap.docs.map(doc => doc.data()?.token).filter(Boolean);
  if (!tokens.length) return;

  const tasksValue = tasksSnap.data()?.value || { items:[] };
  const coverValue = coverSnap.data()?.value || { flights:[] };
  const notifications = [];

  for (const task of tasksValue.items || []) {
    if (task.completed || !dueReminder(task, "notifyAt", "notifiedAt", now)) continue;
    notifications.push({
      title:`Tarea pendiente · ${task.title || "MFE Viajes"}`,
      body:task.description || "Tienes una tarea prevista para el viaje.",
      tag:`task-${task.id || now}`,
      mark:() => { task.notifiedAt = new Date().toISOString(); }
    });
  }

  for (const flight of coverValue.flights || []) {
    if (dueReminder(flight, "checkInNotifyAt", "checkInNotifiedAt", now, 30 * 60 * 1000)) {
      notifications.push({
        title:`Check-in · vuelo ${flight.number || ""}`.trim(),
        body:`Ya puedes revisar el check-in de ${flight.from || "origen"} a ${flight.to || "destino"}.`,
        tag:`checkin-${flight.id || flight.number || now}`,
        mark:() => { flight.checkInNotifiedAt = new Date().toISOString(); }
      });
    }
    if (dueReminder(flight, "leaveNotifyAt", "leaveNotifiedAt", now, 30 * 60 * 1000)) {
      notifications.push({
        title:`Hora de salir hacia el aeropuerto`,
        body:`Vuelo ${flight.number || ""} · ${flight.from || ""} → ${flight.to || ""}`,
        tag:`leave-${flight.id || flight.number || now}`,
        mark:() => { flight.leaveNotifiedAt = new Date().toISOString(); }
      });
    }
  }

  for (const notification of notifications) {
    const response = await getMessaging().sendEachForMulticast({
      tokens,
      data:{
        title:notification.title,
        body:notification.body,
        tag:notification.tag,
        url:"/"
      },
      webpush:{ headers:{ Urgency:"high" } }
    });
    if (response.successCount > 0) notification.mark();
  }

  const writes = [];
  if (notifications.some(n => n.tag.startsWith("task-"))) writes.push(tasksSnap.ref.set({value:tasksValue,updatedAt:new Date()},{merge:true}));
  if (notifications.some(n => n.tag.startsWith("checkin-") || n.tag.startsWith("leave-"))) writes.push(coverSnap.ref.set({value:coverValue,updatedAt:new Date()},{merge:true}));
  await Promise.all(writes);
});
