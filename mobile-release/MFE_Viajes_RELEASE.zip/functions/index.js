const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { initializeApp } = require("firebase-admin/app");
const { getFirestore } = require("firebase-admin/firestore");
const { getStorage } = require("firebase-admin/storage");
const vision = require("@google-cloud/vision");
const cheerio = require("cheerio");

initializeApp();
const db = getFirestore();
const REGION = "europe-west1";

async function requireTravelUser(request, edit = false) {
  if (!request.auth) throw new HttpsError("unauthenticated", "Debes iniciar sesión.");
  const snap = await db.doc(`mfeUsers/${request.auth.uid}`).get();
  if (!snap.exists) throw new HttpsError("permission-denied", "No existe el perfil de acceso.");
  const profile = snap.data();
  const hasAccess = profile.role === "admin" || profile.apps?.travel === true;
  if (!hasAccess) throw new HttpsError("permission-denied", "No tienes acceso a MFE Viajes.");
  if (edit && !["admin", "editor"].includes(profile.role)) throw new HttpsError("permission-denied", "No tienes permiso de edición.");
  return profile;
}

function findProductJson(value) {
  if (!value) return null;
  if (Array.isArray(value)) {
    for (const item of value) { const found = findProductJson(item); if (found) return found; }
    return null;
  }
  if (typeof value !== "object") return null;
  const type = value["@type"];
  if (type === "Product" || (Array.isArray(type) && type.includes("Product"))) return value;
  if (value["@graph"]) return findProductJson(value["@graph"]);
  for (const child of Object.values(value)) { const found = findProductJson(child); if (found) return found; }
  return null;
}

exports.importProductFromUrl = onCall({ region: REGION, timeoutSeconds: 30, memory: "512MiB" }, async (request) => {
  await requireTravelUser(request, true);
  const rawUrl = String(request.data?.url || "").trim();
  let url;
  try { url = new URL(rawUrl); } catch { throw new HttpsError("invalid-argument", "La URL no es válida."); }
  if (!['http:', 'https:'].includes(url.protocol)) throw new HttpsError("invalid-argument", "Solo se admiten URLs web.");

  const controller = new AbortController(); const timer = setTimeout(() => controller.abort(), 16000);
  let response;
  try {
    response = await fetch(url, { signal: controller.signal, redirect: "follow", headers: {
      "User-Agent": "Mozilla/5.0 (compatible; MFEViajes/1.0; +private-travel-planner)",
      "Accept-Language": "es-ES,es;q=0.9,en;q=0.6"
    }});
  } catch (error) { throw new HttpsError("unavailable", `No se pudo abrir la página: ${error.message}`); }
  finally { clearTimeout(timer); }
  if (!response.ok) throw new HttpsError("unavailable", `La tienda respondió ${response.status}.`);
  const html = await response.text(); const $ = cheerio.load(html);

  let product = null;
  $('script[type="application/ld+json"]').each((_, node) => {
    if (product) return;
    try { product = findProductJson(JSON.parse($(node).text())); } catch { /* JSON-LD inválido */ }
  });
  const offers = Array.isArray(product?.offers) ? product.offers[0] : product?.offers;
  const name = product?.name || $('meta[property="og:title"]').attr("content") || $("h1").first().text().trim();
  const imageValue = product?.image || $('meta[property="og:image"]').attr("content") || "";
  const image = Array.isArray(imageValue) ? imageValue[0] : (typeof imageValue === "object" ? imageValue.url : imageValue);
  const priceRaw = offers?.price || offers?.lowPrice || $('meta[property="product:price:amount"]').attr("content") || $('[itemprop="price"]').attr("content") || "";
  const price = Number.parseFloat(String(priceRaw).replace(/[^0-9,.-]/g, "").replace(",", "."));

  if (!name && !Number.isFinite(price)) throw new HttpsError("not-found", "La página no expone datos estructurados del producto. Introduce el precio manualmente.");
  return { name: name || "", image: image || "", price: Number.isFinite(price) ? price : null, currency: offers?.priceCurrency || "EUR" };
});

function parseEuropeanNumber(value) {
  const clean = String(value).replace(/\s/g, "").replace(/\.(?=\d{3}(?:\D|$))/g, "").replace(",", ".");
  const number = Number.parseFloat(clean); return Number.isFinite(number) ? number : null;
}
function parseReceipt(text) {
  const lines = text.split(/\r?\n/).map(s => s.trim()).filter(Boolean);
  const store = lines.find(line => /[A-ZÁÉÍÓÚÑ]{3,}/.test(line)) || lines[0] || "";
  const dateMatch = text.match(/\b(\d{1,2})[\/.\-](\d{1,2})[\/.\-](\d{2,4})\b/);
  let date = "";
  if (dateMatch) { let year = dateMatch[3]; if (year.length === 2) year = `20${year}`; date = `${year}-${dateMatch[2].padStart(2,"0")}-${dateMatch[1].padStart(2,"0")}`; }
  let total = null;
  for (const line of [...lines].reverse()) {
    const match = line.match(/(?:TOTAL|IMPORTE|A PAGAR|TOTAL EUR)[^0-9]*(\d+[.,]\d{2})/i);
    if (match) { total = parseEuropeanNumber(match[1]); break; }
  }
  const items = [];
  for (const line of lines) {
    if (/TOTAL|SUBTOTAL|IVA|TARJETA|EFECTIVO|CAMBIO|IMPORTE|NIF|CIF|TEL|GRACIAS/i.test(line)) continue;
    const match = line.match(/^(.{3,}?)\s+(\d+[.,]\d{2})\s*(?:€|EUR)?$/i);
    if (match) { const price = parseEuropeanNumber(match[2]); if (price !== null) items.push({ name:match[1].replace(/\s{2,}/g," ").trim(), price }); }
  }
  return { store:store.slice(0,80), date, total, items:items.slice(0,150), rawText:text };
}

function driveDownloadUrl(rawUrl) {
  try { const url=new URL(rawUrl); if(url.hostname.includes("drive.google.com")){const id=url.pathname.match(/\/file\/d\/([^/]+)/)?.[1]||url.searchParams.get("id");if(id)return `https://drive.google.com/uc?export=download&id=${encodeURIComponent(id)}`;}return rawUrl; } catch { return rawUrl; }
}
async function readTicketSource(storagePath, rawUrl) {
  if(storagePath){if(!storagePath.startsWith("travelApps/"))throw new HttpsError("invalid-argument","Ruta de ticket no válida.");const file=getStorage().bucket().file(storagePath);const[metadata]=await file.getMetadata();const[buffer]=await file.download();return{buffer,contentType:metadata.contentType||"",storagePath};}
  if(!rawUrl)throw new HttpsError("invalid-argument","Falta el archivo o enlace del ticket.");const response=await fetch(driveDownloadUrl(rawUrl),{redirect:"follow",headers:{"User-Agent":"Mozilla/5.0 MFEViajes OCR"}});if(!response.ok)throw new HttpsError("unavailable",`No se pudo descargar el ticket: HTTP ${response.status}. Revisa los permisos de Drive.`);return{buffer:Buffer.from(await response.arrayBuffer()),contentType:response.headers.get("content-type")||"",storagePath:""};
}
async function visionTextFromPdf(buffer) {
  const bucket=getStorage().bucket();const token=`ocr-temp/${Date.now()}-${Math.random().toString(36).slice(2)}.pdf`;const input=bucket.file(token);await input.save(buffer,{contentType:"application/pdf"});const outputPrefix=`ocr-output/${Date.now()}-${Math.random().toString(36).slice(2)}/`;const client=new vision.ImageAnnotatorClient();try{const[operation]=await client.asyncBatchAnnotateFiles({requests:[{inputConfig:{gcsSource:{uri:`gs://${bucket.name}/${token}`},mimeType:"application/pdf"},features:[{type:"DOCUMENT_TEXT_DETECTION"}],outputConfig:{gcsDestination:{uri:`gs://${bucket.name}/${outputPrefix}`},batchSize:5}}]});await operation.promise();const[files]=await bucket.getFiles({prefix:outputPrefix});let text="";for(const file of files){if(!file.name.endsWith('.json'))continue;const[jsonBuffer]=await file.download();const data=JSON.parse(jsonBuffer.toString('utf8'));for(const response of data.responses||[])text+=`${response.fullTextAnnotation?.text||response.textAnnotations?.[0]?.description||""}\n`;}return text;}finally{await input.delete({ignoreNotFound:true});const[outs]=await bucket.getFiles({prefix:outputPrefix});await Promise.all(outs.map(f=>f.delete({ignoreNotFound:true})));}}
exports.ocrTicket = onCall({ region: REGION, timeoutSeconds: 300, memory: "1GiB" }, async (request) => {
  await requireTravelUser(request, true);const source=await readTicketSource(String(request.data?.storagePath||"").trim(),String(request.data?.url||"").trim());let text="";const isPdf=/pdf/i.test(source.contentType)||String(request.data?.url||"").toLowerCase().includes('.pdf');if(isPdf)text=await visionTextFromPdf(source.buffer);else{const client=new vision.ImageAnnotatorClient();const[result]=await client.documentTextDetection({image:{content:source.buffer}});text=result.fullTextAnnotation?.text||result.textAnnotations?.[0]?.description||"";}if(!text)throw new HttpsError("not-found","No se ha detectado texto en el ticket.");return parseReceipt(text);
});

// Recordatorios push de tareas y vuelos. Requiere desplegar Functions y disponer de tokens FCM activos.
const { onSchedule } = require("firebase-functions/v2/scheduler");
const { getMessaging } = require("firebase-admin/messaging");

function dueReminder(item, field, sentField, now, windowMs = 20 * 60 * 1000) {
  const timestamp = Number(item?.[field] || 0);
  return Boolean(timestamp && !item?.[sentField] && timestamp <= now + 2 * 60 * 1000 && timestamp >= now - windowMs);
}

exports.sendTravelReminders = onSchedule({
  region: REGION,
  schedule: "every 15 minutes",
  timeZone: "Europe/Madrid",
  timeoutSeconds: 120
}, async () => {
  const tripId = "viaje-verano-2026";
  const now = Date.now();
  const [tasksSnap, coverSnap, devicesSnap] = await Promise.all([
    db.doc(`travelApps/${tripId}/sections/tasks`).get(),
    db.doc(`travelApps/${tripId}/sections/cover`).get(),
    db.collection(`travelApps/${tripId}/pushDevices`).where("enabled", "==", true).get()
  ]);
  const tokens = devicesSnap.docs.map(doc => doc.data()?.token).filter(Boolean);
  if (!tokens.length) return;

  const tasksValue = tasksSnap.data()?.value || { items:[] };
  const coverValue = coverSnap.data()?.value || { flights:[] };
  const notifications = [];

  for (const task of tasksValue.items || []) {
    if (task.completed || !dueReminder(task, "notifyAt", "notifiedAt", now)) continue;
    notifications.push({
      title:`Tarea pendiente · ${task.title || "MFE Viajes"}`,
      body:task.description || "Tienes una tarea prevista para el viaje.",
      tag:`task-${task.id || now}`,
      mark:() => { task.notifiedAt = new Date().toISOString(); }
    });
  }

  for (const flight of coverValue.flights || []) {
    if (dueReminder(flight, "checkInNotifyAt", "checkInNotifiedAt", now, 30 * 60 * 1000)) {
      notifications.push({
        title:`Check-in · vuelo ${flight.number || ""}`.trim(),
        body:`Ya puedes revisar el check-in de ${flight.from || "origen"} a ${flight.to || "destino"}.`,
        tag:`checkin-${flight.id || flight.number || now}`,
        mark:() => { flight.checkInNotifiedAt = new Date().toISOString(); }
      });
    }
    if (dueReminder(flight, "leaveNotifyAt", "leaveNotifiedAt", now, 30 * 60 * 1000)) {
      notifications.push({
        title:`Hora de salir hacia el aeropuerto`,
        body:`Vuelo ${flight.number || ""} · ${flight.from || ""} → ${flight.to || ""}`,
        tag:`leave-${flight.id || flight.number || now}`,
        mark:() => { flight.leaveNotifiedAt = new Date().toISOString(); }
      });
    }
  }

  for (const notification of notifications) {
    const response = await getMessaging().sendEachForMulticast({
      tokens,
      data:{
        title:notification.title,
        body:notification.body,
        tag:notification.tag,
        url:"/"
      },
      webpush:{ headers:{ Urgency:"high" } }
    });
    if (response.successCount > 0) notification.mark();
  }

  const writes = [];
  if (notifications.some(n => n.tag.startsWith("task-"))) writes.push(tasksSnap.ref.set({value:tasksValue,updatedAt:new Date()},{merge:true}));
  if (notifications.some(n => n.tag.startsWith("checkin-") || n.tag.startsWith("leave-"))) writes.push(coverSnap.ref.set({value:coverValue,updatedAt:new Date()},{merge:true}));
  await Promise.all(writes);
});

// v2.3.25 · Piscinas Cordial Santa Águeda / Perchel Beach Club + webcams directas.
const POOL_SOURCE_URL = "https://cordial.galileus.es/gweb/siloe/diario/?token=NUEraFBKcnlEYzdUVVRobnRPMHc5Zz09";
const TRAVEL_TRIP_ID = "viaje-verano-2026";
const WEBCAM_PAGES = {
  "santa-agueda": {
    title: "Santa Águeda · El Pajar",
    url: "https://in2thebeach.es/webcam/71/el-pajar-santa-agueda-arguineguin/"
  },
  "el-perchel": {
    title: "Playa de El Perchel",
    url: "https://www.skylinewebcams.com/es/webcam/espana/canarias/las-palmas-gran-canaria/arguineguin-playa-de-el-perchel.html"
  }
};

function cleanRemoteText(value) {
  return String(value ?? "").replace(/\u00a0/g, " ").replace(/\s+/g, " ").trim();
}
function absoluteRemoteUrl(value, base) {
  try { return new URL(String(value || "").replace(/\\u0026/g,"&").replace(/\\\//g,"/"), base).href; }
  catch { return ""; }
}
function metricNumber(value) {
  const match=cleanRemoteText(value).replace(/,/g,'.').match(/-?\d+(?:\.\d+)?/);
  const n=match?Number.parseFloat(match[0]):NaN;
  return Number.isFinite(n)?n:null;
}
function findTemperatureMetric(metrics=[]) {
  for(const metric of metrics){
    const label=cleanRemoteText(metric.label).toLocaleLowerCase('es');
    if(/temperatura|temperature|temp\.?\b/.test(label)){
      const n=metricNumber(metric.value);
      if(n!==null && n>-5 && n<60)return n;
    }
  }
  return null;
}
function pickMeasurementTime(metrics=[], bodyText="") {
  const joined=[...metrics.map(m=>`${m.label} ${m.value}`),bodyText].join(' ');
  const date=joined.match(/\b(\d{1,2})[\/.\-](\d{1,2})[\/.\-](\d{2,4})\b/);
  const time=joined.match(/\b([01]?\d|2[0-3]):([0-5]\d)(?::([0-5]\d))?\b/);
  let dateIso="";
  if(date){let y=date[3];if(y.length===2)y=`20${y}`;dateIso=`${y}-${date[2].padStart(2,'0')}-${date[1].padStart(2,'0')}`;}
  return {date:dateIso,time:time?`${time[1].padStart(2,'0')}:${time[2]}`:""};
}
function metricPairsFromPage($) {
  const pairs=[];
  const add=(label,value)=>{
    label=cleanRemoteText(label);value=cleanRemoteText(value);
    if(!label||!value||label===value||label.length>90||value.length>140)return;
    const key=`${label.toLocaleLowerCase('es')}|${value.toLocaleLowerCase('es')}`;
    if(!pairs.some(x=>x._key===key))pairs.push({label,value,_key:key});
  };
  $('tr').each((_,row)=>{
    const cells=$(row).find('th,td').map((__,cell)=>cleanRemoteText($(cell).text())).get().filter(Boolean);
    if(cells.length===2)add(cells[0],cells[1]);
    else if(cells.length>2){
      const headers=$(row).closest('table').find('tr').first().find('th').map((__,cell)=>cleanRemoteText($(cell).text())).get();
      if(headers.length===cells.length && !$(row).find('th').length){for(let i=0;i<cells.length;i++)add(headers[i]||`Dato ${i+1}`,cells[i]);}
    }
  });
  $('dt').each((_,dt)=>add($(dt).text(),$(dt).next('dd').text()));
  $('label').each((_,label)=>{
    const forId=$(label).attr('for');
    let value='';
    if(forId){const input=$(`#${forId}`);value=input.val()||input.attr('value')||input.text();}
    if(!value){const row=$(label).closest('.row,.form-group,.mb-2,.mb-3,div');value=row.find('input,select,textarea').first().val()||row.find('strong,b,.value,.dato').first().text();}
    add($(label).text(),value);
  });
  $('[data-label],[data-title]').each((_,node)=>{
    const label=$(node).attr('data-label')||$(node).attr('data-title');
    add(label,$(node).text());
  });
  return pairs.map(({_key,...rest})=>rest).filter(m=>!/seleccion|select|volver|back/i.test(`${m.label} ${m.value}`));
}
function tablePoolsFromPage($, measurementLabel="") {
  const pools=[];
  $('table').each((tableIndex,table)=>{
    const rows=$(table).find('tr');if(rows.length<2)return;
    let headers=rows.first().find('th,td').map((_,cell)=>cleanRemoteText($(cell).text())).get();
    if(headers.length<2)return;
    rows.slice(1).each((rowIndex,row)=>{
      const cells=$(row).find('td,th').map((_,cell)=>cleanRemoteText($(cell).text())).get();
      if(cells.length<2)return;
      const first=cells[0];if(!first||/fecha|date|hora|time|parámetro|parameter/i.test(first))return;
      const metrics=[];for(let i=1;i<Math.min(headers.length,cells.length);i++){if(headers[i]&&cells[i])metrics.push({label:headers[i],value:cells[i]});}
      if(!metrics.length)return;
      const when=pickMeasurementTime(metrics,cells.join(' '));
      pools.push({name:first,measurement:measurementLabel||'',metrics,temperature:findTemperatureMetric(metrics),date:when.date,time:when.time,source:`tabla-${tableIndex+1}-${rowIndex+1}`});
    });
  });
  return pools;
}
function formRequestsFromPage(html, pageUrl) {
  const $=cheerio.load(html);const requests=[];
  $('form').each((_,form)=>{
    const $form=$(form), action=absoluteRemoteUrl($form.attr('action')||pageUrl,pageUrl)||pageUrl, method=String($form.attr('method')||'GET').toUpperCase();
    const hidden={};$form.find('input[type="hidden"][name]').each((__,input)=>{hidden[$(input).attr('name')]=String($(input).val()||'');});
    $form.find('select[name]').each((__,select)=>{
      const name=$(select).attr('name');
      $(select).find('option').each((___,option)=>{
        const value=String($(option).attr('value')??'').trim(), label=cleanRemoteText($(option).text());
        if(!value||!label||/select|seleccion|elige|choose/i.test(label))return;
        requests.push({action,method,fields:{...hidden,[name]:value},label});
      });
    });
  });
  if(!requests.length){
    $('select[name]').each((_,select)=>{
      const name=$(select).attr('name');
      $(select).find('option').each((__,option)=>{
        const value=String($(option).attr('value')??'').trim(),label=cleanRemoteText($(option).text());
        if(!value||!label||/select|seleccion|elige|choose/i.test(label))return;
        requests.push({action:pageUrl,method:'GET',fields:{[name]:value},label});
      });
    });
  }
  return requests.slice(0,30);
}
async function fetchRemotePage(url, options={}) {
  const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),18000);
  try{
    const response=await fetch(url,{redirect:'follow',signal:controller.signal,...options,headers:{
      'User-Agent':'Mozilla/5.0 (compatible; MFEViajes/2.3; +private-travel-planner)',
      'Accept':'text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8',
      'Accept-Language':'es-ES,es;q=0.9,en;q=0.5',
      ...(options.headers||{})
    }});
    if(!response.ok)throw new Error(`HTTP ${response.status}`);
    return {text:await response.text(),url:response.url||url,contentType:response.headers.get('content-type')||''};
  }finally{clearTimeout(timer);}
}
async function fetchFormRequest(req) {
  const source=new URL(POOL_SOURCE_URL),target=new URL(req.action);
  if(target.hostname===source.hostname&&!target.searchParams.has('token')&&source.searchParams.get('token'))target.searchParams.set('token',source.searchParams.get('token'));
  if(req.method==='POST'){
    const body=new URLSearchParams(req.fields).toString();
    return fetchRemotePage(target.href,{method:'POST',body,headers:{'Content-Type':'application/x-www-form-urlencoded','Referer':POOL_SOURCE_URL}});
  }
  for(const [k,v] of Object.entries(req.fields))target.searchParams.set(k,v);
  return fetchRemotePage(target.href,{headers:{'Referer':POOL_SOURCE_URL}});
}
function normalizePoolName(value,index=0){const name=cleanRemoteText(value);return name||`Piscina ${index+1}`;}
function mergePoolRecords(records=[]) {
  const merged=new Map();
  for(const [index,row] of records.entries()){
    const name=normalizePoolName(row.name,index), key=name.toLocaleLowerCase('es');
    const existing=merged.get(key)||{name,measurements:[]};
    existing.measurements.push({measurement:row.measurement||'',metrics:row.metrics||[],temperature:row.temperature,date:row.date||'',time:row.time||'',source:row.source||''});
    merged.set(key,existing);
  }
  return [...merged.values()].map(pool=>{
    const sorted=[...pool.measurements].sort((a,b)=>`${a.date} ${a.time}`.localeCompare(`${b.date} ${b.time}`));
    const latest=[...sorted].reverse().find(m=>m.temperature!==null)||sorted.at(-1)||null;
    return {...pool,latest,temperature:latest?.temperature??null};
  });
}
async function scrapePoolMeasurements() {
  const main=await fetchRemotePage(POOL_SOURCE_URL);
  const $=cheerio.load(main.text);let records=tablePoolsFromPage($,'Última medición');
  const formRequests=formRequestsFromPage(main.text,main.url);
  for(const req of formRequests){
    try{
      const page=await fetchFormRequest(req),sub=cheerio.load(page.text);
      const tableRows=tablePoolsFromPage(sub,req.label);
      if(tableRows.length){records.push(...tableRows.map(r=>({ ...r, name:r.name||req.label, measurement:req.label||r.measurement })) );continue;}
      const metrics=metricPairsFromPage(sub);
      if(metrics.length){const bodyText=cleanRemoteText(sub('body').text()),when=pickMeasurementTime(metrics,bodyText);records.push({name:req.label,measurement:'Última medición',metrics,temperature:findTemperatureMetric(metrics),date:when.date,time:when.time,source:'form'});}
    }catch(error){console.warn('Galileus option',req.label,error.message);}
  }
  if(!records.length){
    const metrics=metricPairsFromPage($),when=pickMeasurementTime(metrics,cleanRemoteText($('body').text()));
    if(metrics.length)records.push({name:'Piscinas Cordial / Perchel',measurement:'Última medición',metrics,temperature:findTemperatureMetric(metrics),date:when.date,time:when.time,source:'principal'});
  }
  const pools=mergePoolRecords(records);
  if(!pools.length)throw new Error('La fuente respondió, pero no se pudieron interpretar las mediciones.');
  return {source:'Galileus · SILOE',sourceUrl:POOL_SOURCE_URL,fetchedAt:new Date().toISOString(),pools};
}
function poolFingerprint(payload){const stable=JSON.stringify((payload.pools||[]).map(p=>({name:p.name,measurements:(p.measurements||[]).map(m=>({measurement:m.measurement,metrics:m.metrics,date:m.date,time:m.time}))})));return require('crypto').createHash('sha256').update(stable).digest('hex');}
async function storePoolSnapshot(payload) {
  const latestRef=db.doc(`travelApps/${TRAVEL_TRIP_ID}/liveData/pools`), latestSnap=await latestRef.get();
  const fingerprint=poolFingerprint(payload), previous=latestSnap.data()?.fingerprint||'';
  await latestRef.set({payload,fingerprint,fetchedAt:new Date(),sourceUrl:POOL_SOURCE_URL},{merge:true});
  if(fingerprint!==previous){await db.collection(`travelApps/${TRAVEL_TRIP_ID}/poolMeasurementHistory`).add({payload,fingerprint,fetchedAt:new Date()});}
  return {fingerprint,changed:fingerprint!==previous};
}
async function poolHistory(limit=100){
  const snap=await db.collection(`travelApps/${TRAVEL_TRIP_ID}/poolMeasurementHistory`).orderBy('fetchedAt','desc').limit(limit).get();
  return snap.docs.map(doc=>{const data=doc.data()||{};return {id:doc.id,fetchedAt:data.fetchedAt?.toDate?.().toISOString?.()||data.payload?.fetchedAt||'',pools:data.payload?.pools||[]};}).reverse();
}
async function syncPoolsNow(){const payload=await scrapePoolMeasurements();await storePoolSnapshot(payload);return payload;}
exports.getPoolMeasurements = onCall({region:REGION,timeoutSeconds:60,memory:'512MiB'},async(request)=>{
  await requireTravelUser(request,false);
  const force=request.data?.force===true,latestRef=db.doc(`travelApps/${TRAVEL_TRIP_ID}/liveData/pools`),latestSnap=await latestRef.get();
  let payload=latestSnap.data()?.payload||null;
  const fetched=latestSnap.data()?.fetchedAt?.toMillis?.()||0;
  if(force||!payload||Date.now()-fetched>20*60*1000){try{payload=await syncPoolsNow();}catch(error){if(!payload)throw new HttpsError('unavailable',`No se pudieron leer las piscinas: ${error.message}`);payload={...payload,warning:`No se pudo actualizar ahora: ${error.message}`};}}
  return {...payload,history:await poolHistory(120)};
});
exports.syncPoolMeasurements = onSchedule({region:REGION,schedule:'15 8,12,16,20 * * *',timeZone:'Atlantic/Canary',timeoutSeconds:90,memory:'512MiB'},async()=>{await syncPoolsNow();});

function webcamCandidates(html,pageUrl){
  const $=cheerio.load(html),candidates=[];
  const push=(url,mode,context='')=>{url=absoluteRemoteUrl(url,pageUrl);if(!url||!/^https?:/i.test(url))return;const lower=`${url} ${context}`.toLowerCase();if(/doubleclick|googlesyndication|google\.com\/maps|windy|windguru|facebook|instagram|twitter|analytics|cookie/.test(lower))return;let score=0;if(/\.m3u8(?:$|\?)/i.test(url)){mode='video';score+=100;}if(/\.mp4(?:$|\?)/i.test(url)){mode='video';score+=90;}if(/embed|player|stream|live|webcam|camera/.test(lower))score+=45;if(/iframe/.test(context))score+=10;if(new URL(url).hostname!==new URL(pageUrl).hostname)score+=8;candidates.push({url,mode,score});};
  $('video[src]').each((_,n)=>push($(n).attr('src'),'video','video'));
  $('video source[src],source[type*="mpegURL"][src],source[type*="video"][src]').each((_,n)=>push($(n).attr('src'),'video','video source'));
  $('iframe[src]').each((_,n)=>push($(n).attr('src'),'iframe',`iframe ${$(n).attr('id')||''} ${$(n).attr('class')||''} ${$(n).attr('title')||''}`));
  const decoded=String(html).replace(/\\u0026/g,'&').replace(/\\\//g,'/');
  for(const match of decoded.matchAll(/https?:[^"'<>\s]+?\.m3u8(?:\?[^"'<>\s]*)?/gi))push(match[0],'video','script hls');
  for(const match of decoded.matchAll(/https?:[^"'<>\s]+?(?:embed|player)[^"'<>\s]*/gi))push(match[0],'iframe','script embed player');
  const uniq=new Map();for(const c of candidates){const old=uniq.get(c.url);if(!old||c.score>old.score)uniq.set(c.url,c);}return [...uniq.values()].sort((a,b)=>b.score-a.score);
}
exports.getTravelWebcam = onCall({region:REGION,timeoutSeconds:35,memory:'256MiB'},async(request)=>{
  await requireTravelUser(request,false);const key=String(request.data?.key||'');const def=WEBCAM_PAGES[key];if(!def)throw new HttpsError('invalid-argument','Webcam no válida.');
  let page;try{page=await fetchRemotePage(def.url);}catch(error){throw new HttpsError('unavailable',`No se pudo abrir la webcam: ${error.message}`);}
  const candidates=webcamCandidates(page.text,page.url),best=candidates[0];
  if(!best)throw new HttpsError('not-found','El proveedor no expone ahora un reproductor directo compatible.');
  return {key,title:def.title,mode:best.mode,url:best.url,provider:new URL(def.url).hostname,sourcePage:def.url};
});
