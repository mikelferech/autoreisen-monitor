# MFE Viajes v2.4.57 · Gestión de usuarios

## Qué incorpora

Configuración → Usuarios y permisos (solo administradores):

- Ver usuarios con acceso al viaje, rol y último acceso cuando Firebase lo proporciona.
- Crear una cuenta con correo, nombre, contraseña inicial y rol de Viajes.
- Dar acceso a una cuenta Firebase ya existente (sin crear cuentas duplicadas).
- Editar nombre, correo y rol, manteniendo los permisos de otras MFE Apps.
- Activar/desactivar y retirar **solo** el acceso a Viajes.
- Solicitar por correo un restablecimiento de contraseña.
- Eliminar definitivamente una cuenta SOLO si no tiene accesos a otras MFE Apps.

El servidor valida que el solicitante sea administrador. Las contraseñas no se guardan en Firestore.
No se permite desactivar la propia sesión o la cuenta principal ni retirar al último administrador.

## Despliegue de la versión

`ACTUALIZAR_MFE.bat` instala el frontend y la nueva Cloud Function `manageTravelUsers`.
Para desplegar funciones Firebase debe estar habilitado en el proyecto (puede requerir plan Blaze y facturación).
Sin la función desplegada, el panel indicará error al cargar usuarios.

## IMPORTANTE: reglas de Firestore compartidas

El proyecto `presupuesto-hogar-9dead` también aloja otras aplicaciones. Por seguridad, el instalador **NO sobrescribe automáticamente** las reglas de Firestore.

Para hacer efectivo el **bloqueo de acceso a nivel de base de datos** tras desactivar un usuario o cambiar sus permisos:

1. En Firebase Console → Firestore → Reglas, copia las reglas **actuales**.
2. Fusiona cuidadosamente las funciones `travelRole()`, `hasTravelAccess()` y `canEditTravel()` incluidas en `firestore.rules` con las reglas ya publicadas. Conserva todas las demás colecciones de otras MFE Apps.
3. Publica las reglas fusionadas desde Firebase Console. Si has comprobado que el archivo `firestore.rules` del ZIP incluye TODAS las reglas publicadas y no omite nada, puedes usar `ACTIVAR_REGLAS_USUARIOS.bat`.
4. Verifica con una cuenta de solo lectura que no puede escribir en `travelApps`, y con una cuenta desactivada que no puede leer las secciones del viaje.

Hasta actualizar las reglas, **no se debe considerar garantizada** la restricción de acceso a Firestore de una cuenta previamente administradora; el panel de la web y la función segura ya respetan `travelEnabled`, pero las reglas antiguas podrían seguir autorizando lecturas.

Cambiar el correo de un usuario afectará su inicio de sesión en TODAS las aplicaciones Firebase. Por eso el panel advierte cuando utiliza otras apps. El correo principal se protege por compatibilidad con reglas existentes.

## Administradores actuales

Para abrir el panel, el perfil `mfeUsers/{uid}` del administrador debe tener `apps.travel: true` y `role: "admin"` o `travelRole: "admin"`. Desbloquea Configuración con el candado/PIN antes de editar.

## Si «Usuarios y permisos» se queda cargando

Desde v2.4.57 la lista agota la espera en 30 segundos y muestra un código de error con «Reintentar carga».
- `functions/not-found`: la función no está desplegada en este proyecto/región. Reejecutar `ACTUALIZAR_MFE.bat` y revisar la fase de Functions.
- `functions/permission-denied`: el usuario autenticado no tiene permisos de administrador según el backend. Comprobar `mfeUsers/{uid}`.
- `functions/unauthenticated`: volver a iniciar sesión.
- `functions/unavailable` o `functions/deadline-exceeded`: revisar conexión, región `europe-west1`, estado y registros de la función.
- `functions/internal`: consultar los registros de `manageTravelUsers` en Firebase Console.

No modifiques ni publiques las reglas de Firestore de las otras aplicaciones sin contrastar su contenido actual.
