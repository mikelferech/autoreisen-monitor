# MFE Viajes GC27 v2.4.57 · Desbloqueo de Usuarios y permisos

- La carga de usuarios ya no puede quedarse bloqueada en «Cargando usuarios…» indefinidamente. Si Firebase Functions no responde en 30 segundos, aparece un mensaje con el motivo y un botón Reintentar.
- **Causa corregida:** una carga fallida provocaba que `render()` llamara de nuevo a `load()` sin intervención del usuario, creando un bucle infinito. Solo se intenta una vez automáticamente; los siguientes intentos son manuales.
- El botón Actualizar se vuelve a habilitar y se recupera incluso si falla el renderizado inicial de Configuración.
- Manejo explícito de errores de autenticación, permisos, función no desplegada, caída de red y errores del backend. Se muestra el código del error para diagnosticarlo.
- Se establece un límite de espera en el SDK Firebase para la llamada de listado (30s) y para operaciones de escritura (55s).
- Conserva las funciones de usuarios, hoteles, vehículos, vuelos y seguimientos de la versión anterior. No publica Workers.

**Nota:** Sin acceso a una sesión autenticada de Firebase no puede confirmarse qué está causando la falta de respuesta del servidor en este dispositivo. La nueva versión impide el bloqueo visual y muestra el error real si persiste.
