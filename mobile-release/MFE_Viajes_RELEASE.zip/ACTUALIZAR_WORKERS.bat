@echo off
setlocal
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\update-workers.ps1"
if errorlevel 1 (
  echo.
  echo ERROR al actualizar los Workers.
  pause
  exit /b 1
)
echo.
echo Workers actualizados correctamente.
pause
