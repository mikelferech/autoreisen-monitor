@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
title GC 26 - Actualizar Worker principal 2.2.27

echo ============================================================
echo   GC 26 - WORKER PRINCIPAL 2.2.27
echo ============================================================
echo.
echo Se actualizara SOLO mfe-viajes-precios a v2.2.27.
echo El Worker Vueling no cambia.
echo.

where powershell >nul 2>&1
if errorlevel 1 (
  echo [ERROR] No encuentro PowerShell.
  goto :fail
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\update-workers.ps1"
if errorlevel 1 goto :fail

echo.
echo ============================================================
echo   OK - Worker 2.2.27 actualizado y verificado.
echo ============================================================
echo.
exit /b 0

:fail
echo.
echo [ERROR] No se pudo actualizar el Worker 2.2.27.
echo.
exit /b 1
