@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
title MFE Viajes - Workers Cloudflare v2.2.148

echo ============================================================
echo   MFE VIAJES - WORKERS CLOUDFLARE v2.2.148
echo ============================================================
echo.
echo Se actualizara SOLO:
echo   - mfe-viajes-precios  ^(Worker 2.2.24^)
echo.
echo Se conservan bindings, KV, variables y secretos remotos.
echo.

where powershell.exe >nul 2>&1
if errorlevel 1 (
  echo [ERROR] No se encuentra Windows PowerShell.
  exit /b 1
)

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\update-workers.ps1"
if errorlevel 1 (
  echo.
  echo [ERROR] No se ha podido actualizar el Worker modificado.
  exit /b 1
)

echo.
echo OK - Worker Cloudflare actualizado y verificado.
exit /b 0
