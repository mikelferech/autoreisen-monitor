# GC 27 · v2.4.60 · Alojamiento, dos estancias y reserva única

- Título **🏨 Primera estancia · Gran Canaria** encima de Cordial, manteniendo **🏨 Segunda estancia · Fuerteventura** encima de Dunas. Ambos se adaptan si se invierte el orden.
- El bloque **Reserva** reúne dos fichas interiores, una de Cordial y otra de Dunas, con sus localizadores, importes reservados, pagados y el último precio confirmado de Dunas.
- Se elimina el cuadro independiente **Reserva · Dunas Club** que estaba debajo del segundo alojamiento.
- Se conserva el orden arrastrable de Alojamiento. Si se mueve Cordial, su cabecera se mueve con él.
- Hosting únicamente; no se publican Cloud Functions ni Workers.
- Compatibilidad con Windows: BAT CRLF y scripts corregidos.
