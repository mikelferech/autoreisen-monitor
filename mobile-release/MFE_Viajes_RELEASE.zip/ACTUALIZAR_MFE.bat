@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
title MFE Viajes - Actualizacion
echo Iniciando actualizacion MFE Viajes v2.4.62 ...
echo Esta ventana permanecera abierta al terminar o si hay un error.
echo.

echo ============================================================
echo   MFE VIAJES - FOTO Y MAPA AL 50% v2.4.62
echo ============================================================
echo.

if not exist "firebase.json" (
  echo [ERROR] No encuentro firebase.json.
  echo Ejecuta este archivo desde la carpeta descomprimida de MFE Viajes.
  goto :fail
)

where node >nul 2>&1
if errorlevel 1 (
  echo [ERROR] Node.js no esta instalado o no esta en PATH.
  echo Instala Node.js y vuelve a ejecutar este archivo.
  goto :fail
)

echo [1/3] Validando la version antes de publicar...
node scripts\validate-release.mjs
if errorlevel 1 (
  echo.
  echo [ERROR] La validacion ha fallado. No se publicara nada.
  goto :fail
)
echo Comprobando compatibilidad de rutas y BAT para Windows...
node scripts\test-windows-bat.mjs
if errorlevel 1 (
  echo [ERROR] Hay un problema de rutas o formato en los scripts Windows.
  goto :fail
)
echo Validando cambios de GC27 v2.4.62 y versiones del servidor...
node scripts\test-gc27-2437.mjs
if errorlevel 1 (
  echo [ERROR] Falta alguna correccion de las dos semanas. No se publicara nada.
  goto :fail
)
echo Verificando ahora el funcionamiento de las tarjetas y seguimientos de las dos etapas...
node scripts\test-gc27-ui.mjs
if errorlevel 1 (
  echo.
  echo [ERROR] La prueba funcional ha fallado. No se publicara nada.
  goto :fail
)

echo Comprobando regresiones GC27 v2.4.62 (tiempo, coches, piscinas y mapa)...
node scripts\test-gc27-2438.mjs
if errorlevel 1 (
  echo [ERROR] Falta una de las correcciones v2.4.62. No se publicara nada.
  goto :fail
)

echo Verificando datos reales de GitHub, varias piscinas y los botones de las dos islas...
node scripts\test-gc27-2439.mjs
if errorlevel 1 (
  echo [ERROR] Falta una correccion critica v2.4.62. No se publica nada.
  goto :fail
)

echo Probando los botones de edicion, colores y consultas de las dos islas...
node scripts\test-gc27-2440.mjs
if errorlevel 1 (
  echo [ERROR] Fallan los selectores o los editores. No se publicara nada.
  goto :fail
)

echo Comprobando reparaciones de piscinas, Drive, Dunas, epark y mapa v2.4.62...
node scripts\test-gc27-2441.mjs
if errorlevel 1 (
  echo [ERROR] Alguna correccion v2.4.62 ha fallado. No se publica nada.
  goto :fail
)

node scripts\test-gc27-2443.mjs
if errorlevel 1 (
  echo [ERROR] Falla la prueba de los controles de la version 2.4.62.
  goto :fail
)

echo Verificando paridad AutoReisen, monitor Dunas y las dos lecturas de piscina...
node scripts\test-gc27-2444.mjs
if errorlevel 1 (
  echo [ERROR] Falla la prueba de version 2.4.62. No se publicara nada.
  goto :fail
)

node scripts\test-gc27-2445.mjs
if errorlevel 1 (
  echo [ERROR] Falla la validacion de Cordial, piscinas, colores y Dunas v2.4.62.
  goto :fail
)

echo Comprobando correcciones GC27 2.4.62: Dunas, Cordial, piscinas y orden Alojamiento...
node scripts\test-gc27-2447.mjs
if errorlevel 1 (
  echo [ERROR] Regresion de la version 2.4.62. No se publicara nada.
  goto :fail
)

node scripts\test-gc27-2448.mjs
if errorlevel 1 (
  echo [ERROR] No se superaron las pruebas especificas 2.4.62.
  goto :fail
)

echo Comprobando nuevas correcciones de Alojamiento, Dunas y AutoReisen...
node scripts\test-gc27-2451.mjs
if errorlevel 1 (
  echo [ERROR] Falla la verificacion de v2.4.62. No se publica nada.
  goto :fail
)

node scripts\test-gc27-2453.mjs
if errorlevel 1 (
  echo [ERROR] La reparacion del monitor Cordial no pasa las pruebas. No se publicara nada.
  goto :fail
)
node scripts\test-gc27-2452.mjs
if errorlevel 1 (
  echo [ERROR] Cordial no supera las pruebas de la version 2.4.62.
  goto :fail
)
echo Comprobando Cordial 5 adultos, Beach Club House y sincronizacion Cloudflare...
node scripts\test-gc27-2454.mjs
if errorlevel 1 (
  echo [ERROR] El monitor Cordial no contiene la correccion 2.4.62.
  goto :fail
)


node scripts\test-users-server.mjs
if errorlevel 1 (
  echo [ERROR] Fallan las pruebas del servidor de usuarios.
  goto :fail
)
node scripts\test-users-diagnostic.mjs
if errorlevel 1 (
  echo [ERROR] Fallan las pruebas de diagnóstico del backend de usuarios.
  goto :fail
)
node scripts\test-users-management.mjs
if errorlevel 1 (
  echo [ERROR] No se superaron las pruebas de seguridad de usuarios.
  goto :fail
)
echo Verificando carga segura, fin de bucles y reintento de Usuarios...
node scripts\test-users-loading.mjs
if errorlevel 1 (
  echo [ERROR] El panel de usuarios puede quedarse bloqueado. No se publicara nada.
  goto :fail
)
echo Verificando preferidos de Portada y bloques Binter/epark...
node scripts\test-gc27-2459.mjs
if errorlevel 1 (
  echo [ERROR] Fallan los bloques de Binter/epark o los preferidos. No se publicara nada.
  goto :fail
)
echo Comprobando primera/segunda estancia y ficha Reserva unificada...
node scripts\test-gc27-2460.mjs
if errorlevel 1 (
  echo [ERROR] Falla la prueba de la reserva de ambos hoteles.
  goto :fail
)
echo Comprobando PDF, mapa de Cordial y fichas de piscinas reordenables...
node scripts\test-gc27-2461.mjs
if errorlevel 1 (
  echo [ERROR] La ficha de reserva de ambos hoteles no es correcta.
  goto :fail
)
node scripts\test-postdeploy-caching.mjs
if errorlevel 1 (
  echo [ERROR] Validacion del sistema de recuperacion.
  goto :fail
)

echo Verificando foto y mapa en paralelo en ambos complejos...
node scripts\test-gc27-2462.mjs
if errorlevel 1 (
  echo [ERROR] No se cumplen las reglas de foto y mapa responsive.
  goto :fail
)

echo.
echo [2/3] Solo Firebase Hosting: no se publican Functions ni Workers.
echo Plan Spark compatible: no se necesita Blaze para esta actualizacion.
echo Los datos y reglas de otras aplicaciones no se modifican.
echo.
echo [3/3] Publicando GC27 en Firebase Hosting...
where firebase >nul 2>&1
if not errorlevel 1 (
  firebase deploy --only hosting:viajes --project presupuesto-hogar-9dead
) else (
  where npx >nul 2>&1
  if errorlevel 1 (
    echo [ERROR] No encuentro Firebase CLI ni npx.
    echo Instala Firebase CLI o Node.js y vuelve a intentarlo.
    goto :fail
  )
  echo Firebase CLI no esta instalado globalmente. Usando npx firebase-tools...
  npx --yes firebase-tools@latest deploy --only hosting:viajes --project presupuesto-hogar-9dead
)

if errorlevel 1 (
  echo.
  echo [ERROR] Firebase ha devuelto un error. Revisa el mensaje anterior.
  goto :fail
)

echo.
echo Confirmando que Firebase sirve los archivos nuevos...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\VERIFICAR_PUBLICACION.ps1" -ExpectedVersion 2.4.62 -Attempts 4
if errorlevel 1 (
  echo.
  echo [ERROR] Firebase no devuelve aun los archivos de esta version.
  echo Comprueba el sitio de Hosting o la URL que abres en el navegador.
  goto :fail
)
echo.
echo ============================================================
echo   OK - Web v2.4.62 publicada con Firebase Hosting (Spark).
echo   Cordial, Dunas, AutoReisen y Binter no se han republicado.
echo   El gestor de usuarios requiere Blaze; esta version no lo publica.
echo ============================================================
echo.
pause
exit /b 0

:fail
echo.
echo La actualizacion NO se ha completado.
echo No cierres esta ventana hasta revisar el mensaje de error.
echo.
pause
exit /b 1
