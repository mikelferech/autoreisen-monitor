# MFE Viajes GC27 v2.4.58 · Diagnóstico y tolerancia en Usuarios

- El panel continúa mostrando la lista o un error recuperable (sin bucles ni bloqueos).
- La función `manageTravelUsers` captura y clasifica los fallos de lectura del perfil y del listado Firestore, indicando la fase (`profile-read`, `list-firestore`, etc.).
- Se robusteció la lista frente a perfiles heredados cuyos campos no son cadenas de texto y frente a errores de lectura de metadatos de Firebase Authentication; esto último no elimina ni modifica cuentas.
- Firebase registra errores con código y fase, sin exponer información de otros usuarios en el mensaje de la app.
- Cuando no se puedan obtener metadatos de Authentication, se muestran los perfiles existentes con una advertencia.
- El instalador publica solamente Firebase Functions `manageTravelUsers` y Firebase Hosting `viajes`. No publica Firestore Rules ni Workers.
- Se añadió prueba de diagnóstico de backend con fallos simulados y nombres de perfil antiguos.

**Límite:** el error real de Firebase `functions/internal` todavía no se ha identificado en los logs productivos. Esta versión evita varias causas posibles y devuelve pistas fiables; no debe anunciarse como solucionado hasta comprobarlo en la aplicación publicada.
