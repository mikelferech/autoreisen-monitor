# MFE Viajes GC27 v2.4.56 · Usuarios y permisos

## Novedades
- Panel administrador en Configuración → Usuarios y permisos.
- Alta de cuentas nuevas, acceso de cuentas Firebase existentes, edición de nombre/correo/rol, desactivación/reactivación y retirada del acceso a Viajes.
- Restablecimiento de contraseña por correo, fecha de último acceso disponible y eliminación de cuentas que no usan otras aplicaciones.
- Roles específicos de Viajes: Administrador, Editor y Solo lectura, sin sobrescribir roles de las demás MFE Apps.
- Cloud Function autenticada con comprobación del rol del solicitante y protección del último administrador y de la cuenta principal.
- Vista adaptable a móvil y tablet.

## Despliegue
`ACTUALIZAR_MFE.bat` valida, instala dependencias de Functions, publica **solo** `manageTravelUsers`, publica Hosting de Viajes y verifica versión. No modifica Cloudflare ni los monitores.

**Acceso a Firestore:** las reglas se comparten con otras aplicaciones. No se publican automáticamente; consulta `SEGURIDAD_USUARIOS.md` para fusionar los cambios antes de activarlos. Hasta entonces no consideres garantizadas las restricciones de lectura/escritura a nivel de base de datos.

## Conservado
Inversión de etapas y deshacer; monitor Cordial corregido (5 adultos); tarifas de Dunas responsive; coches, vuelos, piscinas, reservas e históricos.
