@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
title MFE Viajes - Workers Cloudflare v2.2.162

echo ============================================================
echo   MFE VIAJES - WORKERS CLOUDFLARE v2.2.162
echo ============================================================
echo.
echo Se actualizaran SOLO:
echo   - mfe-viajes-precios  ^(Worker 2.2.26^)
echo   - mfe-viajes-vueling  ^(Worker 1.0.22^)
echo.
echo Se conservan bindings, KV, variables y secretos remotos.
echo.

where powershell.exe >nul 2>&1
if errorlevel 1 (
  echo [ERROR] No se encuentra Windows PowerShell.
  exit /b 1
)

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\update-workers.ps1"
if errorlevel 1 (
  echo.
  echo [ERROR] No se han podido actualizar los Workers modificados.
  exit /b 1
)

echo.
echo OK - Workers Cloudflare actualizados y verificados.
exit /b 0
